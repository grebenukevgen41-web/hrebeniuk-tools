"""Ракурс у пультах FABRIC LOOK / WOOD LOOK v2 — через атрибут сцени, а не драйвер на вузлі (2026-10-12).
Драйвер на вузлі «CFG_ANGLE» усередині шейдера міняв значення на КОЖНОМУ кадрі -> Cycles перекомпільовував усі
13 матеріалів у Rendered-вʼюпорті й не звільняв памʼять (+1.3 ГБ на перемикання кадру). Атрибут (як fabric_front)
міняється без перекомпіляції. Тепер: scene["cfg_angle"] з драйвером від Control_Rotation (ROT_Z, світ),
у групах — вузол Attribute VIEW_LAYER «cfg_angle» замість виходу CFG_ANGLE; драйвер вузла вимкнено (mute),
сам вузол лишається (скрипти читають його). Ідемпотентно."""
import bpy

ROT_OBJ = "Control_Rotation"
PROP = "cfg_angle"
GROUPS = ("FABRIC LOOK", "WOOD LOOK v2")


def ensure_scene_driver(sc):
    if PROP not in sc.keys():
        sc[PROP] = 0.0
    ad = sc.animation_data
    if ad and any(d.data_path == f'["{PROP}"]' for d in ad.drivers):
        return "exists"
    fc = sc.driver_add(f'["{PROP}"]')
    drv = fc.driver; drv.type = 'AVERAGE'
    v = drv.variables.new(); v.name = "rz"; v.type = 'TRANSFORMS'
    rot = bpy.data.objects.get(ROT_OBJ)
    v.targets[0].id = rot
    v.targets[0].transform_type = 'ROT_Z'; v.targets[0].transform_space = 'WORLD_SPACE'
    return "added" if rot else "added (NO Control_Rotation!)"


def patch_group(g):
    N, L = g.nodes, g.links
    val = N.get("CFG_ANGLE")
    if val is None:
        return "no CFG_ANGLE"
    attr = N.get("CFG_ANGLE attr")
    if attr is None:
        attr = N.new('ShaderNodeAttribute'); attr.name = attr.label = "CFG_ANGLE attr"
        attr.attribute_type = 'VIEW_LAYER'; attr.attribute_name = PROP
        attr.location = (val.location.x, val.location.y - 160)
    n = 0
    for l in list(val.outputs[0].links):
        to = l.to_socket
        L.remove(l)
        L.new(attr.outputs["Fac"], to)
        n += 1
    if g.animation_data:
        for d in g.animation_data.drivers:
            if "CFG_ANGLE" in d.data_path:
                d.mute = True
    return f"relinked {n}"


def run(scene=None):
    sc = scene or bpy.context.scene
    out = {"driver": ensure_scene_driver(sc)}
    for name in GROUPS:
        g = bpy.data.node_groups.get(name)
        out[name] = patch_group(g) if g else "missing"
    return out


if __name__ == "__main__":
    print("CFGA", run())
