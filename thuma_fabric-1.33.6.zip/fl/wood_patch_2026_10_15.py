"""Пульт дерева (WOOD LOOK v2) — правки 15.10.2026, зібрані з живої сцени v329 в одну функцію apply().
Для колег: аддон Thuma Fabric викликає apply() у пункті «Оновлення моделі» (або при оновленні пульта дерева).
Ідемпотентно: що вже є — не дублює. Нові входи ставляться НЕЙТРАЛЬНО (картинка не змінюється), значення
Євгена (ніжки тощо) — окремо, через синхронізацію налаштувань дерева.

Що робить:
 1. Атрибут вершин fz_hb на основах (меші дерева висотою 8 см): 1 + (z − zmin − верх фаски) — висота над фаскою.
 2. «Низ»: «Фаска знизу: яскравість / насиченість / відблиск / плавність» — нижня фаска основи; вигляд основи
    плавно стікає на фаску (плавність), відблиск підлоги вимикається повзунком «відблиск».
    У 5 групах рейок Finger-Joint: Principled «Specular IOR Level» = 0.5 × вихід «Фаска знизу: відблиск ×».
 3. «Загальне: уся деревина» (перший розділ): яскравість / насиченість / відтінок / тон / заливка + ракурси кадру
    Ф/Л/П/Зад Л/Зад П (як «Вся тканина» у FABRIC LOOK). Тон і заливка — Mix після HSV у всіх 10 групах
    (5 рейок + 5 торців).
УВАГА (урок 16.10): вузли в групах рейок/торців мають ФІКСОВАНІ імена wp15_* — «налаштування Євгена (дерево)»
ставлять значення за іменем вузла, а автоімена (Math.001…) у різних файлах різні -> значення лягало не в той вузол.
УВАГА (урок 15.10): нові входи групи на ІСНУЮЧИХ вузлах-екземплярах отримують 0, а не default -> ставимо явно.
"""
import bpy
import numpy as np

G = "WOOD LOOK v2"
P = "Вся деревина: "
WOOD_MAT = "Thuma_Wood_Finger-Joints_4K"
RAIL_PREFIX = "Thuma_Finger-Joint-Wood"
DOWN_LABEL = "грань дивиться вниз (фаска знизу)"


def _m(N, L, op, a, b=None, c=None, loc=(0, 0), label=""):
    n = N.new('ShaderNodeMath'); n.operation = op; n.location = loc; n.label = label
    for i, v in enumerate((a, b, c)):
        if v is None:
            continue
        if isinstance(v, (int, float)):
            n.inputs[i].default_value = v
        else:
            L.new(v, n.inputs[i])
    return n.outputs[0]


def _instances(g):
    return [n for t in bpy.data.node_groups for n in t.nodes if n.type == 'GROUP' and n.node_tree == g]


def _new_in(g, panel, name, typ, dv, mn=None, mx=None, desc=""):
    it = next((s for s in g.interface.items_tree if s.item_type == 'SOCKET' and s.in_out == 'INPUT' and s.name == name), None)
    if it is not None:
        return False
    s = g.interface.new_socket(name, in_out='INPUT', socket_type=typ)
    s.default_value = dv
    if mn is not None:
        s.min_value = mn
    if mx is not None:
        s.max_value = mx
    s.description = desc
    g.interface.move_to_parent(s, panel, len(panel.interface_items))
    for n in _instances(g):                     # явне значення на екземплярах (інакше 0)
        try:
            n.inputs[name].default_value = dv
        except Exception:
            n.inputs[name].default_value = tuple(dv)
    return True


def _new_out(g, name, typ):
    if not any(s.item_type == 'SOCKET' and s.in_out == 'OUTPUT' and s.name == name for s in g.interface.items_tree):
        g.interface.new_socket(name, in_out='OUTPUT', socket_type=typ)


# ---------------- 1. fz_hb ----------------
def _bases():
    wood = bpy.data.materials.get(WOOD_MAT)
    return {o.data for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential-")
             and round(o.dimensions.z, 3) == 0.08 and any(s.material == wood for s in o.material_slots)}


def ensure_fz_hb():
    out = {}
    for me in _bases():
        V = len(me.vertices); co = np.empty(V * 3); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        P_ = len(me.polygons); nz = np.empty(P_ * 3); me.polygons.foreach_get("normal", nz); nz = nz.reshape(-1, 3)[:, 2]
        lt = np.empty(P_, np.int32); me.polygons.foreach_get("loop_total", lt)
        lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
        pl = np.repeat(np.arange(P_), lt)
        zmin = co[:, 2].min()
        ch = np.unique(lv[np.isin(pl, np.nonzero((nz < -0.3) & (nz > -0.95))[0])])
        hc = (co[ch, 2].max() - zmin) if len(ch) else 0.004
        v = 1.0 + (co[:, 2] - zmin - hc)
        a = me.attributes.get("fz_hb") or me.attributes.new("fz_hb", 'FLOAT', 'POINT')
        a.data.foreach_set("value", v.astype(np.float32)); me.update()
        out[me.name] = round(hc * 1000, 1)
    return out


# ---------------- 2. фаска знизу ----------------
def ensure_chamfer():
    g = bpy.data.node_groups[G]
    st = "вже є" if any(n.type == 'MAP_RANGE' and n.label == DOWN_LABEL for n in g.nodes) else _chamfer_group(g)
    return {"пульт": st, "рейки": _chamfer_rails(g)}


def _chamfer_group(g):
    N, L = g.nodes, g.links
    low = next(it for it in g.interface.items_tree if it.item_type == 'PANEL' and it.name.startswith("Низ"))
    _new_in(g, low, "Фаска знизу: яскравість", 'NodeSocketFloat', 1.0, 0, 3,
            "Яскравість нижньої фаски основи (1 = без змін, менше = темніше)")
    _new_in(g, low, "Фаска знизу: насиченість", 'NodeSocketFloat', 1.0, 0, 3, "Насиченість нижньої фаски основи (1 = без змін)")
    _new_in(g, low, "Фаска знизу: відблиск", 'NodeSocketFloat', 1.0, 0, 1,
            "Відблиск підлоги на нижній фасці: 0 = нема (правка клієнта), 1 = як було")
    _new_in(g, low, "Фаска знизу: плавність", 'NodeSocketFloat', 0.5, 0, 1,
            "Вигляд основи плавно стікає на фаску: 0 = різко, 1 = на всю висоту фаски")
    _new_out(g, "Фаска знизу: відблиск ×", 'NodeSocketFloat')
    gi = next(n for n in N if n.type == 'GROUP_INPUT')
    go = next(n for n in N if n.type == 'GROUP_OUTPUT' and n.is_active_output)
    x, y = go.location.x - 1500, go.location.y - 900
    pl = gi.outputs["Фаска знизу: плавність"]
    # маска за нормаллю (згладжена нормаль), межі залежать від «плавності»
    geo = N.new('ShaderNodeNewGeometry'); geo.location = (x, y)
    sp = N.new('ShaderNodeSeparateXYZ'); sp.location = (x + 180, y); L.new(geo.outputs["Normal"], sp.inputs[0])
    ng = _m(N, L, 'MULTIPLY', sp.outputs[2], -1.0, loc=(x + 340, y))
    mr = N.new('ShaderNodeMapRange'); mr.interpolation_type = 'SMOOTHSTEP'; mr.location = (x + 500, y); mr.label = DOWN_LABEL
    L.new(ng, mr.inputs["Value"])
    L.new(_m(N, L, 'SUBTRACT', 0.40, _m(N, L, 'MULTIPLY', pl, 0.35, loc=(x + 200, y - 150)), loc=(x + 350, y - 150)), mr.inputs["From Min"])
    L.new(_m(N, L, 'ADD', 0.42, _m(N, L, 'MULTIPLY', pl, 0.30, loc=(x + 200, y - 220)), loc=(x + 350, y - 220)), mr.inputs["From Max"])
    # основа стікає на фаску: рампа за глибиною нижче верху фаски (fz_hb), нема атрибута -> 1
    at = N.new('ShaderNodeAttribute'); at.attribute_type = 'GEOMETRY'; at.attribute_name = "fz_hb"
    at.label = "висота над фаскою (fz_hb)"; at.location = (x, y - 350)
    valid = _m(N, L, 'GREATER_THAN', at.outputs["Fac"], 0.5, loc=(x + 200, y - 350))
    depth = _m(N, L, 'SUBTRACT', 1.0, at.outputs["Fac"], loc=(x + 200, y - 420))
    w = _m(N, L, 'MAXIMUM', _m(N, L, 'MULTIPLY', pl, 0.008, loc=(x + 200, y - 490)), 0.0002, loc=(x + 350, y - 490))
    sm = N.new('ShaderNodeMapRange'); sm.interpolation_type = 'SMOOTHSTEP'; sm.location = (x + 500, y - 420)
    sm.inputs["From Min"].default_value = 0.0; L.new(depth, sm.inputs["Value"]); L.new(w, sm.inputs["From Max"])
    ramp = _m(N, L, 'ADD', _m(N, L, 'MULTIPLY', valid, sm.outputs[0], loc=(x + 650, y - 350)),
              _m(N, L, 'SUBTRACT', 1.0, valid, loc=(x + 650, y - 420)), loc=(x + 800, y - 350), label="основа стікає на фаску")
    down = _m(N, L, 'MULTIPLY', mr.outputs[0], ramp, loc=(x + 950, y - 200), label="фаска знизу (з плавним переходом)")
    # яскравість: Value × (1 + down·(b − 1))
    sv = go.inputs["Value"]; src = sv.links[0].from_socket
    k = _m(N, L, 'ADD', 1.0, _m(N, L, 'MULTIPLY', down, _m(N, L, 'SUBTRACT', gi.outputs["Фаска знизу: яскравість"], 1.0,
                                                                  loc=(x + 1000, y - 50)), loc=(x + 1150, y - 50)), loc=(x + 1300, y - 50))
    L.new(_m(N, L, 'MULTIPLY', src, k, loc=(x + 1450, y), label="яскравість × фаска знизу"), sv)
    # насиченість: Saturation × (1 + down·(s − 1))
    ss_ = go.inputs["Saturation"]; srcs = ss_.links[0].from_socket
    f = _m(N, L, 'MULTIPLY_ADD', _m(N, L, 'SUBTRACT', gi.outputs["Фаска знизу: насиченість"], 1.0, loc=(x + 1000, y - 120)),
           down, 1.0, loc=(x + 1150, y - 120))
    L.new(_m(N, L, 'MULTIPLY', srcs, f, loc=(x + 1450, y - 120), label="насиченість × фаска знизу"), ss_)
    # відблиск: 1 − down·(1 − refl)
    r = _m(N, L, 'SUBTRACT', 1.0, _m(N, L, 'MULTIPLY', down, _m(N, L, 'SUBTRACT', 1.0, gi.outputs["Фаска знизу: відблиск"],
                                                                  loc=(x + 1000, y - 190)), loc=(x + 1150, y - 190)), loc=(x + 1300, y - 190),
           label="відблиск фаски ×")
    L.new(r, go.inputs["Фаска знизу: відблиск ×"])
    return "додано"


SPEC_LABEL = "відблиск × (без фаски знизу)"


def _chamfer_rails(g):
    """Рейки: Specular IOR Level = 0.5 × вихід пульта. Окремо від пульта: пульт може прийти готовим із
    «Застосувати налаштування Євгена», а рейки (групи Finger-Joint) — лише звідси."""
    done = []
    for t in bpy.data.node_groups:
        if not t.name.startswith(RAIL_PREFIX):
            continue
        wl = next((n for n in t.nodes if n.type == 'GROUP' and n.node_tree == g), None)
        pb = next((n for n in t.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if wl is None or pb is None or "Фаска знизу: відблиск ×" not in wl.outputs:
            continue
        if any(n.label == SPEC_LABEL for n in t.nodes):
            continue
        spn = t.nodes.new('ShaderNodeMath'); spn.name = "wp15_spec"; spn.operation = 'MULTIPLY'
        spn.inputs[1].default_value = 0.5
        spn.label = SPEC_LABEL; spn.location = (pb.location.x - 200, pb.location.y - 700)
        t.links.new(wl.outputs["Фаска знизу: відблиск ×"], spn.inputs[0])
        t.links.new(spn.outputs[0], pb.inputs["Specular IOR Level"])
        done.append(t.name)
    return done


# ---------------- 3. «Загальне: уся деревина» ----------------
def ensure_general():
    g = bpy.data.node_groups[G]
    st = "вже є" if any(it.item_type == 'SOCKET' and it.name == P + "яскравість" for it in g.interface.items_tree)         else _general_group(g)
    return {"пульт": st, "групи": _general_mix(g)}


def _general_group(g):
    N, L = g.nodes, g.links
    pan = g.interface.new_panel("Загальне: уся деревина (усі кадри)", default_closed=False)
    g.interface.move(pan, 0)
    _new_in(g, pan, P + "яскравість", 'NodeSocketFloat', 1.0, 0, 3, "Яскравість усього дерева цієї породи (1 = без змін)")
    _new_in(g, pan, P + "насиченість", 'NodeSocketFloat', 1.0, 0, 3, "Насиченість усього дерева (1 = без змін)")
    _new_in(g, pan, P + "відтінок", 'NodeSocketFloat', 0.5, 0, 1, "Відтінок (0.5 = без змін)")
    _new_in(g, pan, P + "колір тону", 'NodeSocketColor', (0.93, 0.87, 0.78, 1.0), desc="Колір тону")
    _new_in(g, pan, P + "сила тону", 'NodeSocketFloat', 0.0, 0, 1, "Сила тону (0 = без змін)")
    _new_in(g, pan, P + "колір заливки", 'NodeSocketColor', (0.75, 0.75, 0.75, 1.0), desc="Колір заливки")
    _new_in(g, pan, P + "сила заливки", 'NodeSocketFloat', 0.0, 0, 1, "Сила заливки (0 = без змін)")
    for k, lab in (("яскр.", "яскравість"), ("нас.", "насиченість")):
        for a, an in (("Ф", "фронт-кадри"), ("Л", "3/4, видно лівий бік"), ("П", "3/4, видно правий бік"),
                      ("Зад Л", "задні 3/4 зліва"), ("Зад П", "задні 3/4 справа")):
            _new_in(g, pan, P + f"{k} {a}", 'NodeSocketFloat', 1.0, 0, 3, f"{lab.capitalize()} лише на кадрах: {an} (1 = без змін)")
    for nm in ("Загальне: тон колір", "Загальне: тон сила", "Загальне: заливка колір", "Загальне: заливка сила"):
        _new_out(g, nm, 'NodeSocketColor' if "колір" in nm else 'NodeSocketFloat')
    gi = next(n for n in N if n.type == 'GROUP_INPUT')
    go = next(n for n in N if n.type == 'GROUP_OUTPUT' and n.is_active_output)
    ang = next(n for n in N if n.name == "CFG_ANGLE attr").outputs["Fac"]
    x, y = go.location.x - 1400, go.location.y + 900
    sn = _m(N, L, 'SINE', ang, loc=(x, y)); cs = _m(N, L, 'COSINE', ang, loc=(x, y - 60))
    mr = N.new('ShaderNodeMapRange'); mr.interpolation_type = 'SMOOTHSTEP'; mr.location = (x + 150, y)
    mr.inputs["From Min"].default_value = 0.1; mr.inputs["From Max"].default_value = 0.3
    L.new(_m(N, L, 'ABSOLUTE', sn, loc=(x + 100, y)), mr.inputs["Value"])
    AF = _m(N, L, 'SUBTRACT', 1.0, mr.outputs[0], loc=(x + 300, y), label="ракурс: Ф")
    back = _m(N, L, 'LESS_THAN', cs, 0.0, loc=(x + 150, y - 60)); front = _m(N, L, 'SUBTRACT', 1.0, back, loc=(x + 300, y - 60))
    nf = _m(N, L, 'SUBTRACT', 1.0, AF, loc=(x + 450, y))
    sl = _m(N, L, 'MULTIPLY', nf, _m(N, L, 'GREATER_THAN', sn, 0.0, loc=(x + 450, y - 120)), loc=(x + 600, y))
    sr = _m(N, L, 'MULTIPLY', nf, _m(N, L, 'LESS_THAN', sn, 0.0, loc=(x + 450, y - 180)), loc=(x + 600, y - 60))
    W = {"Ф": AF, "Л": _m(N, L, 'MULTIPLY', sl, front, loc=(x + 750, y)), "П": _m(N, L, 'MULTIPLY', sr, front, loc=(x + 750, y - 60)),
         "Зад Л": _m(N, L, 'MULTIPLY', sl, back, loc=(x + 750, y - 120)), "Зад П": _m(N, L, 'MULTIPLY', sr, back, loc=(x + 750, y - 180))}

    def amult(k, dy):
        t = None
        for i, a in enumerate(("Ф", "Л", "П", "Зад Л", "Зад П")):
            s = gi.outputs[P + f"{k} {a}"]
            t = _m(N, L, 'MULTIPLY', s, W[a], loc=(x + 900, y + dy)) if t is None else \
                _m(N, L, 'MULTIPLY_ADD', s, W[a], t, loc=(x + 1000 + i * 40, y + dy - i * 50))
        return t
    for out, base_in, k, dy in (("Value", P + "яскравість", "яскр.", -400), ("Saturation", P + "насиченість", "нас.", -700)):
        s = go.inputs[out]; src = s.links[0].from_socket
        L.new(_m(N, L, 'MULTIPLY', src, _m(N, L, 'MULTIPLY', gi.outputs[base_in], amult(k, dy), loc=(x + 1200, y + dy)),
                 loc=(x + 1350, y + dy), label=f"Загальне: {k}"), s)
    s = go.inputs["Hue"]; src = s.links[0].from_socket
    L.new(_m(N, L, 'ADD', src, _m(N, L, 'SUBTRACT', gi.outputs[P + "відтінок"], 0.5, loc=(x + 1200, y - 1000)),
             loc=(x + 1350, y - 1000), label="Загальне: відтінок"), s)
    L.new(gi.outputs[P + "колір тону"], go.inputs["Загальне: тон колір"]); L.new(gi.outputs[P + "сила тону"], go.inputs["Загальне: тон сила"])
    L.new(gi.outputs[P + "колір заливки"], go.inputs["Загальне: заливка колір"])
    L.new(gi.outputs[P + "сила заливки"], go.inputs["Загальне: заливка сила"])
    return "додано"


def _general_mix(g):
    """Тон + заливка після HSV, у який іде Value пульта — у всіх 10 групах (кожна окремо: вже є -> пропуск)."""
    done = []
    for t in bpy.data.node_groups:
        wl = next((n for n in t.nodes if n.type == 'GROUP' and n.node_tree == g), None)
        if wl is None or "Загальне: заливка сила" not in wl.outputs or any(n.label == "Загальне: заливка" for n in t.nodes):
            continue
        hsv, stack, seen = None, [l.to_node for l in wl.outputs["Value"].links], set()
        while stack and hsv is None:
            n = stack.pop(0)
            if n in seen:
                continue
            seen.add(n)
            if n.type == 'HUE_SAT':
                hsv = n; break
            for o in n.outputs:
                stack += [l.to_node for l in o.links]
        if hsv is None:
            continue
        dst = [l.to_socket for l in hsv.outputs[0].links]
        TN, TL = t.nodes, t.links; bx, by = hsv.location.x + 150, hsv.location.y - 300
        lc = TN.new('ShaderNodeRGBToBW'); lc.name = "wp15_lc"; lc.location = (bx, by); TL.new(hsv.outputs[0], lc.inputs[0])
        lt = TN.new('ShaderNodeRGBToBW'); lt.name = "wp15_lt"; lt.location = (bx, by - 80); TL.new(wl.outputs["Загальне: тон колір"], lt.inputs[0])
        mx = TN.new('ShaderNodeMath'); mx.name = "wp15_mx"; mx.operation = 'MAXIMUM'; mx.inputs[1].default_value = 0.0001; mx.location = (bx + 150, by - 80)
        TL.new(lt.outputs[0], mx.inputs[0])
        dv = TN.new('ShaderNodeMath'); dv.name = "wp15_dv"; dv.operation = 'DIVIDE'; dv.location = (bx + 300, by)
        TL.new(lc.outputs[0], dv.inputs[0]); TL.new(mx.outputs[0], dv.inputs[1])
        tn = TN.new('ShaderNodeVectorMath'); tn.name = "wp15_tn"; tn.operation = 'SCALE'; tn.location = (bx + 450, by)
        TL.new(wl.outputs["Загальне: тон колір"], tn.inputs[0]); TL.new(dv.outputs[0], tn.inputs["Scale"])
        m1 = TN.new('ShaderNodeMix'); m1.name = "wp15_tone"; m1.data_type = 'RGBA'; m1.location = (bx + 600, by + 100); m1.label = "Загальне: тон"
        TL.new(wl.outputs["Загальне: тон сила"], m1.inputs["Factor_Float" if False else 0])
        TL.new(hsv.outputs[0], m1.inputs[6]); TL.new(tn.outputs[0], m1.inputs[7])
        m2 = TN.new('ShaderNodeMix'); m2.name = "wp15_fill"; m2.data_type = 'RGBA'; m2.location = (bx + 800, by + 100); m2.label = "Загальне: заливка"
        TL.new(wl.outputs["Загальне: заливка сила"], m2.inputs[0]); TL.new(m1.outputs[2], m2.inputs[6])
        TL.new(wl.outputs["Загальне: заливка колір"], m2.inputs[7])
        for s_ in dst:
            for l_ in list(s_.links):
                TL.remove(l_)
            TL.new(m2.outputs[2], s_)
        done.append(t.name)
    return done


def todo():
    """Чого бракує (порожньо = усе вже є). Дешево — для лічильника панелі «Оновлення моделі»."""
    g = bpy.data.node_groups.get(G)
    if g is None or not bpy.data.materials.get(WOOD_MAT):
        return []
    out = []
    if not any(n.type == 'MAP_RANGE' and n.label == DOWN_LABEL for n in g.nodes):
        out.append("фаска знизу")
    if not any(it.item_type == 'SOCKET' and it.name == P + "яскравість" for it in g.interface.items_tree):
        out.append("загальне")
    for t in bpy.data.node_groups:
        if not any(n.type == 'GROUP' and n.node_tree == g for n in t.nodes):
            continue
        if t.name.startswith(RAIL_PREFIX) and not any(n.label == SPEC_LABEL for n in t.nodes):
            out.append("рейки " + t.name)
        if not any(n.label == "Загальне: заливка" for n in t.nodes):
            out.append("тон/заливка " + t.name)
    if any("fz_hb" not in me.attributes for me in _bases()):
        out.append("fz_hb")
    return out


def apply():
    """Усе разом; повертає звіт. Безпечно запускати повторно."""
    return {"fz_hb": ensure_fz_hb(), "chamfer": ensure_chamfer(), "general": ensure_general()}


if __name__ == "__main__":
    print("WOOD PATCH", apply())
