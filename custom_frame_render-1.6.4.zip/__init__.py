bl_info = {
    "name":        "Custom Frame Render",
    "author":      "Hrebeniuk Tools",
    "version":     (1, 6, 4),
    "blender":     (4, 0, 0),
    "location":    "3D Viewport › N-Panel › CFRender",
    "description": "Рендер довільних кадрів + неймінг + маски WireColor",
    "category":    "Render",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


import bpy
import os
import re
import csv
import io
import time
import urllib.request
from bpy.props import (StringProperty, EnumProperty, IntProperty,
                       BoolProperty, PointerProperty, CollectionProperty)
from bpy.types import Panel, Operator, PropertyGroup, UIList

# ─────────────────────────────────────────────────────────────────────────────
#  GLOBALS
# ─────────────────────────────────────────────────────────────────────────────

_queue           = []
_total           = 0
_done_count      = 0
_orig_frame      = 0
_orig_output     = ''
_session_output  = ''   # filepath після застосування custom output
_orig_fstart     = 1
_orig_fend       = 1
_orig_fstep      = 1
_conflict_action    = 'VERSION'
_is_rendering       = False
_beauty_target_path = ''
_next_render_at     = 0.0
_render_in_progress = False   # True тільки між _start_one_frame і render_complete
_frame_start_time   = 0.0
_session_start_time = 0.0
_frame_times        = []      # час рендеру кожного завершеного кадру (для ETA)


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _parse_frames(text):
    frames = set()
    for part in text.replace(' ', '').split(','):
        if not part:
            continue
        if '-' in part:
            a, _, b = part.partition('-')
            try:
                frames.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        else:
            try:
                frames.add(int(part))
            except ValueError:
                pass
    return sorted(frames)


def _wirecolor_ok():
    return (hasattr(bpy.ops, 'wirecolor') and
            hasattr(bpy.ops.wirecolor, 'render_obj_mask') and
            hasattr(bpy.ops.wirecolor, 'render_mat_mask'))


def _apply_output(scene, props):
    orig = scene.render.filepath
    if props.use_custom_output and props.output_path:
        scene.render.filepath = props.output_path
    return orig


def _restore_output(scene, orig):
    scene.render.filepath = orig


def _get_render_ext(scene):
    return {
        'PNG': '.png', 'JPEG': '.jpg', 'JPEG2000': '.jp2',
        'OPEN_EXR': '.exr', 'OPEN_EXR_MULTILAYER': '.exr',
        'TIFF': '.tif', 'BMP': '.bmp', 'HDR': '.hdr',
    }.get(scene.render.image_settings.file_format, '.png')


def _get_output_dir(props, scene):
    if props.use_custom_output and props.output_path:
        return bpy.path.abspath(props.output_path)
    fp = bpy.path.abspath(scene.render.filepath)
    return os.path.dirname(fp) or bpy.path.abspath('//')


def _get_frame_name(props, frame):
    if not props.use_name_map:
        return None
    for e in props.name_map:
        if e.frame == frame:
            n = e.name.strip()
            return n or None
    return None


def _versioned_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    for i in range(1, 100):
        p = f"{base}_V{i:02d}{ext}"
        if not os.path.exists(p):
            return p
    return path


def _build_beauty_path(props, scene, frame):
    name = _get_frame_name(props, frame)
    if not name:
        return None
    return os.path.join(_get_output_dir(props, scene), name + _get_render_ext(scene))


def _check_conflicts(props, scene, queue):
    if not props.use_name_map:
        return []
    seen, conflicts = set(), []
    for frame, task in queue:
        if task != 'BEAUTY':
            continue
        path = _build_beauty_path(props, scene, frame)
        if path and os.path.exists(path) and path not in seen:
            conflicts.append(path)
            seen.add(path)
    return conflicts


def _sheets_to_csv_url(url):
    m = re.search(r'/spreadsheets/d/([a-zA-Z0-9_-]+)', url)
    if not m:
        return None
    sheet_id = m.group(1)
    gid_m = re.search(r'[#&?]gid=(\d+)', url)
    gid   = gid_m.group(1) if gid_m else '0'
    return f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"


def _fetch_sheets_entries(url):
    csv_url = _sheets_to_csv_url(url)
    if not csv_url:
        raise ValueError("Не вдалося розпізнати URL Google Sheets")
    req = urllib.request.Request(csv_url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        content = resp.read().decode('utf-8')
    entries = []
    for row in csv.reader(io.StringIO(content)):
        if len(row) < 2:
            continue
        try:
            frame = int(row[0].strip())
            name  = row[1].strip()
            if name:
                entries.append((frame, name))
        except ValueError:
            continue
    return entries


# ─────────────────────────────────────────────────────────────────────────────
#  RENDER ENGINE  (timer + handler chain, no modal)
# ─────────────────────────────────────────────────────────────────────────────

def _fmt_time(seconds):
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    return f"{s // 60}m {s % 60:02d}s"

def _set_status(text):
    try:
        bpy.context.scene.cfrender_props.render_status = text
    except Exception:
        pass


def _cleanup(scene=None):
    global _is_rendering
    _is_rendering = False
    s = scene or (bpy.context.scene if bpy.context else None)
    if s:
        s.frame_set(_orig_frame)
        _restore_output(s, _orig_output)
        s.frame_start = _orig_fstart
        s.frame_end   = _orig_fend
        s.frame_step  = _orig_fstep
    try:
        p = s.cfrender_props if s else bpy.context.scene.cfrender_props
        p.is_rendering  = False
    except Exception:
        pass


def _start_one_frame(scene, frame, task):
    """Стартує рендер одного кадру або маску."""
    global _done_count, _beauty_target_path, _frame_start_time, _render_in_progress

    _done_count += 1
    _frame_start_time = time.time()
    scene.frame_set(frame)
    label = {"BEAUTY": "Beauty", "OBJ": "Obj Mask", "FACE": "Face Mask", "MAT": "Mat Mask"}[task]
    elapsed = _fmt_time(time.time() - _session_start_time)
    if _frame_times:
        avg = sum(_frame_times) / len(_frame_times)
        eta = _fmt_time(avg * (len(_queue) + 1))
        _set_status(f"{label}  fr.{frame}  ({_done_count}/{_total})  elapsed {elapsed}  ~{eta} left")
    else:
        _set_status(f"{label}  fr.{frame}  ({_done_count}/{_total})  elapsed {elapsed}")

    props = scene.cfrender_props

    if task == 'BEAUTY':
        target = _build_beauty_path(props, scene, frame)
        if not target:
            if props.use_name_map:
                # кадр без імені в таблиці — пропускаємо
                _done_count -= 1
                return
            out_dir = _get_output_dir(props, scene)
            ext    = _get_render_ext(scene)
            target = os.path.join(out_dir, f"{frame:04d}{ext}")
        if _conflict_action == 'VERSION':
            target = _versioned_path(target)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        _beauty_target_path = target
        _render_in_progress = True   # ← позначаємо що НАШІ рендер стартував

        # INVOKE_DEFAULT без animation — просто рендер у вікно, без запису
        # render_complete зробить save_render вручну
        win = bpy.context.window_manager.windows[0]
        with bpy.context.temp_override(window=win):
            bpy.ops.render.render('INVOKE_DEFAULT')

    else:
        if props.use_name_map:
            name = _get_frame_name(props, frame)
            if name:
                ext = _get_render_ext(scene)
                scene.render.filepath = os.path.join(
                    _get_output_dir(props, scene), name + ext)
        orig_compress = scene.render.image_settings.compression
        scene.render.image_settings.compression = 0
        if task == 'OBJ' and _wirecolor_ok():
            bpy.ops.wirecolor.render_obj_mask()
        elif task == 'FACE' and _wirecolor_ok():
            bpy.ops.wirecolor.render_face_mask()
        elif task == 'MAT' and _wirecolor_ok():
            bpy.ops.wirecolor.render_mat_mask()
        scene.render.image_settings.compression = orig_compress
        scene.render.filepath = _session_output


def _do_render_step():
    """Перший тік таймера — стартує першу задачу."""
    if not _is_rendering or not _queue:
        _cleanup()
        return None
    scene = bpy.context.scene
    if not scene:
        return None
    frame, task = _queue.pop(0)
    try:
        _start_one_frame(scene, frame, task)
    except Exception as e:
        print(f"CFRender _start_one_frame error: {e}")
    if task != 'BEAUTY':
        if _queue:
            return 0.05   # наступна маска
        # Остання задача була маска — cleanup тут (render_complete не прийде)
        elapsed = _fmt_time(time.time() - _session_start_time)
        _set_status(f"Done  {_done_count}/{_total}  total {_fmt_time(elapsed)}")
        _cleanup(scene)
        return None
    return None       # beauty — далі веде _poll_render + render_complete


def _poll_render():
    """Крутиться постійно. Чекає 0.5с після render_complete → стартує наступний кадр."""
    global _next_render_at

    if not _is_rendering:
        return None

    if _next_render_at > 0 and time.time() >= _next_render_at:
        _next_render_at = 0.0
        scene = bpy.context.scene
        if not scene or not _queue:
            _cleanup(scene)
            return None
        frame, task = _queue.pop(0)
        _start_one_frame(scene, frame, task)
        if task != 'BEAUTY':
            # Маска синхронна — одразу плануємо наступну або cleanup
            if _queue:
                _next_render_at = time.time() + 0.05
            else:
                elapsed = _fmt_time(time.time() - _session_start_time)
                _set_status(f"Done  {_done_count}/{_total}  total {_fmt_time(elapsed)}")
                _cleanup(scene)
                return None

    return 0.1   # поллимо кожні 100мс


@bpy.app.handlers.persistent
def _cfrender_complete(scene, depsgraph=None):
    """render_complete → зберігаємо через save_render → ставимо час наступного старту."""
    global _beauty_target_path, _next_render_at, _render_in_progress

    if not _is_rendering:
        return
    if not _render_in_progress:
        # Стала подія render_complete (напр. від попереднього F12) — ігноруємо
        return
    _render_in_progress = False

    # Зберігаємо через Image API (бо рендерили без write_still)
    if _beauty_target_path:
        img = bpy.data.images.get('Render Result')
        if img:
            try:
                img.save_render(_beauty_target_path, scene=scene)
            except Exception as e:
                print(f"CFRender save: {e}")
        _beauty_target_path = ''

    # Збираємо статистику
    ft = time.time() - _frame_start_time
    _frame_times.append(ft)
    elapsed  = time.time() - _session_start_time
    remaining = len(_queue)

    if not _queue:
        _set_status(
            f"Done  {_done_count}/{_total}  "
            f"last {_fmt_time(ft)}  total {_fmt_time(elapsed)}"
        )
        _cleanup(scene)
        return

    avg = sum(_frame_times) / len(_frame_times)
    eta = avg * remaining
    _set_status(
        f"({_done_count}/{_total})  "
        f"frame {_fmt_time(ft)}  "
        f"elapsed {_fmt_time(elapsed)}  "
        f"~{_fmt_time(eta)} left"
    )
    _next_render_at = time.time() + 0.5


@bpy.app.handlers.persistent
def _cfrender_cancel(scene, depsgraph=None):
    """ESC — зупиняємо чергу."""
    global _queue, _is_rendering, _next_render_at
    if not _is_rendering:
        return
    _queue.clear()
    _is_rendering   = False
    _next_render_at = 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

class CFRenderNameEntry(PropertyGroup):
    frame: IntProperty(description="Номер кадру", name="Frame", default=1, min=0)
    name:  StringProperty(name="Name", default="")


class CFRenderPreset(PropertyGroup):
    frames: StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Frames", default="1")


def _preset_index_update(self, context):
    idx = self.preset_index
    if self.presets and idx < len(self.presets):
        p = self.presets[idx]
        self.preset_name   = p.name
        self.preset_frames = p.frames


def _nm_index_update(self, context):
    idx = self.name_map_index
    if self.name_map and idx < len(self.name_map):
        e = self.name_map[idx]
        self.new_nm_frame = e.frame
        self.new_nm_name  = e.name


class CFRenderProps(PropertyGroup):
    beauty_frames: StringProperty(name="Beauty Frames", default="1",
                                  description="Кадри: '1, 5, 10-20, 50'")
    mask_frames:   StringProperty(name="Mask Frames",   default="1",
                                  description="Кадри для масок: '1, 5, 10-20, 50'")
    mask_type: EnumProperty(description="Які маски рендерити: по об'єктах, по полігонах (Face) чи по матеріалах", name="Type", default='BOTH', items=[
        ('OBJ',  "Object",   "Тільки object mask"),
        ('FACE', "Face",     "Тільки face mask"),
        ('MAT',  "Material", "Тільки material mask"),
        ('BOTH', "Obj+Face", "Object + Face маски"),
        ('ALL',  "All 3",    "Object + Face + Material маски"),
    ])
    presets_expanded: BoolProperty(description="Показати / сховати пресети кадрів", default=False)
    use_custom_output: BoolProperty(description="Зберігати рендери у свою папку замість шляху з Output Properties", name="Custom Output", default=False)
    output_path:       StringProperty(description="Папка для рендерів", name="Output", default="", subtype='DIR_PATH')
    sheets_url:        StringProperty(name="Sheets URL", default="",
                                      description="Посилання на Google Sheets (Anyone with link)")
    use_name_map:   BoolProperty(description="Називати файли за таблицею «кадр → ім'я» (кадри без імені пропускаються)", name="Name Map", default=False)
    name_map:       CollectionProperty(type=CFRenderNameEntry)
    name_map_index: IntProperty(default=0, min=0, update=_nm_index_update)
    new_nm_frame:   IntProperty(description="Кадр для нового запису", name="Frame", default=1, min=0)
    new_nm_name:    StringProperty(description="Ім'я файлу для цього кадру (без розширення)", name="Name", default="")
    is_rendering:   BoolProperty(default=False)
    render_status:  StringProperty(default="")
    presets:        CollectionProperty(type=CFRenderPreset)
    preset_index:   IntProperty(default=0, min=0, update=_preset_index_update)
    preset_name:    StringProperty(description="Назва пресета", name="Name",   default="")
    preset_frames:  StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Frames", default="")


# ─────────────────────────────────────────────────────────────────────────────
#  UILISTS
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_UL_presets(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.38)
        split.label(text=item.name)
        split.label(text=item.frames)


class CFRENDER_UL_namemap(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.22)
        split.label(text=str(item.frame))
        split.label(text=item.name)


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Presets
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_preset_save(Operator):
    bl_idname = "cfrender.preset_save"
    bl_description = "Зберегти пресет: назва + список кадрів (якщо така назва є — оновиться)"
    bl_label  = "Save Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props  = context.scene.cfrender_props
        name   = props.preset_name.strip()
        frames = props.preset_frames.strip()
        if not name:
            self.report({'WARNING'}, "Введи назву"); return {'CANCELLED'}
        if not frames:
            self.report({'WARNING'}, "Введи кадри");  return {'CANCELLED'}
        idx = props.preset_index
        if props.presets and idx < len(props.presets) and props.presets[idx].name == name:
            props.presets[idx].frames = frames
        else:
            existing = next((p for p in props.presets if p.name == name), None)
            if existing:
                existing.frames = frames
            else:
                p = props.presets.add()
                p.name = name; p.frames = frames
                props.preset_index = len(props.presets) - 1
        self.report({'INFO'}, f"Збережено: {name}")
        return {'FINISHED'}


class CFRENDER_OT_preset_remove(Operator):
    bl_idname = "cfrender.preset_remove"
    bl_description = "Видалити вибраний пресет"
    bl_label  = "Remove Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets): return {'CANCELLED'}
        props.presets.remove(idx)
        props.preset_index = max(0, idx - 1)
        return {'FINISHED'}


class CFRENDER_OT_preset_apply(Operator):
    bl_idname = "cfrender.preset_apply"
    bl_description = "Підставити кадри з пресета в поле Frames"
    bl_label  = "Apply Preset"
    bl_options = {'REGISTER'}
    target: EnumProperty(items=[('BEAUTY',"Beauty",""),('MASK',"Mask","")], default='BEAUTY')

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets):
            self.report({'WARNING'}, "Виділи пресет"); return {'CANCELLED'}
        frames = props.presets[idx].frames
        if self.target == 'BEAUTY': props.beauty_frames = frames
        else:                       props.mask_frames   = frames
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Name Map
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_import_sheets(Operator):
    bl_idname  = "cfrender.import_sheets"
    bl_description = "Завантажити таблицю «кадр → ім'я» з Google Sheets (доступ: Anyone with link)"
    bl_label   = "Import from Google Sheets"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        url   = props.sheets_url.strip()
        if not url:
            self.report({'ERROR'}, "Введи URL"); return {'CANCELLED'}
        try:
            entries = _fetch_sheets_entries(url)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        if not entries:
            self.report({'WARNING'}, "Таблиця порожня або формат не розпізнано")
            return {'CANCELLED'}
        props.name_map.clear()
        for frame, name in entries:
            e = props.name_map.add()
            e.frame = frame; e.name = name
        props.name_map_index = 0
        self.report({'INFO'}, f"Імпортовано {len(entries)} записів")
        return {'FINISHED'}


class CFRENDER_OT_nm_add(Operator):
    bl_idname  = "cfrender.nm_add"
    bl_description = "Додати запис «кадр → ім'я» (якщо кадр вже є — оновить ім'я)"
    bl_label   = "Add / Update Name"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        frame = props.new_nm_frame
        name  = props.new_nm_name.strip()
        if not name:
            self.report({'WARNING'}, "Введи ім'я"); return {'CANCELLED'}
        existing = next((e for e in props.name_map if e.frame == frame), None)
        if existing:
            existing.name = name
        else:
            e = props.name_map.add()
            e.frame = frame; e.name = name
            props.name_map_index = len(props.name_map) - 1
        return {'FINISHED'}


class CFRENDER_OT_nm_remove(Operator):
    bl_idname  = "cfrender.nm_remove"
    bl_description = "Видалити вибраний запис з таблиці імен"
    bl_label   = "Remove Entry"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.name_map_index
        if not props.name_map or idx >= len(props.name_map): return {'CANCELLED'}
        props.name_map.remove(idx)
        props.name_map_index = max(0, idx - 1)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Render
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_render(Operator):
    bl_idname  = "cfrender.render"
    bl_description = "Рендер вказаних кадрів по черзі, кожен зберігається файлом (Esc — зупинити)"
    bl_label   = "Render"
    bl_options = {'REGISTER'}

    mode: EnumProperty(
        items=[('BEAUTY',"Beauty",""),('MASKS',"Masks",""),('ALL',"All","")],
        default='BEAUTY',
    )
    conflict_action: EnumProperty(
        name="Action",
        items=[
            ('VERSION', "Add Version  (_V01, _V02 ...)", ""),
            ('REPLACE', "Replace existing files",        ""),
        ],
        default='VERSION',
    )
    _conflict_list = []

    def draw(self, context):
        layout = self.layout
        cls = self.__class__
        layout.label(text=f"{len(cls._conflict_list)} file(s) already exist:", icon='ERROR')
        box = layout.box()
        col = box.column(align=True)
        for p in cls._conflict_list[:7]:
            col.label(text=os.path.basename(p))
        if len(cls._conflict_list) > 7:
            col.label(text=f"... and {len(cls._conflict_list)-7} more")
        layout.separator(factor=0.5)
        layout.prop(self, "conflict_action", expand=True)

    def _start(self, context):
        global _is_rendering, _orig_frame, _orig_output, _session_output, _total, _done_count
        global _orig_fstart, _orig_fend, _orig_fstep, _session_start_time, _next_render_at, _frame_times, _render_in_progress

        if _is_rendering:
            self.report({'WARNING'}, "Рендер вже запущено")
            return {'CANCELLED'}

        props = context.scene.cfrender_props
        sc = context.scene
        _is_rendering   = True
        _orig_frame     = sc.frame_current
        _orig_fstart    = sc.frame_start
        _orig_fend      = sc.frame_end
        _orig_fstep     = sc.frame_step
        _orig_output    = _apply_output(sc, props)
        _session_output = sc.render.filepath
        _total              = len(_queue)
        _done_count         = 0
        _session_start_time = time.time()
        _next_render_at     = 0.0
        _frame_times        = []
        _render_in_progress = False

        props.is_rendering  = True
        props.render_status = f"Starting... (0/{_total})"

        bpy.app.timers.register(_do_render_step, first_interval=0.1)
        if not bpy.app.timers.is_registered(_poll_render):
            bpy.app.timers.register(_poll_render, first_interval=0.2)
        return {'FINISHED'}

    def invoke(self, context, event):
        global _queue

        if _is_rendering:
            self.report({'WARNING'}, "Рендер вже запущено")
            return {'CANCELLED'}

        props  = context.scene.cfrender_props
        _queue = []

        if self.mode in ('BEAUTY', 'ALL'):
            for f in _parse_frames(props.beauty_frames):
                if props.use_name_map and not _get_frame_name(props, f):
                    continue   # немає імені в таблиці — пропускаємо
                _queue.append((f, 'BEAUTY'))

        if self.mode in ('MASKS', 'ALL'):
            if _wirecolor_ok():
                mtype = props.mask_type
                for f in _parse_frames(props.mask_frames):
                    if props.use_name_map and not _get_frame_name(props, f):
                        continue   # немає імені в таблиці — пропускаємо маску теж
                    if mtype in ('OBJ',  'BOTH', 'ALL'): _queue.append((f, 'OBJ'))
                    if mtype in ('FACE', 'BOTH', 'ALL'): _queue.append((f, 'FACE'))
                    if mtype in ('MAT',           'ALL'): _queue.append((f, 'MAT'))
            elif self.mode == 'MASKS':
                self.report({'ERROR'}, "WireColor Masks addon не встановлено")
                return {'CANCELLED'}

        if not _queue:
            self.report({'ERROR'}, "Немає кадрів для рендеру")
            return {'CANCELLED'}

        conflicts = _check_conflicts(props, context.scene, _queue)
        if conflicts:
            self.__class__._conflict_list = conflicts
            return context.window_manager.invoke_props_dialog(self, width=400)

        return self._start(context)

    def execute(self, context):
        global _conflict_action
        _conflict_action = self.conflict_action
        return self._start(context)


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Stop
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_clear_status(Operator):
    bl_idname      = "cfrender.clear_status"
    bl_label       = "Clear Status"
    bl_description = "Прибрати рядок статусу (і скинути стан рендеру якщо завис)"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        global _is_rendering
        _is_rendering = False
        props = context.scene.cfrender_props
        props.render_status = ""
        props.is_rendering  = False
        return {'FINISHED'}


class CFRENDER_OT_stop(Operator):
    bl_idname      = "cfrender.stop"
    bl_label       = "Stop Render"
    bl_description = "Зупинити чергу рендеру"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        global _queue, _is_rendering
        _queue.clear()
        _is_rendering = False
        try:
            bpy.ops.render.view_cancel()
        except Exception:
            pass
        _cleanup()
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_PT_panel(Panel):
    bl_label       = "Custom Frame Render"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "CFRender"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.cfrender_props

        row = layout.row()
        row.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

        # ── STATUS / STOP ─────────────────────────────────────
        if props.is_rendering or props.render_status:
            box = layout.box()
            row = box.row(align=True)
            row.alert = props.is_rendering
            row.label(text=props.render_status, icon='RENDER_STILL')
            if props.is_rendering:
                row.operator("cfrender.stop", text="", icon='CANCEL')
            row.operator("cfrender.clear_status", text="", icon='X')
            layout.separator(factor=0.3)

        # ── NAME MAP ──────────────────────────────────────────
        box = layout.box()
        box.prop(props, "use_name_map", text="Name Map")
        if props.use_name_map:
            row = box.row(align=True)
            row.prop(props, "sheets_url", text="")
            row.operator("cfrender.import_sheets", text="", icon='URL')
            box.template_list("CFRENDER_UL_namemap", "",
                              props, "name_map", props, "name_map_index", rows=4)
            col = box.column(align=True)
            row = col.row(align=True)
            row.prop(props, "new_nm_frame", text="Fr")
            row.prop(props, "new_nm_name",  text="Name")
            row2 = col.row(align=True)
            row2.operator("cfrender.nm_add",    text="Save",   icon='FILE_TICK')
            row2.operator("cfrender.nm_remove", text="Remove", icon='TRASH')

        layout.separator(factor=0.3)

        # ── PRESETS ───────────────────────────────────────────
        box = layout.box()
        row = box.row()
        row.prop(props, "presets_expanded",
                 icon='TRIA_DOWN' if props.presets_expanded else 'TRIA_RIGHT',
                 icon_only=True, emboss=False)
        row.label(text="Frame Presets", icon='PRESET')
        if props.presets_expanded:
            box.template_list("CFRENDER_UL_presets", "",
                              props, "presets", props, "preset_index", rows=3)
            col = box.column(align=True)
            col.prop(props, "preset_name",   text="Name")
            col.prop(props, "preset_frames", text="Frames")
            row = col.row(align=True)
            row.operator("cfrender.preset_save",   text="Save", icon='FILE_TICK')
            row.operator("cfrender.preset_remove", text="",     icon='TRASH')
            row = col.row(align=True)
            op = row.operator("cfrender.preset_apply", text="→ Beauty", icon='RENDER_STILL')
            op.target = 'BEAUTY'
            op = row.operator("cfrender.preset_apply", text="→ Mask",   icon='IMAGE_DATA')
            op.target = 'MASK'

        layout.separator(factor=0.3)

        # ── OUTPUT ────────────────────────────────────────────
        box = layout.box()
        box.prop(props, "use_custom_output")
        if props.use_custom_output:
            box.prop(props, "output_path", text="")

        layout.separator(factor=0.3)

        # ── BEAUTY ────────────────────────────────────────────
        box = layout.box()
        box.label(text="Beauty", icon='RENDER_STILL')
        box.prop(props, "beauty_frames", text="Frames")
        op = box.operator("cfrender.render", icon='RENDER_STILL')
        op.mode = 'BEAUTY'

        # ── MASKS ─────────────────────────────────────────────
        box = layout.box()
        wc_ok = _wirecolor_ok()
        row = box.row()
        row.label(text="WireColor Masks", icon='IMAGE_DATA')
        if not wc_ok:
            row.label(text="not found", icon='ERROR')
        box.prop(props, "mask_frames", text="Frames")
        box.prop(props, "mask_type",   text="")
        sub = box.row()
        sub.enabled = wc_ok
        op = sub.operator("cfrender.render", icon='IMAGE_DATA')
        op.mode = 'MASKS'



# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    CFRenderNameEntry,
    CFRenderPreset,
    CFRenderProps,
    CFRENDER_UL_presets,
    CFRENDER_UL_namemap,
    CFRENDER_OT_preset_save,
    CFRENDER_OT_preset_remove,
    CFRENDER_OT_preset_apply,
    CFRENDER_OT_import_sheets,
    CFRENDER_OT_nm_add,
    CFRENDER_OT_nm_remove,
    CFRENDER_OT_render,
    CFRENDER_OT_clear_status,
    CFRENDER_OT_stop,
    CFRENDER_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cfrender_props = PointerProperty(type=CFRenderProps)
    if _cfrender_complete not in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.append(_cfrender_complete)
    if _cfrender_cancel not in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.append(_cfrender_cancel)


def unregister():
    if _cfrender_complete in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(_cfrender_complete)
    if _cfrender_cancel in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(_cfrender_cancel)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.cfrender_props


if __name__ == "__main__":
    register()
