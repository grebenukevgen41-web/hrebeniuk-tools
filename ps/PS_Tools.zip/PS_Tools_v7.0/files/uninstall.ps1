﻿# PS Tools (Hrebeniuk) — видалення
param([switch]$PluginOnly, [string]$Targets = '')
$PluginId = 'com.hrebeniuk.pstools'

if ($PluginOnly) {
    foreach ($t in ($Targets -split '\|')) { if ($t) { Remove-Item (Join-Path $t $PluginId) -Recurse -Force -ErrorAction SilentlyContinue } }
    exit 0
}

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Write-Host ''
Write-Host '=== PS Tools (Hrebeniuk) — видалення ===' -ForegroundColor Cyan
Write-Host ''

$targets = @()
foreach ($d in Get-ChildItem 'C:\Program Files\Adobe' -Directory -Filter 'Adobe Photoshop*' -ErrorAction SilentlyContinue) {
    $pi = Join-Path $d.FullName "Plug-ins\$PluginId"
    if (Test-Path $pi) { $targets += (Join-Path $d.FullName 'Plug-ins') }
}
if ($targets) {
    Write-Host 'Панель у Photoshop: Windows попросить дозвіл — натисни «Так».' -ForegroundColor Yellow
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if ($isAdmin) { & $MyInvocation.MyCommand.Path -PluginOnly -Targets ($targets -join '|') }
    else {
        $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $MyInvocation.MyCommand.Path + '"'), '-PluginOnly', '-Targets', ('"' + ($targets -join '|') + '"'))
        try { Start-Process powershell.exe -ArgumentList $a -Verb RunAs -Wait -WindowStyle Hidden } catch {}
    }
}
Get-Process 'PS Batch Export v5' -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item (Join-Path $env:APPDATA 'HrebeniukTools') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:APPDATA 'PSBatchExportV5') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Classes\pstools' -Recurse -Force -ErrorAction SilentlyContinue

$left = @()
foreach ($t in $targets) { if (Test-Path (Join-Path $t $PluginId)) { $left += $t } }
if (Test-Path (Join-Path $env:APPDATA 'HrebeniukTools')) { $left += 'HrebeniukTools' }
if ($left) { Write-Host ('Не вдалося видалити: ' + ($left -join ', ')) -ForegroundColor Red; exit 2 }
Write-Host 'Видалено. Перезапусти Photoshop.' -ForegroundColor Green
exit 0
