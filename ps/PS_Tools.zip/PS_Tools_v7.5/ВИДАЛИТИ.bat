@echo off
chcp 65001 >nul
title PS Tools - uninstall
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\uninstall.ps1"
echo.
pause
