/* PS Tools — рамка панелі.
   Сама панель (кнопки + код) лежить у ui/: вбудована копія тут, оновлена — у папці даних панелі
   (туди можна писати без прав адміністратора). Береться новіша з двох; якщо оновлена не запустилась —
   вбудована. Тому кнопка «Оновити» оновлює і скрипти, і панель, без ВСТАНОВИТИ.bat. */
'use strict';
(async function () {
  var uxp = require('uxp'), lfs = uxp.storage.localFileSystem;
  var SHELL_VERSION = '7.0';
  var logLines = [];
  function log(m) { logLines.push(new Date().toISOString() + ' ' + m); }
  function verGt(a, b) {
    var x = String(a).split('.'), y = String(b).split('.');
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = parseInt(x[i] || '0', 10), q = parseInt(y[i] || '0', 10);
      if (p !== q) return p > q;
    }
    return false;
  }
  async function readText(folder, name) {
    try { var f = await folder.getEntry(name); return String(await f.read()); } catch (e) { return null; }
  }
  var data = await lfs.getDataFolder();
  async function writeLog() {
    try { var f = await data.createFile('loader_log.txt', { overwrite: true }); await f.write(logLines.join('\n')); } catch (e) {}
  }

  var plug = await lfs.getPluginFolder();
  var sources = [];
  try { var b = await plug.getEntry('ui'); sources.push({ dir: b, kind: 'bundled', ver: ((await readText(b, 'ui_version.txt')) || '0').trim() }); } catch (e) { log('no bundled ui: ' + e); }
  try { var d = await data.getEntry('ui'); sources.push({ dir: d, kind: 'downloaded', ver: ((await readText(d, 'ui_version.txt')) || '0').trim() }); } catch (e) {}
  sources.sort(function (s1, s2) { return verGt(s1.ver, s2.ver) ? -1 : (verGt(s2.ver, s1.ver) ? 1 : (s1.kind === 'bundled' ? -1 : 1)); });

  var app = document.getElementById('app');
  for (var i = 0; i < sources.length; i++) {
    var s = sources[i];
    try {
      var html = await readText(s.dir, 'ui.html'), js = await readText(s.dir, 'ui.js');
      if (!html || !js) throw new Error('ui.html / ui.js не знайдено');
      app.innerHTML = html;
      window.__PST = { shellVersion: SHELL_VERSION, uiVersion: s.ver, uiSource: s.kind,
                       bundledVersion: (sources.filter(function (x) { return x.kind === 'bundled'; })[0] || {}).ver || '0' };
      new Function('require', js)(require);
      log('loaded ui ' + s.ver + ' (' + s.kind + ')');
      await writeLog();
      return;
    } catch (e) {
      log('ui ' + s.ver + ' (' + s.kind + ') failed: ' + (e && e.stack || e));
    }
  }
  app.innerHTML = '<div style="color:#ef5350;font-size:11px;padding:6px;">PS Tools: панель не завантажилась. ' +
                  'Перевстанови пакет (ВСТАНОВИТИ.bat).</div>';
  await writeLog();
})();
