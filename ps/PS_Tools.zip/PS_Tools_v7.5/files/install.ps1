﻿# PS Tools (Hrebeniuk) — установка v7.5
# Запускається з ВСТАНОВИТИ.bat. Частина для користувача (скрипти, Batch Export) — без прав адміна;
# панель у папку Photoshop — з одним запитом прав адміністратора (UAC).
param([switch]$PluginOnly, [string]$Targets = '', [string]$Src = '', [switch]$List)

$ErrorActionPreference = 'Stop'
$PluginId = 'com.hrebeniuk.pstools'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'find_ps.ps1')

# ── Режим «тільки панель» (запускається з правами адміна) ────────────────────
if ($PluginOnly) {
    foreach ($t in ($Targets -split '\|')) {
        if (-not $t) { continue }
        New-Item -ItemType Directory -Force $t | Out-Null
        Remove-OldPanelCopies $t $PluginId
        $dst = Join-Path $t $PluginId
        if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
        New-Item -ItemType Directory -Force $dst | Out-Null
        Copy-Item (Join-Path $Src '*') $dst -Recurse -Force
    }
    exit 0
}

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$Here  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Log   = Join-Path $env:TEMP 'PSTools_install.log'
"PS Tools install $(Get-Date)" | Out-File $Log -Encoding utf8
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c; $t | Out-File $Log -Append -Encoding utf8 }
$ok = $true

Write-Host ''
Say '=== PS Tools (Hrebeniuk) — встановлення v7.5 ===' 'Cyan'
Write-Host ''

if (Get-Process Photoshop -ErrorAction SilentlyContinue) {
    Say 'Photoshop зараз відкритий. Встановлення можна продовжити, але панель з''явиться після перезапуску Photoshop.' 'Yellow'
    Write-Host ''
}

# ── 1. Photoshop ─────────────────────────────────────────────────────────────
Write-Host 'Шукаю всі Photoshop на ПК...'
$found = @(Find-AllPhotoshops)
Say ("Знайдено Photoshop: $($found.Count)")
$found | ForEach-Object { Say ('  {0}  (v{1})   {2}' -f $_.Name, $_.Ver, $_.Dir) }
if ($List) { exit 0 }
if (-not $found.Count) {
    $p = (Read-Host 'Не знайшов Photoshop. Перетягни сюди Photoshop.exe і натисни Enter').Trim('"')
    if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { $found = @([pscustomobject]@{ Dir = (Split-Path -Parent $p); Name = (Split-Path (Split-Path -Parent $p) -Leaf); Ver = '' }) }
}
if (-not $found.Count) {
    Say '✗ Photoshop не знайдено. Встанови Photoshop 2022 або новіший і запусти установку ще раз.' 'Red'
    exit 1
}
$found = @(Select-Photoshops $found)
$ps = @($found | ForEach-Object { $_.Dir })
Say ('[1/4] Photoshop: ' + (($found | ForEach-Object { $_.Name }) -join ', ')) 'White'

# ── 2. Скрипти інструментів ──────────────────────────────────────────────────
try {
    $jsxDst = Join-Path $env:APPDATA 'HrebeniukTools\jsx'
    New-Item -ItemType Directory -Force $jsxDst | Out-Null
    Copy-Item (Join-Path $Here 'jsx\*.jsx') $jsxDst -Force
    $n = (Get-ChildItem $jsxDst -Filter *.jsx).Count
    Say "[2/4] Скрипти інструментів → $jsxDst ($n файлів)  ✓" 'Green'
    # версія скриптів — щоб кнопка «Оновити» в панелі знала, що стоїть
    $pkgVer = (Get-Content (Join-Path $Here 'VERSION') -Raw).Trim()
    ('{"version": "' + $pkgVer + '"}') | Out-File (Join-Path $env:APPDATA 'HrebeniukTools\version.json') -Encoding ascii
    foreach ($pd in Get-ChildItem (Join-Path $env:APPDATA 'Adobe\UXP\PluginsStorage\PHSP\*\*\com.hrebeniuk.pstools\PluginData') -Directory -ErrorAction SilentlyContinue) {
        Set-Content (Join-Path $pd.FullName 'scripts_version.txt') $pkgVer -NoNewline -Encoding ascii
    }
} catch { $ok = $false; Say "[2/4] Скрипти: ПОМИЛКА — $($_.Exception.Message)" 'Red' }

# ── 3. PS Batch Export v5 ────────────────────────────────────────────────────
try {
    $beDst = Join-Path $env:APPDATA 'PSBatchExportV5'
    Get-Process 'PS Batch Export v5' -ErrorAction SilentlyContinue | Stop-Process -Force
    New-Item -ItemType Directory -Force $beDst | Out-Null
    Copy-Item (Join-Path $Here 'PS Batch Export v5\*') $beDst -Recurse -Force     # presets.json користувача не чіпаємо
    $exe = Join-Path $beDst 'PS Batch Export v5.exe'
    # pstools:// — щоб кнопка в панелі запускала програму
    New-Item 'HKCU:\Software\Classes\pstools\shell\open\command' -Force | Out-Null
    Set-ItemProperty 'HKCU:\Software\Classes\pstools' -Name '(default)' -Value 'URL:PS Tools Protocol'
    Set-ItemProperty 'HKCU:\Software\Classes\pstools' -Name 'URL Protocol' -Value ''
    Set-ItemProperty 'HKCU:\Software\Classes\pstools\shell\open\command' -Name '(default)' -Value ('"' + $exe + '"')
    if (-not (Test-Path $exe)) { throw 'exe не скопіювався' }
    Say "[3/4] PS Batch Export v5 → $beDst  ✓" 'Green'
} catch { $ok = $false; Say "[3/4] Batch Export: ПОМИЛКА — $($_.Exception.Message)" 'Red' }

# ── 4. Панель PS Tools у Photoshop (потрібні права адміністратора) ───────────
$plugSrc = Join-Path $Here 'panel'
$targets = @()
foreach ($p in $ps) { $targets += (Join-Path $p 'Plug-ins') }     # нема Plug-ins — створиться в адмін-частині
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
try {
    if ($isAdmin) {
        & $MyInvocation.MyCommand.Path -PluginOnly -Targets ($targets -join '|') -Src $plugSrc
    } else {
        Say '[4/4] Панель у Photoshop: Windows зараз попросить дозвіл — натисни «Так».' 'Yellow'
        $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $MyInvocation.MyCommand.Path + '"'),
                  '-PluginOnly', '-Targets', ('"' + ($targets -join '|') + '"'), '-Src', ('"' + $plugSrc + '"'))
        $p = Start-Process powershell.exe -ArgumentList $a -Verb RunAs -Wait -PassThru -WindowStyle Hidden
    }
} catch { Say "     Дозвіл не надано: $($_.Exception.Message)" 'Red' }
$ver = (Get-Content (Join-Path $plugSrc 'manifest.json') -Raw | ConvertFrom-Json).version
foreach ($t in $targets) {
    $m = Join-Path $t "$PluginId\manifest.json"
    if ((Test-Path $m) -and ((Get-Content $m -Raw | ConvertFrom-Json).version -eq $ver)) {
        Say "[4/4] Панель v$ver → $(Split-Path (Split-Path $t) -Leaf)  ✓" 'Green'
    } else { $ok = $false; Say "[4/4] Панель → $(Split-Path (Split-Path $t) -Leaf): НЕ встановлено" 'Red' }
}

Write-Host ''
if ($ok) {
    Say 'ГОТОВО. Перезапусти Photoshop (усі версії) → угорі меню Plugins → PS Tools → постав галочку (увімкнути). Панель з''явиться збоку — її можна прикріпити.' 'Cyan'
    Say 'Поставив інший Photoshop пізніше? Просто запусти ВСТАНОВИТИ ще раз.' 'Gray'
} else {
    Say "Є помилки (див. вище). Лог: $Log" 'Red'
    exit 2
}
exit 0
