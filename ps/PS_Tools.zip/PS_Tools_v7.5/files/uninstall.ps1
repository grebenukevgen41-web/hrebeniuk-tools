﻿# PS Tools (Hrebeniuk) — видалення
param([switch]$PluginOnly, [string]$Targets = '')
$PluginId = 'com.hrebeniuk.pstools'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'find_ps.ps1')

if ($PluginOnly) {
    foreach ($t in ($Targets -split '\|')) {
        if (-not $t) { continue }
        Remove-Item (Join-Path $t $PluginId) -Recurse -Force -ErrorAction SilentlyContinue
        Remove-OldPanelCopies $t $PluginId
    }
    exit 0
}

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Write-Host ''
Write-Host '=== PS Tools (Hrebeniuk) — видалення ===' -ForegroundColor Cyan
Write-Host ''

$targets = @()
foreach ($f in @(Find-AllPhotoshops)) {
    $pi = Join-Path $f.Dir 'Plug-ins'
    if (Test-Path (Join-Path $pi $PluginId)) { $targets += $pi; Write-Host ('  панель знайдено: ' + $f.Name) }
}
if ($targets) {
    Write-Host 'Панель у Photoshop: Windows попросить дозвіл — натисни «Так».' -ForegroundColor Yellow
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if ($isAdmin) { & $MyInvocation.MyCommand.Path -PluginOnly -Targets ($targets -join '|') }
    else {
        $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $MyInvocation.MyCommand.Path + '"'), '-PluginOnly', '-Targets', ('"' + ($targets -join '|') + '"'))
        try { Start-Process powershell.exe -ArgumentList $a -Verb RunAs -Wait -WindowStyle Hidden } catch {}
    }
}
Get-Process 'PS Batch Export v5' -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item (Join-Path $env:APPDATA 'HrebeniukTools') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:APPDATA 'PSBatchExportV5') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Classes\pstools' -Recurse -Force -ErrorAction SilentlyContinue

$left = @()
foreach ($t in $targets) { if (Test-Path (Join-Path $t $PluginId)) { $left += $t } }
if (Test-Path (Join-Path $env:APPDATA 'HrebeniukTools')) { $left += 'HrebeniukTools' }
if ($left) { Write-Host ('Не вдалося видалити: ' + ($left -join ', ')) -ForegroundColor Red; exit 2 }
Write-Host 'Видалено. Перезапусти Photoshop.' -ForegroundColor Green
exit 0
