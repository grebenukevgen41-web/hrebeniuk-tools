﻿# PS Tools — пошук УСІХ Photoshop на ПК (спільне для install.ps1 / uninstall.ps1).
# У кожного Photoshop своя папка Plug-ins, тому панель ставимо в кожен знайдений —
# інакше людина відкриє «не той» (напр. 2024 поруч із 2026) і побачить стару панель.
# Шукаємо скрізь, бо збірки без Creative Cloud часто стоять не в C:\Program Files\Adobe і без реєстру.

function Find-AllPhotoshops {
    $c = New-Object System.Collections.Generic.List[string]
    function Add-Exe($exe) {
        if (-not $exe -or (Split-Path $exe -Leaf) -ne 'Photoshop.exe') { return }      # лише сам Photoshop.exe (не іконки/службові)
        if (Test-Path -LiteralPath $exe -PathType Leaf) { $c.Add((Split-Path -Parent $exe)) }
    }

    # 1) вже запущений Photoshop
    Get-Process Photoshop -ErrorAction SilentlyContinue | ForEach-Object { try { Add-Exe $_.Path } catch {} }
    # 2) реєстр Adobe, App Paths, список встановлених програм
    foreach ($k in Get-ChildItem 'HKLM:\SOFTWARE\Adobe\Photoshop' -ErrorAction SilentlyContinue) {
        $p = (Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue).ApplicationPath
        if ($p) { Add-Exe (Join-Path $p 'Photoshop.exe') }
    }
    foreach ($ap in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Photoshop.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Photoshop.exe') {
        $p = (Get-ItemProperty $ap -ErrorAction SilentlyContinue).'(default)'
        if ($p) { Add-Exe $p.Trim('"') }
    }
    foreach ($u in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*') {
        Get-ItemProperty $u -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like '*Photoshop*' } | ForEach-Object {
            if ($_.InstallLocation) { Add-Exe (Join-Path $_.InstallLocation 'Photoshop.exe') }
            if ($_.DisplayIcon) { Add-Exe (($_.DisplayIcon -split ',')[0].Trim('"')) }
        }
    }
    # 3) чим відкриваються .psd
    $prog = (Get-ItemProperty 'Registry::HKEY_CLASSES_ROOT\.psd' -ErrorAction SilentlyContinue).'(default)'
    if ($prog) {
        $cmd = (Get-ItemProperty "Registry::HKEY_CLASSES_ROOT\$prog\shell\open\command" -ErrorAction SilentlyContinue).'(default)'
        if ($cmd -match '^"?([^"]+?Photoshop\.exe)') { Add-Exe $Matches[1] }
    }
    # 4) усі диски: Photoshop.exe на 1-3 рівні (D:\Adobe Photoshop 2024, E:\Program Files\Adobe\Adobe Photoshop 2024 ...)
    $skipDir = '^(Windows|Users|ProgramData|\$Recycle\.Bin|System Volume Information|Recovery|PerfLogs|Config\.Msi|\$WinREAgent|Intel|AMD|NVIDIA)$'
    foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { $_.Used })) {
        foreach ($l1 in Get-ChildItem -LiteralPath $d.Root -Directory -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch $skipDir }) {
            Add-Exe (Join-Path $l1.FullName 'Photoshop.exe')
            foreach ($l2 in Get-ChildItem -LiteralPath $l1.FullName -Directory -ErrorAction SilentlyContinue) {
                Add-Exe (Join-Path $l2.FullName 'Photoshop.exe')
                if ($l2.Name -match 'Adobe|Photoshop|PS') {        # 3-й рівень лише під «Adobe»-папками, щоб не повзти по всьому диску
                    foreach ($l3 in Get-ChildItem -LiteralPath $l2.FullName -Directory -ErrorAction SilentlyContinue) { Add-Exe (Join-Path $l3.FullName 'Photoshop.exe') }
                }
            }
        }
    }
    # без повторів; назва = папка + версія exe
    $seen = @{}; $res = @()
    foreach ($dir in $c) {
        $full = (Resolve-Path -LiteralPath $dir).Path.TrimEnd('\')
        if ($seen.ContainsKey($full.ToLower())) { continue }
        $seen[$full.ToLower()] = 1
        $v = ''
        try { $v = (Get-Item -LiteralPath (Join-Path $full 'Photoshop.exe')).VersionInfo.ProductVersion } catch {}
        $res += [pscustomobject]@{ Dir = $full; Name = (Split-Path $full -Leaf); Ver = $v }
    }
    return $res
}

function Select-Photoshops($all, [string]$Verb = 'ставити') {
    # кілька Photoshop -> питаємо; Enter = в усі (за замовчуванням), або номери через кому. PST_ALL=1 — без питання.
    if ($all.Count -le 1 -or $env:PST_ALL) { return $all }
    Write-Host ''
    for ($i = 0; $i -lt $all.Count; $i++) { Write-Host ('  [{0}] {1}  (v{2})   {3}' -f ($i + 1), $all[$i].Name, $all[$i].Ver, $all[$i].Dir) }
    $ans = Read-Host "Куди $Verb? Enter = в усі (радимо); або номери через кому, напр. 1 чи 1,2"
    if (-not $ans -or -not $ans.Trim()) { return $all }
    $pick = @($ans -split '[,; ]+' | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ - 1 } |
              Where-Object { $_ -ge 0 -and $_ -lt $all.Count } | Sort-Object -Unique)
    if (-not $pick.Count) { Write-Host 'Не зрозумів відповідь — беру всі.' -ForegroundColor Yellow; return $all }
    return @($pick | ForEach-Object { $all[$_] })
}

function Remove-OldPanelCopies([string]$PlugIns, [string]$Id) {
    # стара панель з тим самим id, але в іншій папці (ручне копіювання, старі установки) — Photoshop показав би її
    foreach ($d in Get-ChildItem -LiteralPath $PlugIns -Directory -ErrorAction SilentlyContinue) {
        if ($d.Name -eq $Id) { continue }
        foreach ($m in @((Join-Path $d.FullName 'manifest.json')) + @(Get-ChildItem -LiteralPath $d.FullName -Directory -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName 'manifest.json' })) {
            if ((Test-Path -LiteralPath $m) -and (Select-String -LiteralPath $m -Pattern ('"' + [regex]::Escape($Id) + '"') -Quiet)) {
                Remove-Item -LiteralPath (Split-Path $m) -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    }
}
