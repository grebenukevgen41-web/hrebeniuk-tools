@echo off
chcp 65001 >nul
title PS Tools - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\install.ps1"
echo.
pause
