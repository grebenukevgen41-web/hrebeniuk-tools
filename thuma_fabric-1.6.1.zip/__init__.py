bl_info = {
    "name": "Thuma Fabric",
    "author": "Hrebeniuk",
    "version": (1, 6, 1),
    "blender": (4, 2, 0),
    "location": "3D View > N > Thuma > Тканина",
    "description": "Перемикач тканини оббивки + повзунки FABRIC LOOK вибраної тканини (майстер-сцена Thuma)",
    "category": "Material",
}
ADDON_VERSION = tuple(bl_info["version"])
"""Панель з'являється лише у файлах, де є тканини з міткою thuma_fabric (майстер-сцена v30+).
Тканина ставиться прямо в слот матеріалу 12 мешів оббивки — її видно в Shader Editor.
Скриптів у самому .blend немає — Blender не питає «Allow Execution»."""
import bpy

_ITEMS = []     # Blender вимагає тримати рядки динамічного списку живими
_KEY = [None]   # набір тканин, з якого зібрано _ITEMS (перебудова лише коли він змінився)


def _meshes():
    return sorted({o.data for o in bpy.data.objects if o.type == 'MESH'
                   and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2}, key=lambda m: m.name)


def _fabrics():
    return sorted((m for m in bpy.data.materials if m.get("thuma_fabric")), key=lambda m: m.name)


def _items(self, context):
    # 1.0.1: НЕ перебудовувати список при кожному виклику — інакше Blender тримає вказівники на старі рядки
    # і в згорнутому списку показує не ту назву (у розгорнутому правильно).
    fabs = _fabrics()
    key = tuple(m.name for m in fabs)
    if key != _KEY[0] or not _ITEMS:
        _ITEMS[:] = [("STORYBOARD", "Storyboard (сірий)", "Сірий матеріал Storyboard")]
        _ITEMS.extend((m.name, m["thuma_fabric"], m.name, i + 1) for i, m in enumerate(fabs))
        _ITEMS[0] = _ITEMS[0] + (0,)
        _KEY[0] = key
    return _ITEMS


def _current():
    ms = _meshes()
    return ms[0].materials[0] if ms and ms[0].materials else None


def _get(self):
    cur = _current()
    names = [i[0] for i in _items(self, None)]
    if cur and cur.get("thuma_fabric") and cur.name in names:
        return names.index(cur.name)
    return 0


def _set(self, value):
    names = [i[0] for i in _items(self, None)]
    v = names[value] if 0 <= value < len(names) else "STORYBOARD"
    for me in _meshes():
        if "storyboard_mat" not in me and me.materials and not me.materials[0].get("thuma_fabric"):
            me["storyboard_mat"] = me.materials[0].name
        mat = bpy.data.materials.get(me.get("storyboard_mat", "")) if v == "STORYBOARD" else bpy.data.materials.get(v)
        if mat:
            me.materials[0] = mat


def _look_node(mat):
    """Нода FABRIC LOOK у матеріалі (у Textured Weave вона всередині групи кольору)."""
    if not mat or not mat.node_tree:
        return None

    def find(t, seen):
        if t.as_pointer() in seen:
            return None
        seen.add(t.as_pointer())
        for n in t.nodes:
            if n.type == 'GROUP' and n.node_tree:
                if n.node_tree.name.startswith("FABRIC LOOK"):
                    return n
                r = find(n.node_tree, seen)
                if r:
                    return r
    return find(mat.node_tree, set())


class THUMA_PT_fabric(bpy.types.Panel):
    bl_label = "Тканина"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Thuma"

    @classmethod
    def poll(cls, context):
        return any(m.get("thuma_fabric") for m in bpy.data.materials)

    def draw_header_preset(self, context):
        self.layout.label(text=".".join(map(str, ADDON_VERSION)))

    def draw(self, context):
        c = self.layout.column()
        c.prop(context.scene, "thuma_fabric_pick", text="")
        if _wood_node():
            c.prop(context.scene, "thuma_wood_pick", text="Дерево")
        if context.space_data.shading.type in {'SOLID', 'WIREFRAME'}:
            c.label(text="Вьюпорт у Solid — тканину видно в Material Preview", icon='INFO')
        _draw_parts_mask(c, context)
        node = _look_node(_current())
        if not node:
            c.label(text="Storyboard — пульта нема")
            return
        # 1.1.0: увесь пульт згортається; кожна зона — окремий блок, що згортається
        root_h, root = c.panel("thuma_fl_root", default_closed=False)
        root_h.label(text="FABRIC LOOK цієї тканини", icon='MATERIAL')
        _eye(root_h, "__ALL__", "")
        root_h.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False).scope = 'ALL'
        if root is not None:
            _draw_look(root, node)
        _draw_custom(c, context)


def _draw_look(c, node):
    rows = []                      # (панель, [(зона, [(суфікс, сокет)])])
    for it in node.node_tree.interface.items_tree:
        if it.item_type == 'PANEL':
            rows.append((it, []))
        elif it.in_out == 'INPUT' and it.name != "Колір":
            s = node.inputs.get(it.name)
            if s is None or s.is_linked:
                continue
            zone, _, suf = it.name.partition(": ")
            if not suf:
                zone, suf = "", it.name
            if not rows:
                rows.append((None, []))
            zl = rows[-1][1]
            if not zl or zl[-1][0] != zone:
                zl.append((zone, []))
            zl[-1][1].append((suf, s))
    for i, (pan, zones) in enumerate(rows):
        if pan is not None:
            head, body = c.panel(f"thuma_fl_{i}", default_closed=getattr(pan, "default_closed", False))
            head.label(text=pan.name, icon=_PANEL_ICON.get(pan.name, 'NONE'))
            if body is None:
                continue
        else:
            body = c
        if pan is not None and pan.name.startswith("Кутик"):
            kb = body.box()
            kb.label(text="Пензель кутика (на виділеному модулі):", icon='BRUSH_DATA')
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Дорисувати", icon='ADD').mode = 'ADD'
            r.operator("thuma.kutik_paint", text="Стерти", icon='REMOVE').mode = 'ERASE'
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Готово", icon='CHECKMARK').mode = 'DONE'
            r.operator("thuma.kutik_paint", text="Очистити модуль", icon='TRASH').mode = 'CLEAR'
        if pan is not None and pan.name == "Шви":
            sb = body.box()
            sb.label(text="Прибрати шов там, де не треба (на модулі):", icon='BRUSH_DATA')
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Прибрати пензлем", icon='REMOVE').mode = 'PAINT_OFF'
            r.operator("thuma.seam_off", text="Повернути пензлем", icon='ADD').mode = 'PAINT_ON'
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Прибрати з виділених", icon='FACESEL').mode = 'SEL_OFF'
            r.operator("thuma.seam_off", text="Повернути виділеним", icon='FACESEL').mode = 'SEL_ON'
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Готово", icon='CHECKMARK').mode = 'DONE'
            r.operator("thuma.seam_off", text="Усі шви на модулі", icon='LOOP_BACK').mode = 'CLEAR'
        many = len(zones) > 1
        for j, (zone, socks) in enumerate(zones):
            if many:                                   # кожна зона окремо згортається
                zh, zb = body.panel(f"thuma_fz_{i}_{j}", default_closed=False)
                zh.label(text=zone or pan.name, icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(zh, zone or pan.name, "|".join(sock.name for _, sock in socks))
                o = zh.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                if zb is None:
                    continue
                col = zb.column(align=True)
            else:
                b = body.column()
                hr = b.row()
                hr.label(text=zone or (pan.name if pan is not None else ""), icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(hr, zone or (pan.name if pan is not None else ""), "|".join(sock.name for _, sock in socks))
                o = hr.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                col = b.column(align=True)
            for suf, s in socks:
                col.prop(s, "default_value", text=suf[:1].upper() + suf[1:])


# ---------------- 1.1.0: СВОЇ ЗОНИ (вибрані полігони конкретної моделі) ----------------
# Зберігаються на МЕШІ (модель): Mesh.thuma_zones (налаштування) + атрибут граней tc_z<id> (які полігони).
# Сумарний результат усіх зон моделі -> атрибут вершин tc_cust (x = яскравість-1, y = насиченість-1);
# FABRIC LOOK множить на (1+x), (1+y). Нема атрибута -> 0 -> без змін. Префікс tc_ (не fz_) — пересбірка
# пульта атрибути fz_* перераховує, а ці не чіпає.
_GRAPH = {}


def _ups_mesh(ob):
    return ob is not None and ob.type == 'MESH' and ob.data in _meshes()


def _graph(me):
    """Сусідство вершин по ребрах (кеш). У Edit Mode — з BMesh (масиви меша тоді неактуальні)."""
    import numpy as np
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        key = (me.name, "edit", len(bm.verts), len(bm.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.array([v.co[:] for v in bm.verts], np.float32)
        ev = np.array([(e.verts[0].index, e.verts[1].index) for e in bm.edges], np.int64).reshape(-1, 2)
    else:
        key = (me.name, len(me.vertices), len(me.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ev = np.empty(len(me.edges) * 2, np.int32); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
    a = np.concatenate([ev[:, 0], ev[:, 1]]); b = np.concatenate([ev[:, 1], ev[:, 0]])
    w = np.linalg.norm(co[a] - co[b], axis=1)
    o = np.argsort(a, kind='stable')
    a, b, w = a[o], b[o], w[o]
    start = np.searchsorted(a, np.arange(len(co) + 1))
    _GRAPH.clear()
    _GRAPH[key] = (start.tolist(), b.tolist(), w.tolist())
    return _GRAPH[key]


def _zone_vmask(me, z):
    """Вершини полігонів зони (у Edit Mode — з шару BMesh)."""
    import numpy as np
    name = f"tc_z{z.uid}"
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        vm = np.zeros(len(bm.verts), bool)
        lay = bm.faces.layers.bool.get(name)
        if lay is None:
            return vm
        for f in bm.faces:
            if f[lay]:
                for v in f.verts:
                    vm[v.index] = True
        return vm
    nv = len(me.vertices)
    at = me.attributes.get(name)
    vm = np.zeros(nv, bool)
    if at is None or len(at.data) != len(me.polygons):
        return vm
    fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
    vm[lv[np.repeat(fm, lt)]] = True
    return vm


def _zone_weights(me, z):
    """Вага зони на вершинах: 1 на її полігонах, плавно до 0 на відстані «Перехід» (по тканині)."""
    import heapq
    import numpy as np
    vm = _zone_vmask(me, z)
    w = vm.astype(np.float32)
    W = z.transition * 0.01
    if W <= 0.0005 or not vm.any():
        return w
    start, nb, wt = _graph(me)
    d = {int(i): 0.0 for i in np.nonzero(vm)[0]}
    h = [(0.0, i) for i in d]
    heapq.heapify(h)
    while h:
        dv, v = heapq.heappop(h)
        if dv > d.get(v, 9.0):
            continue
        for k in range(start[v], start[v + 1]):
            u = nb[k]; nd = dv + wt[k]
            if nd < W and nd < d.get(u, 9.0):
                d[u] = nd
                heapq.heappush(h, (nd, u))
    for i, dv in d.items():
        t = dv / W
        w[i] = max(w[i], 1.0 - t * t * (3 - 2 * t))
    return w


def _rebuild(me):
    import numpy as np
    if me.is_editmode:
        import bmesh
        nv = len(bmesh.from_edit_mesh(me).verts)
    else:
        nv = len(me.vertices)
    b = np.ones(nv, np.float32); s_ = np.ones(nv, np.float32)
    for z in me.thuma_zones:
        if not z.enabled:
            continue
        w = _zone_weights(me, z)
        b *= 1.0 + (z.bright - 1.0) * w
        s_ *= 1.0 + (z.sat - 1.0) * w
    vec = np.stack([b - 1.0, s_ - 1.0, np.zeros(nv, np.float32)], 1)
    if me.is_editmode:
        # 1.1.1: у Edit Mode меш живе в BMesh — пишемо туди (пряма запис падала / губилась при виході)
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        lay = bm.verts.layers.float_vector.get("tc_cust") or bm.verts.layers.float_vector.new("tc_cust")
        if len(bm.verts) == nv:
            for v, d in zip(bm.verts, vec.tolist()):
                v[lay] = d
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return
    at = me.attributes.get("tc_cust")
    if at is not None and (at.domain != 'POINT' or at.data_type != 'FLOAT_VECTOR' or len(at.data) != nv):
        me.attributes.remove(at)                 # 1.1.4: битий шар (напр. з 1.1.0, створений в Edit Mode) — перестворити
        at = None
    if at is None:
        at = me.attributes.new("tc_cust", 'FLOAT_VECTOR', 'POINT')
    at.data.foreach_set("vector", vec.ravel())
    me.update()


def _upd(self, context):
    try:
        _rebuild(self.id_data)
    except Exception as e:                      # не валити UI помилкою під час руху повзунка
        print("[Thuma Fabric] своя зона:", e)


class THUMA_Zone(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Назва", default="Зона", description="Назва зони (двічі клікни, щоб перейменувати)")
    uid: bpy.props.IntProperty()
    enabled: bpy.props.BoolProperty(name="Увімкнено", default=True, update=_upd,
                                    description="Тимчасово вимкнути цю зону (без видалення)")
    bright: bpy.props.FloatProperty(name="Яскравість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                    description="Яскравість вибраних полігонів. 1 = без змін, менше = темніше")
    sat: bpy.props.FloatProperty(name="Насиченість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість вибраних полігонів. 1 = без змін, 0 = сіре")
    transition: bpy.props.FloatProperty(name="Перехід, см", default=0.0, min=0.0, soft_max=30.0, update=_upd,
                                        description="Наскільки плавно зміна заходить на сусідні полігони (по тканині), см. 0 = різко")


def _mode(mode, back=False):
    """mode_set, що не падає на модулі, прихованому в цьому кадрі (видимість конфігурацій анімована).
    Вийти в Object Mode — завжди можна (на мить знімаємо приховування). Повернутись у Edit (back=True) —
    лише якщо видно; інакше тихо лишаємось в Object. Повертає True/False."""
    try:
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        pass
    ob = bpy.context.view_layer.objects.active
    if back or ob is None or mode != 'OBJECT':
        return False
    hv, hs = ob.hide_viewport, ob.hide_get()
    try:
        ob.hide_viewport = False
        ob.hide_set(False)
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        return False
    finally:
        ob.hide_viewport = hv
        ob.hide_set(hs)


def _enter_paint(op, context):
    """Увійти у Vertex Paint; на прихованому модулі — зрозуміле повідомлення замість помилки."""
    if context.mode == 'PAINT_VERTEX':
        return True
    if not _mode('VERTEX_PAINT'):
        op.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        return False
    return True


def _sel_faces(context, ob):
    """Виділені полігони (з Edit Mode синхронізуємо)."""
    import numpy as np
    was_edit = context.mode == 'EDIT_MESH'
    if was_edit:
        _mode('OBJECT')
    me = ob.data
    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
    if was_edit:
        _mode('EDIT', back=True)
    return sel


def _config_of(ob):
    """Колекція конфігурації (дочірня «Product»), у якій лежить об'єкт."""
    prod = bpy.data.collections.get("Product")
    if prod is None:
        return None
    for c in prod.children:
        if ob.name in c.all_objects:
            return c
    return None


def _split_for_config(ob):
    """Окрема копія моделі для ЦІЄЇ конфігурації (усі такі модулі в ній). Повертає новий меш."""
    cfg = _config_of(ob)
    me = ob.data
    if cfg is None:
        return None, None
    if me.get("tc_config") == cfg.name:            # уже окрема для цієї конфігурації
        return me, cfg
    new = me.copy()
    new.name = f"{me.get('tc_base', me.name)} [{cfg.name[:24]}]"
    new["tc_config"] = cfg.name
    new["tc_base"] = me.get("tc_base", me.name)
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = new
    return new, cfg


def _unsplit(ob):
    """Повернути модулі цієї конфігурації до спільної моделі (окрема копія видаляється, якщо більше не потрібна)."""
    me = ob.data
    base = bpy.data.meshes.get(me.get("tc_base", ""))
    cfg = _config_of(ob)
    if base is None or cfg is None or me.get("tc_config") is None:
        return False
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = base
    if me.users == 0:
        bpy.data.meshes.remove(me)
    return True


class THUMA_OT_zone(bpy.types.Operator):
    bl_idname = "thuma.custom_zone"
    bl_label = "Своя зона"
    bl_options = {'REGISTER', 'UNDO'}
    action: bpy.props.EnumProperty(items=[('ADD', "Нова", ""), ('ADD_CFG', "Нова — лише ця конфігурація", ""),
                                          ('UNSPLIT', "Повернути до спільної моделі", ""), ('ASSIGN', "Перепризначити", ""),
                                          ('SELECT', "Показати", ""), ('REMOVE', "Видалити", ""),
                                          ('SEAM', "До шва", ""), ('EDIT', "Вибрати полігони", "")])
    index: bpy.props.IntProperty(default=-1)

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Нова зона УСЮДИ: на всіх таких модулях у всіх конфігураціях (спершу виділи полігони в Edit Mode)",
                'ADD_CFG': "Нова зона ЛИШЕ В ЦІЙ КОНФІГУРАЦІЇ: модуль(і) тут отримають окрему копію моделі, "
                           "зона діятиме тільки тут. Зони «усюди», змінені пізніше, на цю копію не перейдуть",
                'UNSPLIT': "Повернути модулі цієї конфігурації до спільної моделі (зони «лише тут» зникнуть)",
                'ASSIGN': "Замінити полігони зони на поточне виділення",
                'SELECT': "Виділити полігони цієї зони (перейде в Edit Mode)",
                'REMOVE': "Видалити зону",
                'SEAM': "Розширити виділення до швів — увесь шматок тканини між швами",
                'EDIT': "Перейти в Edit Mode (режим полігонів), щоб виділити потрібні"}[props.action]

    def execute(self, context):
        import numpy as np
        ob = context.active_object
        if not _ups_mesh(ob):
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по тканині дивана)")
            return {'CANCELLED'}
        me = ob.data
        if self.action == 'EDIT':
            if context.mode != 'EDIT_MESH':
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except RuntimeError:
                    self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
                    return {'CANCELLED'}
            context.tool_settings.mesh_select_mode = (False, False, True)
            return {'FINISHED'}
        if self.action == 'SEAM':
            if context.mode != 'EDIT_MESH':
                self.report({'WARNING'}, "Спершу виділи хоча б один полігон у Edit Mode")
                return {'CANCELLED'}
            bpy.ops.mesh.select_linked(delimit={'SEAM'})
            return {'FINISHED'}
        # 1.1.1: усі зміни даних меша — в Object Mode, потім повертаємось у той режим, що був
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            _mode('OBJECT')
        try:
            ok = self._apply(context, me)
        except Exception as e:
            self.report({'ERROR'}, f"Своя зона: {e}")
            ok = False
        if was_edit and context.mode != 'EDIT_MESH':
            try:                                   # 1.2.1: прихований у цьому кадрі об'єкт не пускає в Edit Mode — лишаємось в Object
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                pass
        return {'FINISHED'} if ok else {'CANCELLED'}

    def _apply(self, context, me):
        import numpy as np
        if self.action == 'UNSPLIT':
            if not _unsplit(context.active_object):
                self.report({'WARNING'}, "Ця модель і так спільна")
                return False
            return True
        if self.action == 'ADD_CFG':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            new, cfg = _split_for_config(context.active_object)
            if new is None:
                self.report({'WARNING'}, "Не знайшов конфігурацію цього модуля (колекція в «Product»)")
                return False
            me = new
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid} (лише тут)"
            _rebuild(me)
            return True
        if self.action == 'ADD':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid}"
            _rebuild(me)
            return True
        if not (0 <= self.index < len(me.thuma_zones)):
            return False
        z = me.thuma_zones[self.index]
        if self.action == 'ASSIGN':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            at = me.attributes.get(f"tc_z{z.uid}") or me.attributes.new(f"tc_z{z.uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            _rebuild(me)
        elif self.action == 'SELECT':
            at = me.attributes.get(f"tc_z{z.uid}")
            if at is None:
                return False
            fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
            me.polygons.foreach_set("select", fm)
            try:
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        elif self.action == 'REMOVE':
            name = f"tc_z{z.uid}"
            me.thuma_zones.remove(self.index)
            try:                                  # 1.1.4: битий шар зони не заважає видаленню
                at = me.attributes.get(name)
                if at is not None:
                    me.attributes.remove(at)
            except Exception as e:
                print("[Thuma Fabric] видалення шару зони:", e)
            _rebuild(me)
        return True


def _draw_custom(c, context):
    head, body = c.panel("thuma_custom_root", default_closed=False)
    head.label(text="Свої зони (вибрані полігони)", icon='FACESEL')
    if body is None:
        return
    ob = context.active_object
    if not _ups_mesh(ob):
        body.label(text="Виділи модуль оббивки (клік по тканині)", icon='INFO')
        return
    me = ob.data
    if me.get("tc_config"):
        bx = body.box()
        bx.label(text=f"Окрема модель: лише «{me['tc_config']}»", icon='LINKED')
        bx.operator("thuma.custom_zone", text="Повернути до спільної моделі", icon='UNLINKED').action = 'UNSPLIT'
    else:
        body.label(text=f"Модель: {me.name} (спільна для всіх конфігурацій)", icon='MESH_DATA')
    r = body.row(align=True)
    r.operator("thuma.custom_zone", text="Вибрати полігони", icon='EDITMODE_HLT').action = 'EDIT'
    r.operator("thuma.custom_zone", text="До шва", icon='MOD_EDGESPLIT').action = 'SEAM'
    rn = body.row(align=True)
    rn.operator("thuma.custom_zone", text="Нова зона — усюди", icon='ADD').action = 'ADD'
    rn.operator("thuma.custom_zone", text="— лише ця конфігурація", icon='OUTLINER_COLLECTION').action = 'ADD_CFG'
    for i, z in enumerate(me.thuma_zones):
        zh, zb = body.panel(f"thuma_cz_{z.uid}", default_closed=False)
        row = zh.row(align=True)
        row.prop(z, "enabled", text="", icon='HIDE_OFF' if z.enabled else 'HIDE_ON', emboss=False)
        row.label(text=z.name, icon='FACESEL')
        o = row.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False); o.scope = 'CUSTOM'; o.index = i
        if zb is None:
            continue
        zb.prop(z, "name", text="Назва")
        col = zb.column(align=True)
        col.prop(z, "bright"); col.prop(z, "sat"); col.prop(z, "transition")
        rr = zb.row(align=True)
        o = rr.operator("thuma.custom_zone", text="Показати", icon='RESTRICT_SELECT_OFF'); o.action = 'SELECT'; o.index = i
        o = rr.operator("thuma.custom_zone", text="Перепризначити", icon='FILE_REFRESH'); o.action = 'ASSIGN'; o.index = i
        o = rr.operator("thuma.custom_zone", text="", icon='TRASH'); o.action = 'REMOVE'; o.index = i


class THUMA_OT_kutik_paint(bpy.types.Operator):
    bl_idname = "thuma.kutik_paint"
    bl_label = "Пензель кутика"
    bl_description = ("Малювати маску кутика прямо на модулі (Vertex Paint). Дорисувати — додати затемнення, "
                      "Стерти — прибрати там, де не треба. Модуль спільний: однакові модулі в сцені зміняться разом")
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('ADD', "Дорисувати", "Додати затемнення кутика пензлем"),
                                        ('ERASE', "Стерти", "Прибрати затемнення там, де не треба"),
                                        ('DONE', "Готово", "Вийти з малювання"),
                                        ('CLEAR', "Очистити модуль", "Прибрати все намальоване на цьому модулі")])

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Пензель: червоний = додати затемнення кутика (видно, якщо «Кутик: яскравість» < 1 або «Показати зони»)",
                'ERASE': "Пензель: зелений = стерти затемнення там, де воно не потрібне",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Прибрати все намальоване на виділеному модулі (повернути автоматичний кутик)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        ob = context.active_object
        if not ob or ob.type != 'MESH' or ob.data not in _meshes():
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        me = ob.data
        ca = me.color_attributes.get("fz_kutik")
        if ca is None:
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
        if self.mode == 'CLEAR':
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
            me.update()
            return {'FINISHED'}
        me.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = (1.0, 0.0, 0.0) if self.mode == 'ADD' else (0.0, 1.0, 0.0)
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по модулю. " + ("Червоний = додати" if self.mode == 'ADD' else "Зелений = стерти"))
        return {'FINISHED'}


SEAM_OFF = "tc_seam_off"


def _seam_attr(me):
    import numpy as np
    ca = me.color_attributes.get(SEAM_OFF)
    if ca is None:
        ca = me.color_attributes.new(SEAM_OFF, 'BYTE_COLOR', 'POINT')
        ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
    return ca


class THUMA_OT_seam_off(bpy.types.Operator):
    """Прибрати підкреслення шва на окремих місцях модуля (напр. ззаду, де шов не потрібен)"""
    bl_idname = "thuma.seam_off"
    bl_label = "Прибрати шов"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('PAINT_OFF', "Прибрати пензлем", ""), ('PAINT_ON', "Повернути пензлем", ""),
                                        ('SEL_OFF', "Прибрати з виділених", ""), ('SEL_ON', "Повернути виділеним", ""),
                                        ('DONE', "Готово", ""), ('CLEAR', "Усі шви на модулі", "")])

    @classmethod
    def description(cls, context, props):
        return {'PAINT_OFF': "Пензель: червоний = тут шов НЕ підкреслювати. Модуль спільний: однакові модулі в сцені зміняться разом",
                'PAINT_ON': "Пензель: чорний = повернути підкреслення шва там, де прибрали",
                'SEL_OFF': "Edit Mode: виділи полігони біля шва і натисни — шов на них прибереться",
                'SEL_ON': "Edit Mode: повернути шов на виділених полігонах",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Повернути всі шви на виділеному модулі (стерти все прибране)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        obs = [o for o in ({context.active_object} | set(context.selected_objects)) if o]
        obs = [o for o in obs if o.type == 'MESH' and o.data in _meshes()]
        if not obs:
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        if self.mode in ('SEL_OFF', 'SEL_ON', 'CLEAR'):
            was_edit = context.mode == 'EDIT_MESH'
            if was_edit:
                _mode('OBJECT')
            n = 0
            for me in {o.data for o in obs}:
                ca = _seam_attr(me)
                col = np.empty(len(ca.data) * 4, np.float32); ca.data.foreach_get("color", col); col = col.reshape(-1, 4)
                if self.mode == 'CLEAR':
                    col[:, :3] = 0.0
                else:
                    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
                    if not sel.any():
                        continue
                    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
                    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
                    vi = np.unique(lv[np.repeat(sel, lt)])
                    col[vi, 0] = 1.0 if self.mode == 'SEL_OFF' else 0.0
                    col[vi, 1:3] = 0.0
                    n += int(sel.sum())
                ca.data.foreach_set("color", col.ravel()); me.update()
            if was_edit:
                _mode('EDIT', back=True)
            if self.mode != 'CLEAR' and not n:
                self.report({'WARNING'}, "Нічого не виділено: Edit Mode, виділи полігони біля шва")
                return {'CANCELLED'}
            return {'FINISHED'}
        ob = context.active_object if context.active_object in obs else obs[0]
        context.view_layer.objects.active = ob
        ca = _seam_attr(ob.data)
        ob.data.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = (1.0, 0.0, 0.0) if self.mode == 'PAINT_OFF' else (0.0, 0.0, 0.0)
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по шву. " + ("Червоний = прибрати шов" if self.mode == 'PAINT_OFF' else "Чорний = повернути"))
        return {'FINISHED'}


# ── Маска деталей для WireColor (Face) ──────────────────────────────────────────
# Меш має номер деталі на кожному полігоні (атрибут wc_part, розфарбовує скрипт wc_parts_paint.py; палітра —
# scene["wc_parts_palette"]). «По модулях»: колір деталі модуля (спинка модуля, ліва боковина модуля...).
# «По конфігураціях»: деталь — за місцем у зібраному дивані (фронт = дивиться вперед збірки, зовнішня боковина =
# лише крайня боковина збірки ...). Робиться GN-модифікатором WC_FaceConfig на кожен об'єкт (свої кольори для
# кожного номера деталі). WireColor >= 3.7 вмикає модифікатори WC_Face* лише на час Face-маски — звичайний рендер
# їх не бачить.
PARTS_MOD, PARTS_GROUP = "WC_FaceConfig", "WC Face Config"
_EXT = {"Фронт": (0, -1), "Задня стінка": (0, 1), "Боковина зовн. ліва": (-1, 0), "Боковина зовн. права": (1, 0)}
_INN = {"Спинка": (0, -1), "Боковина внутр. ліва": (1, 0), "Боковина внутр. права": (-1, 0)}
_WOOD = {"Дерево: фронт": (0, -1), "Дерево: зад": (0, 1), "Дерево: бік лівий": (-1, 0), "Дерево: бік правий": (1, 0)}


def _palette(scene):
    import json
    raw = scene.get("wc_parts_palette")
    return json.loads(raw) if raw else None


def _parts_group(pal):
    ng = bpy.data.node_groups.get(PARTS_GROUP)
    if ng and len([i for i in ng.interface.items_tree if getattr(i, "in_out", "") == 'INPUT']) == len(pal) + 1:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = bpy.data.node_groups.new(PARTS_GROUP, 'GeometryNodeTree')
    it = ng.interface
    it.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    for name, _c in pal:
        it.new_socket(name, in_out='INPUT', socket_type='NodeSocketColor')
    it.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); gi.location = (-700, 0)
    go = N.new('NodeGroupOutput'); go.location = (500, 0)
    pa = N.new('GeometryNodeInputNamedAttribute'); pa.data_type = 'INT'; pa.location = (-450, 300)
    pa.inputs["Name"].default_value = "wc_part"
    sw = N.new('GeometryNodeIndexSwitch'); sw.data_type = 'RGBA'; sw.location = (-200, 0)
    while len(sw.index_switch_items) < len(pal):
        sw.index_switch_items.new()
    L.new(pa.outputs["Attribute"], sw.inputs[0])
    for i in range(len(pal)):
        L.new(gi.outputs[i + 1], sw.inputs[i + 1])
    st = N.new('GeometryNodeStoreNamedAttribute'); st.data_type = 'FLOAT_COLOR'; st.domain = 'CORNER'
    st.location = (150, 0); st.inputs["Name"].default_value = "wc_mask_color"
    L.new(gi.outputs[0], st.inputs["Geometry"]); L.new(sw.outputs[0], st.inputs["Value"])
    L.new(st.outputs["Geometry"], go.inputs["Geometry"])
    return ng


def _set_input(mod, ident, value):
    props = getattr(mod, "properties", None)
    if props is not None and hasattr(props, "inputs"):
        getattr(props.inputs, ident).value = value
    else:
        mod[ident] = value


def _config_mapping(scene):
    """{ім'я об'єкта: {деталь модуля: деталь у збірці}} для всіх конфігурацій (колекції в «Product»)."""
    import math
    from mathutils import Vector
    cur = scene.frame_current
    first = {}
    obs_all = [o for o in scene.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential")]
    for f in range(scene.frame_start, scene.frame_end + 1):
        scene.frame_set(f)
        for o in obs_all:
            if o.name not in first and o.visible_get():
                first[o.name] = f

    def snap(x, y):
        return (int(round(x)), int(round(y)))
    out = {}
    # збірка = усе, що видно РАЗОМ у кадрі, де об'єкт з'являється вперше (в одній колекції бувають
    # кілька окремих модулів, кожен у своєму кадрі)
    for fr_ in sorted(set(first.values())):
        scene.frame_set(fr_)
        obs = [o for o in obs_all if o.visible_get()]
        targets = {o.name for o in obs_all if first.get(o.name) == fr_}
        if not obs or not targets:
            continue
        dg = bpy.context.evaluated_depsgraph_get()
        MW = {o.name: o.evaluated_get(dg).matrix_world.copy() for o in obs}
        rot = bpy.data.objects.get("Control_Rotation")
        ang = rot.evaluated_get(dg).matrix_world.to_euler().z if rot else 0.0
        yaw = {}
        for o in obs:
            vx = MW[o.name].to_3x3() @ Vector((1, 0, 0))
            yaw[o.name] = math.atan2(vx.y, vx.x) - ang
        up = [o for o in obs if o.dimensions.z > 0.2] or obs
        s4 = sum(math.sin(4 * yaw[o.name]) for o in up)
        c4 = sum(math.cos(4 * yaw[o.name]) for o in up)
        phi = math.atan2(s4, c4) / 4                      # спільний «нахил» збірки
        if len(up) == 1:                                  # один модуль (напр. шезлонг під 45°) — його власний перед
            phi = yaw[up[0].name]
        for o in obs:
            if o.name not in targets:
                continue
            a = yaw[o.name] - phi
            ex = snap(math.cos(a), math.sin(a))
            ey = snap(-math.sin(a), math.cos(a))

            def to_cfg(d, ex=ex, ey=ey):
                return (d[0] * ex[0] + d[1] * ey[0], d[0] * ex[1] + d[1] * ey[1])
            inv = MW[o.name].inverted()
            pts = [inv @ (MW[n.name] @ Vector(c)) for n in obs for c in n.bound_box]
            amn = (min(p.x for p in pts), min(p.y for p in pts))
            amx = (max(p.x for p in pts), max(p.y for p in pts))
            bb = [Vector(c) for c in o.bound_box]
            mmn = (min(c.x for c in bb), min(c.y for c in bb))
            mmx = (max(c.x for c in bb), max(c.y for c in bb))

            def extreme(d, amn=amn, amx=amx, mmn=mmn, mmx=mmx):   # бік модуля d (локально) — на краю збірки?
                k = 0 if d[0] else 1
                return abs((mmx[k] - amx[k]) if (d[0] + d[1]) > 0 else (mmn[k] - amn[k])) < 0.06
            m = {}
            for name, d in _EXT.items():
                D = to_cfg(d)
                if D == (0, -1):
                    m[name] = "Фронт"
                elif D == (0, 1):
                    m[name] = "Задня стінка"
                elif extreme(d):
                    m[name] = "Боковина зовн. ліва" if D == (-1, 0) else "Боковина зовн. права"
                else:
                    m[name] = "Фронт бічний" if name == "Фронт" else "Стик (схований бік)"
            for name, d in _INN.items():
                D = to_cfg(d)
                m[name] = ("Спинка" if D[0] == 0 else "Боковина внутр. ліва" if D == (1, 0) else "Боковина внутр. права")
            for name, d in _WOOD.items():
                D = to_cfg(d)
                if D == (0, -1):
                    m[name] = "Дерево: фронт"
                elif D == (0, 1):
                    m[name] = "Дерево: зад"
                elif extreme(d):
                    m[name] = "Дерево: бік лівий" if D == (-1, 0) else "Дерево: бік правий"
                else:
                    m[name] = "Дерево: фронт бічний" if name == "Дерево: фронт" else "Дерево: стик"
            out[o.name] = m
    scene.frame_set(cur)
    return out


def _face_mask_active(scene):
    p = getattr(scene, "wc_props", None)
    return bool(p and p.preview_active and p.preview_mode == 'FACE')


class THUMA_OT_parts_mask(bpy.types.Operator):
    """Маска деталей для WireColor Face: по модулях або по місцю в зібраній конфігурації"""
    bl_idname = "thuma.parts_mask"
    bl_label = "Маска деталей"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('MODULE', "По модулях", ""), ('CONFIG', "По конфігураціях", "")])

    @classmethod
    def description(cls, context, props):
        if props.mode == 'MODULE':
            return "Деталі як у модуля: спинка, ліва/права боковина МОДУЛЯ… Однаково на всіх моделях"
        return ("Деталі за місцем у ЗІБРАНОМУ дивані: фронт = дивиться вперед, зовнішня боковина = лише крайня, "
                "фронт бічний = фронти бокової частини L/П… Для автоматизації в Photoshop. "
                "Рахує всі конфігурації (~10-30 с)")

    def execute(self, context):
        sc = context.scene
        for o in bpy.data.objects:
            m = o.modifiers.get(PARTS_MOD)
            if m is not None:
                o.modifiers.remove(m)
        if self.mode == 'MODULE':
            self.report({'INFO'}, "Маска деталей: по модулях")
            return {'FINISHED'}
        pal = _palette(sc)
        if not pal:
            self.report({'WARNING'}, "У сцені нема розфарбування деталей (wc_parts_paint.py)")
            return {'CANCELLED'}
        idx = {n: i for i, (n, _c) in enumerate(pal)}
        ng = _parts_group(pal)
        ids = [i.identifier for i in ng.interface.items_tree
               if getattr(i, "in_out", "") == 'INPUT' and i.socket_type == 'NodeSocketColor']
        mapping = _config_mapping(sc)
        on = _face_mask_active(sc)
        n = 0
        for o in sc.objects:
            if o.type != 'MESH' or "wc_part" not in o.data.attributes:
                continue
            mp = mapping.get(o.name, {})
            mod = o.modifiers.new(PARTS_MOD, 'NODES')
            mod.node_group = ng
            mod.show_viewport = mod.show_render = on
            mod.show_in_editmode = True
            try:
                o.modifiers.move(len(o.modifiers) - 1, 0)         # першим — колір об'єкта WireColor іде після
            except Exception:
                pass
            for i, (name, _c) in enumerate(pal):
                tgt = mp.get(name, name)
                _set_input(mod, ids[i], tuple(pal[idx.get(tgt, i)][1]) + (1.0,))
            n += 1
        self.report({'INFO'}, f"Маска деталей по конфігураціях: {n} об'єктів ({len(mapping)} у конфігураціях)")
        return {'FINISHED'}


def _draw_parts_mask(c, context):
    if not _palette(context.scene):
        return
    h, b = c.panel("thuma_parts_mask", default_closed=True)
    h.label(text="Маска деталей (WireColor Face)", icon='FACESEL')
    if b is None:
        return
    cfg = any(o.modifiers.get(PARTS_MOD) for o in context.scene.objects if o.type == 'MESH')
    r = b.row(align=True)
    r.operator("thuma.parts_mask", text="По модулях", depress=not cfg).mode = 'MODULE'
    r.operator("thuma.parts_mask", text="По конфігураціях", depress=cfg).mode = 'CONFIG'
    b.label(text="Показ: WireColor → Перегляд Face", icon='INFO')


class THUMA_OT_reset(bpy.types.Operator):
    bl_idname = "thuma.reset"
    bl_label = "Скинути до стандартних"
    bl_options = {'REGISTER', 'UNDO'}
    scope: bpy.props.EnumProperty(items=[('ALL', "Увесь пульт", ""), ('ZONE', "Зона", ""), ('CUSTOM', "Своя зона", "")])
    names: bpy.props.StringProperty()
    index: bpy.props.IntProperty(default=-1)

    @classmethod
    def description(cls, context, props):
        return {'ALL': "Скинути ВСІ повзунки FABRIC LOOK цієї тканини до стандартних (Ctrl+Z — повернути)",
                'ZONE': "Скинути повзунки цієї зони до стандартних",
                'CUSTOM': "Скинути цю свою зону: яскравість 1, насиченість 1, перехід 0 (полігони лишаються)"}[props.scope]

    def invoke(self, context, event):
        if self.scope == 'ALL':
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        if self.scope == 'CUSTOM':
            ob = context.active_object
            if not _ups_mesh(ob) or not (0 <= self.index < len(ob.data.thuma_zones)):
                return {'CANCELLED'}
            z = ob.data.thuma_zones[self.index]
            z.bright, z.sat, z.transition = 1.0, 1.0, 0.0
            return {'FINISHED'}
        node = _look_node(_current())
        if not node:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        only = set(self.names.split("|")) if self.scope == 'ZONE' else None
        n = 0
        for sock in node.inputs:
            if sock.name == "Колір" or sock.is_linked or sock.name not in defaults:
                continue
            if only is not None and sock.name not in only:
                continue
            try:
                sock.default_value = defaults[sock.name]; n += 1
            except Exception:
                pass
        self.report({'INFO'}, f"Скинуто повзунків: {n}")
        return {'FINISHED'}


def _eye(layout, key, names):
    mat = _current()
    off = bool(mat and mat.get(f"tc_eye_{key}"))
    o = layout.operator("thuma.eye", text="", icon='HIDE_ON' if off else 'HIDE_OFF', emboss=False, depress=off)
    o.key = key; o.names = names


class THUMA_OT_eye(bpy.types.Operator):
    """Глазик: вимкнути налаштування зони (показати «до»), повторний клік — повернути"""
    bl_idname = "thuma.eye"
    bl_label = "Порівняти до/після"
    bl_options = {'REGISTER', 'UNDO'}
    key: bpy.props.StringProperty()
    names: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, props):
        mat = _current()
        if mat and mat.get(f"tc_eye_{props.key}"):
            return "Повернути налаштування цієї зони (зараз показано «до»)"
        return ("Тимчасово вимкнути ВЕСЬ пульт цієї тканини — порівняти до/після" if props.key == "__ALL__"
                else "Тимчасово вимкнути налаштування цієї зони — порівняти до/після. Ще клік — повернути")

    def execute(self, context):
        import json
        mat = _current(); node = _look_node(mat)
        if not node:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        prop = f"tc_eye_{self.key}"
        if mat.get(prop):                                  # повернути
            stash = json.loads(mat[prop])
            for name, v in stash.items():
                sock = node.inputs.get(name)
                if sock is None or sock.is_linked:
                    continue
                cur = sock.default_value
                d = defaults.get(name)
                # якщо поки «око» було вимкнене, користувач змінив повзунок — лишаємо його нове значення
                same = (abs(cur - d) < 1e-6) if isinstance(d, (int, float)) and isinstance(cur, (int, float)) else True
                if same:
                    sock.default_value = v
            del mat[prop]
        else:                                               # вимкнути: запам'ятати і поставити стандартні
            only = None if self.key == "__ALL__" else set(self.names.split("|"))
            stash = {}
            for sock in node.inputs:
                if sock.name == "Колір" or sock.is_linked or sock.name not in defaults or sock.name == "Показати зони":
                    continue
                if only is not None and sock.name not in only:
                    continue
                v = sock.default_value
                if hasattr(v, "__len__"):
                    continue
                stash[sock.name] = v
                sock.default_value = defaults[sock.name]
            mat[prop] = json.dumps(stash, ensure_ascii=False)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# кольори = як у «Показати зони» FABRIC LOOK (приглушені значки колекцій)
_ZONE_ICON = {
    "Спинка": 'COLLECTION_COLOR_05', "Сидіння": 'COLLECTION_COLOR_04',
    "Боковина внутр. ліва": 'COLLECTION_COLOR_07', "Боковина внутр. права": 'COLLECTION_COLOR_06',
    "Боковина зовн. ліва": 'COLLECTION_COLOR_02', "Боковина зовн. права": 'COLLECTION_COLOR_08',
    "Верх": 'COLLECTION_COLOR_03', "Фронт": 'COLLECTION_COLOR_01', "Задня стінка": 'COLORSET_07_VEC',
    "Вся тканина": 'MATERIAL', "Кутик": 'MOD_LINEART',
}
_PANEL_ICON = {"Шви": 'MOD_EDGESPLIT', "Загальне": 'MATERIAL', "Перевірка і плавність": 'HIDE_OFF', "Кутик біля підлокітника": 'MOD_LINEART'}


# ── Дерево: перемикач порід по одній (вузол WOOD у Thuma_Wood_Finger-Joints_4K = 1..5) ─────────────
# Сам вузол Value крокує стрілками по 0.1 — тут список назв, що ставить рівно 1..5. Торці йдуть за ним драйвером.
WOOD_MAT = "Thuma_Wood_Finger-Joints_4K"
WOODS = [("1", "Natural", "Порода 1 — Natural"), ("2", "Oak", "Порода 2 — Oak"), ("3", "Walnut", "Порода 3 — Walnut"),
         ("4", "Espresso", "Порода 4 — Espresso"), ("5", "Grey", "Порода 5 — Grey")]
_WOOD_ITEMS = [(k, n, d, 'NODE_MATERIAL', i) for i, (k, n, d) in enumerate(WOODS)]


def _wood_node():
    m = bpy.data.materials.get(WOOD_MAT)
    return m.node_tree.nodes.get("WOOD") if m and m.node_tree else None


def _wood_get(self):
    n = _wood_node()
    if not n:
        return 0
    return min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)


def _wood_set(self, value):
    n = _wood_node()
    if n:
        n.outputs[0].default_value = float(value + 1)
        for a in bpy.context.screen.areas if bpy.context.screen else []:
            a.tag_redraw()


def register():
    bpy.types.Scene.thuma_fabric_pick = bpy.props.EnumProperty(
        name="Тканина", items=_items, get=_get, set=_set,
        description="Яку тканину поставити на всю оббивку (12 мешів). Матеріал стає в слот — його видно в Shader Editor")
    bpy.types.Scene.thuma_wood_pick = bpy.props.EnumProperty(
        name="Дерево", items=_WOOD_ITEMS, get=_wood_get, set=_wood_set,
        description="Порода дерева (вузол WOOD основного матеріалу дерева: рівно 1-5). Торці перемикаються разом")
    bpy.utils.register_class(THUMA_OT_kutik_paint)
    bpy.utils.register_class(THUMA_Zone)
    bpy.types.Mesh.thuma_zones = bpy.props.CollectionProperty(type=THUMA_Zone)
    bpy.utils.register_class(THUMA_OT_zone)
    bpy.utils.register_class(THUMA_OT_reset)
    bpy.utils.register_class(THUMA_OT_eye)
    bpy.utils.register_class(THUMA_OT_seam_off)
    bpy.utils.register_class(THUMA_OT_parts_mask)
    bpy.utils.register_class(THUMA_PT_fabric)


def unregister():
    bpy.utils.unregister_class(THUMA_PT_fabric)
    bpy.utils.unregister_class(THUMA_OT_kutik_paint)
    bpy.utils.unregister_class(THUMA_OT_zone)
    bpy.utils.unregister_class(THUMA_OT_reset)
    bpy.utils.unregister_class(THUMA_OT_eye)
    bpy.utils.unregister_class(THUMA_OT_seam_off)
    bpy.utils.unregister_class(THUMA_OT_parts_mask)
    del bpy.types.Mesh.thuma_zones
    bpy.utils.unregister_class(THUMA_Zone)
    del bpy.types.Scene.thuma_fabric_pick
    del bpy.types.Scene.thuma_wood_pick
