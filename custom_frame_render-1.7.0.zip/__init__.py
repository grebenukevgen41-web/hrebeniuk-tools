bl_info = {
    "name":        "Custom Frame Render",
    "author":      "Hrebeniuk Tools",
    "version":     (1, 7, 0),
    "blender":     (4, 2, 0),
    "location":    "3D Viewport › N-Panel › CFRender",
    "description": "Рендер вибраних кадрів + неймінг + маски WireColor + DPI",
    "category":    "Render",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


import bpy
import os
import re
import csv
import io
import time
import struct
import zlib
import urllib.request
from bpy.props import (StringProperty, EnumProperty, IntProperty,
                       BoolProperty, PointerProperty, CollectionProperty)
from bpy.types import Panel, Operator, PropertyGroup, UIList

# ─────────────────────────────────────────────────────────────────────────────
#  GLOBALS
# ─────────────────────────────────────────────────────────────────────────────

_queue           = []     # [(frame, task, target_path)]
_total           = 0
_done_count      = 0
_skipped         = 0
_orig_frame      = 0
_orig_output     = ''
_orig_fstart     = 1
_orig_fend       = 1
_orig_fstep      = 1
_conflict_action    = 'VERSION'
_is_rendering       = False
_beauty_target_path = ''
_next_render_at     = 0.0
_render_in_progress = False   # True тільки між _start_one_frame і render_complete
_frame_start_time   = 0.0
_session_start_time = 0.0
_frame_times        = []      # час рендеру кожного завершеного кадру (для ETA)
_dpi                = 0

TASK_LABEL  = {"BEAUTY": "Beauty", "OBJ": "Маска об'єктів", "FACE": "Маска полігонів", "MAT": "Маска матеріалів"}
MASK_SUFFIX = {"OBJ": "_mask_obj", "FACE": "_mask_face", "MAT": "_mask_mat"}
MASK_OP     = {"OBJ": "render_obj_mask", "FACE": "render_face_mask", "MAT": "render_mat_mask"}


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _parse_frames(text):
    frames = set()
    for part in text.replace(' ', '').split(','):
        if not part:
            continue
        if '-' in part:
            a, _, b = part.partition('-')
            try:
                frames.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        else:
            try:
                frames.add(int(part))
            except ValueError:
                pass
    return sorted(frames)


def _compact_ranges(frames):
    """[1,2,3,5,7,8] → '1-3, 5, 7-8'."""
    out, i = [], 0
    while i < len(frames):
        j = i
        while j + 1 < len(frames) and frames[j + 1] == frames[j] + 1:
            j += 1
        out.append(str(frames[i]) if i == j else f"{frames[i]}-{frames[j]}")
        i = j + 1
    return ", ".join(out)


def _wirecolor_ok():
    return (hasattr(bpy.ops, 'wirecolor') and
            hasattr(bpy.ops.wirecolor, 'render_obj_mask') and
            hasattr(bpy.ops.wirecolor, 'render_mat_mask'))


def _shot_list_ok(scene):
    sl = getattr(scene, "shot_list", None)
    return bool(sl and len(sl.shots) and hasattr(bpy.ops, "shot_list")
                and hasattr(bpy.ops.shot_list, "to_cfrender"))


def _get_render_ext(scene):
    return {
        'PNG': '.png', 'JPEG': '.jpg', 'JPEG2000': '.jp2',
        'OPEN_EXR': '.exr', 'OPEN_EXR_MULTILAYER': '.exr',
        'TIFF': '.tif', 'BMP': '.bmp', 'HDR': '.hdr',
    }.get(scene.render.image_settings.file_format, '.png')


def _get_output_dir(props, scene):
    if props.use_custom_output and props.output_path:
        return bpy.path.abspath(props.output_path)
    fp = bpy.path.abspath(scene.render.filepath)
    return os.path.dirname(fp) or bpy.path.abspath('//')


def _get_frame_name(props, frame):
    if not props.use_name_map:
        return None
    for e in props.name_map:
        if e.frame == frame:
            n = e.name.strip()
            return n or None
    return None


def _versioned_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    for i in range(1, 100):
        p = f"{base}_V{i:02d}{ext}"
        if not os.path.exists(p):
            return p
    return path


def _frame_base(props, scene, frame):
    """Шлях без розширення: <папка>/<ім'я з таблиці або 0001>."""
    name = _get_frame_name(props, frame) or f"{frame:04d}"
    return os.path.join(_get_output_dir(props, scene), name)


def _mask_ext(scene):
    # так само, як WireColor обирає розширення маски
    ext = _get_render_ext(scene)
    return ext if ext in ('.png', '.jpg', '.exr', '.tif') else '.png'


def _target_path(props, scene, frame, task):
    base = _frame_base(props, scene, frame)
    if task == 'BEAUTY':
        return base + _get_render_ext(scene)
    return base + MASK_SUFFIX[task] + _mask_ext(scene)


def _fmt_time(seconds):
    s = int(seconds)
    if s < 60:
        return f"{s} с"
    if s < 3600:
        return f"{s // 60} хв {s % 60:02d} с"
    return f"{s // 3600} год {s % 3600 // 60:02d} хв"


# ── DPI у PNG (чистий Python, як у BlenderFarm) ──────────────────────────────

_PNG_SIG = b'\x89PNG\r\n\x1a\n'


def _png_chunk(chunk_type, data):
    c = chunk_type + data
    return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF)


def set_png_dpi(path, dpi):
    """Записати DPI у PNG (чанк pHYs). Повертає True, якщо вдалося."""
    try:
        with open(path, 'rb') as f:
            data = f.read()
        if not data.startswith(_PNG_SIG):
            return False
        ppm = round(dpi / 0.0254)
        out, pos, done = bytearray(_PNG_SIG), 8, False
        while pos + 8 <= len(data):
            length = struct.unpack('>I', data[pos:pos + 4])[0]
            ctype  = data[pos + 4:pos + 8]
            cdata  = data[pos + 8:pos + 8 + length]
            pos   += 12 + length
            if ctype == b'pHYs':
                continue
            out += _png_chunk(ctype, cdata)
            if ctype == b'IHDR' and not done:
                out += _png_chunk(b'pHYs', struct.pack('>IIB', ppm, ppm, 1))
                done = True
        if not done:
            return False
        with open(path, 'wb') as f:
            f.write(out)
        return True
    except Exception as e:
        print(f"CFRender DPI: {path}: {e}")
        return False


def _apply_dpi(path):
    if _dpi > 0 and path and path.lower().endswith('.png') and os.path.exists(path):
        set_png_dpi(path, _dpi)


# ── Google Sheets ────────────────────────────────────────────────────────────

def _sheets_to_csv_url(url):
    m = re.search(r'/spreadsheets/d/([a-zA-Z0-9_-]+)', url)
    if not m:
        return None
    gid_m = re.search(r'[#&?]gid=(\d+)', url)
    gid   = gid_m.group(1) if gid_m else '0'
    return f"https://docs.google.com/spreadsheets/d/{m.group(1)}/export?format=csv&gid={gid}"


def _fetch_sheets_entries(url):
    csv_url = _sheets_to_csv_url(url)
    if not csv_url:
        raise ValueError("Не вдалося розпізнати посилання на Google Sheets")
    req = urllib.request.Request(csv_url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        content = resp.read().decode('utf-8')
    entries = []
    for row in csv.reader(io.StringIO(content)):
        if len(row) < 2:
            continue
        try:
            frame = int(row[0].strip())
            name  = row[1].strip()
            if name:
                entries.append((frame, name))
        except ValueError:
            continue
    return entries


# ─────────────────────────────────────────────────────────────────────────────
#  RENDER ENGINE  (timer + handler chain, no modal)
# ─────────────────────────────────────────────────────────────────────────────

def _redraw():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in ('VIEW_3D', 'PROPERTIES'):
                    area.tag_redraw()
    except Exception:
        pass


def _set_status(text):
    try:
        bpy.context.scene.cfrender_props.render_status = text
    except Exception:
        pass
    _redraw()


def _cleanup(scene=None):
    """Повернути сцену як було (кадр, шлях виводу, діапазон) і зняти прапорці."""
    global _is_rendering, _render_in_progress, _next_render_at
    _is_rendering       = False
    _render_in_progress = False
    _next_render_at     = 0.0
    _queue.clear()
    s = scene or (bpy.context.scene if bpy.context else None)
    if s:
        try:
            s.frame_set(_orig_frame)
            s.render.filepath = _orig_output
            s.frame_start = _orig_fstart
            s.frame_end   = _orig_fend
            s.frame_step  = _orig_fstep
            s.cfrender_props.is_rendering = False
        except Exception as e:
            print(f"CFRender cleanup: {e}")
    _redraw()


def _finish(scene, stopped=False):
    total = _fmt_time(time.time() - _session_start_time)
    done  = _done_count
    msg   = (f"Зупинено: готово {done} з {_total}" if stopped
             else f"Готово: {done} з {_total}  ·  {total}")
    if _skipped:
        msg += f"  ·  пропущено готових: {_skipped}"
    _set_status(msg)
    _cleanup(scene)


def _start_one_frame(scene, frame, task, target):
    """Стартує рендер одного кадру (асинхронно) або маски (синхронно)."""
    global _beauty_target_path, _frame_start_time, _render_in_progress

    _frame_start_time = time.time()
    scene.frame_set(frame)
    status = f"{TASK_LABEL[task]} · кадр {frame}  ({_done_count + 1}/{_total})"
    if _frame_times:
        avg = sum(_frame_times) / len(_frame_times)
        status += f"  ·  лишилось ~{_fmt_time(avg * (len(_queue) + 1))}"
    _set_status(status)

    if _conflict_action == 'VERSION':
        target = _versioned_path(target)
    elif _conflict_action == 'REPLACE' and task != 'BEAUTY' and os.path.exists(target):
        os.remove(target)          # інакше WireColor сам додасть _V01
    os.makedirs(os.path.dirname(target), exist_ok=True)

    if task == 'BEAUTY':
        _beauty_target_path = target
        _render_in_progress = True
        # Рендер у вікно без запису — зберігає render_complete (save_render)
        win = bpy.context.window_manager.windows[0]
        with bpy.context.temp_override(window=win):
            bpy.ops.render.render('INVOKE_DEFAULT')
        return

    # Маска: WireColor бере шлях з scene.render.filepath і додає суфікс
    props = scene.cfrender_props
    scene.render.filepath = _frame_base(props, scene, frame) + _get_render_ext(scene)
    orig_compress = scene.render.image_settings.compression
    scene.render.image_settings.compression = 0
    try:
        getattr(bpy.ops.wirecolor, MASK_OP[task])()
    finally:
        scene.render.image_settings.compression = orig_compress
        scene.render.filepath = _orig_output
    _apply_dpi(target)
    _mark_done()


def _mark_done():
    global _done_count
    _done_count += 1
    _frame_times.append(time.time() - _frame_start_time)


def _run_next():
    """Взяти наступне завдання. Повертає інтервал таймера або None."""
    scene = bpy.context.scene
    if not _is_rendering or not scene:
        return None
    if not _queue:
        _finish(scene)
        return None
    frame, task, target = _queue.pop(0)
    try:
        _start_one_frame(scene, frame, task, target)
    except Exception as e:
        print(f"CFRender: кадр {frame} {task}: {e}")
        _set_status(f"Помилка на кадрі {frame}: {e}")
        _cleanup(scene)
        return None
    if task != 'BEAUTY':
        return 0.05          # маска синхронна — одразу наступне (UI встигає оновитись)
    return None              # beauty — далі веде render_complete → _poll_render


def _poll_render():
    """Після render_complete чекає 0.5 с (Blender звільняє Render Result) і стартує наступне."""
    global _next_render_at
    if not _is_rendering:
        return None
    if _next_render_at > 0 and time.time() >= _next_render_at:
        _next_render_at = 0.0
        bpy.app.timers.register(_run_next, first_interval=0.01)
    return 0.1


@bpy.app.handlers.persistent
def _cfrender_complete(scene, depsgraph=None):
    """render_complete → зберігаємо файл → плануємо наступне."""
    global _beauty_target_path, _next_render_at, _render_in_progress
    if not _is_rendering or not _render_in_progress:
        return            # чужий рендер (напр. звичайний F12)
    _render_in_progress = False
    if _beauty_target_path:
        img = bpy.data.images.get('Render Result')
        if img:
            try:
                img.save_render(_beauty_target_path, scene=scene)
                _apply_dpi(_beauty_target_path)
            except Exception as e:
                print(f"CFRender save: {e}")
        _beauty_target_path = ''
    _mark_done()
    _next_render_at = time.time() + 0.5


@bpy.app.handlers.persistent
def _cfrender_cancel(scene, depsgraph=None):
    """Esc під час рендеру — зупиняємо чергу і повертаємо сцену (після завершення рендеру)."""
    if not _is_rendering:
        return
    _queue.clear()

    def _later():
        _finish(bpy.context.scene, stopped=True)
        return None
    bpy.app.timers.register(_later, first_interval=0.3)


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

class CFRenderNameEntry(PropertyGroup):
    frame: IntProperty(description="Номер кадру", name="Кадр", default=1, min=0)
    name:  StringProperty(description="Ім'я файлу (без розширення)", name="Ім'я", default="")


class CFRenderPreset(PropertyGroup):
    frames: StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Кадри", default="1")


def _preset_index_update(self, context):
    idx = self.preset_index
    if self.presets and idx < len(self.presets):
        p = self.presets[idx]
        self.preset_name   = p.name
        self.preset_frames = p.frames


def _nm_index_update(self, context):
    idx = self.name_map_index
    if self.name_map and idx < len(self.name_map):
        e = self.name_map[idx]
        self.new_nm_frame = e.frame
        self.new_nm_name  = e.name


class CFRenderProps(PropertyGroup):
    do_beauty: BoolProperty(name="Beauty", default=True,
                            description="Рендерити звичайні кадри (Cycles, як у сцені)")
    do_masks:  BoolProperty(name="Маски", default=False,
                            description="Рендерити маски WireColor (швидко, Workbench)")
    beauty_frames: StringProperty(name="Кадри", default="1",
                                  description="Які кадри рендерити: 1, 5, 10-20, 50")
    masks_same_frames: BoolProperty(name="Ті ж кадри", default=True,
                                    description="Маски для тих самих кадрів, що й Beauty")
    mask_frames:   StringProperty(name="Кадри масок", default="1",
                                  description="Кадри для масок: 1, 5, 10-20, 50")
    mask_type: EnumProperty(name="Маски", default='BOTH',
                            description="Які маски рендерити", items=[
        ('OBJ',  "Об'єкти",            "Тільки маска об'єктів (_mask_obj)"),
        ('FACE', "Полігони",           "Тільки маска полігонів (_mask_face)"),
        ('MAT',  "Матеріали",          "Тільки маска матеріалів (_mask_mat)"),
        ('BOTH', "Об'єкти + полігони", "Маски об'єктів і полігонів"),
        ('ALL',  "Усі три",            "Маски об'єктів, полігонів і матеріалів"),
    ])
    conflict_mode: EnumProperty(name="Якщо файл уже є", default='ASK',
                                description="Що робити, коли файл кадру вже існує в папці", items=[
        ('ASK',     "Питати",         "Перед стартом показати список і спитати"),
        ('SKIP',    "Пропустити",     "Не рендерити готові — зручно, щоб дорендерити після збою"),
        ('VERSION', "Нова версія",    "Зберегти поруч як _V01, _V02 …"),
        ('REPLACE', "Замінити",       "Перезаписати існуючі файли"),
    ])
    dpi: IntProperty(name="DPI", default=300, min=0, max=2400,
                     description="Записати DPI у PNG (Beauty і маски). 0 — не чіпати")
    presets_expanded: BoolProperty(default=False)
    use_custom_output: BoolProperty(name="Своя папка", default=False,
                                    description="Зберігати рендери у свою папку замість шляху з Output Properties")
    output_path: StringProperty(name="Папка", default="", subtype='DIR_PATH',
                                description="Папка для рендерів")
    sheets_url:  StringProperty(name="Google Sheets", default="",
                                description="Посилання на Google Sheets (доступ: Anyone with link). Колонки: кадр, ім'я")
    use_name_map: BoolProperty(name="Імена файлів", default=False,
                               description="Називати файли за таблицею «кадр → ім'я» (кадри без імені пропускаються)")
    name_map:       CollectionProperty(type=CFRenderNameEntry)
    name_map_index: IntProperty(default=0, min=0, update=_nm_index_update)
    new_nm_frame:   IntProperty(description="Кадр", name="Кадр", default=1, min=0)
    new_nm_name:    StringProperty(description="Ім'я файлу для цього кадру (без розширення)", name="Ім'я", default="")
    is_rendering:   BoolProperty(default=False)
    render_status:  StringProperty(default="")
    presets:        CollectionProperty(type=CFRenderPreset)
    preset_index:   IntProperty(default=0, min=0, update=_preset_index_update)
    preset_name:    StringProperty(description="Назва пресета", name="Назва", default="")
    preset_frames:  StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Кадри", default="")


# ─────────────────────────────────────────────────────────────────────────────
#  UILISTS
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_UL_presets(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.38)
        split.label(text=item.name)
        split.label(text=item.frames)


class CFRENDER_UL_namemap(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.22)
        split.label(text=str(item.frame))
        split.label(text=item.name)


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Presets
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_preset_save(Operator):
    bl_idname = "cfrender.preset_save"
    bl_description = "Зберегти пресет: назва + список кадрів (якщо така назва є — оновиться)"
    bl_label  = "Зберегти"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props  = context.scene.cfrender_props
        name   = props.preset_name.strip()
        frames = props.preset_frames.strip()
        if not name:
            self.report({'WARNING'}, "Введи назву"); return {'CANCELLED'}
        if not frames:
            self.report({'WARNING'}, "Введи кадри");  return {'CANCELLED'}
        existing = next((p for p in props.presets if p.name == name), None)
        if existing:
            existing.frames = frames
        else:
            p = props.presets.add()
            p.name = name; p.frames = frames
            props.preset_index = len(props.presets) - 1
        self.report({'INFO'}, f"Збережено: {name}")
        return {'FINISHED'}


class CFRENDER_OT_preset_remove(Operator):
    bl_idname = "cfrender.preset_remove"
    bl_description = "Видалити вибраний пресет"
    bl_label  = "Видалити пресет"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets): return {'CANCELLED'}
        props.presets.remove(idx)
        props.preset_index = max(0, idx - 1)
        return {'FINISHED'}


class CFRENDER_OT_preset_apply(Operator):
    bl_idname = "cfrender.preset_apply"
    bl_label  = "Підставити"
    bl_options = {'REGISTER'}
    target: EnumProperty(items=[('BEAUTY', "Beauty", ""), ('MASK', "Маски", "")], default='BEAUTY')

    @classmethod
    def description(cls, context, properties):
        return ("Підставити кадри пресета в поле кадрів Beauty" if properties.target == 'BEAUTY'
                else "Підставити кадри пресета в поле кадрів масок")

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets):
            self.report({'WARNING'}, "Виділи пресет"); return {'CANCELLED'}
        frames = props.presets[idx].frames
        if self.target == 'BEAUTY':
            props.beauty_frames = frames
        else:
            props.mask_frames = frames
            props.masks_same_frames = False
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Name Map / Shot List
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_from_shot_list(Operator):
    bl_idname      = "cfrender.from_shot_list"
    bl_label       = "Взяти кадри з Shot List"
    bl_description = ("Заповнити кадри та імена файлів з Shot List (тільки увімкнені шоти). "
                      "Маски — для тих самих кадрів")
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _shot_list_ok(context.scene)

    def execute(self, context):
        r = bpy.ops.shot_list.to_cfrender()
        if r != {'FINISHED'}:
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        props.masks_same_frames = True
        self.report({'INFO'}, f"З Shot List: {len(props.name_map)} кадрів")
        return {'FINISHED'}


class CFRENDER_OT_import_sheets(Operator):
    bl_idname  = "cfrender.import_sheets"
    bl_description = ("Завантажити / оновити з Google Sheets: кадри та імена файлів "
                      "(таблиця: кадр, ім'я; доступ Anyone with link). Поле «Кадри» заповниться всіма кадрами таблиці")
    bl_label   = "Завантажити таблицю"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        url   = props.sheets_url.strip()
        if not url:
            self.report({'ERROR'}, "Встав посилання на таблицю"); return {'CANCELLED'}
        try:
            entries = _fetch_sheets_entries(url)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        if not entries:
            self.report({'WARNING'}, "Таблиця порожня або формат не розпізнано (потрібно: кадр, ім'я)")
            return {'CANCELLED'}
        props.name_map.clear()
        for frame, name in entries:
            e = props.name_map.add()
            e.frame = frame; e.name = name
        props.name_map_index = 0
        props.use_name_map = True
        # кадри = всі кадри таблиці (можна потім звузити вручну)
        props.beauty_frames = _compact_ranges(sorted({f for f, _n in entries}))
        self.report({'INFO'}, f"Таблиця: {len(entries)} кадрів → {props.beauty_frames}")
        return {'FINISHED'}


class CFRENDER_OT_nm_add(Operator):
    bl_idname  = "cfrender.nm_add"
    bl_description = "Додати запис «кадр → ім'я» (якщо кадр вже є — оновить ім'я)"
    bl_label   = "Зберегти"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        frame = props.new_nm_frame
        name  = props.new_nm_name.strip()
        if not name:
            self.report({'WARNING'}, "Введи ім'я"); return {'CANCELLED'}
        existing = next((e for e in props.name_map if e.frame == frame), None)
        if existing:
            existing.name = name
        else:
            e = props.name_map.add()
            e.frame = frame; e.name = name
            props.name_map_index = len(props.name_map) - 1
        return {'FINISHED'}


class CFRENDER_OT_nm_remove(Operator):
    bl_idname  = "cfrender.nm_remove"
    bl_description = "Видалити вибраний запис з таблиці імен"
    bl_label   = "Видалити"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.name_map_index
        if not props.name_map or idx >= len(props.name_map): return {'CANCELLED'}
        props.name_map.remove(idx)
        props.name_map_index = max(0, idx - 1)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Render
# ─────────────────────────────────────────────────────────────────────────────

def _build_queue(props, scene, mode):
    """[(frame, task, target)] у порядку: по кадрах, у кожному кадрі beauty → маски."""
    want_beauty = mode in ('BEAUTY', 'ALL') and (mode != 'ALL' or props.do_beauty)
    want_masks  = mode in ('MASKS', 'ALL') and (mode != 'ALL' or props.do_masks) and _wirecolor_ok()
    b_frames = _parse_frames(props.beauty_frames) if want_beauty else []
    m_src    = props.beauty_frames if props.masks_same_frames else props.mask_frames
    m_frames = _parse_frames(m_src) if want_masks else []
    mtype    = props.mask_type
    mtasks   = [t for t, on in (('OBJ', mtype in ('OBJ', 'BOTH', 'ALL')),
                                ('FACE', mtype in ('FACE', 'BOTH', 'ALL')),
                                ('MAT', mtype in ('MAT', 'ALL'))) if on]
    queue = []
    for f in sorted(set(b_frames) | set(m_frames)):
        if props.use_name_map and not _get_frame_name(props, f):
            continue   # немає імені в таблиці — пропускаємо
        if f in b_frames:
            queue.append((f, 'BEAUTY', _target_path(props, scene, f, 'BEAUTY')))
        if f in m_frames:
            for t in mtasks:
                queue.append((f, t, _target_path(props, scene, f, t)))
    return queue


class CFRENDER_OT_render(Operator):
    bl_idname  = "cfrender.render"
    bl_label   = "Рендер"
    bl_options = {'REGISTER'}

    mode: EnumProperty(
        items=[('BEAUTY', "Beauty", ""), ('MASKS', "Маски", ""), ('ALL', "Усе вибране", "")],
        default='ALL',
    )
    conflict_action: EnumProperty(
        name="Дія",
        items=[
            ('SKIP',    "Пропустити готові",            "Рендерити тільки те, чого ще немає"),
            ('VERSION', "Нова версія  (_V01, _V02 …)",  "Зберегти поруч з новою версією"),
            ('REPLACE', "Замінити існуючі",             "Перезаписати файли"),
        ],
        default='SKIP',
    )
    _conflict_list = []

    @classmethod
    def description(cls, context, properties):
        return ("Рендер вибраних кадрів по черзі: кожен зберігається окремим файлом. "
                "Esc або ✕ — зупинити")

    def draw(self, context):
        layout = self.layout
        cls = self.__class__
        layout.label(text=f"Уже є файлів: {len(cls._conflict_list)}", icon='ERROR')
        col = layout.box().column(align=True)
        for p in cls._conflict_list[:7]:
            col.label(text=os.path.basename(p))
        if len(cls._conflict_list) > 7:
            col.label(text=f"… і ще {len(cls._conflict_list) - 7}")
        layout.separator(factor=0.5)
        layout.prop(self, "conflict_action", expand=True)

    def invoke(self, context, event):
        global _queue
        if _is_rendering:
            self.report({'WARNING'}, "Рендер вже йде")
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        if self.mode in ('MASKS', 'ALL') and (self.mode == 'MASKS' or props.do_masks) and not _wirecolor_ok():
            self.report({'ERROR'}, "Аддон WireColor Masks не встановлено")
            return {'CANCELLED'}
        _queue = _build_queue(props, context.scene, self.mode)
        if not _queue:
            self.report({'ERROR'}, "Немає кадрів для рендеру")
            return {'CANCELLED'}
        conflicts = [t for _f, _t, t in _queue if os.path.exists(t)]
        if conflicts and props.conflict_mode == 'ASK':
            self.__class__._conflict_list = conflicts
            return context.window_manager.invoke_props_dialog(self, width=420, confirm_text="Рендер")
        self.conflict_action = props.conflict_mode if props.conflict_mode != 'ASK' else 'VERSION'
        return self.execute(context)

    def execute(self, context):
        global _is_rendering, _orig_frame, _orig_output, _total, _done_count, _skipped, _dpi
        global _orig_fstart, _orig_fend, _orig_fstep, _session_start_time, _next_render_at
        global _frame_times, _render_in_progress, _conflict_action, _queue

        if _is_rendering:
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        sc = context.scene
        if not _queue:      # виклик без invoke (скрипт)
            _queue = _build_queue(props, sc, self.mode)
        _conflict_action = self.conflict_action
        _skipped = 0
        if _conflict_action == 'SKIP':
            before = len(_queue)
            _queue = [q for q in _queue if not os.path.exists(q[2])]
            _skipped = before - len(_queue)
        if not _queue:
            props.render_status = f"Усе вже готово (пропущено {_skipped})"
            return {'FINISHED'}

        _is_rendering   = True
        _orig_frame     = sc.frame_current
        _orig_fstart    = sc.frame_start
        _orig_fend      = sc.frame_end
        _orig_fstep     = sc.frame_step
        _orig_output    = sc.render.filepath
        _dpi            = props.dpi
        _total              = len(_queue)
        _done_count         = 0
        _session_start_time = time.time()
        _next_render_at     = 0.0
        _frame_times        = []
        _render_in_progress = False

        props.is_rendering  = True
        props.render_status = f"Старт… (0/{_total})"
        bpy.app.timers.register(_run_next, first_interval=0.1)
        if not bpy.app.timers.is_registered(_poll_render):
            bpy.app.timers.register(_poll_render, first_interval=0.2)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Stop
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_clear_status(Operator):
    bl_idname      = "cfrender.clear_status"
    bl_label       = "Сховати статус"
    bl_description = "Прибрати рядок статусу"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        props = context.scene.cfrender_props
        props.render_status = ""
        if not _is_rendering:
            props.is_rendering = False
        return {'FINISHED'}


class CFRENDER_OT_stop(Operator):
    bl_idname      = "cfrender.stop"
    bl_label       = "Зупинити"
    bl_description = "Зупинити чергу рендеру і повернути сцену як було"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        _queue.clear()
        try:
            bpy.ops.render.view_cancel()
        except Exception:
            pass
        _finish(context.scene, stopped=True)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_PT_panel(Panel):
    bl_label       = "Custom Frame Render"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "CFRender"

    def draw_header_preset(self, context):
        self.layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        props  = scene.cfrender_props
        wc_ok  = _wirecolor_ok()

        # ── СТАТУС ────────────────────────────────────────────
        if props.is_rendering or props.render_status:
            box = layout.box()
            row = box.row(align=True)
            row.alert = props.is_rendering
            row.label(text=props.render_status, icon='RENDER_STILL')
            if props.is_rendering:
                row.operator("cfrender.stop", text="", icon='CANCEL')
            else:
                row.operator("cfrender.clear_status", text="", icon='X')

        # ── ТАБЛИЦЯ (основний спосіб: кадр → ім'я з Google Sheets) ──
        box = layout.box()
        row = box.row(align=True)
        row.prop(props, "sheets_url", text="", icon='URL')
        row.operator("cfrender.import_sheets", text="", icon='FILE_REFRESH')
        if props.use_name_map and len(props.name_map):
            box.label(text=f"Таблиця: {len(props.name_map)} кадрів з іменами", icon='CHECKMARK')
        elif props.sheets_url.strip():
            box.label(text="Натисни ↻, щоб завантажити таблицю", icon='INFO')
        if _shot_list_ok(scene):
            box.operator("cfrender.from_shot_list", icon='SEQUENCE')

        # ── ЩО РЕНДЕРИТИ ─────────────────────────────────────
        box = layout.box()

        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "do_beauty", text="Beauty", toggle=True, icon='RENDER_STILL')
        sub = row.row(align=True)
        sub.enabled = wc_ok
        sub.prop(props, "do_masks", text="Маски", toggle=True, icon='IMAGE_DATA')
        col.prop(props, "beauty_frames", text="Кадри")

        if props.do_masks:
            mb = box.column(align=True)
            if not wc_ok:
                mb.label(text="WireColor Masks не встановлено", icon='ERROR')
            mb.prop(props, "mask_type", text="")
            mb.prop(props, "masks_same_frames")
            if not props.masks_same_frames:
                mb.prop(props, "mask_frames", text="Кадри масок")

        row = box.row()
        row.scale_y = 1.5
        row.enabled = not props.is_rendering and (props.do_beauty or (props.do_masks and wc_ok))
        row.operator("cfrender.render", icon='RENDER_ANIMATION').mode = 'ALL'

        # ── ЗБЕРЕЖЕННЯ ───────────────────────────────────────
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "use_custom_output")
        if props.use_custom_output:
            col.prop(props, "output_path", text="")
        col.separator(factor=0.5)
        col.prop(props, "conflict_mode", text="Якщо файл є")
        col.prop(props, "dpi")

        # ── ІМЕНА ФАЙЛІВ ─────────────────────────────────────
        header, body = layout.panel("cfrender_names", default_closed=True)
        header.prop(props, "use_name_map", text="Імена файлів (перегляд / правка)")
        if body:
            body.enabled = props.use_name_map
            body.template_list("CFRENDER_UL_namemap", "", props, "name_map",
                               props, "name_map_index", rows=4)
            col = body.column(align=True)
            row = col.row(align=True)
            row.prop(props, "new_nm_frame", text="Кадр")
            row.prop(props, "new_nm_name",  text="Ім'я")
            row = col.row(align=True)
            row.operator("cfrender.nm_add",    icon='FILE_TICK')
            row.operator("cfrender.nm_remove", icon='TRASH')

        # ── ПРЕСЕТИ КАДРІВ ───────────────────────────────────
        header, body = layout.panel("cfrender_presets", default_closed=True)
        header.label(text="Пресети кадрів", icon='PRESET')
        if body:
            body.template_list("CFRENDER_UL_presets", "", props, "presets",
                               props, "preset_index", rows=3)
            col = body.column(align=True)
            col.prop(props, "preset_name")
            col.prop(props, "preset_frames")
            row = col.row(align=True)
            row.operator("cfrender.preset_save", icon='FILE_TICK')
            row.operator("cfrender.preset_remove", text="", icon='TRASH')
            row = col.row(align=True)
            row.operator("cfrender.preset_apply", text="→ Beauty", icon='RENDER_STILL').target = 'BEAUTY'
            row.operator("cfrender.preset_apply", text="→ Маски",  icon='IMAGE_DATA').target = 'MASK'


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    CFRenderNameEntry,
    CFRenderPreset,
    CFRenderProps,
    CFRENDER_UL_presets,
    CFRENDER_UL_namemap,
    CFRENDER_OT_preset_save,
    CFRENDER_OT_preset_remove,
    CFRENDER_OT_preset_apply,
    CFRENDER_OT_from_shot_list,
    CFRENDER_OT_import_sheets,
    CFRENDER_OT_nm_add,
    CFRENDER_OT_nm_remove,
    CFRENDER_OT_render,
    CFRENDER_OT_clear_status,
    CFRENDER_OT_stop,
    CFRENDER_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cfrender_props = PointerProperty(type=CFRenderProps)
    if _cfrender_complete not in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.append(_cfrender_complete)
    if _cfrender_cancel not in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.append(_cfrender_cancel)


def unregister():
    if _cfrender_complete in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(_cfrender_complete)
    if _cfrender_cancel in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(_cfrender_cancel)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.cfrender_props


if __name__ == "__main__":
    register()
