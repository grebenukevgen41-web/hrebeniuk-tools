bl_info = {
    "name": "Seam Shadow Painter",
    "author": "Claude",
    "version":     (3, 39, 2),
    "blender": (4, 0, 0),
    "location": "View3D > N-Panel > Seam Shadow",
    "description": "Per-object seam shadows + gradient painter",
    "category": "Mesh",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


import bpy
import bmesh
import heapq
import json
import os
from bpy_extras.io_utils import ExportHelper, ImportHelper

LOG_PATH              = os.path.join(os.path.expanduser("~"), "Desktop", "seam_shadow_log.txt")
_FALLBACK_PRESETS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "seam_presets.json")

def log(msg):
    print(msg)
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(msg + '\n')
    except Exception:
        pass

_SENTINEL = 1.0


# ─── helpers ──────────────────────────────────────────────────────────────────

def _get_obj_layers(obj):
    return obj.seam_layers if (obj and hasattr(obj, 'seam_layers')) else []

def _get_obj_idx(obj):
    return obj.seam_layer_active if (obj and hasattr(obj, 'seam_layer_active')) else 0

def _next_attr_name(layers):
    used = set()
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            for l in obj.seam_layers:
                used.add(l.attr_name)
    i = 0
    while f"ss_{i}" in used:
        i += 1
    return f"ss_{i}"


def _find_principled(mat):
    if not (mat and mat.use_nodes):
        return None, None

    def _search(tree, depth=0):
        if depth > 6:
            return None, None
        p = next((n for n in tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if p:
            return tree, p
        for n in tree.nodes:
            if n.type == 'GROUP' and n.node_tree:
                t, p = _search(n.node_tree, depth + 1)
                if p:
                    return t, p
        return None, None

    return _search(mat.node_tree)


def _bypass_seam_node(tree, n):
    """З'єднати те, що входить у шов (основний «прохідний» вхід), з усім, куди шов виходить."""
    role = n.get('ss_role')
    if role == 'ss_group' or (n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith('SS_')):
        src_in = n.inputs[0] if len(n.inputs) else None
    elif role == 'mix' or n.type in ('MIX_RGB', 'MIX_SHADER'):
        src_in = n.inputs[1] if len(n.inputs) > 1 else None     # Color1 / перший Shader
    else:
        return
    if src_in is None or not src_in.is_linked:
        return
    src = src_in.links[0].from_socket
    for out in n.outputs:
        for lnk in list(out.links):
            dst = lnk.to_socket
            try:
                tree.links.new(src, dst)
            except Exception:
                pass


def _clean_seam_nodes(tree):
    OLD_TAGS = ('ss_layer', 'ss_role', 'seam_shadow_node')
    def _is_seam_node(n):
        if any(n.get(t) is not None for t in OLD_TAGS):
            return True
        # Fallback for nodes from older versions that predate current tagging —
        # matched by label/node_tree naming convention instead of custom props.
        if n.label and n.label.startswith('Seam:'):
            return True
        if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith('SS_ss_'):
            return True
        return False
    to_rm = [n for n in tree.nodes if _is_seam_node(n)]
    # Перед видаленням «прокидаємо» вхід шва на його виходи: текстура, що йшла
    # через ланцюг швів у Base Color / Material Output, лишається підключеною.
    # Без цього Rebuild видаляв старий ланцюг Mix (Legacy) всередині групи
    # тканини і Base Color ставав білим (дефолт).
    for n in to_rm:
        _bypass_seam_node(tree, n)
    for n in to_rm:
        if n.type == 'GROUP' and n.node_tree:
            ng = n.node_tree
            tree.nodes.remove(n)
            try:
                if ng.users == 0:
                    bpy.data.node_groups.remove(ng)
            except Exception:
                pass
        else:
            tree.nodes.remove(n)
    # Recurse into non-seam GROUP nodes only
    for n in list(tree.nodes):
        if n.type == 'GROUP' and n.node_tree and not _is_seam_node(n):
            _clean_seam_nodes(n.node_tree)


def _get_original_upstream(principled):
    base_in = principled.inputs['Base Color']
    if not base_in.is_linked:
        return None, tuple(base_in.default_value)
    sock = base_in.links[0].from_socket
    node = sock.node
    visited = set()
    while node.get('ss_role') == 'mix':
        if id(node) in visited:
            return None, tuple(node.inputs[1].default_value)
        visited.add(id(node))
        inp = node.inputs[1]
        if inp.is_linked:
            sock = inp.links[0].from_socket
            node = sock.node
        else:
            return None, tuple(inp.default_value)
    return sock, None


def _get_original_upstream_bsdf(mat_out):
    """Traverse back through ss seam nodes to find the original BSDF socket."""
    surf_in = mat_out.inputs['Surface']
    if not surf_in.is_linked:
        return None
    sock = surf_in.links[0].from_socket
    node = sock.node
    visited = set()
    while node.get('ss_role') in ('mix', 'ss_group'):
        if id(node) in visited:
            return None
        visited.add(id(node))
        # ss_group: input[0] is 'Shader'; mix (MixShader): input[1] is original BSDF
        inp = node.inputs[0] if node.get('ss_role') == 'ss_group' else node.inputs[1]
        if inp.is_linked:
            sock = inp.links[0].from_socket
            node = sock.node
        else:
            return None
    return sock


def _set_if_changed(sock, value):
    """Пише default_value тільки якщо воно реально інше — кожен зайвий запис
    змушує Blender оновлювати дерево нод (на повзунках це і давало лаги)."""
    cur = sock.default_value
    try:
        same = all(abs(a - b) < 1e-7 for a, b in zip(cur, value))
    except TypeError:
        same = abs(cur - value) < 1e-7
    if not same:
        sock.default_value = value


def _map_range_inputs(map_nd, half_width, falloff):
    if falloff == 'HARD':
        lo, hi, interp = _SENTINEL - half_width, _SENTINEL - half_width + 0.00005, 'LINEAR'
    elif falloff == 'SMOOTH_STEP':
        lo, hi, interp = _SENTINEL - half_width, _SENTINEL, 'SMOOTHSTEP'
    else:
        lo, hi, interp = _SENTINEL - half_width, _SENTINEL, 'LINEAR'
    _set_if_changed(map_nd.inputs[1], lo)
    _set_if_changed(map_nd.inputs[2], hi)
    # зміна interpolation_type = структурна зміна (перекомпіляція шейдера) — тільки якщо інша
    if map_nd.interpolation_type != interp:
        map_nd.interpolation_type = interp


def _node_feeds(src_node, target_socket, limit=400):
    """True якщо вихід src_node (напряму або через будь-які ноди) доходить до target_socket.
    Замінює стару перевірку «підключено напряму», яка вважала нижні шари шва
    «відпалими» і перепідключала їх — через це верхні шари випадали з ланцюга."""
    target_node = target_socket.node
    stack, seen = [src_node], set()
    while stack and len(seen) < limit:
        n = stack.pop()
        if n.as_pointer() in seen:
            continue
        seen.add(n.as_pointer())
        for out in n.outputs:
            for lnk in out.links:
                if not lnk.is_valid:
                    continue
                if lnk.to_socket == target_socket:
                    return True
                if lnk.to_node is not target_node:
                    stack.append(lnk.to_node)
    return False


def _rebuild_shader(mat, layers):
    tree, principled = _find_principled(mat)
    if principled is None:
        return False, "No Principled BSDF found"

    in_group = (tree != mat.node_tree)

    # For top-level approach: capture original BSDF socket BEFORE cleaning
    orig_bsdf_sock = None
    if in_group:
        mat_out = next((n for n in mat.node_tree.nodes if n.type == 'OUTPUT_MATERIAL'
                        and n.is_active_output), None) or \
                  next((n for n in mat.node_tree.nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if mat_out:
            orig_bsdf_sock = _get_original_upstream_bsdf(mat_out)

    _clean_seam_nodes(mat.node_tree)

    if not layers:
        # Restore Material Output connection if we broke it
        if in_group and orig_bsdf_sock and mat_out:
            mat.node_tree.links.new(orig_bsdf_sock, mat_out.inputs['Surface'])
        _force_mat_update(mat, mat.node_tree)
        return True, "0 layer(s) applied"

    if in_group:
        # Restore original connection so _ensure_layer_top_level can chain from it
        if orig_bsdf_sock and mat_out:
            mat.node_tree.links.new(orig_bsdf_sock, mat_out.inputs['Surface'])
        active_layers = [l for l in layers
                         if l.material_name == mat.name or not l.material_name]
        for layer in active_layers:
            _ensure_layer_top_level(mat, layer, layer.attr_name)
        _force_mat_update(mat, mat.node_tree)
        return True, f"{len(active_layers)} layer(s) applied (top-level)"
    else:
        # Original approach: MixRGB on Base Color
        up_sock, base_default = _get_original_upstream(principled)
        nodes = tree.nodes
        links = tree.links
        px = principled.location.x - 700
        py = principled.location.y

        active_layers = [l for l in layers
                         if l.material_name == mat.name or not l.material_name]
        prev_color_sock = up_sock

        for i, layer in enumerate(active_layers):
            y = py - i * 220
            a = layer.attr_name

            def mk(tp, xo, yo, role, lbl="", _y=y, _a=a):
                nd = nodes.new(tp)
                nd.location    = (px + xo, _y + yo)
                nd['ss_layer'] = _a
                nd['ss_role']  = role
                if lbl:
                    nd.label = lbl
                return nd

            attr_nd = mk('ShaderNodeAttribute', 0, -60, 'attr', f"{layer.name}: dist")
            attr_nd.attribute_name = a
            attr_nd.attribute_type = 'GEOMETRY'

            map_nd = mk('ShaderNodeMapRange', 220, -60, 'map_range', f"{layer.name}: falloff")
            map_nd.clamp = True
            map_nd.inputs[3].default_value = 0.0
            map_nd.inputs[4].default_value = 1.0
            _map_range_inputs(map_nd, layer.width / 2.0, layer.falloff)

            str_nd = mk('ShaderNodeMath', 420, -60, 'strength', f"{layer.name}: str")
            str_nd.operation = 'MULTIPLY'
            str_nd.inputs[1].default_value = layer.strength

            ena_attr = mk('ShaderNodeAttribute', 500, -160, 'ena_attr', f"{layer.name}: enabled")
            ena_attr.attribute_type = 'OBJECT'
            ena_attr.attribute_name = f"ss_{a}_enabled"

            ena_mult = mk('ShaderNodeMath', 580, -100, 'ena_mult', f"{layer.name}: gate")
            ena_mult.operation = 'MULTIPLY'

            mix_nd = mk('ShaderNodeMixRGB', 680, 0, 'mix', layer.name)
            mix_nd.blend_type = 'MULTIPLY'
            mix_nd.inputs[2].default_value = (*layer.shadow_color, 1.0)

            links.new(attr_nd.outputs['Fac'],    map_nd.inputs['Value'])
            links.new(map_nd.outputs['Result'],  str_nd.inputs[0])
            links.new(str_nd.outputs['Value'],   ena_mult.inputs[0])
            links.new(ena_attr.outputs['Fac'],   ena_mult.inputs[1])
            links.new(ena_mult.outputs['Value'], mix_nd.inputs['Fac'])

            if prev_color_sock:
                links.new(prev_color_sock, mix_nd.inputs[1])
            else:
                mix_nd.inputs[1].default_value = base_default

            prev_color_sock = mix_nd.outputs['Color']

        if prev_color_sock:
            links.new(prev_color_sock, principled.inputs['Base Color'])
        elif base_default is not None:
            principled.inputs['Base Color'].default_value = base_default

        _force_mat_update(mat, tree)
        return True, f"{len(active_layers)} layer(s) applied"


def _force_mat_update(mat, tree):
    """Force Blender to recompile the shader after node changes."""
    try:
        tree.update_tag()
    except Exception:
        pass
    try:
        mat.node_tree.update_tag()
    except Exception:
        pass
    try:
        mat.update_tag()
    except Exception:
        pass
    # Tag all objects using this material
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material == mat:
                    try:
                        obj.update_tag()
                    except Exception:
                        pass


def _ensure_group_local(mat, tree):
    """If tree is a shared GROUP node tree, make a local copy for this material."""
    if tree == mat.node_tree or tree.users <= 1:
        return tree
    for n in mat.node_tree.nodes:
        if n.type == 'GROUP' and n.node_tree == tree:
            n.node_tree = tree.copy()
            log(f"[Shader] Made group local: '{n.node_tree.name}'")
            return n.node_tree
    return tree


def _ensure_layer_in_shader(mat, layer):
    tree, principled = _find_principled(mat)
    if principled is None:
        return False, "No Principled BSDF found"

    a     = layer.attr_name
    in_group = (tree != mat.node_tree)

    if in_group:
        # Principled is inside GROUP — inject at material level using Mix Shader
        return _ensure_layer_top_level(mat, layer, a)
    else:
        # Principled at material root — use MixRGB on Base Color (original approach)
        return _ensure_layer_in_root(mat, tree, principled, layer, a)


def _make_seam_node_group(layer, a):
    """Create a ShaderNodeTree with all seam shadow nodes inside."""
    ng = bpy.data.node_groups.new(f"SS_{a}", 'ShaderNodeTree')
    ng.interface.new_socket('Shader', in_out='INPUT',  socket_type='NodeSocketShader')
    ng.interface.new_socket('Shader', in_out='OUTPUT', socket_type='NodeSocketShader')

    gnodes = ng.nodes
    glinks = ng.links

    gi = gnodes.new('NodeGroupInput');  gi.location  = (-600, 0)
    go = gnodes.new('NodeGroupOutput'); go.location  = (200, 0)

    def mk(tp, x, y, role, lbl=""):
        nd = gnodes.new(tp)
        nd.location    = (x, y)
        nd['ss_layer'] = a
        nd['ss_role']  = role
        if lbl: nd.label = lbl
        return nd

    attr_nd = mk('ShaderNodeAttribute',  -560, -140, 'attr',      f"{layer.name}: dist")
    attr_nd.attribute_name = a
    attr_nd.attribute_type = 'GEOMETRY'

    map_nd  = mk('ShaderNodeMapRange',   -360, -140, 'map_range', f"{layer.name}: falloff")
    map_nd.clamp = True
    map_nd.inputs[3].default_value = 0.0
    map_nd.inputs[4].default_value = 1.0
    _map_range_inputs(map_nd, layer.width / 2.0, layer.falloff)

    str_nd  = mk('ShaderNodeMath',       -160, -140, 'strength',  f"{layer.name}: str")
    str_nd.operation = 'MULTIPLY'
    str_nd.inputs[1].default_value = layer.strength

    ena_a   = mk('ShaderNodeAttribute',  -160, -260, 'ena_attr',  f"{layer.name}: enabled")
    ena_a.attribute_type = 'OBJECT'
    ena_a.attribute_name = f"ss_{a}_enabled"

    ena_m   = mk('ShaderNodeMath',        -40, -200, 'ena_mult',  f"{layer.name}: gate")
    ena_m.operation = 'MULTIPLY'

    dark_nd = mk('ShaderNodeBsdfDiffuse', -40, -340, 'dark',      f"{layer.name}: shadow")
    dark_nd.inputs['Color'].default_value     = (*layer.shadow_color, 1.0)
    dark_nd.inputs['Roughness'].default_value = 1.0

    mix_nd  = mk('ShaderNodeMixShader',   80,    0,  'mix',       layer.name)

    glinks.new(attr_nd.outputs['Fac'],    map_nd.inputs['Value'])
    glinks.new(map_nd.outputs['Result'],  str_nd.inputs[0])
    glinks.new(str_nd.outputs['Value'],   ena_m.inputs[0])
    glinks.new(ena_a.outputs['Fac'],      ena_m.inputs[1])
    glinks.new(ena_m.outputs['Value'],    mix_nd.inputs['Fac'])
    glinks.new(gi.outputs['Shader'],      mix_nd.inputs[1])
    glinks.new(dark_nd.outputs['BSDF'],   mix_nd.inputs[2])
    glinks.new(mix_nd.outputs['Shader'],  go.inputs['Shader'])

    return ng


def _ensure_layer_top_level(mat, layer, a):
    """Inject seam layer at material top-level as a single GROUP node."""
    tree  = mat.node_tree
    nodes = tree.nodes
    links = tree.links

    mat_out = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'
                    and n.is_active_output), None) or \
              next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
    if not mat_out:
        return False, "No Material Output found"

    # Find existing seam GROUP node for this layer
    grp_nd = next((n for n in nodes
                   if n.get('ss_layer') == a and n.get('ss_role') == 'ss_group'), None)

    if grp_nd and grp_nd.node_tree:
        # Update values inside the group's node tree
        for gn in grp_nd.node_tree.nodes:
            if gn.get('ss_layer') != a:
                continue
            role = gn.get('ss_role')
            if role == 'map_range':
                _map_range_inputs(gn, layer.width / 2.0, layer.falloff)
            elif role == 'strength':
                _set_if_changed(gn.inputs[1], layer.strength)
            elif role == 'dark':
                _set_if_changed(gn.inputs['Color'], (*layer.shadow_color, 1.0))
        # Чи доходить група до Material Output БУДЬ-ЯКИМ шляхом (через інші шви,
        # Mix Shader гілки Oak/Walnut тощо). Стара перевірка йшла тільки прямим
        # ланцюгом ss_group → і вважала «відпалою» групу всередині гілки Mix
        # Shader → перепідключала її нагору, а те, що було вище, випадало
        # (і звідси ж бралися цикли, які потім лікували окремо).
        surf_in = mat_out.inputs['Surface']
        in_chain = _node_feeds(grp_nd, surf_in)
        if not in_chain:
            # ВАЖЛИВО: вставляємо ноду НА ВЕРХ поточного ланцюга (як при fresh
            # injection), а НЕ напряму до оригінального BSDF — бо
            # _get_original_upstream_bsdf іде в сам низ стеку і, підключаючи
            # ноду напряму туди й у Material Output, ВИКИДАЄ з видимого
            # ланцюга всі інші seam-ноди, що стояли між ними. Це і спричиняло
            # "щось злітає одразу після бейку" — цей repair спрацьовував на
            # рутинних бейках набагато частіше, ніж мав би.
            upstream = surf_in.links[0].from_socket if surf_in.is_linked \
                else _get_original_upstream_bsdf(mat_out)
            if upstream and upstream.node is not grp_nd:
                links.new(upstream, grp_nd.inputs['Shader'])
                links.new(grp_nd.outputs['Shader'], mat_out.inputs['Surface'])
                log(f"[Shader] Re-linked group node for '{layer.name}' "
                    f"(inserted on top of current chain)")
        _force_mat_update(mat, tree)
        return True, f"Updated group '{layer.name}'"

    # Fresh injection — create node group
    surf_in = mat_out.inputs['Surface']
    if not surf_in.is_linked:
        # Surface was broken by old code — try to auto-recover
        orig_bsdf = None
        # Prefer MIX_SHADER, then GROUP, then anything with Shader output (skip seam nodes)
        for _type in ('MIX_SHADER', 'GROUP', None):
            for n in nodes:
                if n.get('ss_role') or n.get('ss_layer') or n.type == 'OUTPUT_MATERIAL':
                    continue
                if _type and n.type != _type:
                    continue
                for out in n.outputs:
                    if out.type == 'SHADER':
                        orig_bsdf = out
                        break
                if orig_bsdf:
                    break
            if orig_bsdf:
                break
        if orig_bsdf is None:
            return False, "Material Output Surface not connected"
        log(f"[Shader] Auto-recovered Surface: using '{orig_bsdf.node.name}'")
    else:
        # Take whatever is currently connected — could be orig BSDF or previous ss_group output
        orig_bsdf = surf_in.links[0].from_socket

    ng = _make_seam_node_group(layer, a)

    grp_nd = nodes.new('ShaderNodeGroup')
    grp_nd.node_tree = ng
    grp_nd.location  = (mat_out.location.x - 350,
                         mat_out.location.y - 150 - 220 * sum(
                             1 for n in nodes if n.get('ss_role') == 'ss_group'))
    grp_nd['ss_layer'] = a
    grp_nd['ss_role']  = 'ss_group'
    grp_nd.label       = f"Seam: {layer.name}"
    grp_nd.width       = 220

    links.new(orig_bsdf,               grp_nd.inputs['Shader'])
    links.new(grp_nd.outputs['Shader'], mat_out.inputs['Surface'])

    _force_mat_update(mat, tree)
    log(f"[Shader] Created seam group node '{grp_nd.label}'")
    return True, f"Added group '{layer.name}'"


def _ensure_layer_in_root(mat, tree, principled, layer, a):
    """Original approach: inject MixRGB into Principled Base Color (root-level only)."""
    nodes = tree.nodes
    links = tree.links

    existing = {n.get('ss_role'): n for n in nodes if n.get('ss_layer') == a}

    if existing:
        if 'attr' in existing:
            existing['attr'].label = f"{layer.name}: dist"
        if 'map_range' in existing:
            _map_range_inputs(existing['map_range'], layer.width / 2.0, layer.falloff)
            existing['map_range'].label = f"{layer.name}: falloff"
        if 'strength' in existing:
            existing['strength'].inputs[1].default_value = layer.strength
            existing['strength'].label = f"{layer.name}: str"
        if 'mix' in existing:
            existing['mix'].inputs[2].default_value = (*layer.shadow_color, 1.0)
            existing['mix'].label = layer.name
        for n in existing.values():
            n.mute = False
        if 'ena_attr' not in existing or 'ena_mult' not in existing:
            str_nd = existing.get('strength')
            mix_nd = existing.get('mix')
            if str_nd and mix_nd:
                if 'ena_attr' not in existing:
                    ena_attr = nodes.new('ShaderNodeAttribute')
                    ena_attr.location = (str_nd.location.x + 80, str_nd.location.y - 80)
                    ena_attr['ss_layer'] = a
                    ena_attr['ss_role']  = 'ena_attr'
                    ena_attr.label = f"{layer.name}: enabled"
                    ena_attr.attribute_type = 'OBJECT'
                    ena_attr.attribute_name = f"ss_{a}_enabled"
                    existing['ena_attr'] = ena_attr
                if 'ena_mult' not in existing:
                    ena_mult = nodes.new('ShaderNodeMath')
                    ena_mult.location = (str_nd.location.x + 160, str_nd.location.y - 40)
                    ena_mult['ss_layer'] = a
                    ena_mult['ss_role']  = 'ena_mult'
                    ena_mult.label = f"{layer.name}: gate"
                    ena_mult.operation = 'MULTIPLY'
                    existing['ena_mult'] = ena_mult
                for lnk in list(mix_nd.inputs['Fac'].links):
                    links.remove(lnk)
                links.new(str_nd.outputs['Value'],             existing['ena_mult'].inputs[0])
                links.new(existing['ena_attr'].outputs['Fac'], existing['ena_mult'].inputs[1])
                links.new(existing['ena_mult'].outputs['Value'], mix_nd.inputs['Fac'])
        mix_nd = existing.get('mix')
        if mix_nd:
            # доходить до Base Color хоч через інші шари шва — значить все ок.
            # Раніше рахувалось тільки пряме підключення: нижній шар (під іншим швом)
            # вважався «відпалим», перепідключався напряму, і верхній шов випадав.
            connected = _node_feeds(mix_nd, principled.inputs['Base Color'])
            if not connected:
                links.new(mix_nd.outputs['Color'], principled.inputs['Base Color'])
                log(f"[Shader] Re-linked mix → Principled for '{layer.name}'")
        _force_mat_update(mat, tree)
        return True, f"Updated '{layer.name}'"

    base_in = principled.inputs['Base Color']
    if base_in.is_linked:
        up_sock     = base_in.links[0].from_socket
        base_default = None
    else:
        up_sock      = None
        base_default = tuple(base_in.default_value)

    ss_count = sum(1 for n in nodes if n.get('ss_role') == 'mix')
    px = principled.location.x - 700
    py = principled.location.y - ss_count * 220

    def mk(tp, xo, yo, role, lbl=""):
        nd = nodes.new(tp)
        nd.location    = (px + xo, py + yo)
        nd['ss_layer'] = a
        nd['ss_role']  = role
        if lbl:
            nd.label = lbl
        return nd

    attr_nd = mk('ShaderNodeAttribute', 0, -60, 'attr', f"{layer.name}: dist")
    attr_nd.attribute_name  = a
    attr_nd.attribute_type  = 'GEOMETRY'

    map_nd = mk('ShaderNodeMapRange', 220, -60, 'map_range', f"{layer.name}: falloff")
    map_nd.clamp = True
    map_nd.inputs[3].default_value = 0.0
    map_nd.inputs[4].default_value = 1.0
    _map_range_inputs(map_nd, layer.width / 2.0, layer.falloff)

    str_nd = mk('ShaderNodeMath', 420, -60, 'strength', f"{layer.name}: str")
    str_nd.operation = 'MULTIPLY'
    str_nd.inputs[1].default_value = layer.strength

    ena_attr = mk('ShaderNodeAttribute', 500, -160, 'ena_attr', f"{layer.name}: enabled")
    ena_attr.attribute_type = 'OBJECT'
    ena_attr.attribute_name = f"ss_{a}_enabled"

    ena_mult = mk('ShaderNodeMath', 580, -100, 'ena_mult', f"{layer.name}: gate")
    ena_mult.operation = 'MULTIPLY'

    mix_nd = mk('ShaderNodeMixRGB', 680, 0, 'mix', layer.name)
    mix_nd.blend_type = 'MULTIPLY'
    mix_nd.inputs[2].default_value = (*layer.shadow_color, 1.0)

    links.new(attr_nd.outputs['Fac'],    map_nd.inputs['Value'])
    links.new(map_nd.outputs['Result'],  str_nd.inputs[0])
    links.new(str_nd.outputs['Value'],   ena_mult.inputs[0])
    links.new(ena_attr.outputs['Fac'],   ena_mult.inputs[1])
    links.new(ena_mult.outputs['Value'], mix_nd.inputs['Fac'])

    if up_sock:
        links.new(up_sock, mix_nd.inputs[1])
    else:
        mix_nd.inputs[1].default_value = base_default

    links.new(mix_nd.outputs['Color'], principled.inputs['Base Color'])

    _force_mat_update(mat, tree)
    return True, f"Added '{layer.name}'"


_pending_layers = {}          # (obj_name, attr_name) -> час останньої зміни
_DEBOUNCE = 0.25              # сек тиші після останнього руху повзунка


def _update_layer_live(self, context):
    """Повзунок рухається → НЕ чіпаємо шейдер одразу. Кожна зміна значення в нодах
    змушує Cycles перебудувати шейдер (на дивані ~1.3 с на тік) — при перетягуванні
    таких тіків десятки. Застосовуємо один раз, коли повзунок зупинився."""
    import time
    obj = self.id_data if isinstance(self.id_data, bpy.types.Object) else context.active_object
    if not (obj and obj.type == 'MESH'):
        return
    _pending_layers[(obj.name, self.attr_name)] = time.monotonic()
    if not bpy.app.timers.is_registered(_flush_pending_layers):
        bpy.app.timers.register(_flush_pending_layers, first_interval=_DEBOUNCE)


@bpy.app.handlers.persistent
def _flush_before_render(*_args):
    """F12 / CFRender одразу після руху повзунка — застосувати відкладене до рендеру."""
    if _pending_layers:
        _flush_pending_layers(force=True)


def _flush_pending_layers(force=False):
    import time
    if not _pending_layers:
        return None
    wait = _DEBOUNCE - (time.monotonic() - max(_pending_layers.values()))
    if wait > 0 and not force:
        return wait                         # повзунок ще рухається — чекаємо
    # від ОСТАННЬОГО зміненого до першого: якщо копія і оригінал ділять шов,
    # свій окремий шов отримує той, кого чіпали останнім (а не оригінал)
    items = sorted(_pending_layers, key=_pending_layers.get, reverse=True)
    _pending_layers.clear()
    for obj_name, attr in items:
        obj = bpy.data.objects.get(obj_name)
        if not obj or obj.type != 'MESH':
            continue
        layer = next((l for l in obj.seam_layers if l.attr_name == attr), None)
        if layer is None:
            continue
        try:
            _apply_layer_values(layer, obj)
        except Exception as e:
            log(f"[Live] apply failed for '{obj_name}': {e}")
    return None


def _apply_layer_values(self, obj):
    """Записати width/strength/color/falloff шару в його ноди (тільки те, що змінилось)."""
    # копія Shift+D ділить шов з оригіналом → при першому ж русі повзунка
    # розділяємо, щоб повзунок міняв тільки ЦЕЙ шов (нова нода вже з поточними значеннями)
    if _split_shared_layer(obj, self):
        return
    # Беремо матеріал ЦЬОГО шару (self.material_name), а НЕ obj.active_material —
    # інакше якщо в об'єкта кілька матеріал-слотів і в Shader Editor обраний
    # не той слот, повзунки Width/Strength/Color шукають ноду в чужому дереві
    # нод і мовчки нічого не знаходять (без помилки, просто "не працює").
    mat = bpy.data.materials.get(self.material_name) if self.material_name else None
    if mat is None:
        mat = obj.active_material
    if not (mat and mat.use_nodes):
        return
    a = self.attr_name

    # Повзунки міняють ТІЛЬКИ значення в нодах. Blender сам оновлює шейдер при
    # зміні default_value — _force_mat_update тут не потрібен: він тегав на
    # перерахунок УСІ об'єкти з цим матеріалом (модифікатори, сабдив) на кожен
    # тік повзунка — головна причина лагів.

    # Check for seam GROUP node at material level
    for n in mat.node_tree.nodes:
        if n.get('ss_layer') == a and n.get('ss_role') == 'ss_group' and n.node_tree:
            for gn in n.node_tree.nodes:
                if gn.get('ss_layer') != a:
                    continue
                role = gn.get('ss_role')
                if role == 'map_range':
                    _map_range_inputs(gn, self.width / 2.0, self.falloff)
                elif role == 'strength':
                    _set_if_changed(gn.inputs[1], self.strength)
                elif role == 'dark':
                    _set_if_changed(gn.inputs['Color'], (*self.shadow_color, 1.0))
            # НЕ виходимо: у старих файлах той самий шов може бути ще й старим
            # ланцюгом всередині групи тканини (дубль) — повзунок має керувати обома,
            # інакше при силі 0 тінь лишається від дубля.

    # Root approach / старі дублі всередині групи з Principled
    tree, _ = _find_principled(mat)
    if tree is None:
        return
    all_nodes = list(mat.node_tree.nodes)
    if tree != mat.node_tree:
        all_nodes += list(tree.nodes)
    for n in all_nodes:
        if n.get('ss_layer') != a:
            continue
        role = n.get('ss_role')
        if role == 'map_range':
            _map_range_inputs(n, self.width / 2.0, self.falloff)
        elif role == 'strength':
            _set_if_changed(n.inputs[1], self.strength)
        elif role == 'mix' and n.type == 'MIX_RGB':
            _set_if_changed(n.inputs[2], (*self.shadow_color, 1.0))
        elif role == 'dark':
            _set_if_changed(n.inputs['Color'], (*self.shadow_color, 1.0))


def _rebuild_on_change(self, context):
    obj = context.active_object
    if not obj:
        return
    key = f"ss_{self.attr_name}_enabled"
    # Якщо на цій властивості вже сидить ДРАЙВЕР (шар анімований через
    # keyframe_enabled) — не пишемо в неї напряму. Раніше писали завжди,
    # і це створювало ЦИКЛ ЗАЛЕЖНОСТЕЙ (driver читає layer.enabled, а
    # update-колбек layer.enabled одночасно писав у ту саму driven
    # властивість) — depsgraph плутався й ламав оновлення ІНШИХ нод на
    # тому ж об'єкті (Width/Strength/Color переставали діяти).
    has_driver = bool(obj.animation_data and any(
        fc.data_path == f'["{key}"]' for fc in obj.animation_data.drivers
    ))
    if not has_driver:
        obj[key] = 1.0 if self.enabled else 0.0
    obj.update_tag()
    _tag_v3d_redraw()


# ─── bake ─────────────────────────────────────────────────────────────────────

def _store_float_attr(mesh, attr_name, values):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    if attr_name in bm.verts.layers.float:
        bm.verts.layers.float.remove(bm.verts.layers.float[attr_name])
    lyr = bm.verts.layers.float.new(attr_name)
    for v in bm.verts:
        v[lyr] = values[v.index]
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


def _remove_float_attr(mesh, attr_name):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    removed = False
    if attr_name in bm.verts.layers.float:
        bm.verts.layers.float.remove(bm.verts.layers.float[attr_name])
        removed = True
    if removed:
        bm.to_mesh(mesh)
        mesh.update()
    bm.free()
    if attr_name in mesh.attributes:
        mesh.attributes.remove(mesh.attributes[attr_name])


def _rename_float_attr(mesh, old_name, new_name):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    if old_name in bm.verts.layers.float:
        old_lyr = bm.verts.layers.float[old_name]
        new_lyr = bm.verts.layers.float.new(new_name)
        for v in bm.verts:
            v[new_lyr] = v[old_lyr]
        bm.verts.layers.float.remove(old_lyr)
        bm.to_mesh(mesh)
        mesh.update()
    bm.free()


def _retag_shader_node(mat, old_a, new_a, layer):
    """Перейменовує ІСНУЮЧУ шейдерну ноду шару зі старого attr_name на новий
    IN-PLACE (теги + label + внутрішні Attribute-ноди) — БЕЗ створення нової
    ноди і без зміни звʼязків. Якщо цього не робити, стара нода лишається
    "сиротою" (attribute вже перейменовано на мешi, вона показує 0), а
    _ensure_layer_in_shader створює ЩЕ ОДНУ ноду під новим іменем — і саме
    ця "розтрата" сиріт ламала chain-repair логіку та вибивала інші шви."""
    if not (mat and mat.use_nodes):
        return
    tree, principled = _find_principled(mat)
    if principled is None:
        return
    in_group = (tree != mat.node_tree)

    if in_group:
        grp_nd = next((n for n in mat.node_tree.nodes
                       if n.get('ss_layer') == old_a and n.get('ss_role') == 'ss_group'), None)
        if not grp_nd:
            return
        grp_nd['ss_layer'] = new_a
        grp_nd.label       = f"Seam: {layer.name}"
        if grp_nd.node_tree:
            grp_nd.node_tree.name = f"SS_{new_a}"
            for gn in grp_nd.node_tree.nodes:
                if gn.get('ss_layer') == old_a:
                    gn['ss_layer'] = new_a
                if gn.type == 'ATTRIBUTE':
                    role = gn.get('ss_role')
                    if role == 'attr':
                        gn.attribute_name = new_a
                    elif role == 'ena_attr':
                        gn.attribute_name = f"ss_{new_a}_enabled"
    else:
        matched = [n for n in mat.node_tree.nodes if n.get('ss_layer') == old_a]
        for n in matched:
            n['ss_layer'] = new_a
            if n.type == 'ATTRIBUTE':
                role = n.get('ss_role')
                if role == 'attr':
                    n.attribute_name = new_a
                elif role == 'ena_attr':
                    n.attribute_name = f"ss_{new_a}_enabled"


def _resolve_attr_collision(obj, layer, mat=None):
    """Якщо attr_name шару збігається з шаром на ІНШОМУ об'єкті (дублікат / merge
    з іншого файлу) — перепризначає новий унікальний attr_name, переносить
    забейкані дані, enabled-властивість і (якщо mat передано) перейменовує
    існуючу шейдерну ноду in-place. Повертає True якщо було перейменовано."""
    a = layer.attr_name
    if not a:
        return False

    collision = None
    for other in bpy.data.objects:
        if other is obj or other.type != 'MESH':
            continue
        if any(l.attr_name == a for l in other.seam_layers):
            collision = other
            break

    if not collision:
        return False

    new_a = _next_attr_name(obj.seam_layers)

    if layer.baked:
        _rename_float_attr(obj.data, a, new_a)

    old_key = f"ss_{a}_enabled"
    new_key = f"ss_{new_a}_enabled"
    if old_key in obj:
        obj[new_key] = obj[old_key]
        del obj[old_key]

    if mat is not None:
        _retag_shader_node(mat, a, new_a, layer)

    log(f"[Fix] '{layer.name}' on '{obj.name}': attr '{a}' collided with "
        f"'{collision.name}' -> renamed to '{new_a}'")

    layer.attr_name = new_a
    return True


def _obj_fcurves(obj):
    ad = obj.animation_data
    if not (ad and ad.action):
        return []
    try:
        from bpy_extras.anim_utils import action_get_channelbag_for_slot
        cb = action_get_channelbag_for_slot(ad.action, ad.action_slot)
        return list(cb.fcurves) if cb else []
    except ImportError:
        return list(getattr(ad.action, "fcurves", []))


def _split_shared_layer(obj, layer):
    """Копія об'єкта (Shift+D) має шари з ТИМ САМИМ attr_name, що й оригінал —
    обидва читають одну ноду в спільному матеріалі, і повзунок одного міняє шов
    іншого («накладання»). Тут шар копії отримує свій attr_name і свою ноду;
    нода оригіналу лишається оригіналу. Ключі вкл/викл переносяться.
    Повертає True якщо розділили."""
    a = layer.attr_name
    if not a:
        return False
    shared = any(o is not obj and o.type == 'MESH' and any(l.attr_name == a for l in o.seam_layers)
                 for o in bpy.data.objects)
    if not shared:
        return False
    mesh = obj.data
    if mesh.library is not None or mesh.users > 1:
        obj.data = mesh.copy()
        mesh = obj.data
    new_a = _next_attr_name(obj.seam_layers)
    if layer.baked:
        _rename_float_attr(mesh, a, new_a)
    old_key, new_key = f"ss_{a}_enabled", f"ss_{new_a}_enabled"
    if old_key in obj:
        obj[new_key] = obj[old_key]
        del obj[old_key]
    for fc in _obj_fcurves(obj):
        if fc.data_path == f'["{old_key}"]':
            fc.data_path = f'["{new_key}"]'
    layer.attr_name = new_a
    mat = bpy.data.materials.get(layer.material_name) if layer.material_name else None
    if mat and mat.library is None and layer.baked:
        _ensure_layer_in_shader(mat, layer)
    log(f"[Fix] '{layer.name}' on '{obj.name}' shared attr '{a}' with another object "
        f"(copy) -> own seam '{new_a}'")
    return True


def _get_existing_seam_verts(mesh, attr_name):
    existing = set()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    if attr_name in bm.verts.layers.float:
        lyr  = bm.verts.layers.float[attr_name]
        vals = [v[lyr] for v in bm.verts]
        if vals:
            max_val = max(vals)
            if max_val > 1e-6:
                # Адаптивний поріг: 99.99% від максимуму.
                # Шовні вершини dist=0 → value=max, решта — менше.
                # Працює незалежно від масштабу (0-1 або 0-100).
                threshold = max_val * 0.99999
                for i, v in enumerate(vals):
                    if v >= threshold:
                        existing.add(i)
    bm.free()
    return existing


def _run_bake(mesh, seam_verts, layer):
    a = layer.attr_name
    n = len(mesh.vertices)

    adj = [[] for _ in range(n)]
    for edge in mesh.edges:
        va, vb = edge.vertices[0], edge.vertices[1]
        length = (mesh.vertices[va].co - mesh.vertices[vb].co).length
        adj[va].append((length, vb))
        adj[vb].append((length, va))

    INF  = float('inf')
    dist = [INF] * n
    heap = []
    for vi in seam_verts:
        dist[vi] = 0.0
        heapq.heappush(heap, (0.0, vi))

    while heap:
        d, vi = heapq.heappop(heap)
        if d > dist[vi]:
            continue
        for el, vj in adj[vi]:
            nd2 = d + el
            if nd2 < dist[vj]:
                dist[vj] = nd2
                heapq.heappush(heap, (nd2, vj))

    values = [max(0.0, _SENTINEL - dist[vi]) if dist[vi] < INF else 0.0
              for vi in range(n)]
    _store_float_attr(mesh, a, values)
    log(f"[Bake] '{layer.name}' attr={a} seam_verts={len(seam_verts)}")


# ─── data model ───────────────────────────────────────────────────────────────

class SeamLayer(bpy.types.PropertyGroup):
    name:          bpy.props.StringProperty(name="Name", default="Seam")
    attr_name:     bpy.props.StringProperty()
    baked:         bpy.props.BoolProperty(default=False)
    material_name: bpy.props.StringProperty()

    width: bpy.props.FloatProperty(description="Ширина тіні шва (в одиницях меша = метри при масштабі 1)",
        name="Width", default=0.0035, min=0.00001, max=2.0, precision=5,
        update=_update_layer_live,
    )
    # те саме значення, але в сантиметрах — саме це поле в панелі.
    # 0.0035 (м) = 0.35 см. Зберігається тільки width, тому старі файли/пресети сумісні.
    width_cm: bpy.props.FloatProperty(
        name="Ширина, см",
        description="Повна ширина тіні шва в сантиметрах (по половині з кожного боку від ребра). "
                    "Для моделей з масштабом 1. Напр. 0.35 см",
        get=lambda self: self.width * 100.0,
        set=lambda self, v: setattr(self, "width", max(v, 0.001) / 100.0),
        min=0.001, max=200.0, soft_min=0.05, soft_max=2.0, step=1, precision=3,
    )
    strength: bpy.props.FloatProperty(description="Сила (темнота) тіні", 
        name="Strength", default=0.5, min=0.0, max=1.0,
        update=_update_layer_live,
    )
    shadow_color: bpy.props.FloatVectorProperty(description="Колір тіні шва", 
        name="Shadow Color", subtype='COLOR_GAMMA',
        default=(0.0, 0.0, 0.0), min=0.0, max=1.0,
        update=_update_layer_live,
    )
    falloff: bpy.props.EnumProperty(description="Наскільки м'яко тінь згасає від шва", 
        name="Falloff",
        items=[
            ('HARD',        "Hard",   "Sharp cutoff"),
            ('LINEAR',      "Linear", "Linear gradient"),
            ('SMOOTH_STEP', "Smooth", "Smooth gradient"),
        ],
        default='SMOOTH_STEP',
        update=_update_layer_live,
    )
    enabled: bpy.props.BoolProperty(description="Увімкнути / вимкнути цей шов (можна поставити ключ)", name="", default=True, update=_rebuild_on_change)


# ─── panel helpers ────────────────────────────────────────────────────────────

def _layer_in_shader(mat, attr_name):
    """Чи є ноди цього шару вже в шейдері."""
    if not (mat and mat.use_nodes):
        return False
    # Check for seam GROUP node at material level
    for n in mat.node_tree.nodes:
        if n.get('ss_layer') == attr_name:
            return True
    # Check inside principled tree (root approach)
    tree, _ = _find_principled(mat)
    if tree and tree != mat.node_tree:
        for n in tree.nodes:
            if n.get('ss_layer') == attr_name:
                return True
    return False


def _seam_copies(mat, attr_name):
    """Скільки разів шов реально «намальований» у матеріалі (група на верхньому рівні +
    старі ланцюги Mix всередині груп). >1 = дубль від старих версій → Rebuild Shader."""
    if not (mat and mat.node_tree):
        return 0
    count, seen = 0, set()

    def walk(tree, top):
        nonlocal count
        if tree.as_pointer() in seen:
            return
        seen.add(tree.as_pointer())
        for n in tree.nodes:
            if n.get('ss_layer') == attr_name and (
                    (top and n.get('ss_role') == 'ss_group') or (n.get('ss_role') == 'mix' and n.type == 'MIX_RGB')):
                count += 1
            if n.type == 'GROUP' and n.node_tree and not n.node_tree.name.startswith('SS_') \
                    and n.get('ss_role') != 'ss_group':
                walk(n.node_tree, False)
    walk(mat.node_tree, True)
    return count


def _mat_layers(obj):
    if not (obj and obj.active_material):
        return []
    mat_name = obj.active_material.name
    return [(i, l) for i, l in enumerate(obj.seam_layers)
            if l.material_name == mat_name or not l.material_name]


def _all_mat_layers(mat):
    """Збирає всі шари матеріалу з усіх об'єктів. Якщо два шари РІЗНИХ об'єктів
    мають однаковий attr_name (дублікат/merge з іншого файлу) — раніше другий
    просто відкидався (і губив ноду при rebuild). Тепер колізія лікується тут
    же: другому шару перепризначається новий унікальний attr_name, і він
    лишається в списку — жоден шар більше не зникає при Update Shader /
    Remove Layer / Recover Layers."""
    seen = {}
    result = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        uses_mat = any(s.material == mat for s in obj.material_slots)
        for layer in obj.seam_layers:
            name_ok = (layer.material_name == mat.name or
                       (not layer.material_name and uses_mat))
            if not name_ok:
                continue

            if layer.attr_name in seen and seen[layer.attr_name][0] is not obj:
                old_a = layer.attr_name
                new_a = _next_attr_name(obj.seam_layers)
                if layer.baked:
                    _rename_float_attr(obj.data, old_a, new_a)
                old_key = f"ss_{old_a}_enabled"
                new_key = f"ss_{new_a}_enabled"
                if old_key in obj:
                    obj[new_key] = obj[old_key]
                    del obj[old_key]
                log(f"[Fix] '{layer.name}' on '{obj.name}': attr '{old_a}' collided "
                    f"during rebuild -> renamed to '{new_a}'")
                layer.attr_name = new_a

            seen[layer.attr_name] = (obj, layer)
            result.append(layer)
    return result


# ─── redraw ───────────────────────────────────────────────────────────────────

_msgbus_owner = object()
_last_active  = [None]

def _get_clipboard():
    if 'ss_clipboard' not in bpy.app.driver_namespace:
        bpy.app.driver_namespace['ss_clipboard'] = {}
    return bpy.app.driver_namespace['ss_clipboard']

def _tag_v3d_redraw():
    for wm in bpy.data.window_managers:
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()


def _sync_active_layer(obj):
    """Переключає seam_layer_active на перший шар що відповідає активному матеріалу."""
    if not (obj and obj.type == 'MESH' and obj.active_material):
        return
    mat_name = obj.active_material.name
    layers   = obj.seam_layers
    if not layers:
        return

    # Якщо поточний шар вже відповідає матеріалу — не чіпаємо
    idx = obj.seam_layer_active
    if 0 <= idx < len(layers):
        cur = layers[idx]
        if cur.material_name == mat_name or not cur.material_name:
            return

    # Шукаємо перший шар для нового матеріалу
    for i, l in enumerate(layers):
        if l.material_name == mat_name:
            obj.seam_layer_active = i
            _tag_v3d_redraw()
            return


def _on_material_change():
    try:
        _tag_v3d_redraw()
    except Exception:
        pass


# ─── presets (persistent JSON, per-project) ────────────────────────────────────

def _get_presets_path():
    """Пресети зберігаються поруч з поточним .blend файлом — кожен проєкт/сцена
    має свій власний список, і різні файли не змішують/не затирають пресети один одного.
    Якщо файл ще не збережено — фолбек в папку аддону."""
    blend_path = bpy.data.filepath
    if blend_path:
        return os.path.join(os.path.dirname(blend_path), "seam_presets.json")
    return _FALLBACK_PRESETS_PATH

def _load_presets():
    try:
        with open(_get_presets_path(), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _save_presets(data):
    try:
        with open(_get_presets_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        log(f"[Presets] save error: {e}")

def _get_preset_order(presets):
    """Повертає впорядкований список назв пресетів (без внутрішніх ключів __*)."""
    real_keys = [k for k in presets if not k.startswith('__')]
    stored_order = presets.get('__order__', [])
    # Беремо збережений порядок, відфільтровуємо видалені, додаємо нові в кінець
    ordered = [k for k in stored_order if k in presets and not k.startswith('__')]
    for k in real_keys:
        if k not in ordered:
            ordered.append(k)
    return ordered

# Blender вимагає, щоб рядки з callback EnumProperty жили довше одного виклику,
# інакше Python звільняє память і Blender показує биті символи замість імені
# (і порівняння imені при видаленні перестає збігатися). Тримаємо результат
# у глобальній змінній, щоб рядки не збирались garbage collector'ом.
_preset_enum_cache = []

def _preset_enum_items(self, context):
    global _preset_enum_cache
    presets = _load_presets()
    order = _get_preset_order(presets)
    items = [(k, k, '') for k in order]
    # __none__ завжди є першим — щоб збережений вибір не зникав зі списку
    _preset_enum_cache = [('__none__', '(no presets)' if not items else '— select —', '')] + items
    return _preset_enum_cache

def _refresh_preset_ui():
    try:
        _tag_v3d_redraw()
    except Exception:
        pass

def _selected_preset(scene):
    try:
        v = scene.ss_preset_selected
    except Exception:
        return None
    return v if v and v != '__none__' else None


def _reselect_preset(scene, name):
    """Вибір у списку пресетів Blender тримає по НОМЕРУ рядка, не по імені.
    Після зміни порядку/видалення/імпорту ставимо вибір заново по імені,
    інакше підсвічується сусідній пресет і ▲▼ рухають не той."""
    presets = _load_presets()
    target = name if (name and name in presets and not name.startswith('__')) else '__none__'
    try:
        scene.ss_preset_selected = target
    except Exception:
        pass


def _preset_values(p):
    """Значення пресета з дефолтами — старі пресети можуть не мати якогось поля."""
    return (float(p.get('width', 0.0035)), float(p.get('strength', 0.5)),
            tuple(p.get('color', (0.0, 0.0, 0.0)))[:3], p.get('falloff', 'SMOOTH_STEP'))


def _on_preset_selected(self, context):
    """При виборі пресету з дропдауну — підставляємо його назву в поле вводу."""
    sel = self.ss_preset_selected
    if sel and sel != '__none__':
        self.ss_preset_name = sel


@bpy.app.handlers.persistent
def _seam_shadow_depsgraph(scene, depsgraph):
    try:
        obj  = bpy.context.active_object
        name = obj.name if obj else None
        if name != _last_active[0]:
            _last_active[0] = name
            _tag_v3d_redraw()
    except Exception:
        pass


_last_edge_selection = {}  # obj.name -> frozenset(edge indices) — щоб не форсити слот на кожен тік

def _edge_mat_poll():
    """Timer: у edge mode визначає активний матеріал по виділених ребрах.
    Спрацьовує лише коли ВИДІЛЕННЯ РЕБЕР змінилось з минулого тіку — інакше
    таймер (кожні 0.15с) відкочував би ручне перемикання слоту матеріалу
    назад, бо ребра лишаються ті самі виділені."""
    try:
        ctx = bpy.context
        if not (ctx and ctx.active_object):
            return 0.15
        obj = ctx.active_object
        if obj.type != 'MESH':
            return 0.15

        # Edge select mode: визначаємо матеріал по виділених ребрах
        if obj.mode == 'EDIT' and ctx.tool_settings.mesh_select_mode[1]:
            bm  = bmesh.from_edit_mesh(obj.data)
            sel = frozenset(e.index for e in bm.edges if e.select)

            if sel == _last_edge_selection.get(obj.name):
                return 0.15
            _last_edge_selection[obj.name] = sel

            mat_votes = {}
            for e in bm.edges:
                if e.select:
                    for face in e.link_faces:
                        mi = face.material_index
                        mat_votes[mi] = mat_votes.get(mi, 0) + 1

            if mat_votes:
                best = max(mat_votes, key=mat_votes.get)
                if obj.active_material_index != best:
                    obj.active_material_index = best
                    _tag_v3d_redraw()
    except Exception:
        pass
    return 0.15


# ─── operators ────────────────────────────────────────────────────────────────

class SEAM_SHADOW_OT_refresh(bpy.types.Operator):
    bl_idname  = "seam_shadow.refresh"
    bl_label   = "Refresh"
    bl_description = "Оновити список / прив'язати старі шари до поточного матеріалу"
    bl_options = set()

    def execute(self, context):
        obj      = context.active_object
        mat_name = obj.active_material.name if (obj and obj.active_material) else ""
        if mat_name:
            for l in _get_obj_layers(obj):
                if not l.material_name:
                    l.material_name = mat_name
        _tag_v3d_redraw()
        return {'FINISHED'}


class SEAM_SHADOW_OT_select_layer(bpy.types.Operator):
    bl_idname  = "seam_shadow.select_layer"
    bl_description = "Вибрати цей шар шва"
    bl_label   = "Select Layer"
    bl_options = set()
    index: bpy.props.IntProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        obj.seam_layer_active = self.index

        if obj.mode != 'EDIT':
            return {'FINISHED'}

        layers = obj.seam_layers
        if self.index >= len(layers):
            return {'FINISHED'}

        layer = layers[self.index]
        if not layer.baked or not layer.attr_name:
            return {'FINISHED'}

        seam_verts = _get_existing_seam_verts(obj.data, layer.attr_name)
        if not seam_verts:
            return {'FINISHED'}

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

        for e in bm.edges:
            if e.verts[0].index in seam_verts and e.verts[1].index in seam_verts:
                e.select = True

        bm.select_flush_mode()
        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}


class SEAM_SHADOW_OT_add_layer(bpy.types.Operator):
    bl_idname  = "seam_shadow.add_layer"
    bl_description = "Додати новий шар шва"
    bl_label   = "Add Seam Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.active_material

    def execute(self, context):
        obj    = context.active_object
        mat    = obj.active_material
        layers = obj.seam_layers
        layer  = layers.add()
        layer.attr_name     = _next_attr_name(layers)
        layer.name          = f"Seam {len(layers)}"
        layer.baked         = False
        layer.material_name = mat.name if mat else ""
        obj.seam_layer_active = len(layers) - 1
        return {'FINISHED'}


class SEAM_SHADOW_OT_copy_preset(bpy.types.Operator):
    bl_idname      = "seam_shadow.copy_preset"
    bl_label       = "Copy Seam"
    bl_description = "Скопіювати налаштування шару + запечені дані в буфер"
    bl_options     = set()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and 0 <= _get_obj_idx(obj) < len(_get_obj_layers(obj))

    def execute(self, context):
        obj   = context.active_object
        layer = obj.seam_layers[obj.seam_layer_active]

        cb = _get_clipboard()
        cb.clear()
        cb['name']         = layer.name
        cb['width']        = layer.width
        cb['strength']     = layer.strength
        cb['shadow_color'] = tuple(layer.shadow_color)
        cb['falloff']      = layer.falloff
        cb['attr_values']  = None

        if layer.baked and layer.attr_name:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            if layer.attr_name in bm.verts.layers.float:
                lyr = bm.verts.layers.float[layer.attr_name]
                cb['attr_values'] = [v[lyr] for v in bm.verts]
            bm.free()

        has_data = cb['attr_values'] is not None
        self.report({'INFO'}, f"Copied '{layer.name}'" + (" + baked data" if has_data else " (no bake)"))
        return {'FINISHED'}


class SEAM_SHADOW_OT_paste_preset(bpy.types.Operator):
    bl_idname      = "seam_shadow.paste_preset"
    bl_label       = "Paste Seam"
    bl_description = "Вставити налаштування шару + запечені дані на активний об'єкт"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(_get_clipboard()) and obj and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        mat_name = mat.name if mat else ""

        layers = obj.seam_layers
        # Вставка НЕ затирає вже запечений шов: якщо активний шар забейканий —
        # створюємо новий. Порожній (не забейканий) активний шар — заповнюємо.
        act = layers[obj.seam_layer_active] if 0 <= obj.seam_layer_active < len(layers) else None
        if act is None or act.baked:
            new_layer = layers.add()
            new_layer.attr_name     = _next_attr_name(layers)
            new_layer.material_name = mat_name
            obj.seam_layer_active   = len(layers) - 1

        cb    = _get_clipboard()
        layer = layers[obj.seam_layer_active]
        layer.name          = cb['name']
        layer.width         = cb['width']
        layer.strength      = cb['strength']
        layer.shadow_color  = cb['shadow_color']
        layer.falloff       = cb['falloff']
        layer.material_name = mat_name

        values = cb.get('attr_values')
        if values is not None:
            if len(obj.data.vertices) == len(values):
                _store_float_attr(obj.data, layer.attr_name, values)
                layer.baked = True
                if mat:
                    _ensure_layer_in_shader(mat, layer)
                self.report({'INFO'}, f"Pasted '{layer.name}' with baked data")
            else:
                self.report({'WARNING'},
                    f"Pasted settings only — vert count mismatch "
                    f"(clipboard={len(values)}, this={len(obj.data.vertices)})")
        else:
            self.report({'INFO'}, f"Pasted settings for '{layer.name}'")

        return {'FINISHED'}


class SEAM_SHADOW_OT_recover_layers(bpy.types.Operator):
    bl_idname      = "seam_shadow.recover_layers"
    bl_label       = "Recover Layers from Mesh"
    bl_description = "Знайти в меші запечені атрибути ss_* і відновити список шарів"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        obj  = context.active_object
        mat  = obj.active_material
        found = sorted(
            a.name for a in obj.data.attributes
            if a.name.startswith("ss_") and a.domain == 'POINT' and a.data_type == 'FLOAT'
        )
        if not found:
            self.report({'WARNING'}, "No ss_* attributes found on this mesh")
            return {'CANCELLED'}

        existing_attrs = {l.attr_name for l in obj.seam_layers}
        added = 0
        for attr_name in found:
            if attr_name in existing_attrs:
                continue
            layer = obj.seam_layers.add()
            layer.attr_name     = attr_name
            layer.name          = f"Recovered {attr_name}"
            layer.baked         = True
            layer.material_name = mat.name if mat else ""
            added += 1

        if mat:
            _rebuild_shader(mat, _all_mat_layers(mat))

        # Initialize per-object enabled properties
        for layer in obj.seam_layers:
            key = f"ss_{layer.attr_name}_enabled"
            if key not in obj:
                obj[key] = 1.0

        self.report({'INFO'}, f"Recovered {added} layer(s) — adjust Width/Strength/Color manually")
        return {'FINISHED'}


class SEAM_SHADOW_OT_remove_layer(bpy.types.Operator):
    bl_idname  = "seam_shadow.remove_layer"
    bl_description = "Видалити шар шва"
    bl_label   = "Remove Seam Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and len(_get_obj_layers(obj)) > 0

    def execute(self, context):
        obj    = context.active_object
        layers = obj.seam_layers
        idx    = obj.seam_layer_active
        if idx < 0 or idx >= len(layers):
            return {'CANCELLED'}

        a = layers[idx].attr_name
        try:
            _remove_float_attr(obj.data, a)
        except Exception as e:
            log(f"[Remove] attr cleanup error (ignored): {e}")

        layers.remove(idx)
        obj.seam_layer_active = min(max(idx - 1, 0), max(len(layers) - 1, 0))

        if obj.active_material:
            mat = obj.active_material
            _rebuild_shader(mat, _all_mat_layers(mat))
        return {'FINISHED'}


class SEAM_SHADOW_OT_move_layer(bpy.types.Operator):
    bl_idname  = "seam_shadow.move_layer"
    bl_description = "Посунути шар вище/нижче"
    bl_label   = "Move Seam Layer"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('UP', 'Up', ''), ('DOWN', 'Down', '')]
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and len(_get_obj_layers(obj)) > 1

    def execute(self, context):
        obj    = context.active_object
        layers = obj.seam_layers
        idx    = obj.seam_layer_active
        if self.direction == 'UP' and idx > 0:
            layers.move(idx, idx - 1)
            obj.seam_layer_active = idx - 1
        elif self.direction == 'DOWN' and idx < len(layers) - 1:
            layers.move(idx, idx + 1)
            obj.seam_layer_active = idx + 1
        else:
            return {'CANCELLED'}
        return {'FINISHED'}


def _remove_enabled_driver(obj, key):
    """Прибирає driver з obj["ss_<attr>_enabled"], якщо є (self-heal старих
    файлів — комбінація driver + update-колбек на layer.enabled створює
    СТРУКТУРНИЙ цикл залежностей в depsgraph незалежно від того, що саме
    робить колбек: Blender групує "властивість з update" і "властивість з
    driver" в один блок обчислень об'єкта, і driver що читає одну властивість
    цього блоку щоб писати іншу — це цикл сам по собі. Тому назад до прямого
    кейфрейму на custom property, без driver і без layer.enabled узагалі."""
    data_path = f'["{key}"]'
    if obj.animation_data:
        for fc in list(obj.animation_data.drivers):
            if fc.data_path == data_path:
                obj.driver_remove(data_path)
                return True
    return False


class SEAM_SHADOW_OT_keyframe_enabled(bpy.types.Operator):
    """Кейфреймить УВІМКНЕНО/ВИМКНЕНО стан шва на поточному кадрі.
    Кейфреймимо НАПРЯМУ obj["ss_<attr>_enabled"] (те саме значення, яке
    читає Attribute-нода в шейдері) — без driver і без layer.enabled, щоб
    уникнути структурного циклу залежностей (див. _remove_enabled_driver)."""
    bl_idname      = "seam_shadow.keyframe_enabled"
    bl_label       = "Insert Enabled Keyframe"
    bl_description = "Поставити ключ «увімкнено/вимкнено» цього шва на поточному кадрі"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = _get_obj_layers(obj)
        idx    = _get_obj_idx(obj)
        return obj and 0 <= idx < len(layers)

    def execute(self, context):
        obj   = context.active_object
        idx   = obj.seam_layer_active
        layer = obj.seam_layers[idx]
        key   = f"ss_{layer.attr_name}_enabled"

        _remove_enabled_driver(obj, key)

        if key not in obj:
            obj[key] = 1.0 if layer.enabled else 0.0

        data_path = f'["{key}"]'

        # CONSTANT-інтерполяція — чіткий on/off перемикач, а не плавний перехід.
        prefs       = context.preferences.edit
        prev_interp = prefs.keyframe_new_interpolation_type
        prefs.keyframe_new_interpolation_type = 'CONSTANT'
        try:
            obj.keyframe_insert(data_path=data_path, frame=context.scene.frame_current)
        finally:
            prefs.keyframe_new_interpolation_type = prev_interp

        self.report({'INFO'}, f"Keyframed '{layer.name}' at frame {context.scene.frame_current}")
        return {'FINISHED'}


class SEAM_SHADOW_OT_bake_and_apply(bpy.types.Operator):
    bl_idname      = "seam_shadow.bake_and_apply"
    bl_label       = "Bake & Apply"
    bl_description = "Запекти виділені ребра в активний шар і перебудувати шейдер"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and obj.active_material
                and len(_get_obj_layers(obj)) > 0)

    def execute(self, context):
        obj    = context.active_object
        mat    = obj.active_material
        layers = obj.seam_layers
        idx    = obj.seam_layer_active

        if idx < 0 or idx >= len(layers):
            self.report({'WARNING'}, "No active layer")
            return {'CANCELLED'}
        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}

        layer     = layers[idx]
        prev_mode = obj.mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        if mesh.library is not None or mesh.users > 1:
            obj.data = mesh.copy()
            mesh = obj.data
            log(f"[Bake] Made mesh single-user for '{obj.name}'")

        if _resolve_attr_collision(obj, layer, mat):
            self.report({'INFO'}, f"Fixed duplicate attribute name for '{layer.name}'")

        seam_verts = set()
        for edge in mesh.edges:
            if edge.select:
                seam_verts.add(edge.vertices[0])
                seam_verts.add(edge.vertices[1])

        if not seam_verts:
            self.report({'WARNING'}, "No edges selected")
            bpy.ops.object.mode_set(mode=prev_mode)
            return {'CANCELLED'}

        _run_bake(mesh, seam_verts, layer)
        layer.baked         = True
        layer.material_name = mat.name

        bpy.ops.object.mode_set(mode=prev_mode)

        ok, msg = _ensure_layer_in_shader(mat, layer)
        log(f"[Shader] {msg}")
        if not ok:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        # Initialize per-object enabled property (default: on)
        key = f"ss_{layer.attr_name}_enabled"
        if key not in obj:
            obj[key] = 1.0 if layer.enabled else 0.0

        self.report({'INFO'}, f"Baked '{layer.name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_add_to_layer(bpy.types.Operator):
    bl_idname      = "seam_shadow.add_to_layer"
    bl_label       = "Add Edges to Seam"
    bl_description = "Додати виділені ребра до існуючого шару шва і перезапекти"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = _get_obj_layers(obj)
        idx    = _get_obj_idx(obj)
        return (obj and obj.type == 'MESH' and obj.active_material
                and 0 <= idx < len(layers) and layers[idx].baked)

    def execute(self, context):
        obj    = context.active_object
        mat    = obj.active_material
        layers = obj.seam_layers
        idx    = obj.seam_layer_active
        layer  = layers[idx]

        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}

        prev_mode = obj.mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        if mesh.library is not None or mesh.users > 1:
            obj.data = mesh.copy()
            mesh = obj.data
            log(f"[Add] Made mesh single-user for '{obj.name}'")

        if _resolve_attr_collision(obj, layer, mat):
            self.report({'INFO'}, f"Fixed duplicate attribute name for '{layer.name}'")

        existing  = _get_existing_seam_verts(mesh, layer.attr_name)
        new_verts = {e.vertices[0] for e in mesh.edges if e.select} | \
                    {e.vertices[1] for e in mesh.edges if e.select}

        if not new_verts:
            self.report({'WARNING'}, "No edges selected")
            bpy.ops.object.mode_set(mode=prev_mode)
            return {'CANCELLED'}

        seam_verts = existing | new_verts
        _run_bake(mesh, seam_verts, layer)
        layer.baked         = True
        layer.material_name = mat.name
        log(f"[Add] existing={len(existing)} new={len(new_verts)} total={len(seam_verts)}")

        bpy.ops.object.mode_set(mode=prev_mode)

        _ensure_layer_in_shader(mat, layer)
        self.report({'INFO'}, f"Added edges to '{layer.name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_remove_from_layer(bpy.types.Operator):
    bl_idname      = "seam_shadow.remove_from_layer"
    bl_label       = "Remove Edges from Seam"
    bl_description = "Прибрати виділені ребра з шару шва і перезапекти"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = _get_obj_layers(obj)
        idx    = _get_obj_idx(obj)
        return (obj and obj.type == 'MESH' and obj.active_material
                and 0 <= idx < len(layers) and layers[idx].baked)

    def execute(self, context):
        obj    = context.active_object
        mat    = obj.active_material
        layers = obj.seam_layers
        idx    = obj.seam_layer_active
        layer  = layers[idx]

        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}

        prev_mode = obj.mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        if mesh.library is not None or mesh.users > 1:
            obj.data = mesh.copy()
            mesh = obj.data
            log(f"[Remove] Made mesh single-user for '{obj.name}'")

        if _resolve_attr_collision(obj, layer, mat):
            self.report({'INFO'}, f"Fixed duplicate attribute name for '{layer.name}'")

        remove_verts = {e.vertices[0] for e in mesh.edges if e.select} | \
                       {e.vertices[1] for e in mesh.edges if e.select}

        if not remove_verts:
            self.report({'WARNING'}, "No edges selected")
            bpy.ops.object.mode_set(mode=prev_mode)
            return {'CANCELLED'}

        existing   = _get_existing_seam_verts(mesh, layer.attr_name)
        seam_verts = existing - remove_verts

        if not seam_verts:
            self.report({'WARNING'}, "Would remove all verts — use Clear Bake instead")
            bpy.ops.object.mode_set(mode=prev_mode)
            return {'CANCELLED'}

        _run_bake(mesh, seam_verts, layer)
        log(f"[RemoveEdges] removed={len(remove_verts & existing)} remaining={len(seam_verts)}")

        bpy.ops.object.mode_set(mode=prev_mode)

        _ensure_layer_in_shader(mat, layer)
        self.report({'INFO'}, f"Removed edges from '{layer.name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_apply_shader(bpy.types.Operator):
    bl_idname      = "seam_shadow.apply_shader"
    bl_description = "Видаляє ВСІ ноди швів у цьому матеріалі і будує їх заново (без перезапікання). Використовуй, якщо ноди зламались/переплутались"
    bl_label       = "Rebuild Shader"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.active_material

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}
        ok, msg = _rebuild_shader(mat, _all_mat_layers(mat))
        log(f"[Shader] {msg}")
        self.report({'INFO' if ok else 'ERROR'}, msg)
        return {'FINISHED' if ok else 'CANCELLED'}


class SEAM_SHADOW_OT_clear_layer(bpy.types.Operator):
    bl_idname      = "seam_shadow.clear_layer"
    bl_label       = "Clear Bake"
    bl_description = "Видалити запечений атрибут тільки з меша ЦЬОГО об'єкта"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and len(_get_obj_layers(obj)) > 0

    def execute(self, context):
        obj    = context.active_object
        layers = obj.seam_layers
        idx    = obj.seam_layer_active
        if idx < 0 or idx >= len(layers):
            return {'CANCELLED'}
        layer = layers[idx]
        prev_mode = obj.mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            _remove_float_attr(obj.data, layer.attr_name)
        except Exception as e:
            log(f"[ClearBake] error (ignored): {e}")
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        layer.baked = False
        self.report({'INFO'}, f"Cleared '{layer.name}' on this object")
        return {'FINISHED'}


# ─── preset operators ─────────────────────────────────────────────────────────

class SEAM_SHADOW_OT_preset_save(bpy.types.Operator):
    bl_idname      = "seam_shadow.preset_save"
    bl_label       = "Save Preset"
    bl_description = "Зберегти налаштування шару + виділені ребра як пресет з назвою"
    bl_options     = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj  = context.active_object
        name = getattr(context.scene, 'ss_preset_name', '').strip()
        return (obj and obj.type == 'MESH'
                and len(_get_obj_layers(obj)) > 0
                and bool(name))

    def execute(self, context):
        obj   = context.active_object
        layer = obj.seam_layers[obj.seam_layer_active]
        name  = context.scene.ss_preset_name.strip()

        if obj.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            edges = [[e.verts[0].index, e.verts[1].index] for e in bm.edges if e.select]
        else:
            edges = [[e.vertices[0], e.vertices[1]] for e in obj.data.edges if e.select]

        presets = _load_presets()
        presets[name] = {
            'width':      layer.width,
            'strength':   layer.strength,
            'color':      list(layer.shadow_color),
            'falloff':    layer.falloff,
            'edges':      edges,
            'vert_count': len(obj.data.vertices),
        }
        # Оновлюємо порядок: новий пресет в кінець, існуючий — на місці
        order = _get_preset_order(presets)
        if name not in order:
            order.append(name)
        presets['__order__'] = order
        _save_presets(presets)
        _reselect_preset(context.scene, name)      # щойно збережений — одразу вибраний
        _refresh_preset_ui()
        layer.name = name
        context.scene.ss_preset_name = ""
        self.report({'INFO'}, f"Saved preset '{name}' ({len(edges)} edges)")
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_apply_settings(bpy.types.Operator):
    bl_idname      = "seam_shadow.preset_apply_settings"
    bl_label       = "Apply Settings"
    bl_description = "Застосувати ширину/силу/колір/згасання з пресета до активного шару"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        sel = getattr(context.scene, 'ss_preset_selected', '__none__')
        return obj and obj.type == 'MESH' and obj.active_material and sel != '__none__'

    def execute(self, context):
        obj  = context.active_object
        mat  = obj.active_material
        name = context.scene.ss_preset_selected

        presets = _load_presets()
        if name not in presets:
            self.report({'WARNING'}, f"Preset '{name}' not found")
            return {'CANCELLED'}

        layers = obj.seam_layers
        if len(layers) == 0 or not (0 <= obj.seam_layer_active < len(layers)):
            new_l = layers.add()
            new_l.attr_name     = _next_attr_name(layers)
            new_l.name          = name
            new_l.baked         = False
            new_l.material_name = mat.name if mat else ""
            obj.seam_layer_active = len(layers) - 1

        layer = layers[obj.seam_layer_active]
        layer.width, layer.strength, layer.shadow_color, layer.falloff = _preset_values(presets[name])
        self.report({'INFO'}, f"Applied color/width/strength from '{name}' to '{layer.name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_apply_full(bpy.types.Operator):
    bl_idname      = "seam_shadow.preset_apply_full"
    bl_label       = "Apply Edges + Settings"
    bl_description = "Виділити ребра з пресета + застосувати налаштування. Працює тільки якщо кількість вершин меша збігається"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        sel = getattr(context.scene, 'ss_preset_selected', '__none__')
        return obj and obj.type == 'MESH' and obj.active_material and sel != '__none__'

    def execute(self, context):
        obj  = context.active_object
        mat  = obj.active_material
        name = context.scene.ss_preset_selected

        # спершу перевіряємо пресет — раніше при відсутньому пресеті вже встигав
        # створитись порожній зайвий шар
        presets = _load_presets()
        if name not in presets:
            self.report({'WARNING'}, f"Preset '{name}' not found")
            return {'CANCELLED'}

        layers = obj.seam_layers
        # Шукаємо існуючий шар з таким самим іменем — кожен пресет у свій слот
        target_idx = next((i for i, l in enumerate(layers) if l.name == name), None)
        if target_idx is not None:
            obj.seam_layer_active = target_idx
        else:
            new_l = layers.add()
            new_l.attr_name     = _next_attr_name(layers)
            new_l.name          = name
            new_l.baked         = False
            new_l.material_name = mat.name if mat else ""
            obj.seam_layer_active = len(layers) - 1

        layer = layers[obj.seam_layer_active]

        p = presets[name]
        layer.width, layer.strength, layer.shadow_color, layer.falloff = _preset_values(p)

        edges = p.get('edges', [])
        if not edges:
            self.report({'INFO'}, f"Applied settings from '{name}' (no edges stored)")
            return {'FINISHED'}

        vc = p.get('vert_count', 0)
        if vc and len(obj.data.vertices) != vc:
            self.report({'WARNING'},
                f"Vert mismatch: preset={vc}, obj={len(obj.data.vertices)}. Settings applied, edges skipped.")
            return {'FINISHED'}

        edge_set = {(min(a, b), max(a, b)) for a, b in edges}

        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

        found = 0
        for e in bm.edges:
            key = (min(e.verts[0].index, e.verts[1].index),
                   max(e.verts[0].index, e.verts[1].index))
            if key in edge_set:
                e.select = True
                found += 1

        bm.select_flush_mode()
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"'{name}': виділено {found}/{len(edges)} ребер — тепер натисни Bake & Apply")
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_export(bpy.types.Operator, ExportHelper):
    bl_idname      = "seam_shadow.preset_export"
    bl_label       = "Export Presets"
    bl_description = "Зберегти всі пресети в JSON-файл (щоб поділитись)"
    bl_options     = {'REGISTER'}
    filename_ext   = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        presets = _load_presets()
        if not presets:
            self.report({'WARNING'}, "No presets to export")
            return {'CANCELLED'}
        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(presets, f, indent=2, ensure_ascii=False)
            n = sum(1 for k in presets if not k.startswith('__'))
            self.report({'INFO'}, f"Exported {n} preset(s)")
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_import(bpy.types.Operator, ImportHelper):
    bl_idname      = "seam_shadow.preset_import"
    bl_label       = "Import Presets"
    bl_description = "Завантажити пресети з JSON-файлу (додаються до існуючих)"
    bl_options     = {'REGISTER'}
    filename_ext   = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                incoming = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}
        if not isinstance(incoming, dict):
            self.report({'ERROR'}, "Це не файл пресетів Seam Shadow")
            return {'CANCELLED'}
        sel = _selected_preset(context.scene)
        presets = _load_presets()
        order = _get_preset_order(presets)           # свій порядок лишаємо
        names = [k for k in _get_preset_order(incoming) if isinstance(incoming.get(k), dict)]
        overwritten = [k for k in names if k in presets]
        for k in names:
            presets[k] = incoming[k]
            if k not in order:
                order.append(k)                      # нові — в кінець, у порядку файлу
        presets['__order__'] = order
        _save_presets(presets)
        _reselect_preset(context.scene, sel)
        _refresh_preset_ui()
        msg = f"Imported {len(names)} preset(s)"
        if overwritten:
            msg += f"; замінено однойменні: {', '.join(overwritten[:5])}" + ("…" if len(overwritten) > 5 else "")
        self.report({'WARNING'} if overwritten else {'INFO'}, msg)
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_delete(bpy.types.Operator):
    bl_idname      = "seam_shadow.preset_delete"
    bl_label       = "Delete Preset"
    bl_description = "Видалити вибраний пресет з файлу"
    bl_options     = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return getattr(context.scene, 'ss_preset_selected', '__none__') != '__none__'

    def execute(self, context):
        name    = context.scene.ss_preset_selected
        presets = _load_presets()
        if name in presets:
            del presets[name]
            # Прибираємо з порядку
            order = [k for k in presets.get('__order__', []) if k != name]
            presets['__order__'] = order
            _save_presets(presets)
            _reselect_preset(context.scene, None)
            _refresh_preset_ui()
            self.report({'INFO'}, f"Deleted preset '{name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_move(bpy.types.Operator):
    bl_idname  = "seam_shadow.preset_move"
    bl_description = "Посунути пресет вище/нижче"
    bl_label   = "Move Preset"
    bl_options = {'REGISTER'}

    direction: bpy.props.EnumProperty(
        items=[('UP', 'Up', ''), ('DOWN', 'Down', '')]
    )

    @classmethod
    def poll(cls, context):
        return getattr(context.scene, 'ss_preset_selected', '__none__') != '__none__'

    def execute(self, context):
        name    = context.scene.ss_preset_selected
        presets = _load_presets()
        order   = _get_preset_order(presets)
        if name not in order:
            return {'CANCELLED'}
        i = order.index(name)
        if self.direction == 'UP' and i > 0:
            order[i], order[i - 1] = order[i - 1], order[i]
        elif self.direction == 'DOWN' and i < len(order) - 1:
            order[i], order[i + 1] = order[i + 1], order[i]
        else:
            return {'CANCELLED'}
        presets['__order__'] = order
        _save_presets(presets)
        _reselect_preset(context.scene, name)      # вибір їде разом з пресетом
        _refresh_preset_ui()
        return {'FINISHED'}


class SEAM_SHADOW_OT_preset_row_action(bpy.types.Operator):
    """Дія (Up/Down/Delete) на конкретному пресеті по імені — для розгорнутого
    списку, де кожен рядок має власні кнопки і не треба спершу обирати
    пресет у випадайці."""
    bl_idname  = "seam_shadow.preset_row_action"
    bl_label   = "Preset Row Action"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: bpy.props.StringProperty()
    action: bpy.props.EnumProperty(
        items=[('UP', 'Up', ''), ('DOWN', 'Down', ''), ('DELETE', 'Delete', '')]
    )

    def execute(self, context):
        sel     = _selected_preset(context.scene)   # запам'ятати вибір ДО зміни порядку
        presets = _load_presets()
        order   = _get_preset_order(presets)
        if self.preset_name not in order:
            return {'CANCELLED'}
        i = order.index(self.preset_name)

        if self.action == 'DELETE':
            if self.preset_name in presets:
                del presets[self.preset_name]
            order.pop(i)
            if sel == self.preset_name:
                sel = None
        elif self.action == 'UP' and i > 0:
            order[i], order[i - 1] = order[i - 1], order[i]
        elif self.action == 'DOWN' and i < len(order) - 1:
            order[i], order[i + 1] = order[i + 1], order[i]
        else:
            return {'CANCELLED'}

        presets['__order__'] = order
        _save_presets(presets)
        _reselect_preset(context.scene, sel)       # вибір лишається на тому ж пресеті
        _refresh_preset_ui()
        return {'FINISHED'}


# ─── panel ────────────────────────────────────────────────────────────────────

class SEAM_SHADOW_PT_panel(bpy.types.Panel):
    bl_label       = "Seam Shadow"
    bl_idname      = "SEAM_SHADOW_PT_panel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'Seam Shadow'

    def draw(self, context):
        layout = self.layout
        obj    = context.active_object

        layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

        if not (obj and obj.type == 'MESH'):
            layout.label(text="Select a mesh object", icon='INFO')
            return

        layers   = obj.seam_layers
        idx      = obj.seam_layer_active
        mat      = obj.active_material
        mat_name = mat.name if mat else ""

        row = layout.row(align=False)
        lst = row.column()
        box = lst.box()
        box.scale_y = 0.9

        all_layers = list(enumerate(layers))
        if all_layers:
            for gi, layer in all_layers:
                is_active  = (gi == idx)
                is_cur_mat = (layer.material_name == mat_name or not layer.material_name)

                # ── визначаємо статус шару ──
                if not layer.material_name:
                    status_icon  = 'ERROR'
                    status_alert = True   # не прив'язаний до матеріалу
                elif not is_cur_mat:
                    status_icon  = 'MATERIAL'
                    status_alert = False  # інший матеріал — просто інформація
                elif not layer.baked:
                    status_icon  = 'QUESTION'
                    status_alert = False  # ще не бейкнуто — нормальний стан
                elif mat and _layer_in_shader(mat, layer.attr_name):
                    status_icon  = 'CHECKMARK'
                    status_alert = False  # ✅ бейкнуто + в шейдері
                else:
                    status_icon  = 'UNLINKED'
                    status_alert = True   # ⚠ бейкнуто, але шейдер не застосований

                r = box.row(align=True)
                r.label(text="", icon='LAYER_ACTIVE' if is_active else 'LAYER_USED')
                r.prop(layer, "enabled", text="")
                if is_active:
                    r.operator("seam_shadow.keyframe_enabled", icon='KEYFRAME_HLT', text="")
                btn_text = f"#{gi + 1}  {layer.name}"
                op = r.operator("seam_shadow.select_layer",
                                text=btn_text, emboss=is_active, depress=is_active)
                op.index = gi
                status_col = r.column()
                status_col.alert = status_alert
                status_col.label(text="", icon=status_icon)
        else:
            box.label(text="No seam layers", icon='INFO')

        btn = row.column(align=True)
        btn.operator("seam_shadow.add_layer",    icon='ADD',          text="")
        btn.operator("seam_shadow.remove_layer", icon='REMOVE',       text="")
        btn.separator()
        op_up = btn.operator("seam_shadow.move_layer", icon='TRIA_UP',   text="")
        op_up.direction = 'UP'
        op_dn = btn.operator("seam_shadow.move_layer", icon='TRIA_DOWN', text="")
        op_dn.direction = 'DOWN'
        btn.separator()
        btn.operator("seam_shadow.refresh",      icon='FILE_REFRESH', text="")

        if not all_layers:
            layout.operator("seam_shadow.recover_layers", icon='RECOVER_LAST',
                            text="Recover Layers from Mesh")

        if mat_name:
            layout.label(text=f"Obj: {obj.name}  |  Mat: {mat_name}", icon='OBJECT_DATA')

        layout.separator()

        if layers and 0 <= idx < len(layers):
            layer = layers[idx]
            box2  = layout.box()
            box2.prop(layer, "name", text="Name")
            row_cp = box2.row(align=True)
            row_cp.operator("seam_shadow.copy_preset", icon='COPYDOWN',  text="Copy Preset")
            row_cp.operator("seam_shadow.paste_preset", icon='PASTEDOWN', text="Paste Preset")
            box2.separator()

            col = box2.column(align=True)
            col.prop(layer, "width_cm", slider=True)
            col.prop(layer, "strength", slider=True)
            box2.prop(layer, "shadow_color", text="Color")
            row2 = box2.row(align=True)
            row2.prop(layer, "falloff", expand=True)
            box2.separator()

            box2.operator("seam_shadow.clear_layer", icon='TRASH', text="Clear Bake (this object)")
            if layer.baked:
                box2.label(text="Baked OK", icon='CHECKMARK')
                lmat = bpy.data.materials.get(layer.material_name)
                copies = _seam_copies(lmat, layer.attr_name)
                if copies > 1:
                    warn = box2.column(align=True)
                    warn.alert = True
                    warn.label(text=f"Шов намальований {copies} рази (дубль зі старої версії)", icon='ERROR')
                    warn.label(text="Натисни «Rebuild Shader» — лишиться один")
            else:
                box2.label(text="Not baked — select edges first", icon='ERROR')

        layout.separator()

        # ── Presets ──────────────────────────────────────────────────────────
        box_p = layout.box()
        box_p.label(text="Presets", icon='PRESET')

        row_p1 = box_p.row(align=True)
        row_p1.prop(context.scene, "ss_preset_name", text="")
        row_p1.operator("seam_shadow.preset_save", icon='ADD', text="Save")

        has_preset = (getattr(context.scene, 'ss_preset_selected', '__none__') != '__none__')
        row_p2 = box_p.row(align=True)
        row_p2.prop(context.scene, "ss_preset_selected", text="")
        op_up = row_p2.operator("seam_shadow.preset_move", icon='TRIA_UP',   text="")
        op_up.direction = 'UP'
        op_dn = row_p2.operator("seam_shadow.preset_move", icon='TRIA_DOWN', text="")
        op_dn.direction = 'DOWN'
        row_p2.operator("seam_shadow.preset_delete", icon='TRASH', text="")

        row_apply = box_p.row(align=True)
        row_apply.scale_y = 1.3 if has_preset else 1.0
        row_apply.operator("seam_shadow.preset_apply_settings", icon='SETTINGS', text="Settings")
        row_apply.operator("seam_shadow.preset_apply_full",     icon='EDGESEL',  text="Edges+")

        row_p3 = box_p.row(align=True)
        row_p3.operator("seam_shadow.preset_export", icon='EXPORT', text="Export")
        row_p3.operator("seam_shadow.preset_import", icon='IMPORT', text="Import")

        order = _get_preset_order(_load_presets())
        row_exp = box_p.row()
        row_exp.prop(context.scene, "ss_presets_expanded",
                     icon='TRIA_DOWN' if context.scene.ss_presets_expanded else 'TRIA_RIGHT',
                     icon_only=True, emboss=False,
                     text=f"All Presets ({len(order)})")
        if context.scene.ss_presets_expanded:
            col_list = box_p.column(align=True)
            for i, pname in enumerate(order):
                r = col_list.row(align=True)
                r.label(text=pname)

                sub_up = r.row(align=True)
                sub_up.enabled = i > 0
                op_u = sub_up.operator("seam_shadow.preset_row_action", icon='TRIA_UP', text="")
                op_u.preset_name = pname
                op_u.action      = 'UP'

                sub_dn = r.row(align=True)
                sub_dn.enabled = i < len(order) - 1
                op_d = sub_dn.operator("seam_shadow.preset_row_action", icon='TRIA_DOWN', text="")
                op_d.preset_name = pname
                op_d.action      = 'DOWN'

                op_x = r.operator("seam_shadow.preset_row_action", icon='X', text="")
                op_x.preset_name = pname
                op_x.action      = 'DELETE'

        layout.separator()

        active_layer = layers[idx] if (layers and 0 <= idx < len(layers)) else None
        big = layout.row()
        big.scale_y = 1.6
        if active_layer and not active_layer.baked:
            big.alert = True  # червоний — нагадує що треба бейкнути
        big.operator("seam_shadow.bake_and_apply", icon='SHADERFX', text="Bake & Apply")

        row_add = layout.row(align=True)
        row_add.scale_y = 1.2
        row_add.operator("seam_shadow.add_to_layer",      icon='SELECT_EXTEND',   text="Add Edges")
        row_add.operator("seam_shadow.remove_from_layer", icon='SELECT_SUBTRACT', text="Remove Edges")

        layout.operator("seam_shadow.apply_shader", icon='FILE_REFRESH',
                        text="Rebuild Shader (fix broken nodes)")

        if mat and mat.use_nodes:
            tree, _ = _find_principled(mat)
            if tree:
                has = any(n.get('ss_layer') is not None for n in tree.nodes)
                layout.label(
                    text="Shader: active" if has else "Shader: not applied",
                    icon='CHECKMARK' if has else 'DOT',
                )

        ver = ADDON_VERSION
        layout.label(text=f"Seam Shadow  v{ver[0]}.{ver[1]}.{ver[2]}", icon='SCRIPT')


# ═══════════════════════════════════════════════════════════════════════════════
# GRADIENT PAINTER — completely separate, sg_* tags, sg_* attrs
# ═══════════════════════════════════════════════════════════════════════════════

def _next_grad_attr_name():
    used = set()
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and hasattr(obj, 'gradient_layers'):
            for l in obj.gradient_layers:
                used.add(l.attr_name)
    i = 0
    while f"sg_{i}" in used:
        i += 1
    return f"sg_{i}"


def _dijkstra_dist(mesh, source_verts):
    n   = len(mesh.vertices)
    adj = [[] for _ in range(n)]
    for edge in mesh.edges:
        va, vb = edge.vertices[0], edge.vertices[1]
        length = (mesh.vertices[va].co - mesh.vertices[vb].co).length
        adj[va].append((length, vb))
        adj[vb].append((length, va))
    INF  = float('inf')
    dist = [INF] * n
    heap = []
    for vi in source_verts:
        if 0 <= vi < n:
            dist[vi] = 0.0
            heapq.heappush(heap, (0.0, vi))
    while heap:
        d, vi = heapq.heappop(heap)
        if d > dist[vi]:
            continue
        for el, vj in adj[vi]:
            nd2 = d + el
            if nd2 < dist[vj]:
                dist[vj] = nd2
                heapq.heappush(heap, (nd2, vj))
    return dist


def _run_gradient_bake(mesh, src_verts, tgt_verts, attr_name):
    """
    Geodesic gradient. value=0 at src_verts, value=1 at tgt_verts.
    If tgt_verts is empty: falloff from source, normalized by max distance.
    """
    INF    = float('inf')
    dist_s = _dijkstra_dist(mesh, src_verts)

    if tgt_verts:
        dist_t = _dijkstra_dist(mesh, tgt_verts)
        values = []
        for i in range(len(mesh.vertices)):
            ds, dt = dist_s[i], dist_t[i]
            if ds == INF and dt == INF:
                values.append(0.5)
            elif ds == INF:
                values.append(1.0)
            elif dt == INF:
                values.append(0.0)
            else:
                total = ds + dt
                values.append(ds / total if total > 0 else 0.0)
    else:
        finite = [d for d in dist_s if d < INF]
        max_d  = max(finite) if finite else 1.0
        if max_d == 0.0:
            max_d = 1.0
        values = [min(1.0, d / max_d) if d < INF else 1.0 for d in dist_s]

    _store_float_attr(mesh, attr_name, values)
    log(f"[GradBake] attr={attr_name} src={len(src_verts)} tgt={len(tgt_verts)}")


def _update_gradient_live(self, context):
    obj = context.active_object
    if not (obj and obj.type == 'MESH' and obj.active_material):
        return
    mat = obj.active_material
    if not mat.use_nodes:
        return
    tree, _ = _find_principled(mat)
    if tree is None:
        return
    a = self.attr_name
    for n in tree.nodes:
        if n.get('sg_layer') != a:
            continue
        role = n.get('sg_role')
        if role == 'multiply':
            _set_if_changed(n.inputs[1], self.strength)
        elif role == 'mix':
            _set_if_changed(n.inputs[2], (*self.grad_color, 1.0))


def _rebuild_gradient_on_change(self, context):
    obj = context.active_object
    if not (obj and obj.type == 'MESH' and obj.active_material):
        return
    mat = obj.active_material
    if not mat.use_nodes:
        return
    tree, _ = _find_principled(mat)
    if tree is None:
        return
    a     = self.attr_name
    muted = not self.enabled
    for n in tree.nodes:
        if n.get('sg_layer') == a:
            n.mute = muted


def _clean_gradient_nodes(tree):
    to_rm = [n for n in tree.nodes if n.get('sg_layer') is not None]
    for n in to_rm:
        tree.nodes.remove(n)


def _get_pre_gradient_socket(tree, principled):
    """Walk back through sg_role='mix' chain to find real upstream socket."""
    base_in = principled.inputs['Base Color']
    if not base_in.is_linked:
        return None, tuple(base_in.default_value)
    sock = base_in.links[0].from_socket
    node = sock.node
    while node.get('sg_role') == 'mix':
        inp = node.inputs[1]
        if inp.is_linked:
            sock = inp.links[0].from_socket
            node = sock.node
        else:
            return None, tuple(inp.default_value)
    return sock, None


def _rebuild_gradient_shader(mat, gradient_layers):
    """Full rebuild of gradient node chain. sg_* nodes only, ss_* untouched."""
    tree, principled = _find_principled(mat)
    if principled is None:
        return False, "No Principled BSDF found"

    nodes = tree.nodes
    links = tree.links

    up_sock, up_default = _get_pre_gradient_socket(tree, principled)
    _clean_gradient_nodes(tree)

    active = [l for l in gradient_layers if l.enabled and l.baked]

    if not active:
        if up_sock:
            links.new(up_sock, principled.inputs['Base Color'])
        elif up_default is not None:
            principled.inputs['Base Color'].default_value = up_default
        return True, "No active gradient layers"

    px = principled.location.x - 420
    py = principled.location.y + 260
    prev_sock = up_sock

    for i, layer in enumerate(active):
        a = layer.attr_name
        y = py - i * 200

        def mk(tp, xo, yo, role, lbl="", a=a, y=y):
            nd = nodes.new(tp)
            nd.location   = (px + xo, y + yo)
            nd['sg_layer'] = a
            nd['sg_role']  = role
            if lbl:
                nd.label = lbl
            return nd

        attr_nd = mk('ShaderNodeAttribute', -220, -60, 'attr',     f"{layer.name}: grad")
        mul_nd  = mk('ShaderNodeMath',         0, -60, 'multiply', f"{layer.name}: str")
        mix_nd  = mk('ShaderNodeMixRGB',      180,   0, 'mix',      layer.name)

        attr_nd.attribute_name = a
        attr_nd.attribute_type = 'GEOMETRY'

        mul_nd.operation = 'MULTIPLY'
        mul_nd.inputs[1].default_value = layer.strength
        mul_nd.use_clamp = True

        mix_nd.blend_type = 'MULTIPLY'
        mix_nd.inputs[2].default_value = (*layer.grad_color, 1.0)

        links.new(attr_nd.outputs['Fac'],  mul_nd.inputs[0])
        links.new(mul_nd.outputs['Value'], mix_nd.inputs['Fac'])

        if prev_sock:
            links.new(prev_sock, mix_nd.inputs[1])
        else:
            mix_nd.inputs[1].default_value = up_default or (1.0, 1.0, 1.0, 1.0)

        prev_sock = mix_nd.outputs['Color']

    links.new(prev_sock, principled.inputs['Base Color'])
    return True, f"{len(active)} gradient(s) applied"


def _ensure_gradient_in_shader(mat, layer):
    """Add or update single gradient layer — no full rebuild."""
    tree, principled = _find_principled(mat)
    if principled is None:
        return False, "No Principled BSDF found"

    nodes = tree.nodes
    links = tree.links
    a     = layer.attr_name

    existing = {n.get('sg_role'): n for n in nodes if n.get('sg_layer') == a}

    if existing:
        if 'multiply' in existing:
            existing['multiply'].inputs[1].default_value = layer.strength
        if 'mix' in existing:
            existing['mix'].inputs[2].default_value = (*layer.grad_color, 1.0)
        muted = not layer.enabled
        for n in existing.values():
            n.mute = muted
        return True, f"Updated gradient '{layer.name}'"

    # New layer — insert before current Principled input
    base_in = principled.inputs['Base Color']
    if base_in.is_linked:
        up_sock    = base_in.links[0].from_socket
        up_default = None
    else:
        up_sock    = None
        up_default = tuple(base_in.default_value)

    sg_count = sum(1 for n in nodes if n.get('sg_role') == 'mix')
    px = principled.location.x - 420
    py = principled.location.y + 260 - sg_count * 200

    def mk(tp, xo, yo, role, lbl=""):
        nd = nodes.new(tp)
        nd.location    = (px + xo, py + yo)
        nd['sg_layer'] = a
        nd['sg_role']  = role
        if lbl:
            nd.label = lbl
        return nd

    attr_nd = mk('ShaderNodeAttribute', -220, -60, 'attr',     f"{layer.name}: grad")
    mul_nd  = mk('ShaderNodeMath',         0, -60, 'multiply', f"{layer.name}: str")
    mix_nd  = mk('ShaderNodeMixRGB',      180,   0, 'mix',      layer.name)

    attr_nd.attribute_name = a
    attr_nd.attribute_type = 'GEOMETRY'
    mul_nd.operation = 'MULTIPLY'
    mul_nd.inputs[1].default_value = layer.strength
    mul_nd.use_clamp = True
    mix_nd.blend_type = 'MULTIPLY'
    mix_nd.inputs[2].default_value = (*layer.grad_color, 1.0)

    links.new(attr_nd.outputs['Fac'],  mul_nd.inputs[0])
    links.new(mul_nd.outputs['Value'], mix_nd.inputs['Fac'])

    if up_sock:
        links.new(up_sock, mix_nd.inputs[1])
    else:
        mix_nd.inputs[1].default_value = up_default or (1.0, 1.0, 1.0, 1.0)

    links.new(mix_nd.outputs['Color'], principled.inputs['Base Color'])

    if not layer.enabled:
        for n in (attr_nd, mul_nd, mix_nd):
            n.mute = True

    return True, f"Added gradient '{layer.name}'"


# ─── Gradient data model ───────────────────────────────────────────────────────

class GradientLayer(bpy.types.PropertyGroup):
    name:           bpy.props.StringProperty(name="Name", default="Gradient")
    attr_name:      bpy.props.StringProperty()
    baked:          bpy.props.BoolProperty(default=False)
    material_name:  bpy.props.StringProperty()
    has_source:     bpy.props.BoolProperty(default=False)
    has_target:     bpy.props.BoolProperty(default=False)
    src_verts_json: bpy.props.StringProperty(default="[]")
    tgt_verts_json: bpy.props.StringProperty(default="[]")

    strength: bpy.props.FloatProperty(description="Сила градієнта", 
        name="Strength", default=0.5, min=0.0, max=1.0,
        update=_update_gradient_live,
    )
    grad_color: bpy.props.FloatVectorProperty(description="Колір градієнта", 
        name="Color", subtype='COLOR_GAMMA',
        default=(0.0, 0.0, 0.0), min=0.0, max=1.0,
        update=_update_gradient_live,
    )
    enabled: bpy.props.BoolProperty(description="Увімкнути / вимкнути цей градієнт", name="", default=True, update=_rebuild_gradient_on_change)


# ─── Gradient helpers ──────────────────────────────────────────────────────────

def _grad_get_selected_verts(obj):
    """Sync edit mesh → object data, return selected edge vert indices."""
    prev_mode = obj.mode
    if prev_mode == 'EDIT':
        bpy.ops.object.mode_set(mode='OBJECT')
    verts = set()
    for edge in obj.data.edges:
        if edge.select:
            verts.add(edge.vertices[0])
            verts.add(edge.vertices[1])
    if prev_mode == 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    return verts


# ─── Gradient operators ────────────────────────────────────────────────────────

class SEAM_SHADOW_OT_grad_add(bpy.types.Operator):
    bl_idname  = "seam_shadow.grad_add"
    bl_description = "Додати шар градієнта"
    bl_label   = "Add Gradient Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.active_material

    def execute(self, context):
        obj    = context.active_object
        mat    = obj.active_material
        layers = obj.gradient_layers
        layer  = layers.add()
        layer.attr_name     = _next_grad_attr_name()
        layer.name          = f"Gradient {len(layers)}"
        layer.material_name = mat.name if mat else ""
        obj.gradient_layer_active = len(layers) - 1
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_remove(bpy.types.Operator):
    bl_idname  = "seam_shadow.grad_remove"
    bl_description = "Видалити шар градієнта"
    bl_label   = "Remove Gradient Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and len(getattr(obj, 'gradient_layers', [])) > 0

    def execute(self, context):
        obj    = context.active_object
        layers = obj.gradient_layers
        idx    = obj.gradient_layer_active
        if idx < 0 or idx >= len(layers):
            return {'CANCELLED'}

        a = layers[idx].attr_name
        try:
            _remove_float_attr(obj.data, a)
        except Exception as e:
            log(f"[GradRemove] {e}")

        layers.remove(idx)
        obj.gradient_layer_active = min(max(idx - 1, 0), max(len(layers) - 1, 0))

        if obj.active_material:
            _rebuild_gradient_shader(obj.active_material, obj.gradient_layers)
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_select_layer(bpy.types.Operator):
    bl_idname  = "seam_shadow.grad_select_layer"
    bl_description = "Вибрати цей шар градієнта"
    bl_label   = "Select Gradient Layer"
    bl_options = set()
    index: bpy.props.IntProperty()

    def execute(self, context):
        obj = context.active_object
        if obj:
            obj.gradient_layer_active = self.index
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_set_source(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_set_source"
    bl_label       = "Set Source"
    bl_description = "Позначити виділені ребра як джерело градієнта (темний кінець, значення 0)"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = getattr(obj, 'gradient_layers', [])
        idx    = getattr(obj, 'gradient_layer_active', -1)
        return obj and obj.type == 'MESH' and 0 <= idx < len(layers)

    def execute(self, context):
        obj   = context.active_object
        layer = obj.gradient_layers[obj.gradient_layer_active]
        verts = _grad_get_selected_verts(obj)
        if not verts:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}
        layer.src_verts_json = json.dumps(list(verts))
        layer.has_source     = True
        self.report({'INFO'}, f"Source set: {len(verts)} verts")
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_set_target(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_set_target"
    bl_label       = "Set Target"
    bl_description = "Позначити виділені ребра як ціль градієнта (світлий кінець, значення 1). Необов'язково"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = getattr(obj, 'gradient_layers', [])
        idx    = getattr(obj, 'gradient_layer_active', -1)
        return obj and obj.type == 'MESH' and 0 <= idx < len(layers)

    def execute(self, context):
        obj   = context.active_object
        layer = obj.gradient_layers[obj.gradient_layer_active]
        verts = _grad_get_selected_verts(obj)
        if not verts:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}
        layer.tgt_verts_json = json.dumps(list(verts))
        layer.has_target     = True
        self.report({'INFO'}, f"Target set: {len(verts)} verts")
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_clear_target(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_clear_target"
    bl_label       = "Clear Target"
    bl_description = "Прибрати ціль — градієнт вільно згасає від джерела"
    bl_options     = set()

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = getattr(obj, 'gradient_layers', [])
        idx    = getattr(obj, 'gradient_layer_active', -1)
        return (obj and obj.type == 'MESH'
                and 0 <= idx < len(layers) and layers[idx].has_target)

    def execute(self, context):
        obj   = context.active_object
        layer = obj.gradient_layers[obj.gradient_layer_active]
        layer.tgt_verts_json = "[]"
        layer.has_target     = False
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_bake(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_bake"
    bl_label       = "Bake Gradient"
    bl_description = "Запекти градієнт по поверхні від джерела до цілі (або вільне згасання)"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = getattr(obj, 'gradient_layers', [])
        idx    = getattr(obj, 'gradient_layer_active', -1)
        return (obj and obj.type == 'MESH' and obj.active_material
                and 0 <= idx < len(layers) and layers[idx].has_source)

    def execute(self, context):
        obj   = context.active_object
        mat   = obj.active_material
        layer = obj.gradient_layers[obj.gradient_layer_active]

        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}

        src_verts = set(json.loads(layer.src_verts_json))
        tgt_verts = set(json.loads(layer.tgt_verts_json)) if layer.has_target else set()

        if not src_verts:
            self.report({'WARNING'}, "No source verts — use Set Source first")
            return {'CANCELLED'}

        _run_gradient_bake(obj.data, src_verts, tgt_verts, layer.attr_name)
        layer.baked         = True
        layer.material_name = mat.name

        ok, msg = _ensure_gradient_in_shader(mat, layer)
        log(f"[GradShader] {msg}")
        if not ok:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        self.report({'INFO'}, f"Gradient '{layer.name}' baked")
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_clear(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_clear"
    bl_label       = "Clear Bake"
    bl_description = "Видалити запечений градієнт з цього меша"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj    = context.active_object
        layers = getattr(obj, 'gradient_layers', [])
        idx    = getattr(obj, 'gradient_layer_active', -1)
        return obj and obj.type == 'MESH' and 0 <= idx < len(layers)

    def execute(self, context):
        obj   = context.active_object
        layer = obj.gradient_layers[obj.gradient_layer_active]
        try:
            _remove_float_attr(obj.data, layer.attr_name)
        except Exception as e:
            log(f"[GradClear] {e}")
        layer.baked = False
        self.report({'INFO'}, f"Cleared gradient '{layer.name}'")
        return {'FINISHED'}


class SEAM_SHADOW_OT_grad_apply_shader(bpy.types.Operator):
    bl_idname      = "seam_shadow.grad_apply_shader"
    bl_label       = "Update Gradient Shader"
    bl_description = "Перебудувати ноди шейдера градієнта (без перезапікання)"
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.active_material

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        if mat.library is not None:
            self.report({'ERROR'}, "Material is linked — make local first")
            return {'CANCELLED'}
        ok, msg = _rebuild_gradient_shader(mat, obj.gradient_layers)
        self.report({'INFO' if ok else 'ERROR'}, msg)
        return {'FINISHED' if ok else 'CANCELLED'}


# ─── Gradient panel ────────────────────────────────────────────────────────────

class SEAM_SHADOW_PT_gradient(bpy.types.Panel):
    bl_label       = "Gradient Painter"
    bl_idname      = "SEAM_SHADOW_PT_gradient"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'Seam Shadow'
    bl_options     = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        obj    = context.active_object

        if not (obj and obj.type == 'MESH'):
            layout.label(text="Select a mesh object", icon='INFO')
            return

        layers = obj.gradient_layers
        idx    = obj.gradient_layer_active

        # ── layer list ────────────────────────────────────────
        row = layout.row(align=False)
        lst = row.column()
        box = lst.box()
        box.scale_y = 0.9

        if layers:
            for i, layer in enumerate(layers):
                r = box.row(align=True)
                is_active = (i == idx)
                r.label(text="", icon='LAYER_ACTIVE' if is_active else 'LAYER_USED')
                r.prop(layer, "enabled", text="")
                op = r.operator("seam_shadow.grad_select_layer",
                                text=layer.name, emboss=is_active, depress=is_active)
                op.index = i
                r.label(text="", icon='CHECKMARK' if layer.baked else 'QUESTION')
        else:
            box.label(text="No gradient layers", icon='INFO')

        btn = row.column(align=True)
        btn.operator("seam_shadow.grad_add",    icon='ADD',    text="")
        btn.operator("seam_shadow.grad_remove", icon='REMOVE', text="")

        layout.separator()

        if layers and 0 <= idx < len(layers):
            layer = layers[idx]
            box2  = layout.box()
            box2.prop(layer, "name", text="Name")
            box2.separator()

            col = box2.column(align=True)
            col.prop(layer, "strength", slider=True)
            box2.prop(layer, "grad_color", text="Color")
            box2.separator()

            # Source
            row_s = box2.row(align=True)
            icon_s = 'CHECKMARK' if layer.has_source else 'RADIOBUT_OFF'
            row_s.operator("seam_shadow.grad_set_source", icon=icon_s,
                           text="Set Source  (dark, 0)")

            # Target
            row_t = box2.row(align=True)
            icon_t = 'CHECKMARK' if layer.has_target else 'RADIOBUT_OFF'
            row_t.operator("seam_shadow.grad_set_target", icon=icon_t,
                           text="Set Target  (light, 1)")
            if layer.has_target:
                row_t.operator("seam_shadow.grad_clear_target", icon='X', text="")

            if not layer.has_target:
                box2.label(text="No target → free falloff from source", icon='INFO')

            box2.separator()
            if layer.baked:
                box2.label(text="Baked OK", icon='CHECKMARK')
            else:
                box2.label(text="Not baked", icon='ERROR')
            box2.operator("seam_shadow.grad_clear", icon='TRASH', text="Clear Bake")

        layout.separator()

        big = layout.row()
        big.scale_y = 1.6
        big.operator("seam_shadow.grad_bake", icon='SHADERFX', text="Bake Gradient")

        layout.operator("seam_shadow.grad_apply_shader", icon='FILE_REFRESH',
                        text="Update Shader (no re-bake)")


# ─── persistence ──────────────────────────────────────────────────────────────

def _mat_output_node(tree):
    return (next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output), None)
            or next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL'), None))


def _has_reachable_cycle(mat):
    """True if the shader chain actually feeding Material Output loops back on
    itself. Years of accumulated bake/rebuild passes across old addon versions
    left a handful of materials with a genuine cycle among ss_group nodes —
    the in_chain check in _ensure_layer_top_level only avoids hanging on it,
    it does not repair it. This lets load_post detect and fully rebuild those."""
    tree = mat.node_tree
    if not tree:
        return False
    mat_out = _mat_output_node(tree)
    if not mat_out or not mat_out.inputs['Surface'].is_linked:
        return False
    def dfs(node, path):
        if node.name in path:
            return True
        path = path + [node.name]
        for inp in node.inputs:
            if inp.is_linked and dfs(inp.links[0].from_node, path):
                return True
        return False
    return dfs(mat_out.inputs['Surface'].links[0].from_node, [])


@bpy.app.handlers.persistent
def _seam_shadow_load_post(filepath):
    # Self-heal: прибрати старі "enabled" driver'и (v3.30), що створювали
    # структурний цикл залежностей у depsgraph (driver + update-колбек на
    # layer.enabled в одному "parameters eval" блоці об'єкта). Файли,
    # збережені під час тестування v3.30, самі вилікуються при відкритті.
    fixed_cycles = 0
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or not obj.animation_data:
            continue
        for fc in list(obj.animation_data.drivers):
            dp = fc.data_path
            if dp.startswith('["ss_') and dp.endswith('_enabled"]'):
                obj.driver_remove(dp)
                fixed_cycles += 1
    if fixed_cycles:
        log(f"[Fix] Removed {fixed_cycles} legacy 'enabled' driver(s) on load (dependency cycle fix)")

    # Копії об'єктів (Shift+D) з тим самим attr_name → кожна отримує свій шов.
    # Перший власник attr_name лишає собі оригінальну ноду.
    seen_attr = set()
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or not hasattr(obj, 'seam_layers'):
            continue
        for layer in obj.seam_layers:
            if not layer.attr_name:
                continue
            if layer.attr_name in seen_attr:
                layer.baked = layer.attr_name in obj.data.attributes
                try:
                    _split_shared_layer(obj, layer)
                except Exception as e:
                    log(f"[Fix] split failed for '{layer.name}' on '{obj.name}': {e}")
            seen_attr.add(layer.attr_name)

    updated = set()  # (mat_name, attr_name) — щоб не дублювати
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        if hasattr(obj, 'seam_layers'):
            for layer in obj.seam_layers:
                if layer.attr_name:
                    layer.baked = layer.attr_name in obj.data.attributes
                # Скидаємо параметри шейдера зі збережених властивостей шару.
                # Це виправляє "весь диван чорний" при відкритті на іншому комп'ютері —
                # MapRange та Strength відновлюються з layer.width / layer.strength.
                if layer.baked and layer.material_name:
                    mat = bpy.data.materials.get(layer.material_name)
                    key = (layer.material_name, layer.attr_name)
                    # Матеріали з зовнішнім Mix Shader-переходом (напр. Natural<->Oak
                    # keyframe switch) НЕ чіпаємо: перебудова seam-шарів тут не знає
                    # про 2 окремі гілки (host/embed), і сплайсить нові seam-ноди
                    # не в ту гілку — губить видимі шви на одній зі сторін. Такий
                    # матеріал вважається зовні керованим після побудови переходу.
                    has_transition = mat and mat.node_tree and any(
                        n.get('ss_transition') for n in mat.node_tree.nodes)
                    if mat and mat.library is None and key not in updated and not has_transition:
                        try:
                            _ensure_layer_in_shader(mat, layer)
                            updated.add(key)
                            mat.update_tag()
                        except Exception:
                            pass
                    # Initialize per-object enabled property
                    prop_key = f"ss_{layer.attr_name}_enabled"
                    if prop_key not in obj:
                        obj[prop_key] = 1.0 if layer.enabled else 0.0
                    obj.update_tag()
        if hasattr(obj, 'gradient_layers'):
            for layer in obj.gradient_layers:
                if layer.attr_name:
                    layer.baked = layer.attr_name in obj.data.attributes

    # Self-heal: якщо якийсь матеріал усе одно лишився зі справжнім циклом
    # (роками накопичена корупція зі старих версій, яку простий top-of-chain
    # relink не лагодить) — повністю перебудувати ЙОГО ланцюг з нуля з даних
    # obj.seam_layers (rebuild ідемпотентний і гарантовано ациклічний з чистого
    # старту). Виявлено 2026-07-28: без цього фікс "in_chain" лише ЛОГУВАВ
    # цикл і йшов далі, не усуваючи його — файл ламався знову при КОЖНОМУ
    # відкритті.
    touched_mat_names = {name for (name, _attr) in updated}
    for mat_name in touched_mat_names:
        mat = bpy.data.materials.get(mat_name)
        if not mat or mat.library is not None:
            continue
        if not _has_reachable_cycle(mat):
            continue
        layers_by_attr = {}
        for obj in bpy.data.objects:
            if obj.type != 'MESH' or not hasattr(obj, 'seam_layers'):
                continue
            for l in obj.seam_layers:
                if l.material_name == mat_name and l.attr_name:
                    layers_by_attr[l.attr_name] = l
        try:
            _rebuild_shader(mat, list(layers_by_attr.values()))
            log(f"[Fix] Rebuilt '{mat_name}' from scratch — reachable cycle detected in its shader chain")
        except Exception as e:
            log(f"[Fix] Failed to rebuild '{mat_name}' after cycle detection: {e}")
            continue

        # Third-party node setups (e.g. a Natural<->Oak material-switch Mix Shader,
        # tagged 'ss_transition') can have one input reading from whatever used to
        # feed this material's shader BEFORE the rebuild above — that upstream node
        # just got removed/replaced by _clean_seam_nodes+_rebuild_shader, orphaning
        # that input. Reconnect it to any remaining non-seam, non-transition shader
        # output so external node graphs built on top of this material keep working
        # after a self-heal pass. Found 2026-07-28 on the Natural/Oak switch project.
        for n in mat.node_tree.nodes:
            if not n.get('ss_transition'):
                continue
            for inp in n.inputs:
                if inp.type != 'SHADER' or inp.is_linked:
                    continue
                candidate = None
                for other in mat.node_tree.nodes:
                    if other is n or other.type == 'OUTPUT_MATERIAL':
                        continue
                    if other.get('ss_layer') is not None or other.get('ss_role') is not None:
                        continue
                    if other.get('ss_transition'):
                        continue
                    for out in other.outputs:
                        if out.type == 'SHADER':
                            candidate = out
                            break
                    if candidate:
                        break
                if candidate:
                    mat.node_tree.links.new(candidate, inp)
                    log(f"[Fix] Reconnected orphaned '{inp.name}' on ss_transition node in '{mat_name}' "
                        f"<- '{candidate.node.name}'")


# ─── register ─────────────────────────────────────────────────────────────────

classes = [
    SeamLayer,
    SEAM_SHADOW_OT_refresh,
    SEAM_SHADOW_OT_select_layer,
    SEAM_SHADOW_OT_add_layer,
    SEAM_SHADOW_OT_copy_preset,
    SEAM_SHADOW_OT_paste_preset,
    SEAM_SHADOW_OT_recover_layers,
    SEAM_SHADOW_OT_remove_layer,
    SEAM_SHADOW_OT_move_layer,
    SEAM_SHADOW_OT_keyframe_enabled,
    SEAM_SHADOW_OT_bake_and_apply,
    SEAM_SHADOW_OT_add_to_layer,
    SEAM_SHADOW_OT_remove_from_layer,
    SEAM_SHADOW_OT_apply_shader,
    SEAM_SHADOW_OT_clear_layer,
    SEAM_SHADOW_OT_preset_save,
    SEAM_SHADOW_OT_preset_apply_settings,
    SEAM_SHADOW_OT_preset_apply_full,
    SEAM_SHADOW_OT_preset_export,
    SEAM_SHADOW_OT_preset_import,
    SEAM_SHADOW_OT_preset_delete,
    SEAM_SHADOW_OT_preset_row_action,
    SEAM_SHADOW_OT_preset_move,
    SEAM_SHADOW_PT_panel,
    # Gradient
    GradientLayer,
    SEAM_SHADOW_OT_grad_add,
    SEAM_SHADOW_OT_grad_remove,
    SEAM_SHADOW_OT_grad_select_layer,
    SEAM_SHADOW_OT_grad_set_source,
    SEAM_SHADOW_OT_grad_set_target,
    SEAM_SHADOW_OT_grad_clear_target,
    SEAM_SHADOW_OT_grad_bake,
    SEAM_SHADOW_OT_grad_clear,
    SEAM_SHADOW_OT_grad_apply_shader,
    SEAM_SHADOW_PT_gradient,
]

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            log(f"[Register] Failed on {cls.__name__}: {e}")
            raise
    bpy.types.Object.seam_layers            = bpy.props.CollectionProperty(type=SeamLayer)
    bpy.types.Object.seam_layer_active      = bpy.props.IntProperty(default=0)
    bpy.types.Object.gradient_layers        = bpy.props.CollectionProperty(type=GradientLayer)
    bpy.types.Object.gradient_layer_active  = bpy.props.IntProperty(default=0)
    bpy.types.Scene.ss_preset_name     = bpy.props.StringProperty(name="Preset Name", default="")
    bpy.types.Scene.ss_preset_selected = bpy.props.EnumProperty(
        name="Preset", items=_preset_enum_items,
        update=_on_preset_selected,
    )
    bpy.types.Scene.ss_presets_expanded = bpy.props.BoolProperty(
        name="Expand Preset List", default=False,
    )
    if _seam_shadow_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_seam_shadow_load_post)
    if _seam_shadow_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_seam_shadow_depsgraph)
    if _flush_before_render not in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.append(_flush_before_render)
    if not bpy.app.timers.is_registered(_edge_mat_poll):
        bpy.app.timers.register(_edge_mat_poll, persistent=True)
    bpy.msgbus.subscribe_rna(
        key=bpy.types.Object.bl_rna.properties['active_material_index'],
        owner=_msgbus_owner,
        args=(),
        notify=_on_material_change,
    )

def unregister():
    try:
        bpy.msgbus.clear_by_owner(_msgbus_owner)
    except Exception:
        pass
    if bpy.app.timers.is_registered(_edge_mat_poll):
        bpy.app.timers.unregister(_edge_mat_poll)
    if _seam_shadow_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_seam_shadow_depsgraph)
    if _flush_before_render in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.remove(_flush_before_render)
    if bpy.app.timers.is_registered(_flush_pending_layers):
        bpy.app.timers.unregister(_flush_pending_layers)
    if _seam_shadow_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_seam_shadow_load_post)
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    # Захист від "register() впав на середині минулого разу" — del на
    # незареєстрованій властивості валить весь unregister() з AttributeError
    for owner, attr in (
        (bpy.types.Object, 'seam_layers'),
        (bpy.types.Object, 'seam_layer_active'),
        (bpy.types.Object, 'gradient_layers'),
        (bpy.types.Object, 'gradient_layer_active'),
        (bpy.types.Scene,  'ss_preset_name'),
        (bpy.types.Scene,  'ss_preset_selected'),
        (bpy.types.Scene,  'ss_presets_expanded'),
    ):
        if hasattr(owner, attr):
            try:
                delattr(owner, attr)
            except Exception:
                pass

if __name__ == "__main__":
    register()
