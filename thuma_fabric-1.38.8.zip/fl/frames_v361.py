"""1.38.7 (Євген, 11-10): кадри Armless Chaise як у майстер-сцені v361 — 104 Front, 105 3/4 Front (камери клієнта
product4, кадри 1 і 6). Дописуються В КІНЕЦЬ: кадри 1–103 не чіпаються взагалі (у кожного свої ключі швів, зон).
- Значення 104/105 (поза Control AC, Control_Rotation, камера, лінза, shift, fabric_front) = рівно ключі v361.
- Видимість: Armless Chaise і 7 мешів видно на 104–105, з 106 сховано (як у v361).
- WOOD_CENTER/WOOD_SPLIT на 104/105 за правилом wood_look3 (центр видимого дерева).
- Повзунки колеги (усі інші анімовані значення, крім трансформацій/видимості/камери) на 104/105 = його кадр 4
  (той самий модуль; рішення Євгена 10.11).
- Ключі CONSTANT лише ті, що ставить модуль. Нова крива (поза AC була без ключів) -> ключ-утримання на кадрі 4.
- Захист 1–103: ручки ключів <104 повертаються точно; якщо останній ключ не CONSTANT або екстраполяція не CONSTANT —
  запікаються цілі кадри до 103 старими значеннями. До і після звіряються ВСІ криві на кожному кадрі 1–103.
- Відмова ДО змін: незнайома схема (нема v359-розкладки, є маркер ≥102, ключі ≥102 крім hide 102 і cur_frame).
- Будь-який збій -> усе повернуто як було (у пам'яті), run() -> ok=False. Ідемпотентно: маркер 104 є -> нічого."""
import bpy, math
import frames_v359 as v359

AC = 'Control_Thuma_Essential-Sectional_Armless-Chaise.001'
MARKER = 'Armless Chaise, Front + 3/4 Front'
F_FRONT, F_Q, F_HIDE = 104, 105, 106
LO = 104.0
EPS = 1e-5
T4 = 1e-4
SENSOR = 38.0
# рівно значення ключів майстра v361 (Essential_Sectional_All_Configs_v361.blend, 10.11)
SRC = {
    104: {'ac_loc': (-2.551823854446411e-06, -0.4775356948375702, -0.0003962254850193858),
          'ac_rot': (0.0, -0.0, -2.086162567138672e-07),
          'rc_loc': (0.0, 0.0, 0.0), 'rc_rot': (0.0, 0.0, -2.086162567138672e-07),
          'cam_loc': (2.0846441706103697e-13, -8.035618782043457, 0.9222052097320557),
          'cam_rot': (1.52877676486969, -1.2473409805036084e-10, 1.511240351609322e-12),
          'lens': 158.3333282470703, 'shift': (0.0, -0.15000000596046448), 'ff': 1.0,
          'wood': (-2.473592758178711e-06, -0.4485189616680145, 0.0)},
    105: {'ac_loc': (-0.01395665854215622, -0.4003554880619049, 6.896827835589647e-05),
          'ac_rot': (0.0, -0.0, 0.6582227349281311),
          'rc_loc': (0.0, 0.0, 0.0), 'rc_rot': (0.0, 0.0, 0.6582227349281311),
          'cam_loc': (3.2291289867730777e-12, -12.847214698791504, 1.2805906534194946),
          'cam_rot': (1.5234506130218506, -1.2472428645438072e-10, 2.175535576340315e-12),
          'lens': 211.11111450195312, 'shift': (0.0, -0.15000000596046448), 'ff': 0.0,
          'wood': (-0.03170648217201233, -0.37740081548690796, 0.0)},
}
SKIP = ('hide_', 'location', 'rotation', 'scale', 'lens', 'shift', '["fabric_front"]', '["cur_frame"]')


def _objs():
    o = bpy.data.objects
    return o.get(AC), o.get('Camera_Main'), o.get('Control_Rotation'), o.get('WOOD_CENTER'), o.get('WOOD_SPLIT')


def layout(sc):
    """'new' (уже як v361) / 'old' (треба дописати) / 'after359' (спершу кадри v359) / None (не та сцена)."""
    mk = v359._markers(sc)
    if mk.get(MARKER) == F_FRONT:
        return 'new'
    ac, cam, rc, wc, _ws = _objs()
    if ac is None or cam is None or rc is None or wc is None:
        return None
    lv = v359.layout(sc)
    if lv == 'old':
        return 'after359'
    if lv == 'new':
        return 'old'
    return None


def status(sc):
    try:
        if layout(sc) in ('old', 'after359'):
            return [("frames", "Armless Chaise: Front + 3/4 Front (кадри 104–105, як у таблиці)")]
    except Exception:
        pass
    return []


def _refuse(sc, ac):
    """Причина відмови ДО змін або None."""
    if any(m.frame >= 102 for m in sc.timeline_markers):
        return "є маркер на кадрі ≥102"
    if ac.parent is not None or len(ac.constraints):
        return "у Control Armless Chaise є батько/констрейнт"
    if ac.rotation_mode != 'XYZ':
        return "у Control Armless Chaise не XYZ-поворот"
    for fk, a, fc in v359._all_fcurves():
        for k in fc.keyframe_points:
            x = k.co[0]
            if x < 101.5 or fc.data_path == '["cur_frame"]':
                continue
            if fc.data_path.startswith('hide_') and abs(x - 102) < T4:
                continue
            return f"ключ на кадрі {x:g} ({a.name} {fc.data_path})"
    return None


# ---------------------------------------------------------------- захист 1..103
def _guard_prepare(fc):
    ks = list(fc.keyframe_points)
    lo = [k for k in ks if k.co[0] < LO - T4]
    rec = [(k.co[0], tuple(k.handle_left), tuple(k.handle_right)) for k in lo]
    bake = []
    if lo:
        kp = lo[-1]
        if kp.interpolation != 'CONSTANT' or fc.extrapolation != 'CONSTANT':
            bake = [(f, fc.evaluate(float(f)), 'CONSTANT') for f in range(math.floor(kp.co[0] + T4) + 1, 104)]
        if fc.extrapolation != 'CONSTANT' and len(lo) == 1 and lo[0].interpolation != 'CONSTANT':
            x = math.floor(lo[0].co[0] - T4)
            bake.append((x, fc.evaluate(float(x)), 'LINEAR'))
    return fc, rec, bake


def _guard_bake(g):
    fc, _rec, bake = g
    for f, v, ip in bake:
        k = fc.keyframe_points.insert(float(f), v, options={'FAST'})
        k.interpolation = ip
    if bake:
        fc.update()


def run(sc):
    """-> (ok, рядки звіту). ok=False -> у пам'яті все повернуто як було, сцену НЕ зберігати."""
    lay = layout(sc)
    if lay != 'old':
        if lay == 'after359':
            return False, ["Кадри Armless Chaise: спершу мають перебудуватися кадри диванів (94–101) — нічого не змінено"]
        return True, []
    ac, cam, rc, wc, ws = _objs()
    why = _refuse(sc, ac)
    if why:
        return False, [f"Кадри 104–105: {why} — схема незнайома, нічого не змінено"]
    kids = [k for k in ac.children]
    meshes = [k for k in kids if k.type == 'MESH']
    if not meshes:
        return False, ["Кадри 104–105: у Armless Chaise нема мешів — нічого не змінено"]
    f0 = sc.frame_current
    wood_mat = bpy.data.materials.get(v359.WOOD_MAT)

    # ---------- 0. знімок ДО ----------
    allfc = v359._all_fcurves()
    sc.frame_set(4)
    val4 = {fk: fc.evaluate(4.0) for fk, _a, fc in allfc}
    sliders = {fk: fc for fk, _a, fc in allfc
               if not fc.data_path.startswith(SKIP) and abs(fc.evaluate(104.0) - val4[fk]) > 1e-6}
    vis_ids = [ac] + kids
    keyed = [(ac, ('location', 'rotation_euler', 'hide_render', 'hide_viewport')),
             (rc, ('location', 'rotation_euler')), (cam, ('location', 'rotation_euler')),
             (cam.data, ('lens', 'shift_x', 'shift_y')), (sc, ('["fabric_front"]',))] \
        + [(k, ('hide_render', 'hide_viewport')) for k in kids] + [(o, ('location',)) for o in (wc, ws) if o is not None]
    ids = [i for i, _p in keyed]
    written = {}
    for i, paths in keyed:
        for fk, fc in v359._own_fcurves(i):
            if fc.data_path in paths:
                written[fk] = fc
    touched = dict(written); touched.update(sliders)
    props = [(ac, 'location'), (ac, 'rotation_euler'), (ac, 'hide_render'), (ac, 'hide_viewport'),
             (rc, 'location'), (rc, 'rotation_euler'), (cam, 'location'), (cam, 'rotation_euler'),
             (cam.data, 'lens'), (cam.data, 'shift_x'), (cam.data, 'shift_y')] \
        + [(k, p) for k in kids for p in ('hide_render', 'hide_viewport')] \
        + [(o, 'location') for o in (wc, ws) if o is not None]
    sc.frame_set(4)
    pre4 = {(o.as_pointer(), a): (tuple(getattr(o, a)) if hasattr(getattr(o, a), '__len__') else (float(getattr(o, a)),))
            for o, a in props}
    pre4[(sc.as_pointer(), '["fabric_front"]')] = (float(sc.get('fabric_front', 0.0)),)
    sc.frame_set(f0)
    undo = v359._Undo(sc, ids, touched, props)
    before = {fk: (fc, [fc.evaluate(float(f)) for f in range(1, 104)]) for fk, _a, fc in allfc}
    try:
        ok, out = _build(sc, ac, kids, meshes, cam, rc, wc, ws, wood_mat, val4, sliders, touched, before, pre4, f0)
    except Exception as e:
        import traceback
        traceback.print_exc()
        ok, out = False, [f"Кадри 104–105: помилка {str(e)[:80]}"]
    if ok:
        return True, out
    try:
        for m in list(sc.timeline_markers):
            if m.name == MARKER and m.frame == F_FRONT:
                sc.timeline_markers.remove(m)
        undo.restore()
        rb = undo.verify()
    except Exception as e:
        rb = [f"виняток {str(e)[:60]}"]
    if rb:
        return False, out + ["ВІДКАТ НЕ ПОВНИЙ (" + "; ".join(rb[:3]) + ") — закрий файл БЕЗ збереження"]
    return False, out + ["Усе повернуто як було, нічого не змінено"]


def _build(sc, ac, kids, meshes, cam, rc, wc, ws, wood_mat, val4, sliders, touched, before, pre4, f0):
    guards = [_guard_prepare(fc) for fc in touched.values()]
    for g in guards:
        _guard_bake(g)
    ins = []

    def key(idb, path, f):
        new_curve = not any(fc.data_path == path for _fk, fc in v359._own_fcurves(idb))
        if new_curve:                                # утримання: на 1–103 значення кадру 4, як було
            p = pre4.get((idb.as_pointer(), path))
            cur = getattr(idb, path) if not path.startswith('[') else None
            if p is not None and cur is not None:
                keep = cur.copy() if hasattr(cur, 'copy') else cur
                setattr(idb, path, p if len(p) > 1 else p[0])
                idb.keyframe_insert(path, frame=4); ins.append((idb, path, 4))
                setattr(idb, path, keep)
        idb.keyframe_insert(path, frame=f)
        ins.append((idb, path, f))

    lens_k = cam.data.sensor_width / SENSOR
    for f in (F_FRONT, F_Q):
        S = SRC[f]
        sc.frame_set(f)
        ac.location = S['ac_loc']; ac.rotation_euler = S['ac_rot']
        key(ac, 'location', f); key(ac, 'rotation_euler', f)
        rc.location = S['rc_loc']; rc.rotation_euler = S['rc_rot']
        key(rc, 'location', f); key(rc, 'rotation_euler', f)
        cam.location = S['cam_loc']; cam.rotation_euler = S['cam_rot']
        key(cam, 'location', f); key(cam, 'rotation_euler', f)
        cam.data.lens = S['lens'] * lens_k
        cam.data.shift_x, cam.data.shift_y = S['shift']
        for p in ('lens', 'shift_x', 'shift_y'):
            key(cam.data, p, f)
        sc['fabric_front'] = S['ff']
        sc.keyframe_insert('["fabric_front"]', frame=f); ins.append((sc, '["fabric_front"]', f))
    for o in [ac] + kids:
        for f, hide in ((F_FRONT, False), (F_HIDE, True)):
            o.hide_render = hide; o.hide_viewport = hide
            key(o, 'hide_render', f); key(o, 'hide_viewport', f)
    # повзунки колеги: на 104/105 = його кадр 4
    n_sl = 0
    for fk, fc in sliders.items():
        for f in (F_FRONT, F_Q):
            k = fc.keyframe_points.insert(float(f), val4[fk], options={'FAST'})
            k.interpolation = 'CONSTANT'
        fc.update(); n_sl += 1
    bpy.context.view_layer.update()
    # дерево: центр видимого дерева (правило wood_look3), запасне — значення майстра
    wood = {}
    for f in (F_FRONT, F_Q):
        sc.frame_set(f)
        vis = [o for o in sc.objects if o.type == 'MESH' and o.material_slots and o.material_slots[0].material == wood_mat
               and o.visible_get() and not o.hide_render] if wood_mat else []
        pts = [o.matrix_world @ v359.Vector(c) for o in vis for c in o.bound_box]
        if pts:
            xs = [p.x for p in pts]; ys = [p.y for p in pts]
            c = ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, 0.0)
        else:
            c = SRC[f]['wood']
        wood[f] = c
        for o in (wc, ws):
            if o is not None:
                o.location = c; key(o, 'location', f)
    # CONSTANT лише на свої щойно вставлені ключі
    for idb, path, f in ins:
        for _fk, fc in v359._own_fcurves(idb):
            if fc.data_path == path:
                for k in fc.keyframe_points:
                    if abs(k.co[0] - f) < T4:
                        k.interpolation = 'CONSTANT'
                fc.update()
    for g in guards:
        v359._guard_handles(g)
    sc.timeline_markers.new(MARKER, frame=F_FRONT)
    bpy.context.view_layer.update()

    # ---------- перевірка ----------
    bad = []
    for (an, _sl, dp, ix), (fc, vals) in before.items():
        for f, v in zip(range(1, 104), vals):
            if abs(fc.evaluate(float(f)) - v) > EPS:
                bad.append(f"{an} {dp}[{ix}] кадр {f}"); break
    for i in [ac, rc, cam, cam.data, sc] + kids + [o for o in (wc, ws) if o is not None]:
        for fk, fc in v359._own_fcurves(i):
            if fk in before:
                continue
            p = pre4.get((i.as_pointer(), fc.data_path))
            if p is None or fc.array_index >= len(p):
                bad.append(f"{i.name}: нова крива {fc.data_path}"); continue
            if any(abs(fc.evaluate(float(f)) - p[fc.array_index]) > EPS for f in range(1, 104)):
                bad.append(f"{i.name}: {fc.data_path}[{fc.array_index}] на 1–103 змінилось")
    want = {m.name for m in meshes}
    for f in (F_FRONT, F_Q):
        S = SRC[f]
        sc.frame_set(f)
        if max(abs(a - b) for a, b in zip(tuple(ac.location) + tuple(ac.rotation_euler), S['ac_loc'] + S['ac_rot'])) > 1e-6 \
                or max(abs(a - b) for a, b in zip(tuple(cam.location) + tuple(cam.rotation_euler), S['cam_loc'] + S['cam_rot'])) > 1e-6 \
                or abs(rc.rotation_euler.z - S['rc_rot'][2]) > 1e-6 or abs(cam.data.lens - S['lens'] * lens_k) > 1e-4 \
                or abs(float(sc.get('fabric_front', -1)) - S['ff']) > EPS:
            bad.append(f"кадр {f}: камера/поза не як у v361")
        vis = {o.name for o in sc.objects if o.type == 'MESH' and not o.hide_render and o.name.startswith('Thuma_Essential-')}
        if vis != want:
            bad.append(f"кадр {f}: видно {len(vis)} мешів, а треба {len(want)} Armless Chaise")
    sc.frame_set(F_HIDE)
    if any(not o.hide_render for o in meshes):
        bad.append("кадр 106: Armless Chaise не сховано")
    sc.frame_set(f0)
    if bad:
        return False, ["Кадри 104–105 НЕ додано чисто: " + "; ".join(bad[:4])]
    dw = max(abs(a - b) for f in (F_FRONT, F_Q) for a, b in zip(wood[f], SRC[f]['wood']))
    return True, ["Кадри 104–105: Armless Chaise Front + 3/4 Front (1–103 без змін"
                  + (f", повзунків з кадру 4: {n_sl}" if n_sl else "") + ")"
                  + ("" if dw < 1e-4 else f" [дерево ≠ майстер на {dw * 1000:.1f} мм]")]
