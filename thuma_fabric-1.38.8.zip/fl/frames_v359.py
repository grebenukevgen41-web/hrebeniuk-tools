"""1.38.5 (Євген, 11-08): кадри диванів і крісла як у майстер-сцені v359 — фронт + 3/4 фронт.
Було (v358 і старші): 94 Sofa 72, 95 Sofa 84, 96 Sofa 96, 97 Armchair — лише фронти.
Стало: 94/95 Sofa 72 (F, 3/4F), 96/97 Sofa 84, 98/99 Sofa 96, 100/101 Armchair.
- УСІ ключі сцени на кадрах 94..98 (камера, видимість, тканини, дерево, СВОЇ ключі колег) їдуть разом із фронтом:
  кадр f -> 2f-94. На новому 3/4F тримається значення фронту того ж продукту (ключ на фронті -> CONSTANT).
- 3/4F: продукт +30° (Child Of на Control_Rotation, як у конфігурацій), камера клієнта, fabric_front = 0,
  WOOD_CENTER/WOOD_SPLIT за правилом wood_look3 (центр видимого дерева).
- Кадри 1..93 не чіпаються (фікс після фазз-тесту 11-08):
  * сегмент кривої, що йде з кадру <94 у 94+ (BEZIER/LINEAR повзунка), запікається цілими кадрами (prev..93]
    зі старими значеннями; ручки всіх ключів <94 повертаються точно такими, як були;
  * LINEAR-екстраполяція без ключів <94 — два опорні ключі 92/93 на старій прямій;
  * дробові ключі всередині 94–98 або ключі на 99–102 -> відмова ДО змін.
- Будь-який збій (перевірка 1–93, 3/4F, виняток) -> усе, що модуль змінив, повертається як було (у пам'яті),
  і run() повертає ok=False. До і після звіряються значення ВСІХ кривих на кожному кадрі 1..93.
- Ідемпотентно: сцена, де Armchair уже на 100, не змінюється.
- Окремо: cur_frame (лінійні ключі = номер кадру, FL70) — якщо ключі стали CONSTANT, повертає LINEAR."""
import bpy, json, math
from mathutils import Matrix, Vector

SRC = json.loads(r'''{"Sofa_72":{"F_ctl":[[1.0,0.0,0.0,0.0],[0.0,1.0,0.0,0.029012469574809074],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_ctl":[[0.8660253882408142,-0.5,0.0,0.005760475993156433],[0.5,0.8660253882408142,0.0,0.019035033881664276],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_cam":[[1.0,0.0,0.0,0.001296748872846365],[0.0,0.030975349247455597,-0.9995201230049133,-9.748174667358398],[0.0,0.9995201230049133,0.030975349247455597,1.092749834060669],[0.0,0.0,0.0,1.0]],"Q_lens":150.0,"Q_sensor":38.0,"Q_shift":[0.0,-0.15000000596046448],"Q_fit":"AUTO"},"Sofa_84":{"F_ctl":[[1.0,0.0,0.0,0.0],[0.0,1.0,0.0,0.029012469574809074],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_ctl":[[0.8660253882408142,-0.5,0.0,0.005760475993156433],[0.5,0.8660253882408142,0.0,0.019035033881664276],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_cam":[[1.0,0.0,0.0,-0.006790786981582642],[0.0,0.030975349247455597,-0.9995201230049133,-11.011116981506348],[0.0,0.9995201230049133,0.030975349247455597,1.1262359619140625],[0.0,0.0,0.0,1.0]],"Q_lens":150.0,"Q_sensor":38.0,"Q_shift":[0.0,-0.15000000596046448],"Q_fit":"AUTO"},"Sofa_96":{"F_ctl":[[1.0,0.0,0.0,0.0],[0.0,1.0,0.0,0.029012469574809074],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_ctl":[[0.8660253882408142,-0.5,0.0,0.005760475993156433],[0.5,0.8660253882408142,0.0,0.019035033881664276],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_cam":[[1.0,0.0,0.0,-0.015309552662074566],[0.0,0.030975349247455597,-0.9995201230049133,-12.299692153930664],[0.0,0.9995201230049133,0.030975349247455597,1.2223877906799316],[0.0,0.0,0.0,1.0]],"Q_lens":150.0,"Q_sensor":38.0,"Q_shift":[0.0,-0.15000000596046448],"Q_fit":"AUTO"},"Armchair":{"F_ctl":[[1.0,0.0,0.0,0.0],[0.0,1.0,0.0,0.029012469574809074],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_ctl":[[0.8660253882408142,-0.5,0.0,0.005760475993156433],[0.5,0.8660253882408142,0.0,0.019035033881664276],[0.0,0.0,1.0,-0.0010320404544472694],[0.0,0.0,0.0,1.0]],"Q_cam":[[1.0,0.0,0.0,0.0],[0.0,0.07101152837276459,-0.9974755048751831,-8.884876251220703],[0.0,0.9974755048751831,0.07101152837276459,1.311103343963623],[0.0,0.0,0.0,1.0]],"Q_lens":150.0,"Q_sensor":36.0,"Q_shift":[0.0,-0.15000000596046448],"Q_fit":"AUTO"}}''')
PRODS = [('Sofa_72', 'Control_Thuma_Essential-Sofa_72in', 94, 'Essential Sofa, 72in'),
         ('Sofa_84', 'Control_Thuma_Essential-Sofa_84in', 95, 'Essential Sofa, 84in'),
         ('Sofa_96', 'Control_Thuma_Essential-Sofa_96in', 96, 'Essential Sofa, 96in'),
         ('Armchair', 'Control_Thuma_Essential-Armchair', 97, 'Essential Armchair')]
WOOD_MAT = "Thuma_Wood_Finger-Joints_4K"
EPS = 1e-5
T4 = 1e-4
LO, HI = 94.0, 98.0          # ключі в цьому діапазоні -> 2f-94


def _fcurves(act):
    out = []
    for ly in act.layers:
        for st in ly.strips:
            for cb in st.channelbags:
                out += list(cb.fcurves)
    return out


def _fkey(act, cb, fc):
    """Стабільний ключ кривої (обгортки RNA щоразу нові, id() не годиться)."""
    return (act.name, cb.slot.handle if cb.slot else -1, fc.data_path, fc.array_index)


def _own_fcurves(idb, with_cb=False):
    """[(ключ, крива)] САМЕ цього ID (у спільного action кілька слотів — чужі не чіпати)."""
    ad = idb.animation_data
    if not ad or not ad.action:
        return []
    out = []
    for ly in ad.action.layers:
        for st in ly.strips:
            cb = st.channelbag(ad.action_slot) if ad.action_slot else None
            if cb:
                out += [((_fkey(ad.action, cb, fc), fc, cb) if with_cb else (_fkey(ad.action, cb, fc), fc)) for fc in cb.fcurves]
    return out


def _all_fcurves():
    """[(ключ, action, крива)] усіх кривих файлу."""
    out = []
    for a in bpy.data.actions:
        for ly in a.layers:
            for st in ly.strips:
                for cb in st.channelbags:
                    out += [(_fkey(a, cb, fc), a, fc) for fc in cb.fcurves]
    return out


def _markers(sc):
    return {m.name: m.frame for m in sc.timeline_markers}


def _cur_frame_broken(sc):
    ad = sc.animation_data
    if not ad or not ad.action:
        return False
    for fc in _fcurves(ad.action):
        if fc.data_path == '["cur_frame"]' and len(fc.keyframe_points) >= 2:
            return abs(fc.evaluate(50.0) - 50.0) > 1e-3
    return False


def layout(sc):
    """'old' (треба мігрувати) / 'new' (уже як v359) / None (не та сцена або незнайома схема)."""
    mk = _markers(sc)
    a, s84 = mk.get('Essential Armchair'), mk.get('Essential Sofa, 84in')
    if a == 100 and s84 == 96:
        return 'new'
    if a == 97 and s84 == 95 and all(bpy.data.objects.get(c) for _, c, _, _ in PRODS) \
            and bpy.data.objects.get('Camera_Main') and bpy.data.objects.get('Control_Rotation'):
        return 'old'
    return None


def status(sc):
    """[(ключ, текст)] для банера «Є оновлення». Дешево: лише маркери і одна крива."""
    out = []
    try:
        if layout(sc) == 'old':
            out.append(("frames", "кадри диванів і крісла: + 3/4 фронт (94–101, як у таблиці)"))
        elif _cur_frame_broken(sc):
            out.append(("frames", "лічильник кадрів cur_frame (для «Своїх зон» і дерева)"))
    except Exception:
        pass
    return out


def _fix_cur_frame(sc):
    ad = sc.animation_data
    n = 0
    for fc in _fcurves(ad.action) if ad and ad.action else []:
        if fc.data_path == '["cur_frame"]':
            for k in fc.keyframe_points:
                if k.interpolation != 'LINEAR':
                    k.interpolation = 'LINEAR'; n += 1
            fc.extrapolation = 'LINEAR'
            fc.update()
    return n


# ---------------------------------------------------------------- знімок / відкат
_KATTR = ('interpolation', 'handle_left_type', 'handle_right_type', 'easing', 'type', 'back', 'amplitude', 'period')


def _krec(k):
    return (tuple(k.co), tuple(k.handle_left), tuple(k.handle_right)) + tuple(getattr(k, a) for a in _KATTR)


def _kset(k, r):
    for a, v in zip(_KATTR, r[3:]):
        setattr(k, a, v)
    k.co = r[0]; k.handle_left = r[1]; k.handle_right = r[2]


def _keys_clear(kp):
    try:
        kp.clear()
    except Exception:
        while len(kp):
            kp.remove(kp[0], fast=True)


class _Undo:
    """Все, що модуль може змінити: криві (ключі, ручки, екстраполяція), нові криві/actions на своїх ID,
    маркери, Child Of, статичні значення, які модуль пише. restore() повертає все, verify() звіряє."""

    def __init__(self, sc, ids, fcs, props):
        self.sc, self.ids, self.props = sc, ids, props
        self.f0 = sc.frame_current
        self.fc = {fk: (fc.extrapolation, [_krec(k) for k in fc.keyframe_points],
                        [fc.evaluate(float(f)) for f in range(1, 103)]) for fk, fc in fcs.items()}
        self.ad = {i.as_pointer(): (i.animation_data is not None, i.animation_data.action if i.animation_data else None)
                   for i in ids}
        self.own = {i.as_pointer(): {fk for fk, _ in _own_fcurves(i)} for i in ids}
        self.actions = {a.name for a in bpy.data.actions}
        self.markers = [(m.name, m.frame) for m in sc.timeline_markers]
        self.cons = []           # (obj, ім'я) доданих Child Of
        self.vals = [(o, a, (getattr(o, a).copy() if hasattr(getattr(o, a), 'copy') else getattr(o, a))) for o, a in props]
        self.ff = ('fabric_front' in sc, sc.get('fabric_front'))

    def restore(self):
        cur = {fk: fc for fk, _a, fc in _all_fcurves()}
        for fk, (ext, recs, _v) in self.fc.items():
            fc = cur.get(fk)
            if fc is None:
                continue
            kp = fc.keyframe_points
            _keys_clear(kp)
            kp.add(len(recs))
            for k, r in zip(kp, recs):
                _kset(k, r)
            fc.extrapolation = ext
            fc.update()
            for k, r in zip(fc.keyframe_points, recs):      # update() перераховує AUTO-ручки — повернути точно
                k.handle_left = r[1]; k.handle_right = r[2]
        for i in self.ids:                                  # нові криві / actions на своїх ID
            had_ad, act = self.ad[i.as_pointer()]
            if not had_ad:
                if i.animation_data:
                    i.animation_data_clear()
                continue
            if act is None:
                if i.animation_data and i.animation_data.action:
                    i.animation_data.action = None
                continue
            old = self.own[i.as_pointer()]
            for fk, fc, cb in _own_fcurves(i, with_cb=True):
                if fk not in old:
                    cb.fcurves.remove(fc)
        for a in list(bpy.data.actions):
            if a.name not in self.actions and a.users == 0:
                bpy.data.actions.remove(a)
        for m, (_n, f) in zip(self.sc.timeline_markers, self.markers):
            m.frame = f
        for o, cn in self.cons:
            c = o.constraints.get(cn)
            if c:
                o.constraints.remove(c)
        for o, a, v in self.vals:
            setattr(o, a, v)
        has, v = self.ff
        if has:
            self.sc['fabric_front'] = v
        elif 'fabric_front' in self.sc:
            del self.sc['fabric_front']
        self.sc.frame_set(self.f0)

    def verify(self):
        bad = []
        cur = {fk: fc for fk, _a, fc in _all_fcurves()}
        for fk, (_e, recs, vals) in self.fc.items():
            fc = cur.get(fk)
            if fc is None or len(fc.keyframe_points) != len(recs) or \
                    any(abs(fc.evaluate(float(f)) - v) > EPS for f, v in zip(range(1, 103), vals)):
                bad.append(f"{fk[0]} {fk[2]}[{fk[3]}]")
        for i in self.ids:
            if {fk for fk, _ in _own_fcurves(i)} != self.own[i.as_pointer()]:
                bad.append(f"{i.name}: криві")
        if [(m.name, m.frame) for m in self.sc.timeline_markers] != self.markers:
            bad.append("маркери")
        return bad


# ---------------------------------------------------------------- захист 1..93
def _guard_prepare(fc, will_get_keys_ge94):
    """До змін: що запекти і які ручки повернути, щоб значення на 1..93 не зрушили.
    -> (fc, [(x, hl, hr)] ключів <94, [(кадр, старе значення, interp)] нових опорних ключів)."""
    ks = list(fc.keyframe_points)
    lo = [k for k in ks if k.co[0] < LO - T4]
    hi = [k for k in ks if k.co[0] >= LO - T4]
    rec = [(k.co[0], tuple(k.handle_left), tuple(k.handle_right)) for k in lo]
    bake = []
    if not (hi or will_get_keys_ge94):
        return fc, rec, bake
    if lo:
        kp = lo[-1]                                         # останній ключ до 94: його сегмент іде в 94+
        if kp.interpolation != 'CONSTANT':
            bake = [(f, fc.evaluate(float(f)), 'LINEAR') for f in range(math.floor(kp.co[0] + T4) + 1, 94)]
        if fc.extrapolation != 'CONSTANT' and len(lo) == 1 and lo[0].interpolation == 'LINEAR' and not bake:
            x = math.floor(lo[0].co[0] - T4)                # нахил лівої екстраполяції = від сусіда
            bake = [(x, fc.evaluate(float(x)), 'LINEAR')]
    elif fc.extrapolation != 'CONSTANT':                    # 1..93 = пряма з першого ключа 94+
        bake = [(92, fc.evaluate(92.0), 'LINEAR'), (93, fc.evaluate(93.0), 'LINEAR')]
    return fc, rec, bake


def _guard_bake(g):
    fc, _rec, bake = g
    if not bake:
        return
    for f, v, ip in bake:
        k = fc.keyframe_points.insert(float(f), v, options={'FAST'})
        k.interpolation = ip
    fc.update()


def _guard_handles(g):
    """Після всіх змін: ручки ключів <94 точно як були (тип FREE лише там, де їх перерахувало)."""
    fc, rec, _b = g
    lost = 0
    for _ in range(2):
        changed = False
        for x, hl, hr in rec:
            k = next((k for k in fc.keyframe_points if abs(k.co[0] - x) < 1e-6), None)
            if k is None:
                lost += 1; continue
            if max(abs(a - b) for a, b in zip(tuple(k.handle_left) + tuple(k.handle_right), hl + hr)) > 1e-9:
                k.handle_left_type = 'FREE'; k.handle_right_type = 'FREE'
                k.handle_left = hl; k.handle_right = hr
                changed = True
        if not changed:
            break
        fc.update()
    return lost


# ---------------------------------------------------------------- run
def run(sc):
    """-> (ok, рядки звіту). ok=False -> у пам'яті все повернуто як було, сцену НЕ зберігати."""
    lines = []
    if layout(sc) != 'old':
        if _cur_frame_broken(sc):
            _fix_cur_frame(sc)
            ok_cf = not _cur_frame_broken(sc)
            lines.append("cur_frame: знову = номер кадру" if ok_cf else "cur_frame НЕ виправився")
            return ok_cf, lines
        return True, lines
    cam = bpy.data.objects['Camera_Main']
    rc = bpy.data.objects['Control_Rotation']
    wc = bpy.data.objects.get('WOOD_CENTER')
    ws = bpy.data.objects.get('WOOD_SPLIT')
    ctls = [bpy.data.objects[cn] for _, cn, _, _ in PRODS]
    tpl = next((c for o in bpy.data.objects for c in o.constraints if c.type == 'CHILD_OF' and c.target == rc), None)
    if tpl is None:
        return False, lines + ["Кадри: не знайшов Child Of на Control_Rotation — нічого не змінено"]

    # ---------- 0. знімок ДО + відмови ДО змін ----------
    allfc = _all_fcurves()
    moved = {}           # ключ -> (fc, {f: v_old})
    for fk, a, fc in allfc:
        xs = [k.co[0] for k in fc.keyframe_points]
        if any(HI + T4 < x <= 2 * HI - 94 + T4 for x in xs):
            return False, lines + [f"Кадри: є ключі на 99–102 ({a.name} {fc.data_path}) — схема незнайома, нічого не змінено"]
        if any(LO - T4 <= x <= HI + T4 and abs(x - round(x)) > T4 for x in xs):
            return False, lines + [f"Кадри: дробовий ключ між 94 і 98 ({a.name} {fc.data_path}) — нічого не змінено"]
        if any(LO - T4 <= x <= HI + T4 for x in xs):
            moved[fk] = (fc, {f: fc.evaluate(float(f)) for f in range(94, 99)})
    keyed = [(rc, ('location', 'rotation_euler')), (cam, ('location', 'rotation_euler')),
             (cam.data, ('lens', 'shift_x', 'shift_y')), (sc, ('["fabric_front"]',))] \
        + [(c, ('location', 'rotation_euler')) for c in ctls] + [(o, ('location',)) for o in (wc, ws) if o is not None]
    ids = [i for i, _p in keyed]
    written = {}                                             # криві, у які модуль пише ключі сам
    for i, paths in keyed:
        for fk, fc in _own_fcurves(i):
            if fc.data_path in paths:
                written[fk] = fc
    touched = dict(written)
    touched.update({fk: fc for fk, (fc, _v) in moved.items()})
    snap = dict(touched)                                     # + cur_frame (його лагодження теж відкочується)
    snap.update({fk: fc for fk, fc in _own_fcurves(sc) if fc.data_path == '["cur_frame"]'})
    props = [(rc, 'location'), (rc, 'rotation_euler'), (cam, 'location'), (cam, 'rotation_euler'), (cam, 'scale'),
             (cam.data, 'lens'), (cam.data, 'shift_x'), (cam.data, 'shift_y')] \
        + [(c, p) for c in ctls for p in ('location', 'rotation_euler', 'scale')] \
        + [(o, 'location') for o in (wc, ws) if o is not None]
    pre = {(o.as_pointer(), a): (tuple(getattr(o, a)) if hasattr(getattr(o, a), '__len__') else (getattr(o, a),)) for o, a in props}
    pre[(sc.as_pointer(), '["fabric_front"]')] = (float(sc.get('fabric_front', 0.0)),)
    undo = _Undo(sc, ids, snap, props)

    try:
        if _cur_frame_broken(sc):
            _fix_cur_frame(sc)
            if _cur_frame_broken(sc):
                raise RuntimeError("cur_frame НЕ виправився")
            lines.append("cur_frame: знову = номер кадру")
        before = {fk: (fc, [fc.evaluate(float(f)) for f in range(1, 94)]) for fk, _a, fc in allfc}
        ok, out = _migrate(sc, cam, rc, wc, ws, ctls, tpl, moved, before, written, touched, pre, undo)
    except Exception as e:
        import traceback
        traceback.print_exc()
        ok, out = False, [f"Кадри: помилка {str(e)[:80]}"]
    if ok:
        return True, lines + out
    try:
        undo.restore()
        rb = undo.verify()
    except Exception as e:
        rb = [f"виняток {str(e)[:60]}"]
    if rb:
        return False, lines + out + ["ВІДКАТ НЕ ПОВНИЙ (" + "; ".join(rb[:3]) + ") — закрий файл БЕЗ збереження"]
    return False, lines + out + ["Усе повернуто як було, нічого не змінено"]


def _migrate(sc, cam, rc, wc, ws, ctls, tpl, moved, before, written, touched, pre, undo):
    f0 = sc.frame_current
    wood_mat = bpy.data.materials.get(WOOD_MAT)
    # захист 1..93: запекти сегменти, що йдуть у 94+, і запам'ятати ручки ключів <94
    guards = [_guard_prepare(fc, fk in written) for fk, fc in touched.items()]
    for g in guards:
        _guard_bake(g)

    # ---------- 1. ключі 94..98 -> 2f-94, маркери так само ----------
    n_keys = 0
    for fc, _v in moved.values():
        for k in fc.keyframe_points:
            f = k.co[0]
            if LO - T4 <= f <= HI + T4:
                d = f - 94.0
                k.co[0] += d; k.handle_left[0] += d; k.handle_right[0] += d
                n_keys += 1
        fc.update()
    for m in sc.timeline_markers:
        if LO <= m.frame <= HI:
            m.frame = 2 * m.frame - 94

    # ---------- 2. 3/4F тримає значення фронту того ж продукту ----------
    def hold(fc, vold):
        for f in range(94, 98):
            n = 2 * f - 94
            k = next((k for k in fc.keyframe_points if abs(k.co[0] - n) < T4), None)
            if k is None and (abs(fc.evaluate(n) - vold[f]) > EPS or abs(fc.evaluate(n + 1) - vold[f]) > EPS):
                k = fc.keyframe_points.insert(n, vold[f], options={'FAST'})
            if k is not None:
                k.interpolation = 'CONSTANT'
        fc.update()
    for fc, vold in moved.values():
        hold(fc, vold)

    # ---------- 3. Child Of на контролах продуктів (як у конфігурацій) ----------
    props = [p.identifier for p in tpl.bl_rna.properties if not p.is_readonly
             and p.identifier not in ('name', 'target', 'subtarget', 'inverse_matrix', 'set_inverse_pending')]
    for ctl in ctls:
        if not any(c.type == 'CHILD_OF' and c.target == rc for c in ctl.constraints):
            c = ctl.constraints.new('CHILD_OF'); c.name = tpl.name
            undo.cons.append((ctl, c.name))
            for p in props:
                try:
                    setattr(c, p, getattr(tpl, p))
                except Exception:
                    pass
            c.target = rc; c.inverse_matrix = tpl.inverse_matrix.copy(); c.set_inverse_pending = False

    # ---------- 4. нові 3/4F ----------
    explicit = set()      # криві, які ставимо самі (на 3/4F значення інше, ніж на фронті)

    def key(idb, path, f):
        idb.keyframe_insert(path, frame=f)
        for fk, fc in _own_fcurves(idb):
            if fc.data_path == path:
                explicit.add(fk)
                for k in fc.keyframe_points:
                    if abs(k.co[0] - f) < T4:                # CONSTANT лише на свій щойно вставлений ключ
                        k.interpolation = 'CONSTANT'
                fc.update()
    newf = {}
    for i, (name, cn, _f, _m) in enumerate(PRODS):
        Ff, Fq = 94 + 2 * i, 95 + 2 * i
        newf[name] = (Ff, Fq)
        ctl = ctls[i]; S = SRC[name]
        WsF, WsQ = Matrix(S['F_ctl']), Matrix(S['Q_ctl'])
        sc.frame_set(Ff)
        WvQ = (WsQ @ WsF.inverted()) @ ctl.matrix_world.copy()
        ang = WsQ.to_euler().z - WsF.to_euler().z
        rc.location = (0, 0, 0); rc.rotation_euler = (0, 0, ang)
        key(rc, 'location', Fq); key(rc, 'rotation_euler', Fq)
        scl = tuple(ctl.scale)
        locF = ctl.matrix_basis.copy()
        locQ = Matrix.Rotation(ang, 4, 'Z').inverted() @ WvQ
        ctl.matrix_basis = locF; ctl.scale = scl; key(ctl, 'location', Ff); key(ctl, 'rotation_euler', Ff)
        ctl.matrix_basis = locQ; ctl.scale = scl; key(ctl, 'location', Fq); key(ctl, 'rotation_euler', Fq)
        cscl = tuple(cam.scale)
        cam.matrix_world = Matrix(S['Q_cam']); cam.scale = cscl
        cam.data.lens = S['Q_lens'] * cam.data.sensor_width / S['Q_sensor']
        cam.data.shift_x, cam.data.shift_y = S['Q_shift']
        key(cam, 'location', Fq); key(cam, 'rotation_euler', Fq)
        for p in ('lens', 'shift_x', 'shift_y'):
            key(cam.data, p, Fq)
        sc['fabric_front'] = 0.0; key(sc, '["fabric_front"]', Fq)
    # дерево: центр видимого дерева на 3/4F (правило wood_look3.build_center)
    for name, (Ff, Fq) in newf.items():
        sc.frame_set(Fq)
        vis = [o for o in sc.objects if o.type == 'MESH' and o.material_slots and o.material_slots[0].material == wood_mat
               and o.visible_get() and not o.hide_render] if wood_mat else []
        pts = [o.matrix_world @ Vector(c) for o in vis for c in o.bound_box]
        if pts:
            xs = [p.x for p in pts]; ys = [p.y for p in pts]
            c = Vector(((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, 0.0))
        else:
            sc.frame_set(Ff); c = wc.location.copy() if wc else None; sc.frame_set(Fq)
        for o in (wc, ws):
            if o is not None and c is not None:
                o.location = c; key(o, 'location', Fq)

    # ---------- 4б. ручки ключів <94 точно як були ----------
    lost = sum(_guard_handles(g) for g in guards)

    # ---------- 5. перевірка ----------
    bad = []
    if lost:
        bad.append(f"зникли ключі <94: {lost}")
    for (an, _sl, dp, ix), (fc, vals) in before.items():
        for f, v in zip(range(1, 94), vals):
            if abs(fc.evaluate(float(f)) - v) > EPS:
                bad.append(f"{an} {dp}[{ix}] кадр {f}"); break
    for fid, (fc, vold) in moved.items():
        if fid in explicit:
            continue
        for f in range(94, 98):
            n = 2 * f - 94
            if abs(fc.evaluate(n) - vold[f]) > EPS or abs(fc.evaluate(n + 1) - vold[f]) > EPS:
                bad.append(f"{fc.data_path} кадр {n}/{n + 1}"); break
        if fc.extrapolation == 'CONSTANT' and abs(fc.evaluate(102.0) - vold[98]) > EPS:
            bad.append(f"{fc.data_path} кадр 102")
    for i in [rc, cam, cam.data, sc] + ctls + [o for o in (wc, ws) if o is not None]:   # нові криві: на 1..93 = старе значення
        for fk, fc in _own_fcurves(i):
            if fk in before:
                continue
            p = pre.get((i.as_pointer(), fc.data_path))
            if p is None or fc.array_index >= len(p):
                bad.append(f"{i.name}: нова крива {fc.data_path}"); continue
            if any(abs(fc.evaluate(float(f)) - p[fc.array_index]) > EPS for f in range(1, 94)):
                bad.append(f"{i.name}: {fc.data_path}[{fc.array_index}] на 1–93 змінилось")
    mk = _markers(sc)
    if mk.get('Essential Armchair') != 100 or mk.get('Essential Sofa, 84in') != 96:
        bad.append("маркери не на місці")
    for name, (Ff, Fq) in newf.items():
        sc.frame_set(Fq)
        if abs(sc.get('fabric_front', 1.0)) > EPS or abs(rc.rotation_euler.z - 0.5236) > 1e-3:
            bad.append(f"{name}: 3/4F кадр {Fq} не такий")
        sc.frame_set(Ff)
        if abs(rc.rotation_euler.z) > 1e-4:
            bad.append(f"{name}: фронт кадр {Ff} повернутий")
    sc.frame_set(f0)
    if bad:
        return False, ["Кадри НЕ перебудовано чисто: " + "; ".join(bad[:4])]
    return True, [f"Кадри 94–101: дивани й крісло = фронт + 3/4 фронт (ключів пересунуто {n_keys}, 1–93 без змін)"]
