bl_info = {
    "name":        "Custom Frame Render",
    "author":      "Hrebeniuk Tools",
    "version":     (1, 13, 0),
    "blender":     (4, 2, 0),
    "location":    "3D Viewport › N-Panel › CFRender",
    "description": "Рендер вибраних кадрів + неймінг + маски WireColor (і Cycles з рельєфом) + DPI",
    "category":    "Render",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])
ADDON_CHANGES = {
    (1, 13, 0): "Маски — тепер завжди «Face+Obj Cycles (рельєф)» зі згладжуванням Cycles: досить увімкнути Masks і натиснути "
                "Render (або чергу таблиць). Вибір типу маски і країв прибрано; маски лягають у підпапку Masks поруч із рендерами",
    (1, 12, 1): "Маски «Face+Obj Cycles (рельєф)» тепер лягають у підпапку Masks поруч із рендерами, імена як раніше: "
                "<ім'я>_mask_face.png і <ім'я>_mask_object.png (було поруч із бьюті і _mask_obj)",
    (1, 12, 0): "Маски «Face+Obj Cycles (рельєф)»: контур маски йде по справжньому рельєфу тканини, як у бьюті. Рендеряться "
                "після бьюті одним фоновим проходом (інтерфейс вільний). Кнопки «Перевірити» і «Перерахувати застарілі» — "
                "рендерять лише кадри, де сцена/камера/тканина змінились (для черги таблиць — по всіх відмічених). "
                "Потрібен WireColor 3.10.0+. "
                "Краї масок Cycles: Cycles AA (рекомендовано, згладжує сам Cycles), М'які (швидкі) або Жорсткі (для чарівної палички PS)",
    (1, 11, 0): "Черга таблиць рендериться в тому порядку, в якому ставиш галочки; біля відміченої — синій номер у черзі "
                "(наведи — підказка)",
    (1, 10, 2): "Черга таблиць: тканина й порода кожної таблиці знову ставляться перед її рендером (після відкриття "
                "файла Thuma Material «губився» — рендерилась попередня тканина з іменами іншої таблиці)",
    (1, 10, 1): "Вікно «Рендер черги» показує, чи є вже файли в папці кожної таблиці; "
                "вибір Add Version / Replace / Skip — лише коли справді є що перезаписати",
    (1, 10, 0): "Черга таблиць: кожна таблиця рендериться у свою підпапку (з назвою розцвітки) у вибраній папці, "
                "копія 2K — всередині неї. Звичайний Render — як раніше, прямо у вибрану папку",
}
ADDON_FRAMES = {
    (1, 12, 1): "жодних — лише куди лягають маски Cycles",
    (1, 12, 0): "лише маски Cycles (новий тип); бьюті й Workbench-маски без змін",
    (1, 11, 0): "жодних — лише порядок черги",
    (1, 10, 2): "черга таблиць — усі кадри",
    (1, 10, 1): "жодних — лише панель",
    (1, 10, 0): "жодних — лише куди зберігаються файли",
}


import bpy
import os
import re
import csv
import io
import time
import struct
import zlib
import urllib.request
from bpy.props import (StringProperty, EnumProperty, IntProperty,
                       BoolProperty, PointerProperty, CollectionProperty)
from bpy.types import Panel, Operator, PropertyGroup, UIList

# ─────────────────────────────────────────────────────────────────────────────
#  GLOBALS
# ─────────────────────────────────────────────────────────────────────────────

_queue           = []     # [(frame, task, target_path)]
_total           = 0
_done_count      = 0
_skipped         = 0
_orig_frame      = 0
_orig_output     = ''
_orig_fstart     = 1
_orig_fend       = 1
_orig_fstep      = 1
_conflict_action    = 'VERSION'
_is_rendering       = False
_beauty_target_path = ''
_next_render_at     = 0.0
_render_in_progress = False   # True тільки між _start_one_frame і render_complete
_pending_save       = ''      # кадр відрендерено — зберегти в основному потоці (_poll_render)
_save_at            = 0.0
_orig_lock          = False   # Lock Interface до початку пачки
_frame_start_time   = 0.0
_session_start_time = 0.0
_frame_times        = []      # час рендеру кожного завершеного кадру (для ETA)
_dpi                = 0

TASK_LABEL  = {"BEAUTY": "Beauty", "OBJ": "Obj Mask", "FACE": "Face Mask", "MAT": "Mat Mask", "CYC": "Cycles Masks"}
MASK_SUFFIX = {"OBJ": "_mask_obj", "FACE": "_mask_face", "MAT": "_mask_mat"}
CYC_DIR, CYC_OBJ_SUFFIX = "Masks", "_mask_object"   # 1.12.1: маски Cycles — у підпапку Masks, імена як маски v02
MASK_OP     = {"OBJ": "render_obj_mask", "FACE": "render_face_mask", "MAT": "render_mat_mask"}
_CYC        = {"active": False, "status": "", "n": 0, "mode": "render", "note": ""}   # 1.12.0: фоновий прохід масок Cycles


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _parse_frames(text):
    frames = set()
    for part in text.replace(' ', '').split(','):
        if not part:
            continue
        if '-' in part:
            a, _, b = part.partition('-')
            try:
                frames.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        else:
            try:
                frames.add(int(part))
            except ValueError:
                pass
    return sorted(frames)


def _compact_ranges(frames):
    """[1,2,3,5,7,8] → '1-3, 5, 7-8'."""
    out, i = [], 0
    while i < len(frames):
        j = i
        while j + 1 < len(frames) and frames[j + 1] == frames[j] + 1:
            j += 1
        out.append(str(frames[i]) if i == j else f"{frames[i]}-{frames[j]}")
        i = j + 1
    return ", ".join(out)


def _wirecolor_ok():
    return (hasattr(bpy.ops, 'wirecolor') and
            hasattr(bpy.ops.wirecolor, 'render_obj_mask') and
            hasattr(bpy.ops.wirecolor, 'render_mat_mask'))


def _wc_cycles_ok():
    return hasattr(bpy.ops, 'wirecolor') and hasattr(bpy.ops.wirecolor, 'cycles_masks')


def _shot_list_ok(scene):
    sl = getattr(scene, "shot_list", None)
    return bool(sl and len(sl.shots) and hasattr(bpy.ops, "shot_list")
                and hasattr(bpy.ops.shot_list, "to_cfrender"))


def _get_render_ext(scene):
    return {
        'PNG': '.png', 'JPEG': '.jpg', 'JPEG2000': '.jp2',
        'OPEN_EXR': '.exr', 'OPEN_EXR_MULTILAYER': '.exr',
        'TIFF': '.tif', 'BMP': '.bmp', 'HDR': '.hdr',
    }.get(scene.render.image_settings.file_format, '.png')


def _get_output_dir(props, scene):
    if props.use_custom_output and props.output_path:
        d = bpy.path.abspath(props.output_path)
    else:
        fp = bpy.path.abspath(scene.render.filepath)
        d = os.path.dirname(fp) or bpy.path.abspath('//')
    if _MQ.get("items") and _MQ.get("subdir"):      # 1.10.0: черга таблиць -> своя підпапка на кожну таблицю
        d = os.path.join(d, _MQ["subdir"])
    return d


def _safe_dirname(label):
    s = re.sub(r'[<>:"/\\|?*]', '_', label or "")
    return re.sub(r'\s+', ' ', s).strip(' .') or "sheet"


def _get_frame_name(props, frame):
    if not props.use_name_map:
        return None
    for e in props.name_map:
        if e.frame == frame:
            n = e.name.strip()
            return n or None
    return None


def _versioned_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    for i in range(1, 100):
        p = f"{base}_V{i:02d}{ext}"
        if not os.path.exists(p):
            return p
    return path


def _frame_base(props, scene, frame):
    """Шлях без розширення: <папка>/<ім'я з таблиці або 0001>."""
    name = _get_frame_name(props, frame) or f"{frame:04d}"
    return os.path.join(_get_output_dir(props, scene), name)


def _mask_ext(scene):
    # так само, як WireColor обирає розширення маски
    ext = _get_render_ext(scene)
    return ext if ext in ('.png', '.jpg', '.exr', '.tif') else '.png'


def _mask_type(props):
    """1.13.0: є WireColor 3.10+ -> завжди маски Cycles (рельєф); інакше — як вибрано (старий WireColor)."""
    return 'CYC' if _wc_cycles_ok() else props.mask_type


def _target_path(props, scene, frame, task):
    base = _frame_base(props, scene, frame)
    if task == 'BEAUTY':
        return base + _get_render_ext(scene)
    if task == 'CYC':                                   # 1.12.1: <папка>\Masks\<ім'я>_mask_face.png (як маски v02)
        d, n = os.path.split(base)
        return os.path.join(d, CYC_DIR, n + MASK_SUFFIX["FACE"] + ".png")
    return base + MASK_SUFFIX[task] + _mask_ext(scene)


def _cyc_obj_path(face_path):
    return face_path[:-len(MASK_SUFFIX["FACE"] + ".png")] + CYC_OBJ_SUFFIX + ".png"


def _fmt_time(seconds):
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60:02d}s"
    return f"{s // 3600}h {s % 3600 // 60:02d}m"


# ── DPI у PNG (чистий Python, як у BlenderFarm) ──────────────────────────────

_PNG_SIG = b'\x89PNG\r\n\x1a\n'


def _png_chunk(chunk_type, data):
    c = chunk_type + data
    return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF)


def set_png_dpi(path, dpi):
    """Записати DPI у PNG (чанк pHYs). Повертає True, якщо вдалося."""
    try:
        with open(path, 'rb') as f:
            data = f.read()
        if not data.startswith(_PNG_SIG):
            return False
        ppm = round(dpi / 0.0254)
        out, pos, done = bytearray(_PNG_SIG), 8, False
        while pos + 8 <= len(data):
            length = struct.unpack('>I', data[pos:pos + 4])[0]
            ctype  = data[pos + 4:pos + 8]
            cdata  = data[pos + 8:pos + 8 + length]
            pos   += 12 + length
            if ctype == b'pHYs':
                continue
            out += _png_chunk(ctype, cdata)
            if ctype == b'IHDR' and not done:
                out += _png_chunk(b'pHYs', struct.pack('>IIB', ppm, ppm, 1))
                done = True
        if not done:
            return False
        with open(path, 'wb') as f:
            f.write(out)
        return True
    except Exception as e:
        print(f"CFRender DPI: {path}: {e}")
        return False


def _make_2k(path, size):
    """1.9.0: зменшена копія кадру -> <папка>/2K/<імʼя>.png (OpenImageIO з Blender, Lanczos-3, без втрат,
    та сама розрядність/канали/DPI). У фоновому потоці — наступний кадр не чекає."""
    try:
        import OpenImageIO as oiio
        src = oiio.ImageBuf(path)
        spec = src.spec()
        w, h = spec.width, spec.height
        if max(w, h) <= size:
            return
        k = size / max(w, h)
        nw, nh = max(1, round(w * k)), max(1, round(h * k))
        dst = oiio.ImageBufAlgo.resize(src, filtername="lanczos3", roi=oiio.ROI(0, nw, 0, nh, 0, 1, 0, spec.nchannels))
        for name in ("XResolution", "YResolution", "ResolutionUnit"):
            v = spec.getattribute(name)
            if v is not None:
                dst.specmod().attribute(name, v)
        out_dir = os.path.join(os.path.dirname(path), "2K")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, os.path.basename(path))
        tmp = out[:-4] + ".part.png"
        dst.set_write_format(spec.format)
        if not dst.write(tmp):
            raise RuntimeError(dst.geterror())
        os.replace(tmp, out)
    except Exception as e:
        print(f"CFRender 2K: {e}")


def _copy_2k(path):
    props = getattr(bpy.context.scene, "cfrender_props", None)
    if props and props.copy_2k and path and path.lower().endswith('.png') and os.path.exists(path):
        import threading
        threading.Thread(target=_make_2k, args=(path, props.size_2k), daemon=True).start()


def _apply_dpi(path):
    if _dpi > 0 and path and path.lower().endswith('.png') and os.path.exists(path):
        set_png_dpi(path, _dpi)


# ── Google Sheets ────────────────────────────────────────────────────────────

def _sheets_to_csv_url(url):
    m = re.search(r'/spreadsheets/d/([a-zA-Z0-9_-]+)', url)
    if not m:
        return None
    gid_m = re.search(r'[#&?]gid=(\d+)', url)
    gid   = gid_m.group(1) if gid_m else '0'
    return f"https://docs.google.com/spreadsheets/d/{m.group(1)}/export?format=csv&gid={gid}"


def _fetch_sheets_entries(url):
    csv_url = _sheets_to_csv_url(url)
    if not csv_url:
        raise ValueError("Could not recognize the Google Sheets URL")
    req = urllib.request.Request(csv_url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        content = resp.read().decode('utf-8')
    entries = []
    for row in csv.reader(io.StringIO(content)):
        if len(row) < 2:
            continue
        try:
            frame = int(row[0].strip())
            name  = row[1].strip()
            if name:
                entries.append((frame, name))
        except ValueError:
            continue
    return entries


# ─────────────────────────────────────────────────────────────────────────────
#  RENDER ENGINE  (timer + handler chain, no modal)
# ─────────────────────────────────────────────────────────────────────────────

def _redraw():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in ('VIEW_3D', 'PROPERTIES'):
                    area.tag_redraw()
    except Exception:
        pass


def _set_status(text):
    if _MQ.get("items"):
        text = f"[{_MQ['i'] + 1}/{len(_MQ['items'])} {_MQ['items'][_MQ['i']][0]}]  " + text
    try:
        bpy.context.scene.cfrender_props.render_status = text
    except Exception:
        pass
    _redraw()


def _cleanup(scene=None):
    """Повернути сцену як було (кадр, шлях виводу, діапазон) і зняти прапорці."""
    global _is_rendering, _render_in_progress, _next_render_at, _pending_save
    _is_rendering       = False
    _render_in_progress = False
    _next_render_at     = 0.0
    _pending_save       = ''
    _queue.clear()
    s = scene or (bpy.context.scene if bpy.context else None)
    if s:
        try:
            s.render.use_lock_interface = _orig_lock
            s.frame_set(_orig_frame)
            s.render.filepath = _orig_output
            s.frame_start = _orig_fstart
            s.frame_end   = _orig_fend
            s.frame_step  = _orig_fstep
            s.cfrender_props.is_rendering = False
        except Exception as e:
            print(f"CFRender cleanup: {e}")
    _redraw()


def _finish(scene, stopped=False):
    total = _fmt_time(time.time() - _session_start_time)
    done  = _done_count
    msg   = (f"Stopped: {done}/{_total} done" if stopped
             else f"Done: {done}/{_total}  ·  {total}")
    if _skipped:
        msg += f"  ·  skipped existing: {_skipped}"
    if _CYC.get("note"):
        msg = _CYC["note"] + "  ·  " + msg
        _CYC["note"] = ""
    _set_status(msg)
    _cleanup(scene)
    _mq_advance(stopped)                            # 1.8.0: черга таблиць — далі наступна


def _start_one_frame(scene, frame, task, target):
    """Стартує рендер одного кадру (асинхронно) або маски (синхронно)."""
    global _beauty_target_path, _frame_start_time, _render_in_progress

    _frame_start_time = time.time()
    scene.frame_set(frame)
    status = f"{TASK_LABEL[task]}  fr.{frame}  ({_done_count + 1}/{_total})"
    if _frame_times:
        avg = sum(_frame_times) / len(_frame_times)
        status += f"  ·  ~{_fmt_time(avg * (len(_queue) + 1))} left"
    _set_status(status)

    if _conflict_action == 'VERSION':
        target = _versioned_path(target)
    elif _conflict_action == 'REPLACE' and task != 'BEAUTY' and os.path.exists(target):
        os.remove(target)          # інакше WireColor сам додасть _V01
    os.makedirs(os.path.dirname(target), exist_ok=True)

    if task == 'BEAUTY':
        _beauty_target_path = target
        _render_in_progress = True
        # Рендер у вікно без запису — зберігає render_complete (save_render)
        win = bpy.context.window_manager.windows[0]
        with bpy.context.temp_override(window=win):
            bpy.ops.render.render('INVOKE_DEFAULT')
        return

    # Маска: WireColor бере шлях з scene.render.filepath і додає суфікс
    props = scene.cfrender_props
    scene.render.filepath = _frame_base(props, scene, frame) + _get_render_ext(scene)
    orig_compress = scene.render.image_settings.compression
    scene.render.image_settings.compression = 0
    try:
        getattr(bpy.ops.wirecolor, MASK_OP[task])()
    finally:
        scene.render.image_settings.compression = orig_compress
        scene.render.filepath = _orig_output
    _apply_dpi(target)
    _mark_done()


def _mark_done():
    global _done_count
    _done_count += 1
    _frame_times.append(time.time() - _frame_start_time)


def _run_next():
    """Взяти наступне завдання. Повертає інтервал таймера або None."""
    scene = bpy.context.scene
    if not _is_rendering or not scene:
        return None
    if not _queue:
        _finish(scene)
        return None
    frame, task, target = _queue.pop(0)
    if task == 'CYC':
        try:
            _cyc_start(scene, [(frame, task, target)])
        except Exception as e:
            print(f"CFRender: Cycles masks: {e}")
            _set_status(f"Маски Cycles: {e}"[:200])
            _cleanup(scene)
        return None
    try:
        _start_one_frame(scene, frame, task, target)
    except Exception as e:
        print(f"CFRender: frame {frame} {task}: {e}")
        _set_status(f"Error on frame {frame}: {e}")
        _cleanup(scene)
        return None
    if task != 'BEAUTY':
        return 0.05          # маска синхронна — одразу наступне (UI встигає оновитись)
    return None              # beauty — далі веде render_complete → _poll_render


def _cyc_start(scene, first):
    """Усі задачі CYC з черги -> один фоновий Blender (WireColor). Далі веде _cyc_poll."""
    global _queue, _frame_start_time
    import json
    import tempfile
    group = first + [q for q in _queue if q[1] == 'CYC']
    _queue = [q for q in _queue if q[1] != 'CYC']
    items = []
    for f, _t, face in group:
        obj = _cyc_obj_path(face)
        if _conflict_action == 'VERSION' and _CYC["mode"] == "render":
            face, obj = _versioned_path(face), _versioned_path(obj)
        os.makedirs(os.path.dirname(face), exist_ok=True)
        items.append({"frame": f, "face": face, "obj": obj})
    st = os.path.join(tempfile.gettempdir(), "wc_masks", f"cfr_status_{int(time.time())}.json")
    os.makedirs(os.path.dirname(st), exist_ok=True)
    _frame_start_time = time.time()
    _CYC.update(active=True, status=st, n=len(items), note="")
    _set_status(f"Маски Cycles: старт фонового Blender ({len(items)} кадр.)…")
    kw = {}
    try:                                                # WireColor без м'яких країв — просто не передаємо
        if "edges" in bpy.ops.wirecolor.cycles_masks.get_rna_type().properties:
            kw["edges"] = "cycles"             # 1.13.0: єдиний режим
    except Exception:
        pass
    r = bpy.ops.wirecolor.cycles_masks('EXEC_DEFAULT', mode=_CYC["mode"], job_items=json.dumps(items), status_path=st,
                                       **kw)
    if 'FINISHED' not in r:
        _CYC["active"] = False
        raise RuntimeError("WireColor не запустив маски (див. Info)")
    bpy.app.timers.register(_cyc_poll, first_interval=2.0)


def _cyc_poll():
    global _done_count
    if not _CYC["active"]:
        return None
    import json
    try:
        with open(_CYC["status"], encoding="utf-8") as fh:
            st = json.load(fh)
    except Exception:
        return 1.0
    if not st.get("finished"):
        cur = st.get("current")
        _set_status(f"Маски Cycles {st.get('done', 0)}/{_CYC['n']}" + (f"  ·  fr.{cur}" if cur is not None else "")
                    + (f"  ·  актуальні {st['skipped']}" if st.get("skipped") else ""))
        return 1.0
    _CYC["active"] = False
    for pth in st.get("files", []):
        _apply_dpi(pth)
    _done_count += _CYC["n"]
    _frame_times.append(time.time() - _frame_start_time)
    errs = st.get("errors") or []
    note = ""
    if _CYC["mode"] == "check":
        stl, mis = st.get("stale", []), st.get("missing", [])
        note = (f"Маски: застаріли {len(stl)}" + (f" (кадри {_compact_ranges(stl)})" if stl else "")
                + f" · нема {len(mis)}" + (f" ({_compact_ranges(mis)})" if mis else "")
                + f" · актуальні {len(st.get('fresh', []))}")
    elif _CYC["mode"] == "stale":
        note = f"Маски: перераховано {st.get('rendered', 0)}, актуальні {st.get('skipped', 0)}"
    if errs:
        note += f"  ·  ПОМИЛКИ {len(errs)}: " + str(errs[0].get("error", ""))[:120]
        print("CFRender Cycles masks errors:", errs)
    _CYC["note"] = note
    if _MQ.get("items"):
        _MQ.setdefault("cyc_notes", []).append(f"{_MQ['items'][_MQ['i']][0]}: {note}")
    _finish(bpy.context.scene, stopped=bool(errs) and not st.get("done"))
    return None


def _render_job_running():
    try:
        return bpy.app.is_job_running('RENDER')
    except Exception:
        return False


def _save_pending():
    """Зберегти відрендерений кадр — ТІЛЬКИ в основному потоці і коли рендер-джоб уже закінчився.
    Раніше зберігали прямо в render_complete (інший потік): клік по вікну рендеру в цей момент
    = обидва потоки чекають Render Result -> Blender зависав намертво."""
    global _pending_save, _next_render_at
    path, _pending_save = _pending_save, ''
    img = bpy.data.images.get('Render Result')
    if img:
        try:
            img.save_render(path, scene=bpy.context.scene)
            _apply_dpi(path)
            _copy_2k(path)                       # 1.9.0
        except Exception as e:
            print(f"CFRender save: {e}")
    _mark_done()
    _next_render_at = time.time() + 0.3


def _poll_render():
    """Основний потік: зберегти готовий кадр, потім через паузу стартувати наступний."""
    global _next_render_at
    if not _is_rendering:
        return None
    if _pending_save and time.time() >= _save_at and not _render_job_running():
        _save_pending()
    if _next_render_at > 0 and time.time() >= _next_render_at:
        _next_render_at = 0.0
        bpy.app.timers.register(_run_next, first_interval=0.01)
    return 0.1


@bpy.app.handlers.persistent
def _cfrender_complete(scene, depsgraph=None):
    """render_complete (потік рендеру!) → тільки позначаємо; зберігає _poll_render в основному потоці."""
    global _beauty_target_path, _next_render_at, _render_in_progress, _pending_save, _save_at
    if not _is_rendering or not _render_in_progress:
        return            # чужий рендер (напр. звичайний F12)
    _render_in_progress = False
    if _beauty_target_path:
        _pending_save, _beauty_target_path = _beauty_target_path, ''
        _save_at = time.time() + 0.2
    else:
        _mark_done()
        _next_render_at = time.time() + 0.5


@bpy.app.handlers.persistent
def _cfrender_cancel(scene, depsgraph=None):
    """Esc під час рендеру — зупиняємо чергу і повертаємо сцену (після завершення рендеру)."""
    if not _is_rendering:
        return
    _queue.clear()

    def _later():
        _finish(bpy.context.scene, stopped=True)
        return None
    bpy.app.timers.register(_later, first_interval=0.3)


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

class CFRenderNameEntry(PropertyGroup):
    frame: IntProperty(description="Номер кадру", name="Frame", default=1, min=0)
    name:  StringProperty(description="Ім'я файлу (без розширення)", name="Name", default="")


class CFRenderPreset(PropertyGroup):
    frames: StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Frames", default="1")


def _preset_index_update(self, context):
    idx = self.preset_index
    if self.presets and idx < len(self.presets):
        p = self.presets[idx]
        self.preset_name   = p.name
        self.preset_frames = p.frames


def _nm_index_update(self, context):
    idx = self.name_map_index
    if self.name_map and idx < len(self.name_map):
        e = self.name_map[idx]
        self.new_nm_frame = e.frame
        self.new_nm_name  = e.name


def _queue_ordered(props):
    """1.11.0: відмічені таблиці в порядку, в якому ставили галочки (order 1, 2, 3 ...);
    старі відмітки без номера — після них, за місцем у списку."""
    q = list(props.sheet_queue)
    used = [(i, it) for i, it in enumerate(q) if it.use]
    used.sort(key=lambda p: (p[1].order or 10 ** 6 + p[0]))
    return [it for _i, it in used]


def _use_changed(self, context):
    props = self.id_data.cfrender_props
    if self.use:
        self["order"] = max([x.order for x in props.sheet_queue if x.use] + [0]) + 1
    else:
        self["order"] = 0
    for n, it in enumerate(_queue_ordered(props), 1):  # без дірок: 1..N
        it["order"] = n


class CFRenderSheetItem(PropertyGroup):
    url: StringProperty(name="URL", default="", description="Посилання на вкладку таблиці (з #gid=...)")
    use: BoolProperty(name="Рендерити", default=False, update=_use_changed,
                      description="Включити цю таблицю в чергу рендеру. Порядок рендеру = порядок, у якому ставиш галочки")
    order: IntProperty(default=0, min=0)


class CFRENDER_OT_queue_num(Operator):
    bl_idname = "cfrender.queue_num"
    bl_label = "Номер у черзі"
    bl_options = {'INTERNAL'}
    n: IntProperty()
    total: IntProperty()

    @classmethod
    def description(cls, context, props):
        return (f"Ця таблиця рендериться {props.n}-ю з {props.total}. Порядок = порядок, у якому ставив галочки: "
                "зняв і знову поставив — стане останньою")

    def execute(self, context):
        return {'CANCELLED'}


class CFRenderProps(PropertyGroup):
    do_beauty: BoolProperty(name="Beauty", default=True,
                            description="Рендерити звичайні кадри (Cycles, як у сцені)")
    do_masks:  BoolProperty(name="Masks", default=False,
                            description="Рендерити маски WireColor (швидко, Workbench)")
    beauty_frames: StringProperty(name="Frames", default="1",
                                  description="Які кадри рендерити: 1, 5, 10-20, 50")
    masks_same_frames: BoolProperty(name="Same Frames as Beauty", default=True,
                                    description="Маски для тих самих кадрів, що й Beauty")
    mask_frames:   StringProperty(name="Mask Frames", default="1",
                                  description="Кадри для масок: 1, 5, 10-20, 50")
    mask_type: EnumProperty(name="Mask Type", default='CYC',
                            description="Які маски рендерити", items=[
        ('OBJ',  "Object",             "Тільки маска об'єктів (_mask_obj)"),
        ('FACE', "Face",               "Тільки маска полігонів (_mask_face)"),
        ('MAT',  "Material",           "Тільки маска матеріалів (_mask_mat)"),
        ('BOTH', "Obj+Face",           "Маски об'єктів і полігонів"),
        ('ALL',  "All 3",              "Маски об'єктів, полігонів і матеріалів"),
        ('CYC',  "Face+Obj Cycles (рельєф)", "Face і Object маски Cycles: контур по справжньому рельєфу тканини, як у "
                                             "бьюті. Рендеряться фоновим Blender після бьюті. Потрібен WireColor 3.10+"),
    ])
    mask_edges: EnumProperty(name="Краї", default='cycles', description="Які краї зон у масках Cycles", items=[
        ('cycles', "Cycles AA (рекомендовано)", "Справжнє згладжування самим Cycles (16 семплів, як у бьюті): край "
                                                "точно по рельєфу, без сходинок; кілька секунд на кадр. Потрібен "
                                                "WireColor з режимом Cycles AA, інакше — як у панелі WireColor"),
        ('soft', "М'які (швидкі)", "Гладкий край без сходинок: звичайний рендер, край згладжується після "
                                   "нього (+1–2 с на кадр). Всередині зон колір рівно як у легенді, лише "
                                   "крайові пікселі — суміш сусідніх кольорів"),
        ('hard', "Жорсткі (чарівна паличка PS)", "Кожен піксель — рівно колір легенди, край сходинками. Для виділення "
                                                 "чарівною паличкою Photoshop без допуску"),
    ])
    dpi: IntProperty(name="DPI", default=300, min=0, max=2400,
                     description="Записати DPI у PNG (Beauty і маски). 0 — не чіпати")
    copy_2k: BoolProperty(name="+ копія 2K", default=False,
                          description="Після кожного Beauty-кадру поруч у папці «2K» — та сама картинка зменшена "
                                      "(більша сторона = розмір нижче, Lanczos, PNG без втрат). Для раундів правок / Miro; "
                                      "на фінал вимкни. Оригінал не змінюється")
    size_2k: IntProperty(name="Розмір, px", default=2000, min=256, max=8000,
                         description="Більша сторона зменшеної копії, px")
    presets_expanded: BoolProperty(default=False)
    use_custom_output: BoolProperty(name="Custom Output", default=False,
                                    description="Зберігати рендери у свою папку замість шляху з Output Properties")
    output_path: StringProperty(name="Output", default="", subtype='DIR_PATH',
                                description="Папка для рендерів")
    sheets_url:  StringProperty(name="Sheets URL", default="", update=lambda self, ctx: _sheets_url_changed(self, ctx),
                                description="Посилання на Google Sheets (доступ: Anyone with link). Колонки: кадр, ім'я. "
                                            "Після зміни посилання кадри й імена завантажуються самі")
    use_name_map: BoolProperty(name="Name Map", default=False,
                               description="Називати файли за таблицею «кадр → ім'я» (кадри без імені пропускаються)")
    name_map:       CollectionProperty(type=CFRenderNameEntry)
    sheet_queue:    CollectionProperty(type=CFRenderSheetItem)
    name_map_index: IntProperty(default=0, min=0, update=_nm_index_update)
    new_nm_frame:   IntProperty(description="Кадр", name="Frame", default=1, min=0)
    new_nm_name:    StringProperty(description="Ім'я файлу для цього кадру (без розширення)", name="Name", default="")
    lock_ui: BoolProperty(name="Lock UI", default=False,
                          description="Блокувати інтерфейс на час пачки (Render › Lock Interface). "
                                      "Найбезпечніше від зависань, але сцену під час рендеру не подивишся. "
                                      "Вимкнено — можна працювати, збереження кадрів і так іде безпечно")
    is_rendering:   BoolProperty(default=False)
    render_status:  StringProperty(default="")
    presets:        CollectionProperty(type=CFRenderPreset)
    preset_index:   IntProperty(default=0, min=0, update=_preset_index_update)
    preset_name:    StringProperty(description="Назва пресета", name="Name", default="")
    preset_frames:  StringProperty(description="Кадри пресета, напр.: 1, 5, 10-20", name="Frames", default="")


# ─────────────────────────────────────────────────────────────────────────────
#  UILISTS
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_UL_presets(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.38)
        split.label(text=item.name)
        split.label(text=item.frames)


class CFRENDER_UL_namemap(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(factor=0.22)
        split.label(text=str(item.frame))
        split.label(text=item.name)


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Presets
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_preset_save(Operator):
    bl_idname = "cfrender.preset_save"
    bl_description = "Зберегти пресет: назва + список кадрів (якщо така назва є — оновиться)"
    bl_label  = "Save Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props  = context.scene.cfrender_props
        name   = props.preset_name.strip()
        frames = props.preset_frames.strip()
        if not name:
            self.report({'WARNING'}, "Enter a name"); return {'CANCELLED'}
        if not frames:
            self.report({'WARNING'}, "Enter frames");  return {'CANCELLED'}
        existing = next((p for p in props.presets if p.name == name), None)
        if existing:
            existing.frames = frames
        else:
            p = props.presets.add()
            p.name = name; p.frames = frames
            props.preset_index = len(props.presets) - 1
        self.report({'INFO'}, f"Saved: {name}")
        return {'FINISHED'}


class CFRENDER_OT_preset_remove(Operator):
    bl_idname = "cfrender.preset_remove"
    bl_description = "Видалити вибраний пресет"
    bl_label  = "Remove Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets): return {'CANCELLED'}
        props.presets.remove(idx)
        props.preset_index = max(0, idx - 1)
        return {'FINISHED'}


class CFRENDER_OT_preset_apply(Operator):
    bl_idname = "cfrender.preset_apply"
    bl_label  = "Apply Preset"
    bl_options = {'REGISTER'}
    target: EnumProperty(items=[('BEAUTY', "Beauty", ""), ('MASK', "Mask", "")], default='BEAUTY')

    @classmethod
    def description(cls, context, properties):
        return ("Підставити кадри пресета в поле кадрів Beauty" if properties.target == 'BEAUTY'
                else "Підставити кадри пресета в поле кадрів масок")

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.preset_index
        if not props.presets or idx >= len(props.presets):
            self.report({'WARNING'}, "Select a preset"); return {'CANCELLED'}
        frames = props.presets[idx].frames
        if self.target == 'BEAUTY':
            props.beauty_frames = frames
        else:
            props.mask_frames = frames
            props.masks_same_frames = False
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Name Map / Shot List
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_from_shot_list(Operator):
    bl_idname      = "cfrender.from_shot_list"
    bl_label       = "Frames from Shot List"
    bl_description = ("Заповнити кадри та імена файлів з Shot List (тільки увімкнені шоти). "
                      "Маски — для тих самих кадрів")
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _shot_list_ok(context.scene)

    def execute(self, context):
        r = bpy.ops.shot_list.to_cfrender()
        if r != {'FINISHED'}:
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        props.masks_same_frames = True
        self.report({'INFO'}, f"From Shot List: {len(props.name_map)} frames")
        return {'FINISHED'}


def _apply_entries(props, entries):
    props.name_map.clear()
    for frame, name in entries:
        e = props.name_map.add()
        e.frame = frame; e.name = name
    props.name_map_index = 0
    props.use_name_map = True
    # кадри = всі кадри таблиці (можна потім звузити вручну)
    props.beauty_frames = _compact_ranges(sorted({f for f, _n in entries}))


_AUTO = {"pending": None}


def _sheets_url_changed(props, context):
    """1.7.5: нове посилання -> автоматично завантажити кадри й імена (як кнопка Import), через таймер."""
    url = props.sheets_url.strip()
    if not url:
        return
    scene_name = props.id_data.name if getattr(props, "id_data", None) else (context.scene.name if context else "")
    _AUTO["pending"] = (scene_name, url)

    def run():
        job, _AUTO["pending"] = _AUTO["pending"], None
        if not job:
            return None
        sc = bpy.data.scenes.get(job[0])
        if sc is None or sc.cfrender_props.sheets_url.strip() != job[1]:
            return None
        try:
            entries = _fetch_sheets_entries(job[1])
        except Exception as e:
            sc.cfrender_props.render_status = f"Sheets: {e}"[:200]
            print("[CFRender] auto import:", e)
            return None
        if entries:
            _apply_entries(sc.cfrender_props, entries)
            print(f"[CFRender] auto import: {len(entries)} entries -> frames {sc.cfrender_props.beauty_frames}")
        for w in bpy.context.window_manager.windows if bpy.context.window_manager else []:
            for a in w.screen.areas:
                a.tag_redraw()
        return None
    if not bpy.app.timers.is_registered(run):
        bpy.app.timers.register(run, first_interval=0.2)


# ---------------- 1.8.0: ЧЕРГА ТАБЛИЦЬ (кілька розцвіток по черзі) ----------------
# Кожен пункт = посилання на вкладку Google Sheets. Перед пунктом викликаються хуки інших аддонів
# (bpy.app.driver_namespace["cfrender_sheet_hooks"]: f(scene, url)) — напр. Thuma Fabric ставить тканину й породу.
_MQ = {"items": [], "i": 0, "mode": 'ALL', "conflict": 'VERSION', "t0": 0.0, "subdir": ""}
_MQ_EXISTING = {}       # 1.10.1: {назва таблиці: файлів у її підпапці} — для діалогу черги


def _sheet_hooks():
    """1.10.2: хуки черги таблиць. Blender очищає driver_namespace при відкритті файла, тож хук аддона, доданий
    під час запуску, міг зникнути -> черга рендерила стару тканину. Тому ще й шукаємо функцію _cfr_sheet_hook
    у завантажених аддонах (Thuma Material) напряму."""
    import sys
    hooks = list(bpy.app.driver_namespace.get("cfrender_sheet_hooks", []))
    seen = {(getattr(h, "__module__", ""), getattr(h, "__name__", "")) for h in hooks}
    for name, mod in list(sys.modules.items()):
        if not name.startswith("bl_ext.") or name.count(".") != 2:
            continue
        f = getattr(mod, "_cfr_sheet_hook", None)
        if callable(f) and (f.__module__, f.__name__) not in seen:
            hooks.append(f); seen.add((f.__module__, f.__name__))
    return hooks


def _mq_advance(stopped=False):
    if not _MQ.get("items"):
        return
    if stopped:
        _MQ["items"] = []
        return
    _MQ["i"] += 1
    if _MQ["i"] < len(_MQ["items"]):
        bpy.app.timers.register(_mq_start_current, first_interval=1.0)
    else:
        n = len(_MQ["items"]); _MQ["items"] = []
        notes = _MQ.get("cyc_notes") or []
        if notes:                                       # 1.12.0: підсумок масок по таблицях — у консоль і в статус
            print("CFRender masks:\n  " + "\n  ".join(notes))
        _set_status(f"Черга таблиць: усі {n} готово  ·  {_fmt_time(time.time() - _MQ.get('t0', time.time()))}"
                    + ("  ·  " + " | ".join(notes) if notes else ""))


def _mq_start_current():
    """Запустити поточний пункт черги: хуки -> завантажити кадри/імена -> рендер."""
    sc = bpy.context.scene
    props = sc.cfrender_props
    if not _MQ.get("items"):
        return None
    label, url = _MQ["items"][_MQ["i"]]
    _MQ["subdir"] = _safe_dirname(label)            # 1.10.0: <Output>/<назва таблиці>/ (+ своя 2K всередині)
    for hook in _sheet_hooks():
        try:
            hook(sc, url)
        except Exception as e:
            print("[CFRender] hook:", e)
    try:
        entries = _fetch_sheets_entries(url)
    except Exception as e:
        _MQ["items"] = []
        _set_status(f"Черга зупинена: {label}: {e}"[:200])
        return None
    if not entries:
        _MQ["items"] = []
        _set_status(f"Черга зупинена: {label}: таблиця порожня")
        return None
    _AUTO["pending"] = None
    props["sheets_url"] = url                      # без автоімпорту (кадри ставимо самі нижче)
    _apply_entries(props, entries)
    try:
        bpy.ops.cfrender.render('EXEC_DEFAULT', mode=_MQ["mode"], conflict_action=_MQ["conflict"],
                                cyc_mode=_MQ.get("cyc_mode", "render"))
    except Exception as e:
        _MQ["items"] = []
        _set_status(f"Черга зупинена: {label}: {e}"[:200])
        return None
    if not _is_rendering:                           # нічого рендерити (напр. усе вже є при Skip) -> далі
        _mq_advance()
    return None


class CFRENDER_OT_sheet_queue(Operator):
    bl_idname = "cfrender.sheet_queue"
    bl_label = "Render queue"
    bl_description = ("Відрендерити по черзі всі відмічені таблиці: спершу першу (усі її кадри), потім наступну. "
                      "Перед кожною інші аддони (Thuma Fabric) ставлять свої матеріали. Esc / ✕ — зупинити")
    conflict_action: EnumProperty(
        name="Існуючі файли",
        items=[('VERSION', "Add Version  (_V01, _V02 ...)", "Зберегти поруч з новою версією"),
               ('REPLACE', "Replace existing files", "Перезаписати файли"),
               ('SKIP', "Skip existing (render only missing)", "Рендерити тільки те, чого ще немає")],
        default='VERSION')
    cyc_mode: EnumProperty(items=[('render', "Рендер", ""), ('stale', "Застарілі", ""), ('check', "Перевірити", "")],
                           default='render', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        if _is_rendering:
            self.report({'WARNING'}, "Render already running")
            return {'CANCELLED'}
        items = [it for it in _queue_ordered(context.scene.cfrender_props) if it.url.strip()]
        if not items:
            self.report({'WARNING'}, "Відміть хоча б одну таблицю в черзі")
            return {'CANCELLED'}
        if self.cyc_mode != 'render':
            return self.execute(context)
        # 1.10.1: скільки файлів уже лежить у підпапці кожної таблиці -> вибір «Існуючі файли» лише коли є що перезаписати
        base = _get_output_dir(context.scene.cfrender_props, context.scene)
        _MQ_EXISTING.clear()
        for it in items:
            d = os.path.join(base, _safe_dirname(it.name))
            try:
                n = sum(1 for f in os.listdir(d) if os.path.isfile(os.path.join(d, f)))
            except OSError:
                n = 0
            _MQ_EXISTING[it.name] = n
        return context.window_manager.invoke_props_dialog(
            self, width=420, title=f"Рендер черги: {len(items)} табл.", confirm_text="Render")

    def draw(self, context):
        col = self.layout.column(align=True)
        for k, it in enumerate([it for it in _queue_ordered(context.scene.cfrender_props) if it.url.strip()], 1):
            n = _MQ_EXISTING.get(it.name, 0)
            col.label(text=f"{k}.  " + it.name + (f"   (уже є файлів: {n})" if n else "   (нова папка)"),
                      icon='ERROR' if n else 'CHECKBOX_HLT')
        if any(_MQ_EXISTING.values()):
            self.layout.prop(self, "conflict_action", expand=True)
        else:
            self.layout.label(text="Папок ще немає — нічого не перезапишеться", icon='CHECKMARK')

    def execute(self, context):
        props = context.scene.cfrender_props
        items = [(it.name, it.url.strip()) for it in _queue_ordered(props) if it.url.strip()]
        if not items:
            return {'CANCELLED'}
        cm = self.cyc_mode
        _MQ.update(items=items, i=0, mode='ALL' if cm == 'render' else 'MASKS',
                   conflict=self.conflict_action if cm == 'render' else 'REPLACE', t0=time.time(), cyc_mode=cm, cyc_notes=[])
        bpy.app.timers.register(_mq_start_current, first_interval=0.1)
        return {'FINISHED'}


class CFRENDER_OT_sheet_queue_add(Operator):
    bl_idname = "cfrender.sheet_queue_add"
    bl_label = "Додати поточну таблицю в чергу"
    bl_description = "Додати поточне посилання (Sheets URL) у чергу таблиць"

    def execute(self, context):
        props = context.scene.cfrender_props
        url = props.sheets_url.strip()
        if not url:
            self.report({'WARNING'}, "Спершу встав посилання на таблицю")
            return {'CANCELLED'}
        it = next((x for x in props.sheet_queue if x.url == url), None) or props.sheet_queue.add()
        it.url = url; it.use = True
        if not it.name:
            m = re.search(r'gid=(\d+)', url)
            it.name = f"gid {m.group(1)}" if m else url[-30:]
        return {'FINISHED'}


class CFRENDER_OT_sheet_queue_clear(Operator):
    bl_idname = "cfrender.sheet_queue_clear"
    bl_label = "Очистити чергу таблиць"
    bl_description = "Прибрати всі таблиці з черги"

    def execute(self, context):
        context.scene.cfrender_props.sheet_queue.clear()
        return {'FINISHED'}


class CFRENDER_OT_import_sheets(Operator):
    bl_idname  = "cfrender.import_sheets"
    bl_description = ("Завантажити / оновити з Google Sheets: кадри та імена файлів "
                      "(таблиця: кадр, ім'я; доступ Anyone with link). Поле Frames заповниться всіма кадрами таблиці")
    bl_label   = "Import from Google Sheets"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        url   = props.sheets_url.strip()
        if not url:
            self.report({'ERROR'}, "Paste the sheet URL"); return {'CANCELLED'}
        try:
            entries = _fetch_sheets_entries(url)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        if not entries:
            self.report({'WARNING'}, "Sheet is empty or format not recognized (need: frame, name)")
            return {'CANCELLED'}
        _apply_entries(props, entries)
        self.report({'INFO'}, f"Imported {len(entries)} entries → frames {props.beauty_frames}")
        return {'FINISHED'}


class CFRENDER_OT_nm_add(Operator):
    bl_idname  = "cfrender.nm_add"
    bl_description = ("Додати запис «кадр → ім'я» вручну (якщо кадр вже є — оновить ім'я). "
                      "Можна і без Google Sheets")
    bl_label   = "Add / Update Name"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        frame = props.new_nm_frame
        name  = props.new_nm_name.strip()
        if not name:
            self.report({'WARNING'}, "Enter a name"); return {'CANCELLED'}
        existing = next((e for e in props.name_map if e.frame == frame), None)
        if existing:
            existing.name = name
        else:
            e = props.name_map.add()
            e.frame = frame; e.name = name
            props.name_map_index = len(props.name_map) - 1
        props.use_name_map = True
        return {'FINISHED'}


class CFRENDER_OT_nm_remove(Operator):
    bl_idname  = "cfrender.nm_remove"
    bl_description = "Видалити вибраний запис з таблиці імен"
    bl_label   = "Remove Entry"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.cfrender_props
        idx   = props.name_map_index
        if not props.name_map or idx >= len(props.name_map): return {'CANCELLED'}
        props.name_map.remove(idx)
        props.name_map_index = max(0, idx - 1)
        return {'FINISHED'}


class CFRENDER_OT_nm_clear(Operator):
    bl_idname      = "cfrender.nm_clear"
    bl_label       = "Clear Name Map"
    bl_description = ("Скинути таблицю: видалити всі імена і посилання, вимкнути Name Map "
                      "(кадри в полі Frames лишаються)")
    bl_options     = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event, title="Clear Name Map?", message="Всі імена і посилання буде видалено", confirm_text="Clear")

    def execute(self, context):
        props = context.scene.cfrender_props
        n = len(props.name_map)
        props.name_map.clear()
        props.name_map_index = 0
        props.sheets_url = ""
        props.use_name_map = False
        self.report({'INFO'}, f"Name Map cleared ({n} entries)")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Render
# ─────────────────────────────────────────────────────────────────────────────

def _build_queue(props, scene, mode):
    """[(frame, task, target)] у порядку: по кадрах, у кожному кадрі beauty → маски."""
    want_beauty = mode in ('BEAUTY', 'ALL') and (mode != 'ALL' or props.do_beauty)
    want_masks  = mode in ('MASKS', 'ALL') and (mode != 'ALL' or props.do_masks) and _wirecolor_ok()
    b_frames = _parse_frames(props.beauty_frames) if want_beauty else []
    m_src    = props.beauty_frames if props.masks_same_frames else props.mask_frames
    m_frames = _parse_frames(m_src) if want_masks else []
    mtype    = _mask_type(props)
    if mtype == 'CYC' and not _wc_cycles_ok():
        m_frames = []
    mtasks   = [t for t, on in (('OBJ', mtype in ('OBJ', 'BOTH', 'ALL')),
                                ('FACE', mtype in ('FACE', 'BOTH', 'ALL')),
                                ('MAT', mtype in ('MAT', 'ALL'))) if on]
    queue, cyc = [], []
    for f in sorted(set(b_frames) | set(m_frames)):
        if props.use_name_map and not _get_frame_name(props, f):
            continue   # немає імені в таблиці — пропускаємо
        if f in b_frames:
            queue.append((f, 'BEAUTY', _target_path(props, scene, f, 'BEAUTY')))
        if f in m_frames:
            for t in mtasks:
                queue.append((f, t, _target_path(props, scene, f, t)))
            if mtype == 'CYC':
                cyc.append((f, 'CYC', _target_path(props, scene, f, 'CYC')))
    return queue + cyc          # маски Cycles — одним фоновим проходом після всіх бьюті (одне завантаження сцени)


class CFRENDER_OT_render(Operator):
    bl_idname  = "cfrender.render"
    bl_label   = "Render"
    bl_options = {'REGISTER'}

    mode: EnumProperty(
        items=[('BEAUTY', "Beauty", ""), ('MASKS', "Masks", ""), ('ALL', "All", "")],
        default='ALL',
    )
    conflict_action: EnumProperty(
        name="Action",
        items=[
            ('VERSION', "Add Version  (_V01, _V02 ...)",       "Зберегти поруч з новою версією"),
            ('REPLACE', "Replace existing files",              "Перезаписати файли"),
            ('SKIP',    "Skip existing (render only missing)", "Рендерити тільки те, чого ще немає"),
        ],
        default='VERSION',
    )
    cyc_mode: EnumProperty(items=[('render', "Рендер", ""), ('stale', "Застарілі", ""), ('check', "Перевірити", "")],
                           default='render', options={'SKIP_SAVE'})
    _conflict_list = []

    @classmethod
    def description(cls, context, properties):
        return ("Рендер вибраних кадрів по черзі: кожен зберігається окремим файлом. "
                "Esc або ✕ — зупинити")

    def draw(self, context):
        layout = self.layout
        cls = self.__class__
        layout.label(text=f"{len(cls._conflict_list)} file(s) already exist:", icon='ERROR')
        col = layout.box().column(align=True)
        for p in cls._conflict_list[:7]:
            col.label(text=os.path.basename(p))
        if len(cls._conflict_list) > 7:
            col.label(text=f"... and {len(cls._conflict_list) - 7} more")
        layout.separator(factor=0.5)
        layout.prop(self, "conflict_action", expand=True)

    def invoke(self, context, event):
        global _queue
        if _is_rendering:
            self.report({'WARNING'}, "Render already running")
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        if self.mode in ('MASKS', 'ALL') and (self.mode == 'MASKS' or props.do_masks) and not _wirecolor_ok():
            self.report({'ERROR'}, "WireColor Masks addon not installed")
            return {'CANCELLED'}
        if self.cyc_mode != 'render':                     # 1.12.0: перевірка / застарілі — без діалогу, лише маски Cycles
            if _mask_type(props) != 'CYC':
                self.report({'ERROR'}, "Потрібен тип маски «Face+Obj Cycles» і WireColor 3.10+")
                return {'CANCELLED'}
            self.mode, self.conflict_action = 'MASKS', 'REPLACE'
        _queue = _build_queue(props, context.scene, self.mode)
        if not _queue:
            self.report({'ERROR'}, "No frames to render")
            return {'CANCELLED'}
        if self.cyc_mode != 'render':
            return self.execute(context)
        conflicts = [t for _f, _t, t in _queue if os.path.exists(t)]
        if conflicts:
            self.__class__._conflict_list = conflicts
            return context.window_manager.invoke_props_dialog(self, width=420, confirm_text="Render")
        return self.execute(context)

    def execute(self, context):
        global _is_rendering, _orig_frame, _orig_output, _total, _done_count, _skipped, _dpi
        global _orig_fstart, _orig_fend, _orig_fstep, _session_start_time, _next_render_at
        global _frame_times, _render_in_progress, _conflict_action, _queue, _orig_lock, _pending_save

        if _is_rendering:
            return {'CANCELLED'}
        props = context.scene.cfrender_props
        sc = context.scene
        if self.cyc_mode != 'render':
            self.mode, self.conflict_action = 'MASKS', 'REPLACE'
        if not _queue:      # виклик без invoke (скрипт)
            _queue = _build_queue(props, sc, self.mode)
        _conflict_action = self.conflict_action
        _CYC["mode"] = self.cyc_mode
        _skipped = 0
        if _conflict_action == 'SKIP':
            before = len(_queue)
            _queue = [q for q in _queue if not os.path.exists(q[2])]
            _skipped = before - len(_queue)
        if not _queue:
            props.render_status = f"All done already (skipped {_skipped})"
            return {'FINISHED'}

        _is_rendering   = True
        _orig_frame     = sc.frame_current
        _orig_fstart    = sc.frame_start
        _orig_fend      = sc.frame_end
        _orig_fstep     = sc.frame_step
        _orig_output    = sc.render.filepath
        _dpi            = props.dpi
        _total              = len(_queue)
        _done_count         = 0
        _session_start_time = time.time()
        _next_render_at     = 0.0
        _frame_times        = []
        _render_in_progress = False
        _pending_save       = ''
        # Lock Interface — за бажанням (галочка Lock UI): UI не чіпає дані сцени під час рендеру
        _orig_lock = sc.render.use_lock_interface
        if props.lock_ui:
            sc.render.use_lock_interface = True

        props.is_rendering  = True
        props.render_status = f"Starting... (0/{_total})"
        bpy.app.timers.register(_run_next, first_interval=0.1)
        if not bpy.app.timers.is_registered(_poll_render):
            bpy.app.timers.register(_poll_render, first_interval=0.2)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATOR — Stop
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_OT_clear_status(Operator):
    bl_idname      = "cfrender.clear_status"
    bl_label       = "Clear Status"
    bl_description = "Прибрати рядок статусу"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        props = context.scene.cfrender_props
        props.render_status = ""
        if not _is_rendering:
            props.is_rendering = False
        return {'FINISHED'}


class CFRENDER_OT_stop(Operator):
    bl_idname      = "cfrender.stop"
    bl_label       = "Stop Render"
    bl_description = "Зупинити чергу рендеру і повернути сцену як було"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        _queue.clear()
        _MQ["items"] = []                                # 1.8.0: зупинити й чергу таблиць
        if _CYC["active"]:                               # 1.12.0: фоновий Blender масок
            _CYC["active"] = False
            try:
                bpy.ops.wirecolor.cycles_masks_stop()
            except Exception:
                pass
        try:
            bpy.ops.render.view_cancel()
        except Exception:
            pass
        _finish(context.scene, stopped=True)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class CFRENDER_PT_panel(Panel):
    bl_label       = "Custom Frame Render"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "CFRender"

    def draw_header_preset(self, context):
        self.layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        props  = scene.cfrender_props
        wc_ok  = _wirecolor_ok()

        # ── STATUS ────────────────────────────────────────────
        if props.is_rendering or props.render_status:
            box = layout.box()
            row = box.row(align=True)
            row.alert = props.is_rendering
            row.label(text=props.render_status, icon='RENDER_STILL')
            if props.is_rendering:
                row.operator("cfrender.stop", text="", icon='CANCEL')
            else:
                row.operator("cfrender.clear_status", text="", icon='X')

        # ── NAME MAP: посилання + таблиця імен (вручну або з Google Sheets) ──
        box = layout.box()
        box.prop(props, "use_name_map", text="Name Map")
        row = box.row(align=True)
        row.prop(props, "sheets_url", text="", icon='URL')
        row.operator("cfrender.import_sheets", text="", icon='FILE_REFRESH')
        if _shot_list_ok(scene):
            box.operator("cfrender.from_shot_list", icon='SEQUENCE')
        col = box.column()
        col.active = props.use_name_map      # сіре, але редагується; Save вмикає Name Map
        col.template_list("CFRENDER_UL_namemap", "", props, "name_map",
                          props, "name_map_index", rows=5)
        sub = col.column(align=True)
        row = sub.row(align=True)
        row.prop(props, "new_nm_frame", text="Fr")
        row.prop(props, "new_nm_name",  text="Name")
        row = sub.row(align=True)
        row.operator("cfrender.nm_add",    text="Save",   icon='FILE_TICK')
        row.operator("cfrender.nm_remove", text="Remove", icon='TRASH')
        row.operator("cfrender.nm_clear",  text="", icon='X')

        # ── FRAME PRESETS ─────────────────────────────────────
        header, box = layout.panel("cfrender_presets", default_closed=True)
        header.label(text="Frame Presets", icon='PRESET')
        if box:
            self._draw_presets(box, props)

        self._draw_render(layout, props, wc_ok)

    def _draw_presets(self, box, props):
        box.template_list("CFRENDER_UL_presets", "", props, "presets",
                          props, "preset_index", rows=3)
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "preset_name", text="Name")
        row.prop(props, "preset_frames", text="Frames")
        row = col.row(align=True)
        row.operator("cfrender.preset_save", text="Save", icon='FILE_TICK')
        row.operator("cfrender.preset_remove", text="", icon='TRASH')
        row = col.row(align=True)
        row.operator("cfrender.preset_apply", text="→ Beauty", icon='RENDER_STILL').target = 'BEAUTY'
        row.operator("cfrender.preset_apply", text="→ Mask",   icon='IMAGE_DATA').target = 'MASK'

    def _draw_render(self, layout, props, wc_ok):
        # ── 1.8.0: ЧЕРГА ТАБЛИЦЬ ──────────────────────────────
        header, qb = layout.panel("cfrender_sheet_queue", default_closed=not len(props.sheet_queue))
        header.label(text=f"Черга таблиць ({sum(1 for x in props.sheet_queue if x.use)}/{len(props.sheet_queue)})",
                     icon='SEQUENCE')
        if qb:
            col = qb.column(align=True)
            order = {it.as_pointer(): n for n, it in enumerate(_queue_ordered(props), 1)}
            for it in props.sheet_queue:
                row = col.row(align=True)
                row.prop(it, "use", text=it.name or it.url[-30:])
                n = order.get(it.as_pointer())
                if n:                                    # 1.11.0: номер у черзі (синій, підказка при наведенні)
                    sub = row.row(align=True); sub.ui_units_x = 1.6
                    op = sub.operator("cfrender.queue_num", text=str(n), depress=True)
                    op.n = n; op.total = len(order)
            row = qb.row(align=True)
            row.operator("cfrender.sheet_queue_add", text="+ поточна", icon='ADD')
            row.operator("cfrender.sheet_queue_clear", text="", icon='TRASH')
            row = qb.row()
            row.scale_y = 1.4
            row.enabled = not props.is_rendering and any(x.use for x in props.sheet_queue)
            row.operator("cfrender.sheet_queue", text="Render queue", icon='RENDER_ANIMATION')
        # ── RENDER ────────────────────────────────────────────
        box = layout.box()
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "do_beauty", text="Beauty", toggle=True, icon='RENDER_STILL')
        sub = row.row(align=True)
        sub.enabled = wc_ok
        sub.prop(props, "do_masks", text="Masks", toggle=True, icon='IMAGE_DATA')
        col.prop(props, "beauty_frames", text="Frames")
        if props.do_masks:
            mb = box.column(align=True)
            if not wc_ok:
                mb.label(text="WireColor Masks not found", icon='ERROR')
            if not _wc_cycles_ok():                    # 1.13.0: тип/краї не вибираються — лише старий WireColor
                mb.prop(props, "mask_type", text="")
            if _mask_type(props) == 'CYC':
                if not _wc_cycles_ok():
                    mb.label(text="Потрібен WireColor 3.10+ (онови в хабі)", icon='ERROR')
                else:
                    nq = sum(1 for x in props.sheet_queue if x.use and x.url.strip())
                    op_id = "cfrender.sheet_queue" if nq else "cfrender.render"
                    r2 = mb.row(align=True)
                    r2.enabled = not props.is_rendering
                    a = r2.operator(op_id, text="Перевірити", icon='VIEWZOOM')
                    a.cyc_mode = 'check'
                    b = r2.operator(op_id, text="Перерахувати застарілі", icon='FILE_REFRESH')
                    b.cyc_mode = 'stale'
                    if op_id == "cfrender.render":
                        a.mode = b.mode = 'MASKS'
                    mb.label(text=(f"по черзі таблиць ({nq})" if nq else "по кадрах масок нижче"), icon='INFO')
            mb.prop(props, "masks_same_frames")
            if not props.masks_same_frames:
                mb.prop(props, "mask_frames", text="Mask Frames")
        box.prop(props, "lock_ui", icon='LOCKED' if props.lock_ui else 'UNLOCKED')
        row = box.row()
        row.scale_y = 1.5
        row.enabled = not props.is_rendering and (props.do_beauty or (props.do_masks and wc_ok))
        row.operator("cfrender.render", text="Render", icon='RENDER_ANIMATION').mode = 'ALL'

        # ── OUTPUT ────────────────────────────────────────────
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "use_custom_output")
        if props.use_custom_output:
            col.prop(props, "output_path", text="")
        col.prop(props, "dpi")
        row = col.row(align=True)                # 1.9.0: зменшена копія для раундів правок
        row.prop(props, "copy_2k", icon='IMAGE_DATA')
        sub = row.row(align=True); sub.enabled = props.copy_2k
        sub.prop(props, "size_2k", text="")


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    CFRenderNameEntry,
    CFRenderSheetItem,
    CFRenderPreset,
    CFRenderProps,
    CFRENDER_UL_presets,
    CFRENDER_UL_namemap,
    CFRENDER_OT_preset_save,
    CFRENDER_OT_preset_remove,
    CFRENDER_OT_preset_apply,
    CFRENDER_OT_from_shot_list,
    CFRENDER_OT_import_sheets,
    CFRENDER_OT_sheet_queue,
    CFRENDER_OT_queue_num,
    CFRENDER_OT_sheet_queue_add,
    CFRENDER_OT_sheet_queue_clear,
    CFRENDER_OT_nm_add,
    CFRENDER_OT_nm_remove,
    CFRENDER_OT_nm_clear,
    CFRENDER_OT_render,
    CFRENDER_OT_clear_status,
    CFRENDER_OT_stop,
    CFRENDER_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cfrender_props = PointerProperty(type=CFRenderProps)
    if _cfrender_complete not in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.append(_cfrender_complete)
    if _cfrender_cancel not in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.append(_cfrender_cancel)


def unregister():
    if _cfrender_complete in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(_cfrender_complete)
    if _cfrender_cancel in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(_cfrender_cancel)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.cfrender_props


if __name__ == "__main__":
    register()
