# 1.39.0: «Надіслати сцену Євгену» — копія відкритої сцени (+ змінені бітмапи) у папку на Google Drive Євгена.
# Транспорт: Apps Script Євгена (Code.gs) створює папку і видає посилання resumable-upload; байти йдуть напряму
# в Google Drive шматками по 16 МБ (докачка після обриву). У колеги нічого ставити/логінитись не треба.
import bpy
import os
import json
import time
import threading
import tempfile
import http.client
import urllib.parse
import urllib.request

URL = ""            # Web app URL Apps Script (Deploy → Web app). Порожньо → кнопка неактивна
KEY = "9OlZ8yx_iCj07Fu9Y1HD6ImF"
CHUNK = 16 * 1024 * 1024        # кратне 256 КБ (вимога Drive)
RECENT_DAYS = 7                 # бітмапи, змінені за останні N днів, позначаються одразу
_IMG_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".exr", ".hdr", ".tga", ".bmp", ".webp", ".psd"}

_JOB = {"running": False, "stage": "", "done": 0, "total": 0, "file_i": 0, "file_n": 0,
        "error": "", "ok": "", "cancel": False}


# ---------------- мережа ----------------
def _call(payload):
    data = json.dumps(dict(payload, key=KEY)).encode("utf-8")
    req = urllib.request.Request(URL, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:      # Apps Script відповідає 302 → urllib сам іде GET-ом
        res = json.loads(r.read().decode("utf-8"))
    if not res.get("ok"):
        raise RuntimeError("приймач: " + str(res.get("error")))
    return res


def _conn(netloc):
    return http.client.HTTPSConnection(netloc, timeout=180)


def _status(conn, path_q, total):
    """Скільки байтів Drive уже має (після обриву). None = файл уже готовий."""
    conn.request("PUT", path_q, body=b"", headers={"Content-Length": "0", "Content-Range": f"bytes */{total}"})
    r = conn.getresponse()
    r.read()
    if r.status in (200, 201):
        return None
    if r.status == 308:
        rng = r.getheader("Range")
        return int(rng.split("-")[1]) + 1 if rng else 0
    raise RuntimeError(f"Drive: статус {r.status}")


def _upload(upload_url, path, total, base_done):
    u = urllib.parse.urlsplit(upload_url)
    path_q = u.path + ("?" + u.query if u.query else "")
    conn = _conn(u.netloc)
    pos, fails = 0, 0
    with open(path, "rb") as f:
        while pos < total:
            if _JOB["cancel"]:
                raise RuntimeError("скасовано")
            f.seek(pos)
            data = f.read(CHUNK)
            end = pos + len(data) - 1
            try:
                conn.request("PUT", path_q, body=data,
                             headers={"Content-Length": str(len(data)), "Content-Range": f"bytes {pos}-{end}/{total}"})
                r = conn.getresponse()
                body = r.read()
                if r.status in (200, 201):
                    pos = total
                elif r.status == 308:
                    rng = r.getheader("Range")
                    pos = int(rng.split("-")[1]) + 1 if rng else 0
                elif r.status in (429, 500, 502, 503, 504):
                    raise ConnectionError(f"HTTP {r.status}")
                else:
                    raise RuntimeError(f"Drive: HTTP {r.status} {body[:200]!r}")
                fails = 0
            except (OSError, http.client.HTTPException, ConnectionError) as e:
                fails += 1
                if fails > 8:
                    raise RuntimeError(f"зв'язок обривається: {e}")
                time.sleep(min(60, 2 ** fails))
                conn.close()
                conn = _conn(u.netloc)
                try:
                    st = _status(conn, path_q, total)
                    pos = total if st is None else st
                except Exception:
                    pass                                     # спробуємо той самий шматок ще раз
            _JOB["done"] = base_done + pos
    conn.close()


def _worker(files, folder_name, use_tex, note):
    try:
        _JOB["stage"] = "створюю папку"
        fo = _call({"action": "folder", "name": folder_name, "textures": bool(use_tex)})
        _JOB["total"] = sum(s for _, _, s, _ in files)
        done = 0
        for i, (path, name, size, is_tex) in enumerate(files):
            _JOB["file_i"], _JOB["stage"] = i + 1, name
            parent = fo["textures"] if is_tex else fo["folder"]
            ses = _call({"action": "session", "parent": parent, "name": name, "size": size})
            _upload(ses["upload"], path, size, done)
            done += size
        _call({"action": "note", "parent": fo["folder"], "text": note})
        _JOB["ok"] = folder_name
    except Exception as e:
        _JOB["error"] = str(e)[:300]
    finally:
        _JOB["running"] = False
        tmp = files[0][0] if files else ""
        if tmp.startswith(_tmp_dir()):
            try:
                os.remove(tmp)
            except OSError:
                pass


def _tmp_dir():
    return os.path.join(tempfile.gettempdir(), "hrb_send_scene")


def _redraw():
    wm = bpy.context.window_manager
    for w in (wm.windows if wm else []):
        for a in w.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()
    return 0.5 if _JOB["running"] else None


# ---------------- список бітмап ----------------
class THUMA_SendItem(bpy.types.PropertyGroup):
    path: bpy.props.StringProperty()
    label: bpy.props.StringProperty()
    use: bpy.props.BoolProperty(name="Надіслати", default=False,
                                description="Надіслати цей файл у папку textures")


class THUMA_UL_send(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        r = layout.row(align=True)
        r.prop(item, "use", text="")
        r.label(text=item.label, icon='IMAGE_DATA')


def _fill_images(wm):
    wm.thuma_send_items.clear()
    seen, now = set(), time.time()
    rows = []
    for img in bpy.data.images:
        if img.source not in {'FILE', 'SEQUENCE'} or img.packed_file or not img.filepath:
            continue
        p = os.path.normpath(bpy.path.abspath(img.filepath, library=img.library))
        if p.lower() in seen or "<UDIM>" in p or not os.path.isfile(p):
            continue
        seen.add(p.lower())
        mt = os.path.getmtime(p)
        days = int((now - mt) // 86400)
        lab = f"{os.path.basename(p)}  ·  {'сьогодні' if days == 0 else f'{days} дн. тому'}"
        if img.is_dirty:
            lab += "  ·  ЗМІНЕНО В BLENDER, НЕ ЗБЕРЕЖЕНО"
        rows.append((not (img.is_dirty or now - mt < RECENT_DAYS * 86400), -mt, p, lab))
    for unchecked, _, p, lab in sorted(rows):
        it = wm.thuma_send_items.add()
        it.path, it.label, it.use = p, lab, not unchecked


# ---------------- оператори ----------------
def _safe(s):
    return "".join("_" if ch in '\\/:*?"<>|' else ch for ch in s).strip() or "scene"


class THUMA_OT_send_scene(bpy.types.Operator):
    bl_idname = "thuma.send_scene"
    bl_label = "Надіслати сцену Євгену"
    bl_description = ("Копія цієї сцени (як є зараз, навіть незбережена) летить Євгену на Google Drive. "
                      "Спитає назву і чи змінювались текстури. Твій файл не змінюється")

    @classmethod
    def poll(cls, context):
        return bool(URL) and not _JOB["running"]

    def invoke(self, context, event):
        wm = context.window_manager
        stem = os.path.splitext(os.path.basename(bpy.data.filepath))[0] or "scene"
        wm.thuma_send_name = stem
        wm.thuma_send_note = ""
        wm.thuma_send_tex = False
        _JOB["ok"] = _JOB["error"] = ""
        return wm.invoke_props_dialog(self, width=420, title="Надіслати сцену Євгену", confirm_text="Далі")

    def draw(self, context):
        wm = context.window_manager
        c = self.layout.column()
        c.label(text="Напиши назву:")
        c.prop(wm, "thuma_send_name", text="")
        c.prop(wm, "thuma_send_note", text="Що змінив")
        c.separator()
        c.prop(wm, "thuma_send_tex", text="Я змінював самі текстури (бітмапи)")

    def execute(self, context):
        wm = context.window_manager
        if not wm.thuma_send_name.strip():
            self.report({'WARNING'}, "Напиши назву")
            return {'CANCELLED'}
        if wm.thuma_send_tex:
            _fill_images(wm)
            return bpy.ops.thuma.send_scene_tex('INVOKE_DEFAULT')
        return _start(self, context, [])


class THUMA_OT_send_scene_tex(bpy.types.Operator):
    bl_idname = "thuma.send_scene_tex"
    bl_label = "Які текстури змінювались"
    bl_description = "Познач змінені бітмапи або додай свої файли — вони ляжуть у папку textures поруч зі сценою"
    idx: bpy.props.IntProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=560, title="Які текстури змінювались?",
                                                          confirm_text="Надіслати")

    def draw(self, context):
        wm = context.window_manager
        c = self.layout.column()
        n = sum(1 for it in wm.thuma_send_items if it.use)
        c.label(text=f"Позначені летять у textures/ ({n}). Одразу позначені — змінені за {RECENT_DAYS} днів",
                icon='INFO')
        c.template_list("THUMA_UL_send", "", wm, "thuma_send_items", self, "idx", rows=10)
        c.operator("thuma.send_scene_add", text="Додати файли з диска…", icon='FILEBROWSER')

    def execute(self, context):
        files = [it.path for it in context.window_manager.thuma_send_items if it.use]
        return _start(self, context, files)


class THUMA_OT_send_scene_add(bpy.types.Operator):
    bl_idname = "thuma.send_scene_add"
    bl_label = "Додати файли"
    bl_description = "Вибрати бітмапи на диску (можна кілька) — додадуться в список позначеними"
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    filter_image: bpy.props.BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_folder: bpy.props.BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        wm = context.window_manager
        have = {os.path.normcase(it.path): it for it in wm.thuma_send_items}
        for f in self.files:
            p = os.path.normpath(os.path.join(self.directory, f.name))
            if not os.path.isfile(p):
                continue
            it = have.get(os.path.normcase(p))
            if it is None:
                it = wm.thuma_send_items.add()
                it.path, it.label = p, os.path.basename(p) + "  ·  додано вручну"
            it.use = True
        bpy.ops.thuma.send_scene_tex('INVOKE_DEFAULT')
        return {'FINISHED'}


class THUMA_OT_send_scene_cancel(bpy.types.Operator):
    bl_idname = "thuma.send_scene_cancel"
    bl_label = "Скасувати надсилання"
    bl_description = "Зупинити надсилання (у Євгена лишиться неповна папка)"

    def execute(self, context):
        _JOB["cancel"] = True
        return {'FINISHED'}


def _start(op, context, tex_paths):
    if not getattr(bpy.app, "online_access", True):
        op.report({'ERROR'}, "Увімкни Edit › Preferences › System › Allow Online Access")
        return {'CANCELLED'}
    wm = context.window_manager
    name = _safe(wm.thuma_send_name)
    os.makedirs(_tmp_dir(), exist_ok=True)
    tmp = os.path.join(_tmp_dir(), name + ".blend")
    context.window.cursor_set('WAIT')
    try:
        bpy.ops.wm.save_as_mainfile(filepath=tmp, copy=True, compress=True)    # копія; відкритий файл не чіпаємо
    finally:
        context.window.cursor_set('DEFAULT')
    files = [(tmp, name + ".blend", os.path.getsize(tmp), False)]
    used = set()
    for p in tex_paths:
        b = os.path.basename(p)
        stem, ext = os.path.splitext(b)
        k = 2
        while b.lower() in used:                        # однакові імена з різних папок
            b = f"{stem}_{k}{ext}"
            k += 1
        used.add(b.lower())
        if os.path.getsize(p) > 0:
            files.append((p, b, os.path.getsize(p), True))
    from . import ADDON_VERSION
    who = os.environ.get("USERNAME", "?")
    pc = os.environ.get("COMPUTERNAME", "?")
    stamp = time.strftime("%Y-%m-%d %H-%M")
    folder = f"{name} — {who} {stamp}"
    lines = [f"Від: {who} (ПК {pc})", f"Коли: {stamp}", f"Файл у нього: {bpy.data.filepath or '(не збережений)'}",
             f"Blender {bpy.app.version_string}, пульт {'.'.join(map(str, ADDON_VERSION))}",
             f"Що змінив: {wm.thuma_send_note or '—'}",
             f"Текстури змінювались: {'так' if tex_paths else 'ні'}"]
    if len(files) > 1:
        lines.append(f"textures/ ({len(files) - 1}) — файл  ←  де лежав у нього:")
        lines += [f"  {n}  ←  {p}" for p, n, _, t in files if t]
    _JOB.update(running=True, cancel=False, error="", ok="", done=0, total=sum(f[2] for f in files),
                file_i=0, file_n=len(files), stage="старт")
    threading.Thread(target=_worker, args=(files, folder, bool(tex_paths), "\n".join(lines)), daemon=True).start()
    bpy.app.timers.register(_redraw, first_interval=0.5)
    op.report({'INFO'}, f"Надсилаю «{name}» Євгену…")
    return {'FINISHED'}


# ---------------- панель ----------------
def draw(layout):
    """Рядок у пульті: кнопка або прогрес / підсумок."""
    if not URL and not _JOB["running"]:       # 1.40.0: поки нема Web app URL — кнопку не показуємо
        return
    if _JOB["running"]:
        mb = 1024 * 1024
        pct = int(100 * _JOB["done"] / _JOB["total"]) if _JOB["total"] else 0
        r = layout.row(align=True)
        r.progress(factor=pct / 100, type='BAR',
                   text=f"Надсилаю {pct}% · {_JOB['done'] // mb}/{_JOB['total'] // mb} МБ · "
                        f"файл {_JOB['file_i']}/{_JOB['file_n']}")
        r.operator("thuma.send_scene_cancel", text="", icon='X')
        return
    r = layout.row(align=True)
    r.operator("thuma.send_scene", text="Надіслати сцену Євгену" if URL else "Надіслати сцену (ще не налаштовано)",
               icon='EXPORT')
    if _JOB["ok"]:
        layout.label(text=f"Надіслано: {_JOB['ok']}", icon='CHECKMARK')
    elif _JOB["error"]:
        layout.label(text=f"Не вдалося: {_JOB['error']}", icon='ERROR')


_CLASSES = (THUMA_SendItem, THUMA_UL_send, THUMA_OT_send_scene, THUMA_OT_send_scene_tex, THUMA_OT_send_scene_add,
            THUMA_OT_send_scene_cancel)


def register():
    for c in _CLASSES:
        bpy.utils.register_class(c)
    wm = bpy.types.WindowManager
    wm.thuma_send_items = bpy.props.CollectionProperty(type=THUMA_SendItem)
    wm.thuma_send_name = bpy.props.StringProperty(name="Назва", description="Як назвати сцену в папці Євгена")
    wm.thuma_send_note = bpy.props.StringProperty(name="Що змінив",
                                                  description="Коротко: що правив (необов'язково)")
    wm.thuma_send_tex = bpy.props.BoolProperty(
        name="Змінював текстури",
        description="Якщо правив самі картинки текстур (не повзунки) — наступним кроком позначиш їх, "
                    "і вони ляжуть у папку textures поруч зі сценою")


def unregister():
    _JOB["cancel"] = True
    wm = bpy.types.WindowManager
    for p in ("thuma_send_items", "thuma_send_name", "thuma_send_note", "thuma_send_tex"):
        if hasattr(wm, p):
            delattr(wm, p)
    for c in reversed(_CLASSES):
        bpy.utils.unregister_class(c)
