"""fz7_exp: які бічні сторони модуля ВІЛЬНІ в його конфігурації (не впираються в сусідній модуль).
Властивість об'єкта оббивки ob["fz7_exp"] = [+X, -X, +Y, -Y] у координатах об'єкта (1 = вільна, 0 = стик).
Шейдер FABRIC LOOK v7.2 бере «перехід» зовнішніх зон лише від вільних сторін (інакше від схованих у стику
боків модуля йшли смуги на фронт біля кожного стику). Конфігурація = дочірня колекція «Product».
Перезапускати, якщо переставили модулі.
"""
import bpy
from mathutils import Vector

GAP = 0.06          # м: сусід ближче за це до сторони = стик
OVERLAP = 0.15      # м: мінімальне перекриття вздовж сторони
AHEAD = 0.05        # м: FL76, сусід виступає вперед більше за це = стіна біля фасаду


def upholstery(objs):
    return [o for o in objs if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2]


def run():
    prod = bpy.data.collections.get("Product")
    sc = bpy.context.scene
    cur = sc.frame_current
    # кадр, де конфігурація видима (положення модулів задають Control-об'єкти -> рахуємо після frame_set)
    first = {}
    for f in range(min([sc.frame_start] + [m.frame for m in sc.timeline_markers]), max([sc.frame_end] + [m.frame for m in sc.timeline_markers]) + 1):      # FL71: + маркери (діапазон рендера буває 1..1)
        sc.frame_set(f)
        for o in upholstery(sc.objects):
            if o.name not in first and o.visible_get():
                first[o.name] = f
    out = {}
    for cfg in (prod.children if prod else []):
        obs = upholstery(cfg.all_objects)
        fr = [first[o.name] for o in obs if o.name in first]
        if not fr:
            continue
        sc.frame_set(min(fr))
        dg = bpy.context.evaluated_depsgraph_get()
        MW = {o.name: o.evaluated_get(dg).matrix_world.copy() for o in obs}
        for o in obs:
            inv = MW[o.name].inverted()
            bb = [Vector(c) for c in o.bound_box]
            mn = Vector((min(c.x for c in bb), min(c.y for c in bb), min(c.z for c in bb)))
            mx = Vector((max(c.x for c in bb), max(c.y for c in bb), max(c.z for c in bb)))
            exp = [1.0, 1.0, 1.0, 1.0]
            # v7.48: ДЕ саме сторона торкається сусіда (відрізок уздовж сторони) — бік шезлонга торкається лише ззаду
            NO = (9.0, -9.0)
            ct = {0: NO, 1: NO, 2: NO, 3: NO}
            ahead = [0.0, 0.0, 0.0, 0.0]            # FL76: fz7_ahead, де сусід стоїть попереду фасаду (підсвітка стику там гасне)

            def add(k, a, b):
                c0, c1 = ct[k]
                ct[k] = (min(c0, a), max(c1, b))
            for n in obs:
                if n is o:
                    continue
                pts = [inv @ (MW[n.name] @ Vector(c)) for c in n.bound_box]
                nmn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
                nmx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
                if min(mx.z, nmx.z) - max(mn.z, nmn.z) < 0.05:
                    continue
                ovy = min(mx.y, nmx.y) - max(mn.y, nmn.y)
                ovx = min(mx.x, nmx.x) - max(mn.x, nmn.x)
                # FL76: ±X — сусід збоку виступає вперед (-Y) і доходить до площини фасаду
                if nmn.y < mn.y - AHEAD and nmx.y > mn.y - GAP:
                    if abs(nmn.x - mx.x) < GAP or (nmn.x < mx.x + GAP and nmx.x > mx.x):
                        ahead[0] = 1.0
                    if abs(nmx.x - mn.x) < GAP or (nmx.x > mn.x - GAP and nmn.x < mn.x):
                        ahead[1] = 1.0
                # FL76: -Y — повернутий модуль стоїть цією стороною до сусіда, ширшого по X
                if ovx > OVERLAP and (nmn.x < mn.x - AHEAD or nmx.x > mx.x + AHEAD):
                    if abs(nmx.y - mn.y) < GAP or (nmx.y > mn.y - GAP and nmn.y < mn.y):
                        ahead[3] = 1.0
                if ovy > OVERLAP:
                    ya, yb = max(mn.y, nmn.y), min(mx.y, nmx.y)
                    if abs(nmn.x - mx.x) < GAP or (nmn.x < mx.x + GAP and nmx.x > mx.x):
                        exp[0] = 0.0; add(0, ya, yb)
                    if abs(nmx.x - mn.x) < GAP or (nmx.x > mn.x - GAP and nmn.x < mn.x):
                        exp[1] = 0.0; add(1, ya, yb)
                if ovx > OVERLAP:
                    xa, xb = max(mn.x, nmn.x), min(mx.x, nmx.x)
                    if abs(nmn.y - mx.y) < GAP or (nmn.y < mx.y + GAP and nmx.y > mx.y):
                        exp[2] = 0.0; add(2, xa, xb)
                    if abs(nmx.y - mn.y) < GAP or (nmx.y > mn.y - GAP and nmn.y < mn.y):
                        exp[3] = 0.0; add(3, xa, xb)
            o["fz7_exp"] = exp
            o["fz7_ahead"] = ahead
            o["fz7_cx"] = [*ct[0], *ct[1]]          # +X: y від..до, -X: y від..до (9,-9 = нема стику)
            o["fz7_cy"] = [*ct[2], *ct[3]]          # +Y: x від..до, -Y: x від..до
            out[o.name] = exp
        # v7.7: габарити всієї збірки В КООРДИНАТАХ КОЖНОГО МОДУЛЯ (не залежить від повороту/зсуву кадру 3/4)
        for o in obs:
            inv = MW[o.name].inverted()
            pts = [inv @ (MW[n.name] @ Vector(c)) for n in obs for c in n.bound_box]
            o["fz7_asm"] = [min(p.x for p in pts), max(p.x for p in pts), min(p.y for p in pts), max(p.y for p in pts)]
    sc.frame_set(cur)
    return out


if __name__ == "__main__":
    r = run()
    print("FZ7EXP", len(r))
