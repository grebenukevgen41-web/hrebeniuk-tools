"""FABRIC LOOK v4 — розмітка оббивки ПО ГРАНЯХ (FACE, без згладжування -> маски не розмазуються).

Атрибути (FACE, FLOAT 0/1), локальні координати меша:
  fz4_top    — верх спинки й підлокітників
  fz4_seat   — верх сидіння / пуфа
  fz4_inner  — внутрішні вертикальні грані: подушки спинки з боку сидіння, внутрішні боки підлокітників,
               друга спинка кутового, складки між сидінням і спинкою/підлокітником (усе всередині контуру модуля)
  fz4_bb     — блок спинки/підлокітника вище сидіння
  fz4_ldx/ldy — локальний напрям ДЕТАЛІ для внутрішніх граней (спинка = (0,-1), лівий підлокітник = (+1,0)…):
               скруглення й складки беруть напрям своєї деталі, а не своєї нормалі
  fz4_jin    — грань блоку, що дивиться в бік сидіння (стик між модулями тут = продовження внутрішньої грані)
Решта граней = зовнішні (фронт / боки / зад / стики) — їх напрям рахує шейдер відносно всієї збірки.
"""
import bpy

BLOCK = 0.27      # глибина спинки / ширина підлокітника + запас (виміряно 0.24)
HULL = 0.035      # грань ближче за 3.5 см до габариту модуля = зовнішній контур
NAMES = ["fz4_top", "fz4_seat", "fz4_inner", "fz4_bb", "fz4_jin", "fz4_ldx", "fz4_ldy"]


def upholstery_meshes():
    return sorted({o.data for o in bpy.data.objects
                   if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2},
                  key=lambda m: m.name)


def classify(me):
    vs = me.vertices
    xmin = min(v.co.x for v in vs); xmax = max(v.co.x for v in vs)
    ymin = min(v.co.y for v in vs); ymax = max(v.co.y for v in vs)
    zmin = min(v.co.z for v in vs)
    high = [v.co for v in vs if v.co.z - zmin > 0.5]
    front_high = [c for c in high if c.y < ymax - BLOCK - 0.05]
    left_block = any(c.x < xmin + BLOCK for c in front_high)
    right_block = any(c.x > xmax - BLOCK for c in front_high)
    has_back = any(c.y > ymax - BLOCK for c in high)
    # центр сидіння (центроїд граней сидіння) — внутрішні грані дивляться на нього
    sx = sy = sw = 0.0
    for p in me.polygons:
        if p.normal.z > 0.55 and 0.2 < p.center.z - zmin <= 0.46:
            sx += p.center.x * p.area; sy += p.center.y * p.area; sw += p.area
    scx, scy = (sx / sw, sy / sw) if sw else (0.0, 0.0)

    n_f = len(me.polygons)
    out = {k: [0.0] * n_f for k in NAMES}
    for i, p in enumerate(me.polygons):
        n, c = p.normal, p.center
        zr = c.z - zmin
        hull = (c.x < xmin + HULL or c.x > xmax - HULL or c.y < ymin + HULL or c.y > ymax - HULL)
        in_back = has_back and c.y > ymax - BLOCK
        in_left = left_block and c.x < xmin + BLOCK
        in_right = right_block and c.x > xmax - BLOCK
        out["fz4_bb"][i] = 1.0 if (in_back or in_left or in_right) and zr > 0.24 else 0.0
        # бік блоку спинки/підлокітника з боку сидіння (для стиків: це продовження внутрішньої грані)
        if out["fz4_bb"][i]:
            if in_back and not (in_left or in_right):
                toward = n.y < 0.0                           # спинка: бік сидіння = її перед (-Y)
            else:
                toward = n.x * (1.0 if c.x < (xmin + xmax) / 2 else -1.0) > 0.0   # підлокітник: до центру
            if toward:
                out["fz4_jin"][i] = 1.0
        if n.z > 0.55:
            if zr > 0.46:
                out["fz4_top"][i] = 1.0
            elif zr > 0.2:
                out["fz4_seat"][i] = 1.0
            continue
        if n.z < -0.3 or zr < 0.2:
            continue                               # низ / основа -> зовнішні
        cx_side = 1.0 if c.x < (xmin + xmax) / 2 else -1.0      # напрям до центру модуля по X
        # перетин блоків спинки й підлокітника: що дивиться вперед — спинка, вбок — підлокітник
        back_wins = in_back and (in_left or in_right) and -n.y > abs(n.x)
        if zr > 0.24 and in_back and (not (in_left or in_right) or back_wins):
            if n.y < -0.2:                         # блок спинки: усе, що дивиться в бік сидіння
                out["fz4_inner"][i] = 1.0
                out["fz4_ldy"][i] = -1.0
            continue
        if zr > 0.24 and (in_left or in_right):
            if n.x * cx_side > 0.2 or (n.y < -0.2 and c.y > ymax - BLOCK):
                out["fz4_inner"][i] = 1.0          # блок підлокітника / 2-ї спинки кутового: до центру
                out["fz4_ldx"][i] = cx_side
            continue
        if hull:
            continue                               # зовнішній контур -> зовнішні
        dx, dy = scx - c.x, scy - c.y
        d = (dx * dx + dy * dy) ** 0.5 or 1.0
        nl = (n.x * n.x + n.y * n.y) ** 0.5 or 1.0
        if (n.x * dx + n.y * dy) / (d * nl) > 0.2:
            out["fz4_inner"][i] = 1.0              # дивиться на сидіння = внутрішня (складки біля сидіння)
            M = 0.1                                # складка біля деталі бере її напрям
            if left_block and c.x < xmin + BLOCK + M:
                out["fz4_ldx"][i] = 1.0
            elif right_block and c.x > xmax - BLOCK - M:
                out["fz4_ldx"][i] = -1.0
            elif has_back and c.y > ymax - BLOCK - M:
                out["fz4_ldy"][i] = -1.0
    for k in NAMES:
        old = me.attributes.get(k)
        if old and old.domain != 'FACE':
            me.attributes.remove(old)
            old = None
        at = old or me.attributes.new(k, 'FLOAT', 'FACE')
        at.data.foreach_set("value", out[k])
    return {"faces": n_f, "seat_c": [round(scx, 3), round(scy, 3)], "L": left_block, "R": right_block,
            "share": {k: round(sum(out[k]) / n_f, 3) for k in NAMES}}


def run():
    return {me.name: classify(me) for me in upholstery_meshes()}
