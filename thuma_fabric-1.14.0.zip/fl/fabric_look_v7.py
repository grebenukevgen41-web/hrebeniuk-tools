"""FABRIC LOOK v7 — + «<зона>: перехід» (см): правка зони плавно заходить на сусідні деталі; зони змішуються
зваженим середнім (при всіх переходах 0 = як v6). Відстані до панелей — fabric_zones7 (атрибути вершин fz7_d*).
FABRIC LOOK v6 — тип зони цілою ПАНЕЛЛЮ тканини (UV-острів), межа = шов; напрями плавно.
Було v5 — маски неперервні в шейдері (fabric_zones5: у меші лише розміри модуля).
Було v4 — зони по гранях, сума всіх зон = 1 у кожній точці (повзунок діє тільки на свою зону).

Зони: Спинка, Сидіння, Боковина внутр. ліва/права, Боковина зовн. ліва/права, Верх, Фронт, Задня стінка.
  * Верх / Сидіння / «внутрішня» — атрибути граней (fabric_zones4.py, локально, без розмазування).
  * Внутрішні грані ділимо за напрямом ВІДНОСНО ЗБІРКИ: дивиться вперед/назад -> Спинка,
    вбік -> Боковина внутр. ліва (дивиться праворуч) / права (дивиться ліворуч).
    Тож спинка бічної частини кутового дивана = внутрішня боковина (вона дивиться вбік).
  * Зовнішні грані за напрямом відносно збірки: Фронт / Задня стінка / Боковина зовн. ліва / права.
  * Грань, що дивиться на інший модуль далі ніж 12 см (через П-подібну збірку) -> внутрішня.
  * Стик між модулями (сусід ближче 12 см) -> продовження своєї великої грані.
  * Перехід між напрямами на скругленнях — вузький (±0.1), без подвійної дії.

У відкритому файлі:  ns={}; exec(open(this).read(), ns); ns["upgrade"]()
"""
import bpy
import math as _m
import os
import sys

# v7.28: шляхи відносно цього файлу — той самий код працює і з папки скриптів, і зсередини аддона Thuma Fabric
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else \
    r"E:\disk_D\pROG\Thuma_prog\Blender\Sectional_Configs\fabric_look"
FL_VERSION = 31            # номер збірки пульта; аддон порівнює з g["fl_version"] і пропонує «Оновити пульт»


def _tidy():
    """Акуратна розкладка вузлів (лише координати)."""
    for path in (os.path.join(HERE, "tidy_pults.py"), os.path.join(os.path.dirname(HERE), "tidy_pults.py")):
        if os.path.exists(path):
            try:
                exec(open(path, encoding="utf-8").read(), {"__name__": "tidy", "HRB_GROUPS": [GROUP]})
            except Exception as e:
                print("tidy:", e)
            return


def ensure_front_flag():
    """Прапорець сцени fabric_front: 1 на фронт-кадрах (поворот збірки 0°), 0 на інших; ключі CONSTANT.
    Раніше ставився вручну — тепер завжди відповідає поточним маркерам/повороту."""
    sc = bpy.context.scene
    rot = bpy.data.objects.get(ROT_OBJ)
    if rot is None:
        return 0
    cur = sc.frame_current
    sc["fabric_front"] = 0.0
    if sc.animation_data and sc.animation_data.action:
        try:
            for L_ in sc.animation_data.action.layers:
                for st in L_.strips:
                    for cb in st.channelbags:
                        for fc in [c for c in cb.fcurves if c.data_path == '["fabric_front"]']:
                            cb.fcurves.remove(fc)
        except Exception:
            fc = sc.animation_data.action.fcurves.find('["fabric_front"]')
            if fc:
                sc.animation_data.action.fcurves.remove(fc)
    n = 0
    for f in range(sc.frame_start, sc.frame_end + 1):
        sc.frame_set(f)
        v = 1.0 if abs(_m.sin(rot.matrix_world.to_euler().z)) < 0.1 else 0.0
        sc["fabric_front"] = v
        sc.keyframe_insert('["fabric_front"]', frame=f)
        n += int(v)
    try:
        for L_ in sc.animation_data.action.layers:
            for st in L_.strips:
                for cb in st.channelbags:
                    for fc in cb.fcurves:
                        if fc.data_path == '["fabric_front"]':
                            for k in fc.keyframe_points:
                                k.interpolation = 'CONSTANT'
    except Exception:
        pass
    sc.frame_set(cur)
    return n
GROUP = "FABRIC LOOK"
ROT_OBJ = "Control_Rotation"
RAY_LEN = 3.0
STAGE_Y = 2.8

ZONES = [
    ("back", "Спинка", "Спинка й сидіння",
     "Внутрішні грані, що дивляться вперед: подушки спинки з боку сидіння", (0, 0.4, 1)),
    ("seat", "Сидіння", "Спинка й сидіння", "Верх сидіння (і пуфа)", (0, 1, 0)),
    # v7.25: меню — ліві боковини разом, праві разом (користувач)
    ("in_l", "Боковина внутр. ліва", "Боковини ліві",
     "Внутрішня грань ЛІВОЇ боковини (дивиться праворуч). Ліво = якщо дивитись на диван спереду. "
     "У кутовому дивані сюди ж — спинка лівої бічної частини", (1, 0, 1)),
    # v7.22-23: бортик ніжки Г/П усередині кута (за типом деталі, на всю висоту)
    ("low_l", "Низ внутр. ліва", "Боковини ліві",
     "Бортик ніжки Г/П усередині кута, що дивиться ПРАВОРУЧ (ліва ніжка), на всю висоту "
     "(напр. кадри 44, 70, 73). Зовнішні боки дивана, стики, спинки сюди не входять", (1, 0.6, 0.8)),
    ("out_l", "Боковина зовн. ліва", "Боковини ліві", "Зовнішній бік дивана ЗЛІВА (дивиться назовні вліво)", (1, 0.45, 0)),
    ("in_r", "Боковина внутр. права", "Боковини праві",
     "Внутрішня грань ПРАВОЇ боковини (дивиться ліворуч). Право = якщо дивитись на диван спереду. "
     "У кутовому дивані сюди ж — спинка правої бічної частини", (0.55, 0, 1)),
    ("low_r", "Низ внутр. права", "Боковини праві",
     "Бортик ніжки Г/П усередині кута, що дивиться ЛІВОРУЧ (права ніжка), на всю висоту "
     "(напр. кадри 70, 73). Зовнішні боки дивана, стики, спинки сюди не входять", (0.6, 0.4, 1)),
    ("out_r", "Боковина зовн. права", "Боковини праві", "Зовнішній бік дивана СПРАВА (дивиться назовні вправо)", (0.55, 0.3, 0)),
    ("top", "Верх", "Верх", "Верхній кант спинки й підлокітників", (1, 1, 0)),
    ("front", "Фронт", "Фронт і зад", "Зовнішні грані, що дивляться вперед відносно всієї збірки", (1, 0, 0)),
    ("rear", "Задня стінка", "Фронт і зад", "Зовнішні грані, що дивляться назад (видно на 3/4 ззаду)", (0, 1, 1)),
]
MIGRATE = {"Верх спинки": ["Верх"],
           "Боковини внутрішні": ["Боковина внутр. ліва", "Боковина внутр. права"],
           "Боковини зовнішні": ["Боковина зовн. ліва", "Боковина зовн. права"]}


def _instances(g):
    out = []
    trees = [m.node_tree for m in bpy.data.materials if m.node_tree] + \
            [t for t in bpy.data.node_groups if t.bl_idname == 'ShaderNodeTree']
    for t in trees:
        for n in t.nodes:
            if n.type == 'GROUP' and n.node_tree == g:
                out.append(n)
    return out


def _snapshot(g):
    snap = []
    for n in _instances(g):
        vals = {}
        for s in n.inputs:
            if hasattr(s, "default_value") and not s.is_linked:
                v = s.default_value
                vals[s.name] = tuple(v) if hasattr(v, "__len__") else v
        snap.append((n, vals, [(l.from_node.name, l.from_socket.name, l.to_node.name, l.to_socket.name)
                               for l in n.id_data.links if l.to_node == n or l.from_node == n]))
    return snap


FULL_MIGRATE = {"Верх: колір тону": "Вся тканина: колір тону", "Верх: сила тону": "Вся тканина: сила тону",
                # v7.25: блок «Фронт-кадри: кут» — «Фронт: …» плутався з зоною «Фронт»
                "Фронт: ліва боковина внутр.": "Кут: ліва боковина",
                "Фронт: спинка біля лівої": "Кут: спинка",
                "Фронт: ширина, см": "Кут: ширина, см",
                "Фронт: згасання до країв": "Кут: згасання до країв",
                "Фронт: боковина, довжина": "Кут: довжина боковини",
}


def _restore(snap):
    for n, vals, links in snap:
        # нові повзунки в уже наявних нодах Blender ставить у 0 — виставити значення за замовчуванням
        for it in n.node_tree.interface.items_tree:
            if it.item_type == 'SOCKET' and it.in_out == 'INPUT' and hasattr(it, "default_value"):
                s = n.inputs.get(it.name)
                if s is not None and hasattr(s, "default_value") and not s.is_linked:
                    try:
                        s.default_value = it.default_value
                    except Exception:
                        pass
        for k, v in vals.items():
            k = FULL_MIGRATE.get(k, k)
            base, _, kind = k.partition(": ")
            names = [f"{b}: {kind}" for b in MIGRATE[base]] if base in MIGRATE else [k]
            for nm in names:
                s = n.inputs.get(nm)
                if s is not None and hasattr(s, "default_value"):
                    try:
                        s.default_value = v
                    except Exception:
                        pass
        t = n.id_data
        for fn, fs, tn, ts in links:          # перев'язати ЗА ІМЕНАМИ
            a, b = t.nodes.get(fn), t.nodes.get(tn)
            if a and b and a.outputs.get(fs) and b.inputs.get(ts):
                if not any(l.from_socket == a.outputs[fs] and l.to_socket == b.inputs[ts] for l in t.links):
                    t.links.new(a.outputs[fs], b.inputs[ts])
        for l in list(t.links):
            if (l.to_node == n or l.from_node == n) and \
                    (l.from_node.name, l.from_socket.name, l.to_node.name, l.to_socket.name) not in links:
                t.links.remove(l)


def build_interface(g):
    g.interface.clear()
    it = g.interface
    s = it.new_socket("Колір", in_out='INPUT', socket_type='NodeSocketColor')
    s.default_value = (0.5, 0.5, 0.5, 1); s.hide_value = True
    s.description = "Колір тканини (з Color Match) — не чіпати"
    it.new_socket("Колір", in_out='OUTPUT', socket_type='NodeSocketColor')

    def fsock(name, d, tip, panel, mn=0.0, mx=3.0):
        assert len(name.encode()) < 64, name
        s = it.new_socket(name, in_out='INPUT', socket_type='NodeSocketFloat', parent=panel)
        s.default_value = d; s.min_value = mn; s.max_value = mx; s.description = tip

    def angle_socks(nm, what, panel):
        # v7.12: множники за РАКУРСОМ кадру: Ф = фронт-кадри, Л/П = кадри 3/4 з лівим/правим боком дивана. 1 = без змін
        for kind, kname in (("яскр.", "Яскравість"), ("нас.", "Насиченість")):
            for a, aname in (("Ф", "ФРОНТ-кадрах (інші ракурси не змінюються)"),
                             ("Л", "кадрах 3/4, де видно ЛІВИЙ бік дивана (напр. 2, 24, 27, 29)"),
                             ("П", "кадрах 3/4, де видно ПРАВИЙ бік дивана (напр. 3, 23, 26, 30)")):
                fsock(f"{nm}: {kind} {a}", 1.0, f"{what}: {kname.lower()} лише на {aname}. "
                      "Множник поверх основного значення, 1 = без змін", panel)

    p = it.new_panel("Загальне")
    fsock("Вся тканина: яскравість", 1.0, "Яскравість усієї тканини. 1 = без змін, менше = темніше", p)
    fsock("Вся тканина: насиченість", 1.0, "Насиченість усієї тканини. 1 = без змін, 0 = сіра", p)
    angle_socks("Вся тканина", "Уся тканина", p)
    fsock("Вся тканина: відтінок", 0.5, "Зсув відтінку. 0.5 = без змін; ±0.02 вже помітно", p, 0.0, 1.0)
    s = it.new_socket("Вся тканина: колір тону", in_out='INPUT', socket_type='NodeSocketColor', parent=p)
    s.default_value = (0.8, 0.7, 0.55, 1)
    s.description = ("Яким кольором дотонувати всю тканину. Береться відтінок — "
                     "яскравість тканини зберігається")
    fsock("Вся тканина: сила тону", 0.0, "Наскільки дотонувати всю тканину в колір тону. "
          "0 = без тону, 1 = повністю", p, 0.0, 1.0)
    # v7.24: звичайна заливка кольором (без збереження яскравості тканини) + відсоток змішування
    s = it.new_socket("Вся тканина: колір заливки", in_out='INPUT', socket_type='NodeSocketColor', parent=p)
    s.default_value = (0.5, 0.5, 0.5, 1)
    s.description = ("Простий колір, яким заливається вся текстура тканини (як шар кольору зверху). "
                     "На відміну від «колір тону» яскравість тканини НЕ зберігається")
    fsock("Вся тканина: сила заливки", 0.0, "Скільки змішати заливку з тканиною: 0 = без заливки, "
          "0.1 = 10 %, 1 = повністю цей колір", p, 0.0, 1.0)
    def corner_panel():
        p = it.new_panel("Фронт-кадри: кут біля боковини")
        fsock("Кут: ліва боковина", 1.0, "Лише на ФРОНТ-кадрах (3/4 не змінюються): яскравість внутрішньої "
              "грані ЛІВОГО підлокітника. 1 = без змін, більше = світліше (клієнт: кут не такий темний)", p)
        fsock("Кут: спинка", 1.0, "Лише на ФРОНТ-кадрах: яскравість спинки поруч із ЛІВИМ підлокітником "
              "(тінь від нього). 1 = без змін; тінь дуже темна, тому тут потрібні великі значення (4-8)", p, 0.0, 12.0)
        fsock("Кут: ширина, см", 40.0, "Лише на ФРОНТ-кадрах: ширина трикутника біля СИДІННЯ, см від лівого "
              "підлокітника. Угорі трикутник сходиться в кут стику", p, 2.0, 100.0)
        fsock("Кут: згасання до країв", 0.0, "Лише на ФРОНТ-кадрах: як світло кута спадає до нуля В ТИХ САМИХ межах "
              "(ширина не змінюється). 0 = як було: біля кута рівна яскрава пляма, далі спад. 10 = світло починає "
              "зменшуватись одразу від кута і рівномірно, плавно доходить до 0 на краю", p, 0.0, 10.0)
        fsock("Кут: довжина боковини", 1.0, "Лише на ФРОНТ-кадрах: докуди внизу доходить підсвітка лівої боковини "
              "від стику зі спинкою вперед. 1 = майже до краю сидіння (без 2 см), 0.5 = до половини", p, 0.1, 2.0)

    panels = {}
    for key, nm, pn, tip, _ in ZONES:
        if pn not in panels:
            if "Боковини праві" in panels:            # v7.25: блок «кут» одразу під боковинами
                if "_corner" not in panels:
                    corner_panel(); panels["_corner"] = True
            panels[pn] = it.new_panel(pn)
        fsock(f"{nm}: яскравість", 1.0, f"{tip}. Яскравість, 1 = без змін", panels[pn])
        fsock(f"{nm}: насиченість", 1.0, f"{tip}. Насиченість, 1 = без змін", panels[pn])
        fsock(f"{nm}: перехід", 0.0, f"{tip}. Плюс: наскільки плавно зміна цієї зони заходить на сусідні деталі, см "
              "(5-15 = м'який перехід). Мінус: зміна звужується до центру зони — від країв зони плавно до 0 "
              "на цій відстані, см. 0 = різко по шву", panels[pn], -30.0, 30.0)
        angle_socks(nm, tip, panels[pn])
    p = it.new_panel("Кутик біля підлокітника")
    fsock("Кутик: яскравість", 1.0, "Вертикальна щілина на фронті між сидінням і підлокітником (боковиною). "
          "Менше 1 = темніше (клієнт просить затемнити)", p)
    fsock("Кутик: насиченість", 1.0, "Насиченість у щілині між сидінням і підлокітником. 1 = без змін", p)
    fsock("Кутик: розмір", 1.0, "Ширина затемнення в щілині. 1 = звичайна, 2 = ширше, 0.5 = вужче", p, 0.2, 4.0)
    fsock("Кутик: висота", 1.0, "До якої висоти доходить затемнення в щілині. 1 = до шва сидіння, "
          "менше = нижче, більше = вище", p, 0.3, 1.5)
    p = it.new_panel("Шви")
    fsock("Шви: сила", 0.0, "Наскільки підкреслити ВСІ шви тканини (тінь у шві). 0 = вимкнено, 0.3 = як у файлі "
          "диванів, 1 = чорний шов. Діє на всі моделі сцени", p, 0.0, 1.0)
    fsock("Шви: ширина", 0.35, "Повна ширина тіні шва, см (по половині з кожного боку). Напр. 0.35", p, 0.02, 3.0)
    p = it.new_panel("Перевірка і плавність", default_closed=True)
    fsock("Плавність переходів", 1.0, "Ширина плавного переходу між зонами на скругленнях і стиках деталей. "
          "1 = звичайна, 2-3 = м'якше, 0.3 = різкіше", p, 0.2, 4.0)
    fsock("М'якість спаду переходу", 1.6, "Наскільки плавно згасає «перехід» зон: 1 = як було (коротший край), "
          "1.6 = довший м'який хвіст, 2.5-3 = дуже розтягнуто. Діє на всі зони", p, 1.0, 3.0)
    s = it.new_socket("Показати зони", in_out='INPUT', socket_type='NodeSocketBool', parent=p)
    s.default_value = False
    s.description = ("Замість тканини показати зони кольорами: синій спинка, зелений сидіння, рожевий/фіолетовий "
                     "внутр. ліва/права, помаранчевий/коричневий зовн. ліва/права, жовтий верх, "
                     "червоний фронт, бірюзовий задня стінка")


def build_nodes(g):
    if g.animation_data:
        g.animation_data_clear()
    g.nodes.clear()
    N, L = g.nodes, g.links
    gi = N.new('NodeGroupInput'); gi.location = (-2600, 0)
    go = N.new('NodeGroupOutput'); go.location = (1700, 0)
    y = [1600]
    K = None                                   # «Плавність переходів», не менше 0.1 (0 зламав би переходи)

    def nxt():
        y[0] -= 45
        return y[0]

    def math(op, a, b=None, c=None, x=-900, clamp=False, label=None):
        n = N.new('ShaderNodeMath'); n.operation = op; n.location = (x, nxt()); n.use_clamp = clamp
        if label:
            n.label = label
        for i, v in enumerate((a, b, c)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                n.inputs[i].default_value = v
            else:
                L.new(v, n.inputs[i])
        return n.outputs[0]

    def ss(v, a, b, x=-900):                    # фіксований smoothstep
        n = N.new('ShaderNodeMapRange'); n.interpolation_type = 'SMOOTHSTEP'; n.location = (x, nxt())
        n.inputs["From Min"].default_value = a; n.inputs["From Max"].default_value = b
        L.new(v, n.inputs["Value"])
        return n.outputs[0]

    def ssk(v, c, w, x=-900):                   # smoothstep з шириною w * «Плавність переходів»
        hw = math('MULTIPLY', K, w, x=x)
        n = N.new('ShaderNodeMapRange'); n.interpolation_type = 'SMOOTHSTEP'; n.location = (x, nxt())
        L.new(math('SUBTRACT', c, hw, x=x), n.inputs["From Min"])
        L.new(math('ADD', c, hw, x=x), n.inputs["From Max"])
        L.new(v, n.inputs["Value"])
        return n.outputs[0]

    def sep(vec, x=-2000):
        n = N.new('ShaderNodeSeparateXYZ'); n.location = (x, nxt()); L.new(vec, n.inputs[0])
        return n.outputs

    def attr(name):
        a = N.new('ShaderNodeAttribute'); a.attribute_type = 'GEOMETRY'; a.attribute_name = name
        a.location = (-2300, nxt()); a.label = name
        return sep(a.outputs["Vector"])

    K = math('MAXIMUM', gi.outputs["Плавність переходів"], 0.1, x=-2300)

    # ---- кут збірки (драйвер без Python) ----
    ang = N.new('ShaderNodeValue'); ang.name = ang.label = "CFG_ANGLE"; ang.location = (-2400, 1500)
    rot = bpy.data.objects.get(ROT_OBJ)
    if rot:
        fc = g.driver_add('nodes["CFG_ANGLE"].outputs[0].default_value')
        drv = fc.driver; drv.type = 'AVERAGE'
        v = drv.variables.new(); v.name = "rz"; v.type = 'TRANSFORMS'
        v.targets[0].id = rot; v.targets[0].transform_type = 'ROT_Z'; v.targets[0].transform_space = 'WORLD_SPACE'

    def to_cfg(vec_out, frm='OBJECT'):
        if frm == 'OBJECT':
            vt = N.new('ShaderNodeVectorTransform'); vt.vector_type = 'VECTOR'; vt.convert_from = 'OBJECT'
            vt.convert_to = 'WORLD'; vt.location = (-2000, nxt()); L.new(vec_out, vt.inputs[0]); vec_out = vt.outputs[0]
        r = N.new('ShaderNodeVectorRotate'); r.rotation_type = 'Z_AXIS'; r.invert = True; r.location = (-1800, nxt())
        L.new(vec_out, r.inputs["Vector"]); L.new(ang.outputs[0], r.inputs["Angle"])
        return sep(r.outputs[0], x=-1600)

    geo = N.new('ShaderNodeNewGeometry'); geo.location = (-2400, 1300)
    tc = N.new('ShaderNodeTexCoord'); tc.location = (-2400, 1100)
    # нормаль форми з атрибута (Geometry.Normal містить рельєф тканини -> шум у масках)
    an = N.new('ShaderNodeAttribute'); an.attribute_type = 'GEOMETRY'; an.attribute_name = "fz5_n"
    an.location = (-2400, 1250); an.label = "нормаль форми"
    nn = N.new('ShaderNodeVectorMath'); nn.operation = 'NORMALIZE'; nn.location = (-2200, 1300)
    L.new(an.outputs["Vector"], nn.inputs[0])
    nox, noy, noz = sep(nn.outputs[0])                   # гладка нормаль у координатах модуля
    px, py, pz = sep(tc.outputs["Object"])               # точна позиція в координатах модуля
    ncx, ncy, _ = to_cfg(nn.outputs[0])                  # нормаль у координатах збірки
    # v7.12: Ф/Л/П — за РАКУРСОМ КАДРУ (поворот збірки CFG_ANGLE), а не за гранню: одне значення на весь кадр,
    # тож повзунок одного ракурсу не чіпає інші (v7.11 за кутом грані фарбував сидіння/верх на всіх кадрах).
    # Ф = фронт-кадр (0°); Л = 3/4, де видно ЛІВИЙ бік дивана (sin кута > 0: кадри 2, 24, 27, 29…);
    # П = 3/4, де видно ПРАВИЙ бік (sin < 0: кадри 3, 23, 26, 30…). Перевірено по Control_Rotation.
    sn_a = math('SINE', ang.outputs[0], x=-1600)
    A_F = math('SUBTRACT', 1.0, ss(math('ABSOLUTE', sn_a, x=-1600), 0.1, 0.3, x=-1600), x=-1600, label="ракурс: Ф")
    A_L = math('MULTIPLY', math('SUBTRACT', 1.0, A_F, x=-1600), math('GREATER_THAN', sn_a, 0.0, x=-1600),
               x=-1600, label="ракурс: Л")
    A_R = math('MULTIPLY', math('SUBTRACT', 1.0, A_F, x=-1600), math('LESS_THAN', sn_a, 0.0, x=-1600),
               x=-1600, label="ракурс: П")

    def angle_mult(nm, kind):                  # Ф*wF + Л*wL + П*wR
        k = "яскр." if kind == "яскравість" else "нас."
        t = math('MULTIPLY', gi.outputs[f"{nm}: {k} Ф"], A_F, x=-400)
        t = math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} Л"], A_L, t, x=-400)
        return math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} П"], A_R, t, x=-400)
    xmin, xmax, ymin = attr("fz5_a")
    ymax, zmin, _ = attr("fz5_b")
    scx, scy, hasB = attr("fz5_c")
    hasL, hasR, _ = attr("fz5_d")
    bx0, bx1, ayl = attr("fz5_e")
    ayr, _, _ = attr("fz5_f")
    nxl, nxr, nfl = attr("fz5_g")
    nfr, is_corner, nby = attr("fz5_h")
    # кутовий модуль: кутик лише якщо його боковина на краю збірки (fz_corner_arm = 1); у середині — сусід перед нею
    ca = N.new('ShaderNodeAttribute'); ca.attribute_type = 'OBJECT'; ca.attribute_name = "fz_corner_arm"
    ca.location = (-2300, nxt()); ca.label = "кутовий на краю"
    corner_ok = math('SUBTRACT', 1.0, math('MULTIPLY', is_corner, math('SUBTRACT', 1.0, ca.outputs["Fac"])))
    nfl = math('MULTIPLY', nfl, corner_ok)
    B = 0.27
    zr = math('SUBTRACT', pz, zmin, x=-1600)

    # ---- ПАНЕЛІ (UV-острови): тип зони цілою панеллю, межа = шов ----
    def fattr(name):
        a_ = N.new('ShaderNodeAttribute'); a_.attribute_type = 'GEOMETRY'; a_.attribute_name = name
        a_.location = (-2300, nxt()); a_.label = name
        return a_
    a_ts = fattr("fz6_ts").outputs["Fac"]
    a_in = fattr("fz6_in").outputs["Fac"]
    ldx, ldy, _ = sep(fattr("fz6_ld").outputs["Vector"])
    top = math('COMPARE', a_ts, 1.0, 0.25, label="ZONE top")
    seat = math('COMPARE', a_ts, 2.0, 0.25, label="ZONE seat")
    V = math('SUBTRACT', math('SUBTRACT', 1.0, top), seat, clamp=True)
    inner_p = math('MULTIPLY', V, a_in)                      # внутрішня панель
    ext = math('SUBTRACT', V, inner_p, clamp=True)           # зовнішня панель

    # блоки деталей (для стиків у щілинах між модулями)
    above = ss(zr, 0.22, 0.26)
    inb = math('MULTIPLY', hasB, ssk(math('SUBTRACT', py, math('SUBTRACT', ymax, B)), 0.0, 0.015))
    inb = math('MULTIPLY', inb, math('MULTIPLY', ssk(math('SUBTRACT', px, bx0), 0.0, 0.015),
                                     ssk(math('SUBTRACT', bx1, px), 0.0, 0.015)))
    inl = math('MULTIPLY', hasL, ssk(math('SUBTRACT', math('ADD', xmin, B), px), 0.0, 0.015))
    inl = math('MULTIPLY', inl, ssk(math('SUBTRACT', py, ayl), 0.0, 0.015))
    inr = math('MULTIPLY', hasR, ssk(math('SUBTRACT', px, math('SUBTRACT', xmax, B)), 0.0, 0.015))
    inr = math('MULTIPLY', inr, ssk(math('SUBTRACT', py, ayr), 0.0, 0.015))
    arm = math('MAXIMUM', inl, inr)
    backpart = math('MULTIPLY', above, math('MULTIPLY', inb, math('SUBTRACT', 1.0, arm)))
    armpart = math('MULTIPLY', above, arm)
    cs = math('MULTIPLY_ADD', ssk(math('SUBTRACT', math('MULTIPLY', math('ADD', xmin, xmax), 0.5), px), 0.0, 0.02), 2.0, -1.0)

    # ---- промені уздовж головної осі збірки (стики й погляд на інший модуль) ----
    use_x = math('GREATER_THAN', math('ABSOLUTE', ncx), math('ABSOLUTE', ncy), x=-1500)
    sgx, sgy = math('SIGN', ncx, x=-1500), math('SIGN', ncy, x=-1500)
    dcx = math('MULTIPLY', use_x, sgx, x=-1500)
    dcy = math('MULTIPLY', math('SUBTRACT', 1.0, use_x, x=-1500), sgy, x=-1500)

    def ray(off):
        """Промінь з точки, зсунутої вбік (поперек напряму) на off метрів."""
        hd = N.new('ShaderNodeCombineXYZ'); hd.location = (-1400, nxt())
        L.new(dcx, hd.inputs[0]); L.new(dcy, hd.inputs[1])
        dw = N.new('ShaderNodeVectorRotate'); dw.rotation_type = 'Z_AXIS'; dw.location = (-1300, nxt())
        L.new(hd.outputs[0], dw.inputs["Vector"]); L.new(ang.outputs[0], dw.inputs["Angle"])
        side = N.new('ShaderNodeVectorRotate'); side.rotation_type = 'Z_AXIS'; side.location = (-1300, nxt())
        L.new(dw.outputs[0], side.inputs["Vector"]); side.inputs["Angle"].default_value = 1.5708
        o1 = N.new('ShaderNodeVectorMath'); o1.operation = 'MULTIPLY_ADD'; o1.location = (-1200, nxt())
        L.new(side.outputs[0], o1.inputs[0]); o1.inputs[1].default_value = (off, off, 0.0)
        L.new(geo.outputs["Position"], o1.inputs[2])
        o2 = N.new('ShaderNodeVectorMath'); o2.operation = 'MULTIPLY_ADD'; o2.location = (-1200, nxt())
        L.new(dw.outputs[0], o2.inputs[0]); o2.inputs[1].default_value = (0.004, 0.004, 0.004)
        L.new(o1.outputs[0], o2.inputs[2])
        rc = N.new('ShaderNodeRaycast'); rc.location = (-1100, nxt())
        L.new(o2.outputs[0], rc.inputs["Position"]); L.new(dw.outputs[0], rc.inputs["Direction"])
        rc.inputs["Length"].default_value = RAY_LEN
        _, hy, hz = sep(rc.outputs["Hit Position"], x=-1000)
        other = math('MULTIPLY', math('SUBTRACT', rc.outputs["Is Hit"], rc.outputs["Self Hit"], clamp=True),
                     math('MULTIPLY', math('LESS_THAN', hy, STAGE_Y), math('GREATER_THAN', hz, 0.03)))
        return other, rc.outputs["Hit Distance"]

    o0, d0 = ray(0.0)
    near = math('SUBTRACT', 1.0, ss(d0, 0.06, 0.12))
    joint = math('MULTIPLY', math('MULTIPLY', o0, near), ext, label="стик")
    # один точний промінь (бічні промені зачіпали сусідній шезлонг і «заливали» фронт біля стику)
    far = math('MULTIPLY', math('MULTIPLY', o0, ss(d0, 0.08, 0.16)),
               math('SUBTRACT', 1.0, ss(d0, RAY_LEN * 0.8, RAY_LEN)))
    ext_far = math('MULTIPLY', math('SUBTRACT', ext, joint, clamp=True), far); ext_far.node.label = 'DBG ext_far'
    # стик = продовження своєї деталі: у блоці спинки/підлокітника -> внутрішня деталь, інакше зовнішня
    bsum = math('MAXIMUM', math('ADD', backpart, armpart), 0.0001)
    jin = math('MINIMUM', math('ADD', backpart, armpart), 1.0)
    jb = math('MULTIPLY', math('MULTIPLY', joint, jin), math('DIVIDE', backpart, bsum))
    ja = math('MULTIPLY', math('MULTIPLY', joint, jin), math('DIVIDE', armpart, bsum))
    outer = math('SUBTRACT', math('SUBTRACT', ext, ext_far), math('ADD', jb, ja), clamp=True)

    # ---- напрями ----
    # деталь спинки дивиться локально (0,-1), підлокітник (cs,0) -> у координатах збірки
    bdv = N.new('ShaderNodeCombineXYZ'); bdv.location = (-1400, nxt()); bdv.inputs[1].default_value = -1.0
    bdx, bdy, _ = to_cfg(bdv.outputs[0])
    adv = N.new('ShaderNodeCombineXYZ'); adv.location = (-1400, nxt()); L.new(cs, adv.inputs[0])
    adx, ady, _ = to_cfg(adv.outputs[0])

    def mix(f, a, b):                         # a + (b-a)*f
        return math('MULTIPLY_ADD', math('SUBTRACT', b, a), f, a)

    def split(xv, yv):                        # (вздовж X, X>0, вздовж Y, Y>0) — гладко
        dX = ssk(math('SUBTRACT', math('ABSOLUTE', xv), math('ABSOLUTE', yv)), 0.0, 0.1)
        return dX, math('GREATER_THAN', xv, 0.0), math('SUBTRACT', 1.0, dX), math('GREATER_THAN', yv, 0.0)

    bX, bXp, bY, _ = split(bdx, bdy)
    aX, aXp, aY, _ = split(adx, ady)
    nX, nXp, nY, nYp = split(ncx, ncy)
    # внутрішня панель: напрям її деталі (з fz6_ld), якщо є; інакше — за нормаллю
    pld = N.new('ShaderNodeCombineXYZ'); pld.location = (-1400, nxt())
    L.new(ldx, pld.inputs[0]); L.new(ldy, pld.inputs[1])
    pdx, pdy, _ = to_cfg(pld.outputs[0])
    has_pd = math('GREATER_THAN', math('ADD', math('ABSOLUTE', ldx), math('ABSOLUTE', ldy)), 0.5)
    pX, pXp, pY, _ = split(mix(has_pd, ncx, pdx), mix(has_pd, ncy, pdy))
    IB = jb                                    # стик у блоці спинки
    IA = ja                                    # стик у блоці підлокітника
    IP = inner_p                               # внутрішня панель
    RN = ext_far                               # зовнішня панель, що дивиться на інший модуль (П-збірка)

    def inner_side(pos):                       # внутрішні грані, що дивляться вздовж +X (pos) / -X
        def part(w, dX, dXp):
            return math('MULTIPLY', math('MULTIPLY', w, dX), dXp if pos else math('SUBTRACT', 1.0, dXp))
        return math('ADD', math('ADD', math('ADD', part(IB, bX, bXp), part(IA, aX, aXp)), part(RN, nX, nXp)),
                    part(IP, pX, pXp))

    zone = {
        "back": math('ADD', math('ADD', math('ADD', math('MULTIPLY', IB, bY), math('MULTIPLY', IA, aY)),
                                 math('MULTIPLY', RN, nY)), math('MULTIPLY', IP, pY)),
        "seat": seat,
        "in_l": inner_side(True),              # ліва боковина дивиться праворуч (+X)
        "in_r": inner_side(False),
        "out_l": math('MULTIPLY', math('MULTIPLY', outer, nX), math('SUBTRACT', 1.0, nXp)),
        "out_r": math('MULTIPLY', math('MULTIPLY', outer, nX), nXp),
        "top": top,
        "front": math('MULTIPLY', math('MULTIPLY', outer, nY), math('SUBTRACT', 1.0, nYp)),
        "rear": math('MULTIPLY', math('MULTIPLY', outer, nY), nYp),
    }
    for k, sock in zone.items():
        sock.node.label = "ZONE " + k

    rN = math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.05)

    def notch(nx, flag, arm_neg):
        # V-щілина між скругленими передніми кромками сидіння й підлокітника (виміряно: від ~0.15 м над низом
        # оббивки до верху сидіння, глибина кількох см). Маска: втоплено за фронт на 3 мм…7 см (далі — ні,
        # інакше смуга по всій глибині модуля й ззаду), поруч із лінією щілини по X, по висоті — сама V.
        dep = math('SUBTRACT', py, ymin)
        in_dep = math('MULTIPLY', ss(dep, 0.0015, 0.008), math('SUBTRACT', 1.0, ss(dep, 0.07, 0.10)))
        dx = math('ABSOLUTE', math('SUBTRACT', px, nx))
        near_x = math('SUBTRACT', 1.0, ssk(dx, math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.055), 0.015))
        # лише бік ПІДЛОКІТНИКА в щілині (сидіння — інший бік V — не чіпаємо)
        side_v = math('SUBTRACT', nx, px) if arm_neg else math('SUBTRACT', px, nx)
        arm_side = ss(side_v, -0.004, 0.004)
        return math('MULTIPLY', flag, math('MULTIPLY', math('MULTIPLY', in_dep, near_x), arm_side))
    # верх затемнення: трохи вище шва сидіння на фронті (шов 0.258 м над низом оббивки) × «Кутик: висота»
    top_h = math('MULTIPLY', gi.outputs["Кутик: висота"], 0.258)
    top_f = N.new('ShaderNodeMapRange'); top_f.interpolation_type = 'SMOOTHSTEP'; top_f.location = (-900, nxt())
    L.new(top_h, top_f.inputs["From Min"]); L.new(math('ADD', top_h, 0.017), top_f.inputs["From Max"])
    L.new(zr, top_f.inputs["Value"])
    hz = math('MULTIPLY', ss(zr, 0.13, 0.17), math('SUBTRACT', 1.0, top_f.outputs[0]))   # не вище сидіння
    # кутовий на краю, де підлокітником працює основна спинка: щілина біля її внутрішньої грані (y = nby),
    # «фронт» модуля тут — площина x = xmax
    ca1 = N.new('ShaderNodeAttribute'); ca1.attribute_type = 'OBJECT'; ca1.attribute_name = "fz_corner_arm1"
    ca1.location = (-2300, nxt()); ca1.label = "основна спинка кутового на краю"
    dep_c = math('SUBTRACT', xmax, px)
    in_dep_c = math('MULTIPLY', ss(dep_c, 0.0015, 0.008), math('SUBTRACT', 1.0, ss(dep_c, 0.07, 0.10)))
    near_c = math('SUBTRACT', 1.0, ssk(math('ABSOLUTE', math('SUBTRACT', py, nby)),
                                     math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.055), 0.015))
    arm_side_c = ss(math('SUBTRACT', py, nby), -0.004, 0.004)
    notch_c = math('MULTIPLY', math('MULTIPLY', is_corner, ca1.outputs["Fac"]),
                   math('MULTIPLY', math('MULTIPLY', in_dep_c, near_c), arm_side_c))
    notch_m = math('MULTIPLY', math('MAXIMUM', math('MAXIMUM', notch(nxl, nfl, True), notch(nxr, nfr, False)), notch_c), hz,
                   label="ZONE notch")
    # пензель (шар кольору fz_kutik у меші): R = дорисувати, G = стерти; шару нема -> чорний -> без змін
    kb = N.new('ShaderNodeVertexColor'); kb.layer_name = "fz_kutik"; kb.location = (-1000, nxt()); kb.label = "Кутик: пензель"
    ksp = N.new('ShaderNodeSeparateColor'); ksp.location = (-850, nxt()); L.new(kb.outputs["Color"], ksp.inputs[0])
    notch_m = math('MAXIMUM', math('MULTIPLY', notch_m, math('SUBTRACT', 1.0, ksp.outputs[1], clamp=True)),
                   ksp.outputs[0], label="ZONE notch + пензель")

    # ---- м'які ваги зон (v7.1): облямівка лише навколо САМОЇ зони — відстань до її граней (fz7_*),
    #      напрям граней у координатах меша переводимо в координати збірки (модулі повернуті на 90°*k)
    def vattr(name):
        a_ = N.new('ShaderNodeAttribute'); a_.attribute_type = 'GEOMETRY'; a_.attribute_name = name
        a_.location = (-2300, nxt()); a_.label = name
        return sep(a_.outputs["Vector"])
    dTop, dSeat, _ = vattr("fz7_a")
    eXp, eXn, eYp = vattr("fz7_b")
    eYn, iXp, iXn = vattr("fz7_c")
    iYp, iYn, _ = vattr("fz7_d")

    def cdir(x, y_):
        v = N.new('ShaderNodeCombineXYZ'); v.location = (-1400, nxt())
        v.inputs[0].default_value = x; v.inputs[1].default_value = y_
        cx, cy, _ = to_cfg(v.outputs[0])
        return cx, cy
    Q = {"+X": cdir(1, 0), "-X": cdir(-1, 0), "+Y": cdir(0, 1), "-Y": cdir(0, -1)}
    # v7.2: сторона модуля, що впирається в сусіда (стик), не дає «переходу» зовнішнім зонам
    ex = N.new('ShaderNodeAttribute'); ex.attribute_type = 'OBJECT'; ex.attribute_name = "fz7_exp"
    ex.location = (-2300, nxt()); ex.label = "вільні сторони модуля (fz7_exp)"
    exs = N.new('ShaderNodeSeparateColor'); exs.location = (-2100, nxt()); L.new(ex.outputs["Color"], exs.inputs[0])
    EXP = {"+X": exs.outputs[0], "-X": exs.outputs[1], "+Y": exs.outputs[2], "-Y": ex.outputs["Alpha"]}

    def free(d, e):                            # стик -> «далеко» (1 м)
        return math('ADD', math('MULTIPLY', d, e), math('SUBTRACT', 1.0, e))
    EXT = {k: free(v, EXP[k]) for k, v in {"+X": eXp, "-X": eXn, "+Y": eYp, "-Y": eYn}.items()}
    INN = {"+X": iXp, "-X": iXn, "+Y": iYp, "-Y": iYn}

    def neg(v):
        return math('MULTIPLY', v, -1.0)

    # v7.7: «Боковина зовн.» лише біля крайнього лівого/правого краю ВСІЄЇ збірки. fz7_asm = габарити збірки
    # у координатах цього модуля -> від повороту/зсуву кадру не залежить. Яка сторона модуля «права» в збірці — з Q.
    asm = N.new('ShaderNodeAttribute'); asm.attribute_type = 'OBJECT'; asm.attribute_name = "fz7_asm"
    asm.location = (-2300, nxt()); asm.label = "габарити збірки в модулі (fz7_asm)"
    asp = N.new('ShaderNodeSeparateColor'); asp.location = (-2100, nxt()); L.new(asm.outputs["Color"], asp.inputs[0])
    a_x0, a_x1, a_y0, a_y1 = asp.outputs[0], asp.outputs[1], asp.outputs[2], asm.outputs["Alpha"]
    no_asm = math('LESS_THAN', math('SUBTRACT', a_x1, a_x0), 0.1)              # нема властивості -> як раніше
    DSIDE = {"+X": math('SUBTRACT', a_x1, px), "-X": math('SUBTRACT', px, a_x0),
             "+Y": math('SUBTRACT', a_y1, py), "-Y": math('SUBTRACT', py, a_y0)}

    def edge_dist(comp):                            # відстань до краю збірки з боку, що в збірці дивиться в comp
        acc = None
        for k, (cx, cy) in Q.items():
            t = math('MULTIPLY', ss(comp(cx, cy), 0.5, 0.9), DSIDE[k])
            acc = t if acc is None else math('ADD', acc, t)
        return acc

    def gate(d, far, near_):
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHSTEP'; n_.location = (-1500, nxt())
        n_.inputs["From Min"].default_value = far; n_.inputs["From Max"].default_value = near_
        L.new(d, n_.inputs["Value"])
        return math('MAXIMUM', n_.outputs[0], no_asm)
    # v7.8: відстань до краю збірки ВЗДОВЖ ВЛАСНОЇ НОРМАЛІ грані (у координатах модуля) — не залежить від того,
    # як модуль повернутий (кадр 4: шезлонг сам під ~45°, через Q сторона ділилась навпіл)
    lX_, lXp_, _, lYp_ = split(nox, noy)
    dX = math('MULTIPLY_ADD', math('SUBTRACT', DSIDE["+X"], DSIDE["-X"]), lXp_, DSIDE["-X"])
    dY = math('MULTIPLY_ADD', math('SUBTRACT', DSIDE["+Y"], DSIDE["-Y"]), lYp_, DSIDE["-Y"])
    d_n = math('MULTIPLY_ADD', math('SUBTRACT', dX, dY), lX_, dY)
    g_n = gate(d_n, 0.18, 0.10)
    zone["out_r"] = math('MULTIPLY', zone["out_r"], g_n)
    zone["out_l"] = math('MULTIPLY', zone["out_l"], g_n)
    edge_rw = edge_lw = gate(d_n, 0.48, 0.40)

    def pick(D, comp):                         # відстань до граней, що в збірці дивляться в потрібний бік
        acc = wsum = None
        for k, (cx, cy) in Q.items():
            w = ss(comp(cx, cy), 0.5, 0.9)
            t = math('MULTIPLY', w, D[k])
            acc = t if acc is None else math('ADD', acc, t)
            wsum = w if wsum is None else math('ADD', wsum, w)
        return math('ADD', acc, math('SUBTRACT', 1.0, wsum, clamp=True))   # нема таких граней -> далеко
    DZ = {"top": dTop, "seat": dSeat,
          "front": pick(EXT, lambda cx, cy: neg(cy)), "rear": pick(EXT, lambda cx, cy: cy),
          "out_l": pick(EXT, lambda cx, cy: neg(cx)), "out_r": pick(EXT, lambda cx, cy: cx),
          "in_l": pick(INN, lambda cx, cy: cx), "in_r": pick(INN, lambda cx, cy: neg(cx)),
          "back": math('MINIMUM', pick(INN, lambda cx, cy: cy), pick(INN, lambda cx, cy: neg(cy)))}
    # v7.22: «Низ внутр.» — вертикальні грані нижче верху подушки (0.31 м над низом оббивки), що дивляться вздовж ±X
    # збірки, крім зовнішніх боків/фронту/заду; забирають ці грані у «Боковина внутр.» (у П) і в «без зони» (у Г)
    # v7.23 (користувач: «впливає на багато інших панелей, навіть на спинку; хай доходить до верху бортика»):
    # не за висотою, а за типом деталі — ЗОВНІШНЯ панель ніжки, що дивиться вбік усередину Г/П:
    #  П: зовнішня панель, що через кут дивиться на інший модуль (RN = ext_far);
    #  Г: зовнішня панель, що дивиться вбік, але НЕ крайній бік усього дивана (те, що g_n прибрав з «зовн.»).
    # Стики між модулями (jb/ja), внутрішні панелі (спинки, подушки) сюди не входять; бортик — на всю висоту.
    side_free = math('MULTIPLY', outer, math('SUBTRACT', 1.0, g_n))
    low_b = math('MULTIPLY', math('MINIMUM', math('ADD', RN, side_free), 1.0), nX)
    # v7.27: не щілини між модулями (прямий диван, кадри 25/58 — тонкі смужки): промінь ТОЧНО вбік по ±X збірки
    # на 15 см; влучив у сусідній модуль -> щілина, не бортик. (v7.26 через fz7_exp губив бік шезлонга, кадр 70)
    sdx = N.new('ShaderNodeCombineXYZ'); sdx.location = (-1400, nxt()); L.new(math('SIGN', ncx), sdx.inputs[0])
    sdw = N.new('ShaderNodeVectorRotate'); sdw.rotation_type = 'Z_AXIS'; sdw.location = (-1300, nxt())
    L.new(sdx.outputs[0], sdw.inputs["Vector"]); L.new(ang.outputs[0], sdw.inputs["Angle"])
    sp0 = N.new('ShaderNodeVectorMath'); sp0.operation = 'MULTIPLY_ADD'; sp0.location = (-1200, nxt())
    L.new(sdw.outputs[0], sp0.inputs[0]); sp0.inputs[1].default_value = (0.004, 0.004, 0.004)
    L.new(geo.outputs["Position"], sp0.inputs[2])
    src = N.new('ShaderNodeRaycast'); src.location = (-1100, nxt())
    L.new(sp0.outputs[0], src.inputs["Position"]); L.new(sdw.outputs[0], src.inputs["Direction"])
    src.inputs["Length"].default_value = 0.15
    gap = math('SUBTRACT', src.outputs["Is Hit"], src.outputs["Self Hit"], clamp=True)
    low_b = math('MULTIPLY', low_b, math('SUBTRACT', 1.0, gap))
    zone["low_l"] = math('MULTIPLY', low_b, nXp, label="ZONE low_l")
    zone["low_r"] = math('MULTIPLY', low_b, math('SUBTRACT', 1.0, nXp), label="ZONE low_r")
    zone["in_l"] = math('MULTIPLY', zone["in_l"], math('SUBTRACT', 1.0, zone["low_l"]))
    zone["in_r"] = math('MULTIPLY', zone["in_r"], math('SUBTRACT', 1.0, zone["low_r"]))
    far1 = N.new('ShaderNodeValue'); far1.outputs[0].default_value = 1.0; far1.location = (-900, nxt())
    DZ["low_l"] = DZ["low_r"] = far1.outputs[0]          # плюсовий «перехід» для низу не діє (мінус — так)
    fz9 = N.new('ShaderNodeAttribute'); fz9.attribute_type = 'GEOMETRY'; fz9.attribute_name = "fz9_in"
    fz9.location = (-900, nxt()); fz9.label = "до краю шматка тканини (fz9_in)"
    W = {}
    for key, nm, _, _, _ in ZONES:
        wcm = gi.outputs[f"{nm}: перехід"]
        wm = math('MAXIMUM', math('MULTIPLY', wcm, 0.01), 0.0001)
        fr = N.new('ShaderNodeMapRange'); fr.interpolation_type = 'SMOOTHERSTEP'; fr.location = (-700, nxt())
        fr.inputs["From Min"].default_value = 0.0
        fo = gi.outputs["М'якість спаду переходу"]          # v7.9: спад довший (W*f) і м'якший ((1-s)^f); f=1 -> як було
        # v7.15: плюсовий перехід — спад удвічі довший і плавний на обох кінцях (smootherstep), без видимої межі
        L.new(math('MULTIPLY', math('MULTIPLY', wm, fo), 2.0), fr.inputs["From Max"]); L.new(DZ[key], fr.inputs["Value"])
        on = math('GREATER_THAN', wcm, 0.001)
        bleed = math('MULTIPLY', math('POWER', math('SUBTRACT', 1.0, fr.outputs[0]), fo), on)
        # v7.3: обмеження за типом панелі прибрано — відстань тепер по тканині (fabric_zones7), фронт до спинки «далеко»
        if key == "out_l":
            bleed = math('MULTIPLY', bleed, edge_lw)
        elif key == "out_r":
            bleed = math('MULTIPLY', bleed, edge_rw)
        # v7.13: мінусовий «перехід» — зона звужується до центру: вага всередині зони плавно росте від її країв
        # до 1 на глибині |перехід| × «М'якість спаду». Край зони = шов (зони — цілі шматки тканини між швами),
        # відстань до шва по тканині — fz9_in (fabric_inner9.py, до 0.6 м)
        inner_d = fz9.outputs["Fac"]
        # v7.14: спад удвічі довший і м'якший біля краю (користувач: «більше фолофу»): лінійно на 2×|перехід|×м'якість,
        # потім ^1.6 — біля шва росте повільно, до центру плавно виходить на 1
        # v7.15/16: ще плавніше (користувач: «щоб не було видно межі»): спад на 2×|перехід|×м'якість, smootherstep —
        # нульовий нахил і біля шва, і там, де виходить на повну силу (нема «зламу» = нема видимої межі)
        shr = N.new('ShaderNodeMapRange'); shr.interpolation_type = 'SMOOTHERSTEP'; shr.location = (-700, nxt())
        shr.inputs["From Min"].default_value = 0.0
        L.new(math('MULTIPLY', math('MAXIMUM', math('MULTIPLY', wcm, -0.02), 0.0001), fo), shr.inputs["From Max"])
        L.new(inner_d, shr.inputs["Value"])
        # v7.16: біля шва ефект не 0, а 40 % («з самого початку, лише тьмяніше»), до центру плавно 100 %
        shr_o = math('MULTIPLY_ADD', shr.outputs[0], 0.6, 0.4)
        neg = math('LESS_THAN', wcm, -0.001)
        z_eff = math('MULTIPLY', zone[key], math('MULTIPLY_ADD', math('SUBTRACT', shr_o, 1.0), neg, 1.0))
        W[key] = math('MAXIMUM', z_eff, bleed, label="W " + key)

    y[0] = 1200
    S = None
    for key, _, _, _, _ in ZONES:
        S = W[key] if S is None else math('ADD', S, W[key])
    rest = math('SUBTRACT', 1.0, S, clamp=True)                 # частина без зони -> без змін (1)
    den = math('MAXIMUM', S, 1.0)
    acc = {"яскравість": rest, "насиченість": rest}
    dbg = None
    for key, nm, _, _, col in ZONES:
        for kind in ("яскравість", "насиченість"):
            zv = math('MULTIPLY', gi.outputs[f"{nm}: {kind}"], angle_mult(nm, kind), x=-350)
            acc[kind] = math('MULTIPLY_ADD', zv, W[key], acc[kind], x=-300)
        c = N.new('ShaderNodeMix'); c.data_type = 'RGBA'; c.location = (500, nxt())
        c.inputs[6].default_value = (0, 0, 0, 1); c.inputs[7].default_value = (*col, 1)
        L.new(math('DIVIDE', W[key], den, x=300), c.inputs[0])
        if dbg is None:
            dbg = c.outputs[2]
        else:
            ad = N.new('ShaderNodeMix'); ad.data_type = 'RGBA'; ad.blend_type = 'ADD'; ad.location = (700, nxt())
            ad.inputs[0].default_value = 1.0
            L.new(dbg, ad.inputs[6]); L.new(c.outputs[2], ad.inputs[7])
            dbg = ad.outputs[2]
    bri = math('MULTIPLY', math('MULTIPLY', gi.outputs["Вся тканина: яскравість"], angle_mult("Вся тканина", "яскравість")),
               math('DIVIDE', acc["яскравість"], den, x=-200), x=-100)
    sat = math('MULTIPLY', math('MULTIPLY', gi.outputs["Вся тканина: насиченість"], angle_mult("Вся тканина", "насиченість")),
               math('DIVIDE', acc["насиченість"], den, x=-200), x=-100)
    # v7.4: «Свої зони» з аддона Thuma Fabric — атрибут вершин tc_cust (x = яскравість-1, y = насиченість-1)
    cu = N.new('ShaderNodeAttribute'); cu.attribute_type = 'GEOMETRY'; cu.attribute_name = "tc_cust"
    cu.location = (-500, nxt()); cu.label = "Свої зони (tc_cust)"
    cux, cuy, _ = sep(cu.outputs["Vector"], x=-350)
    # v7.12: свої зони за ракурсом — tc_cust = Ф, tc_cust_l = Л, tc_cust_r = П (аддон ≥ 1.7 пише всі три)
    cul = N.new('ShaderNodeAttribute'); cul.attribute_type = 'GEOMETRY'; cul.attribute_name = "tc_cust_l"
    cul.location = (-500, nxt()); cul.label = "Свої зони: Л (tc_cust_l)"
    cur_ = N.new('ShaderNodeAttribute'); cur_.attribute_type = 'GEOMETRY'; cur_.attribute_name = "tc_cust_r"
    cur_.location = (-500, nxt()); cur_.label = "Свої зони: П (tc_cust_r)"
    clx, cly, _ = sep(cul.outputs["Vector"], x=-350)
    crx, cry, _ = sep(cur_.outputs["Vector"], x=-350)
    cux = math('MULTIPLY_ADD', crx, A_R, math('MULTIPLY_ADD', clx, A_L, math('MULTIPLY', cux, A_F, x=-300), x=-300), x=-300)
    cuy = math('MULTIPLY_ADD', cry, A_R, math('MULTIPLY_ADD', cly, A_L, math('MULTIPLY', cuy, A_F, x=-300), x=-300), x=-300)
    bri = math('MULTIPLY', bri, math('ADD', cux, 1.0, x=-250), x=-100)
    sat = math('MULTIPLY', sat, math('ADD', cuy, 1.0, x=-250), x=-100)

    # кутик біля підлокітника — поверх зон
    bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кутик: яскравість"], 1.0, x=-300),
                                     notch_m, 1.0, x=-300), x=-100)
    sat = math('MULTIPLY', sat, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кутик: насиченість"], 1.0, x=-300),
                                     notch_m, 1.0, x=-300), x=-100)
    # v7.10: кут біля підлокітника лише на фронт-кадрах — прапорець сцени fabric_front (ключі 1/0 по кадрах)
    ff = N.new('ShaderNodeAttribute'); ff.attribute_type = 'VIEW_LAYER'; ff.attribute_name = "fabric_front"
    ff.location = (-500, nxt()); ff.label = "фронт-кадр (fabric_front)"
    def ssv(v, a, b):                          # smoothstep зі змінними межами
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHSTEP'; n_.location = (-500, nxt())
        for sk, val in (("From Min", a), ("From Max", b), ("Value", v)):
            if isinstance(val, (int, float)):
                n_.inputs[sk].default_value = val
            else:
                L.new(val, n_.inputs[sk])
        return n_.outputs[0]

    # лінія стику спинка/підлокітник — виміряна по мешу кожного модуля (measure_joints -> fj_x / fj_y)
    fjx = N.new('ShaderNodeAttribute'); fjx.attribute_type = 'OBJECT'; fjx.attribute_name = "fj_x"
    fjx.location = (-2300, nxt()); fjx.label = "стик: підлокітники (fj_x)"
    fjy = N.new('ShaderNodeAttribute'); fjy.attribute_type = 'OBJECT'; fjy.attribute_name = "fj_y"
    fjy.location = (-2300, nxt()); fjy.label = "стик: спинка (fj_y)"
    fxs = N.new('ShaderNodeSeparateColor'); fxs.location = (-2100, nxt()); L.new(fjx.outputs["Color"], fxs.inputs[0])
    fys = N.new('ShaderNodeSeparateColor'); fys.location = (-2100, nxt()); L.new(fjy.outputs["Color"], fys.inputs[0])
    t_arm = ss(zr, 0.44, 0.60)                 # середина -> верх (скруглення)
    armL = mix(t_arm, fxs.outputs[0], fxs.outputs[1])
    armR = mix(t_arm, fxs.outputs[2], fjx.outputs["Alpha"])
    back_t = mix(ss(zr, 0.32, 0.58), fys.outputs[0], fys.outputs[1])
    # лише підлокітник, що В ЗБІРЦІ лівий (його внутрішня грань дивиться праворуч, +X збірки)
    # + у меші справді знайдено внутрішню грань підлокітника (fj > 5 см), інакше (Island, Armless) — нема кута
    wL = math('MULTIPLY', math('MULTIPLY', hasL, ss(Q["+X"][0], 0.5, 0.9)), math('GREATER_THAN', fxs.outputs[0], 0.05))
    wR = math('MULTIPLY', math('MULTIPLY', hasR, ss(Q["-X"][0], 0.5, 0.9)), math('GREATER_THAN', fxs.outputs[2], 0.05))
    # -1 см -> трикутник починається саме в куті; нема лівого підлокітника -> «далеко»
    d_l = math('ADD', math('SUBTRACT', px, math('ADD', xmin, math('SUBTRACT', armL, 0.01))),
               math('MULTIPLY', math('SUBTRACT', 1.0, wL), 9.0))
    d_r = math('ADD', math('SUBTRACT', math('SUBTRACT', xmax, math('SUBTRACT', armR, 0.01)), px),
               math('MULTIPLY', math('SUBTRACT', 1.0, wR), 9.0))
    # трикутник: угорі вершина в куті стику, донизу ширшає. Висота оббивки 0.59 м, спинка над сидінням ≈ 0.28…0.59
    hn = math('DIVIDE', math('SUBTRACT', zr, 0.28), 0.31, clamp=True)
    tri = math('MAXIMUM', math('SUBTRACT', 1.0, hn), 0.04)
    ramp = math('MULTIPLY_ADD', math('SUBTRACT', 1.0, hn), 0.65, 0.35)   # угорі 35 %, біля сидіння 100 %
    # --- спинка біля лівого підлокітника ---
    # «вершина в кут»: угорі трикутник заходить у кут на 4 см (до сидіння зсув плавно -> 0), без повзунка
    tip = math('MULTIPLY', hn, 0.04)
    d_tip = math('ADD', math('MINIMUM', d_l, d_r), tip)   # межа «спинка/підлокітник» угорі на 3 см глибше в кут
    # v7.21: «згасання до країв» — НЕ розширює (користувач): у тих самих межах форма спаду від «плато + спад»
    # (smoothstep, v=0) до «одразу від кута рівномірно до 0» ((1-x)^1.6, v=10)
    kg = gi.outputs["Кут: згасання до країв"]
    k_t = math('MULTIPLY', kg, 0.1, clamp=True)
    na_ = N.new('ShaderNodeMapRange'); na_.interpolation_type = 'LINEAR'; na_.location = (-500, nxt())
    na_.inputs["From Min"].default_value = 0.0
    L.new(math('DIVIDE', math('MAXIMUM', d_tip, 0.0), tri), na_.inputs["Value"])   # форма v101 (користувач: «відмінно»)
    # спад має дійти до 0 ДО кінця свого модуля (інакше обрізається на стику з сусіднім): d/tri ≤ (ширина модуля − підлокітник − 4 см)/tri
    d_room = math('MAXIMUM', math('SUBTRACT', math('SUBTRACT', xmax, xmin), math('ADD', armL, 0.04)), 0.05)
    L.new(math('MINIMUM', math('MULTIPLY', gi.outputs["Кут: ширина, см"], 0.01),
               math('DIVIDE', d_room, tri)), na_.inputs["From Max"])
    x_b = na_.outputs[0]                                   # 0 біля кута -> 1 на краю

    def profile(x):                                        # 1-f: 0 біля кута, 1 на краю (як «near»)
        sm = ss(x, 0.0, 1.0)
        lin = math('SUBTRACT', 1.0, math('POWER', math('SUBTRACT', 1.0, x), 1.6))
        return math('MULTIPLY_ADD', math('SUBTRACT', lin, sm), k_t, sm)
    near_arm = profile(x_b)
    # скруглення стику (грані дивляться частково вбік -> потрапляють у «in_l») теж рахуємо спинкою,
    # інакше між підлокітником і трикутником лишається темна смужка: це грані ЗА площиною підлокітника
    # (v98 пробував додати кант «Верх» + ширшу вершину — користувач відхилив, гірше)
    fillet = math('MULTIPLY', zone["in_l"], ss(math('MINIMUM', d_l, d_r), 0.012, 0.03))   # межа зон — на стику
    # v7.19: «Фронт: згасання до країв» замінив «кут, перехід» (v7.17-18, користувачу незрозумілий);
    # мінус = біля шва 40 % і плавно до 100 % всередину (відстань до шва fz9_in); smootherstep — без видимої межі

    def smst(v, hi):
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHERSTEP'; n_.location = (-500, nxt())
        n_.inputs["From Min"].default_value = 0.0
        L.new(hi, n_.inputs["From Max"]); L.new(v, n_.inputs["Value"])
        return n_.outputs[0]
    m_back = math('MULTIPLY', math('MINIMUM', math('ADD', zone["back"], fillet), 1.0),
                  math('SUBTRACT', 1.0, near_arm), label="ZONE front back")
    m_back = math('MULTIPLY', m_back, ramp)
    # лише справжня спинка, не передня кромка модуля (з оттоманкою впритул вона стає «стиком» -> зона спинки)
    m_back = math('MULTIPLY', m_back, ss(math('SUBTRACT', py, ymin), 0.08, 0.15))
    # не чіпати скруглену верхню кромку біля стику (там з'являлась світла плямка); оббивка ~0.59 м
    m_back = math('MULTIPLY', m_back, math('SUBTRACT', 1.0, ss(zr, 0.57, 0.59)))
    # верхня частина біля кута трохи слабша (до -35 %), щоб не виділялась
    m_back = math('MULTIPLY', m_back, math('SUBTRACT', 1.0, math('MULTIPLY', ss(zr, 0.50, 0.57), 0.35)))
    # --- внутрішня грань САМОГО лівого підлокітника (не стики між модулями, які теж в «in_l») ---
    onL = math('MULTIPLY', wL, math('SUBTRACT', 1.0, ss(math('SUBTRACT', math('SUBTRACT', px, xmin), armL), 0.015, 0.04)))
    onR = math('MULTIPLY', wR, math('SUBTRACT', 1.0, ss(math('SUBTRACT', math('SUBTRACT', xmax, px), armR), 0.015, 0.04)))
    on_arm = math('MULTIPLY', math('MULTIPLY', zone["in_l"], math('MAXIMUM', onL, onR)),
                  math('SUBTRACT', 1.0, ss(math('MINIMUM', d_l, d_r), 0.012, 0.03)))   # без скруглення (воно — спинка)
    # дзеркальний трикутник по глибині: від стику зі спинкою вперед; унизу майже до краю сидіння (-2 см)
    joint_y = math('SUBTRACT', ymax, back_t)
    dy = math('MAXIMUM', math('SUBTRACT', joint_y, math('ADD', py, 0.01)), 0.0)
    # до переднього кінця ПІДЛОКІТНИКА (у шезлонга він коротший за сидіння) мінус 2 см
    reach = math('MULTIPLY', math('MAXIMUM', math('SUBTRACT', math('SUBTRACT', fys.outputs[2], back_t), 0.02), 0.05),
                 gi.outputs["Кут: довжина боковини"])
    # біля кута рівна «полиця», далі плавний спад до 0 на кінці
    # м'якший і довший спад (користувач: «плавніше від краю»): з 10 % довжини до 130 %
    fx_ = N.new('ShaderNodeMapRange'); fx_.interpolation_type = 'LINEAR'; fx_.location = (-500, nxt())
    L.new(math('DIVIDE', dy, tri), fx_.inputs["Value"])
    L.new(math('MULTIPLY', reach, 0.1), fx_.inputs["From Min"]); L.new(math('MULTIPLY', reach, 1.3), fx_.inputs["From Max"])
    fade = profile(fx_.outputs[0])
    # не у V-щілині спереду між сидінням і підлокітником (зона «Кутик») і без верхньої кромки підлокітника
    on_arm = math('MULTIPLY', on_arm, math('MULTIPLY', math('SUBTRACT', 1.0, notch_m, clamp=True),
                                           math('SUBTRACT', 1.0, ss(zr, 0.565, 0.585))))
    # передні 1-5 см підлокітника (самий торець) — без підсвітки; V-щілину вже вирізає notch_m
    # (v7.18: було 3-12 см — користувач: «до краю трохи не доходить»)
    dy_end = math('SUBTRACT', fys.outputs[2], back_t)
    front_cut = math('SUBTRACT', 1.0, ssv(dy, math('SUBTRACT', dy_end, 0.05), math('SUBTRACT', dy_end, 0.01)))
    on_arm = math('MULTIPLY', on_arm, front_cut)
    # v7.19: «згасання до країв» — та сама степінь, що й на спинці
    m_arm = math('MULTIPLY', math('MULTIPLY', on_arm, math('SUBTRACT', 1.0, fade)), ramp,
                 label="ZONE front arm")
    fl = math('ADD', math('MULTIPLY', math('SUBTRACT', gi.outputs["Кут: ліва боковина"], 1.0, x=-300), m_arm),
              math('MULTIPLY', math('SUBTRACT', gi.outputs["Кут: спинка"], 1.0, x=-300), m_back))
    bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', fl, ff.outputs["Fac"], 1.0, x=-200), x=-100)
    # v7.5: шви — fz8_seam (відстань по тканині до UV-шва), bri *= 1 - сила * (1 - smoothstep(d, 0, ширина/2))
    sa = N.new('ShaderNodeAttribute'); sa.attribute_type = 'GEOMETRY'; sa.attribute_name = "fz8_seam"
    sa.location = (-500, nxt()); sa.label = "шви (fz8_seam)"
    smr = N.new('ShaderNodeMapRange'); smr.interpolation_type = 'SMOOTHSTEP'; smr.location = (-300, nxt())
    smr.inputs["From Min"].default_value = 0.0
    L.new(math('MAXIMUM', math('MULTIPLY', gi.outputs["Шви: ширина"], 0.005, x=-400), 0.00005, x=-400), smr.inputs["From Max"])
    # v7.31: «зсув від ямки» (v7.29-30) прибрано на прохання користувача — тінь знову по центру шва
    L.new(sa.outputs["Fac"], smr.inputs["Value"])
    # v7.9: де шов прибрано пензлем/виділенням аддона — атрибут tc_seam_off (червоний = без шва)
    so = N.new('ShaderNodeAttribute'); so.attribute_type = 'GEOMETRY'; so.attribute_name = "tc_seam_off"
    so.location = (-500, nxt()); so.label = "шов прибрано (tc_seam_off)"
    sor, _, _ = sep(so.outputs["Color"], x=-350)
    seam_d = math('MULTIPLY', math('SUBTRACT', 1.0, smr.outputs[0], x=-200), math('SUBTRACT', 1.0, sor, clamp=True, x=-250), x=-200)
    seam_k = math('SUBTRACT', 1.0, math('MULTIPLY', gi.outputs["Шви: сила"], seam_d, x=-200),
                  x=-150, label="шви: множник")
    bri = math('MULTIPLY', bri, seam_k, x=-100)
    nd = N.new('ShaderNodeMix'); nd.data_type = 'RGBA'; nd.location = (800, nxt())
    L.new(notch_m, nd.inputs[0]); L.new(dbg, nd.inputs[6]); nd.inputs[7].default_value = (0, 0, 0, 1)
    dbg = nd.outputs[2]                        # у «Показати зони» кутик — чорний

    hsv = N.new('ShaderNodeHueSaturation'); hsv.location = (200, 1300); hsv.label = "Look (HSV)"
    L.new(gi.outputs["Колір"], hsv.inputs["Color"])
    L.new(gi.outputs["Вся тканина: відтінок"], hsv.inputs["Hue"])
    L.new(sat, hsv.inputs["Saturation"]); L.new(bri, hsv.inputs["Value"])
    hsv.inputs["Fac"].default_value = 1.0
    lum_c = N.new('ShaderNodeRGBToBW'); lum_c.location = (450, 1500); L.new(hsv.outputs[0], lum_c.inputs[0])
    lum_t = N.new('ShaderNodeRGBToBW'); lum_t.location = (450, 1600); L.new(gi.outputs["Вся тканина: колір тону"], lum_t.inputs[0])
    ratio = math('DIVIDE', lum_c.outputs[0], math('MAXIMUM', lum_t.outputs[0], 0.0001, x=650), x=650)
    cv = N.new('ShaderNodeCombineColor'); cv.location = (800, 1600)
    for i in range(3):
        L.new(ratio, cv.inputs[i])
    tn = N.new('ShaderNodeMix'); tn.data_type = 'RGBA'; tn.blend_type = 'MULTIPLY'; tn.location = (950, 1600)
    tn.inputs[0].default_value = 1.0
    L.new(gi.outputs["Вся тканина: колір тону"], tn.inputs[6]); L.new(cv.outputs[0], tn.inputs[7])
    fac = gi.outputs["Вся тканина: сила тону"]          # тон на всю тканину
    mx = N.new('ShaderNodeMix'); mx.data_type = 'RGBA'; mx.location = (1150, 1300)
    L.new(fac, mx.inputs[0]); L.new(hsv.outputs[0], mx.inputs[6]); L.new(tn.outputs[2], mx.inputs[7])
    base = N.new('ShaderNodeMix'); base.data_type = 'RGBA'; base.blend_type = 'ADD'; base.location = (1150, 900)
    base.inputs[0].default_value = 1.0; base.inputs[6].default_value = (0.1, 0.1, 0.1, 1)
    L.new(dbg, base.inputs[7])
    sw = N.new('ShaderNodeMix'); sw.data_type = 'RGBA'; sw.location = (1450, 1100); sw.name = "SHOW_ZONES"
    L.new(gi.outputs["Показати зони"], sw.inputs[0])
    fill = N.new('ShaderNodeMix'); fill.data_type = 'RGBA'; fill.location = (1300, 1300); fill.label = "заливка кольором"
    L.new(gi.outputs["Вся тканина: сила заливки"], fill.inputs[0])
    L.new(mx.outputs[2], fill.inputs[6]); L.new(gi.outputs["Вся тканина: колір заливки"], fill.inputs[7])
    L.new(fill.outputs[2], sw.inputs[6]); L.new(base.outputs[2], sw.inputs[7])
    L.new(sw.outputs[2], go.inputs[0])
    return len(g.nodes)


def upgrade():
    sys.path.insert(0, HERE)
    import importlib
    import fabric_zones6
    importlib.reload(fabric_zones6)
    # пензель кутика (fz_kutik) — малюнок користувача: зберегти до перерахунку зон і повернути після
    import numpy as np
    keep = {}
    for me in bpy.data.meshes:
        ca = me.color_attributes.get("fz_kutik")
        if ca is not None:
            a = np.empty(len(ca.data) * 4, np.float32); ca.data.foreach_get("color", a); keep[me.name] = a
    info = fabric_zones6.run()
    import fabric_zones7
    importlib.reload(fabric_zones7)
    fabric_zones7.run()
    import fabric_exposure7
    importlib.reload(fabric_exposure7)
    fabric_exposure7.run()
    import fabric_seams8
    importlib.reload(fabric_seams8)
    fabric_seams8.run()
    import fabric_inner9
    importlib.reload(fabric_inner9)
    fabric_inner9.run()
    for nm, a in keep.items():
        me = bpy.data.meshes.get(nm)
        ca = me.color_attributes.get("fz_kutik") if me else None
        if ca is None and me is not None:
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
        if ca is not None and len(ca.data) * 4 == len(a):
            ca.data.foreach_set("color", a); me.update()
    joints = measure_joints()
    fronts = ensure_front_flag()
    g = bpy.data.node_groups[GROUP]
    snap = _snapshot(g)
    build_interface(g)
    nn = build_nodes(g)
    _restore(snap)
    g["fl_version"] = FL_VERSION
    _tidy()
    for o in bpy.data.objects:
        if "fj_x" in o:
            o.update_tag()
    bad = [n.id_data.name for n, _, _ in snap
           if not n.outputs[0].links or n.outputs[0].links[0].to_socket.name != "Base Color"
           or not n.inputs[0].links]
    return {"instances": len(snap), "nodes": nn, "bad_links": bad, "meshes": len(info), "joints": joints, "fronts": fronts}


def measure_joints():
    """Лінія стику спинка/підлокітник по мешу кожного модуля -> властивості об'єкта (координати меша, м):
    fj_x = (лівий підлокітник від xmin: середина, верх; правий від xmax: середина, верх)
    fj_y = (спинка від ymax: низ ~0.3, верх ~0.6, 0, 0). Середина = z 0.28-0.44 над низом оббивки, верх = 0.56+."""
    done = 0
    cache = {}
    for o in bpy.data.objects:
        m = o.active_material
        if o.type != 'MESH' or not m or not m.get('thuma_fabric'):
            continue
        me = o.data
        if me.name not in cache:
            xs = [v.co.x for v in me.vertices]; ys = [v.co.y for v in me.vertices]; zs = [v.co.z for v in me.vertices]
            x0, x1, y1, z0 = min(xs), max(xs), max(ys), min(zs)

            def band(vals, lo, hi, fn):
                v = [d for z, d in vals if lo <= z <= hi]
                return fn(v) if v else 0.0
            al, ar, bk, arm_len = [], [], [], []
            for p in me.polygons:
                c, n, z = p.center, p.normal, p.center.z - z0
                if n.x > 0.8 and c.x < (x0 + x1) / 2:
                    al.append((z, c.x - x0)); arm_len.append(y1 - c.y)
                elif n.x < -0.8 and c.x > (x0 + x1) / 2:
                    ar.append((z, x1 - c.x)); arm_len.append(y1 - c.y)
                elif n.y < -0.8 and x0 + 0.3 < c.x < x1 - 0.3 and z > 0.28:
                    bk.append((z, y1 - c.y))
            cache[me.name] = ((band(al, 0.28, 0.44, max), band(al, 0.54, 0.62, max),
                               band(ar, 0.28, 0.44, max), band(ar, 0.54, 0.62, max)),
                              (band(bk, 0.28, 0.36, min), band(bk, 0.54, 0.62, min),
                               max(arm_len) if arm_len else 0.0, 0.0))     # [2] = довжина підлокітника від ymax
        o["fj_x"], o["fj_y"] = cache[me.name]
        done += 1
    return done


def rebuild():
    """Лише пересобрати вузли групи (атрибути зон у мешах не чіпати) — значення повзунків зберігаються."""
    joints = measure_joints()
    g = bpy.data.node_groups[GROUP]
    snap = _snapshot(g)
    build_interface(g)
    nn = build_nodes(g)
    _restore(snap)
    g["fl_version"] = FL_VERSION
    _tidy()
    return {"instances": len(snap), "nodes": nn, "joints": joints}


if __name__ == "__main__" and "--" in sys.argv:
    print("FL6", upgrade())
