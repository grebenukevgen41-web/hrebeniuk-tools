"""fz7_exp: які бічні сторони модуля ВІЛЬНІ в його конфігурації (не впираються в сусідній модуль).
Властивість об'єкта оббивки ob["fz7_exp"] = [+X, -X, +Y, -Y] у координатах об'єкта (1 = вільна, 0 = стик).
Шейдер FABRIC LOOK v7.2 бере «перехід» зовнішніх зон лише від вільних сторін (інакше від схованих у стику
боків модуля йшли смуги на фронт біля кожного стику). Конфігурація = дочірня колекція «Product».
Перезапускати, якщо переставили модулі.
"""
import bpy
from mathutils import Vector

GAP = 0.06          # м: сусід ближче за це до сторони = стик
OVERLAP = 0.15      # м: мінімальне перекриття вздовж сторони


def upholstery(objs):
    return [o for o in objs if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2]


def run():
    prod = bpy.data.collections.get("Product")
    sc = bpy.context.scene
    cur = sc.frame_current
    # кадр, де конфігурація видима (положення модулів задають Control-об'єкти -> рахуємо після frame_set)
    first = {}
    for f in range(sc.frame_start, sc.frame_end + 1):
        sc.frame_set(f)
        for o in upholstery(sc.objects):
            if o.name not in first and o.visible_get():
                first[o.name] = f
    out = {}
    for cfg in (prod.children if prod else []):
        obs = upholstery(cfg.all_objects)
        fr = [first[o.name] for o in obs if o.name in first]
        if not fr:
            continue
        sc.frame_set(min(fr))
        dg = bpy.context.evaluated_depsgraph_get()
        MW = {o.name: o.evaluated_get(dg).matrix_world.copy() for o in obs}
        for o in obs:
            inv = MW[o.name].inverted()
            bb = [Vector(c) for c in o.bound_box]
            mn = Vector((min(c.x for c in bb), min(c.y for c in bb), min(c.z for c in bb)))
            mx = Vector((max(c.x for c in bb), max(c.y for c in bb), max(c.z for c in bb)))
            exp = [1.0, 1.0, 1.0, 1.0]
            for n in obs:
                if n is o:
                    continue
                pts = [inv @ (MW[n.name] @ Vector(c)) for c in n.bound_box]
                nmn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
                nmx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
                if min(mx.z, nmx.z) - max(mn.z, nmn.z) < 0.05:
                    continue
                ovy = min(mx.y, nmx.y) - max(mn.y, nmn.y)
                ovx = min(mx.x, nmx.x) - max(mn.x, nmn.x)
                if ovy > OVERLAP:
                    if abs(nmn.x - mx.x) < GAP or (nmn.x < mx.x + GAP and nmx.x > mx.x):
                        exp[0] = 0.0
                    if abs(nmx.x - mn.x) < GAP or (nmx.x > mn.x - GAP and nmn.x < mn.x):
                        exp[1] = 0.0
                if ovx > OVERLAP:
                    if abs(nmn.y - mx.y) < GAP or (nmn.y < mx.y + GAP and nmx.y > mx.y):
                        exp[2] = 0.0
                    if abs(nmx.y - mn.y) < GAP or (nmx.y > mn.y - GAP and nmn.y < mn.y):
                        exp[3] = 0.0
            o["fz7_exp"] = exp
            out[o.name] = exp
        # v7.7: габарити всієї збірки В КООРДИНАТАХ КОЖНОГО МОДУЛЯ (не залежить від повороту/зсуву кадру 3/4)
        for o in obs:
            inv = MW[o.name].inverted()
            pts = [inv @ (MW[n.name] @ Vector(c)) for n in obs for c in n.bound_box]
            o["fz7_asm"] = [min(p.x for p in pts), max(p.x for p in pts), min(p.y for p in pts), max(p.y for p in pts)]
    sc.frame_set(cur)
    return out


if __name__ == "__main__":
    r = run()
    print("FZ7EXP", len(r))
