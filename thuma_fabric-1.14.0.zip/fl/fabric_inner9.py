"""fz9_in: відстань ПО ТКАНИНІ (м) від кожної вершини до найближчого шва (UV seam) = до краю свого шматка
тканини. Як fz8_seam, але до CAP = 0.6 м — для мінусового «переходу» FABRIC LOOK (зона звужується до центру:
зони = цілі шматки тканини між швами, тож відстань до шва = відстань до краю зони).
Назва fz9_ (не fz_) — пересбірка зон її не стирає.
"""
import bpy
import heapq
import numpy as np

CAP = 0.6


def meshes():
    return sorted({o.data for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential-")
                   and o.dimensions.z > 0.2}, key=lambda m: m.name)


def run():
    info = {}
    for me in meshes():
        nv, ne = len(me.vertices), len(me.edges)
        co = np.empty(nv * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ev = np.empty(ne * 2, np.int32); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
        seam = np.zeros(ne, bool); me.edges.foreach_get("use_seam", seam)
        w = np.linalg.norm(co[ev[:, 0]] - co[ev[:, 1]], axis=1)
        a = np.concatenate([ev[:, 0], ev[:, 1]]); b = np.concatenate([ev[:, 1], ev[:, 0]]); ww = np.concatenate([w, w])
        o = np.argsort(a, kind='stable'); a, b, ww = a[o], b[o], ww[o]
        st = np.searchsorted(a, np.arange(nv + 1)).tolist(); nb = b.tolist(); wt = ww.tolist()
        d = [CAP] * nv
        src = set(ev[seam].ravel().tolist())
        h = [(0.0, i) for i in src]
        for i in src:
            d[i] = 0.0
        heapq.heapify(h)
        while h:
            dv, v = heapq.heappop(h)
            if dv > d[v]:
                continue
            for k in range(st[v], st[v + 1]):
                u = nb[k]; nd = dv + wt[k]
                if nd < d[u]:
                    d[u] = nd; heapq.heappush(h, (nd, u))
        at = me.attributes.get("fz9_in")
        if at is not None and (at.domain != 'POINT' or len(at.data) != nv):
            me.attributes.remove(at); at = None
        at = at or me.attributes.new("fz9_in", 'FLOAT', 'POINT')
        at.data.foreach_set("value", np.array(d, np.float32))
        me.update()
        info[me.name] = (nv, int(seam.sum()))
    return info


if __name__ == "__main__":
    print("FZ9", run())
