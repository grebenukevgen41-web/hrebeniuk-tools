"""Акуратно розкласти вузли пультів (WOOD LOOK v2, FABRIC LOOK) по колонках за потоком даних.
ЛИШЕ координати вузлів — зв'язки, значення, операції не змінюються (перевіряється відбитком до/після).
exec у відкритому файлі; глобальна HRB_GROUPS = список назв (за замовч. обидва пульти).
"""
import bpy

GROUPS = globals().get("HRB_GROUPS") or ["WOOD LOOK v2", "FABRIC LOOK"]
GAP_X, GAP_Y = 80, 24


def fingerprint(g):
    links = sorted((l.from_node.name, l.from_socket.identifier, l.to_node.name, l.to_socket.identifier) for l in g.links)
    vals = []
    for n in g.nodes:
        props = tuple((p, str(getattr(n, p))) for p in ("operation", "data_type", "blend_type", "interpolation_type",
                                                          "attribute_name", "attribute_type", "use_clamp", "label")
                      if hasattr(n, p))
        ins = []
        for s in n.inputs:
            if hasattr(s, "default_value"):
                v = s.default_value
                ins.append((s.identifier, tuple(v) if hasattr(v, "__len__") else v))
        vals.append((n.name, n.bl_idname, props, tuple(ins), n.node_tree.name if getattr(n, "node_tree", None) else None))
    return (tuple(links), tuple(sorted(vals, key=lambda x: x[0])))


def est_h(n):
    if n.dimensions.y > 1:
        return n.dimensions.y
    vis = sum(1 for s in n.inputs if s.enabled and not s.hide) + sum(1 for s in n.outputs if s.enabled and not s.hide)
    extra = 30 if n.type in ('MATH', 'VECT_MATH', 'MIX', 'MAP_RANGE', 'ATTRIBUTE', 'VALTORGB', 'MAPPING') else 0
    if n.type == 'VALTORGB':
        extra += 120
    return 36 + 22 * vis + extra


def est_w(n):
    return n.dimensions.x if n.dimensions.x > 1 else n.width


def tidy(g):
    nodes = list(g.nodes)
    succ = {n: set() for n in nodes}; pred = {n: set() for n in nodes}
    for l in g.links:
        if l.from_node is l.to_node:
            continue
        succ[l.from_node].add(l.to_node); pred[l.to_node].add(l.from_node)
    layer = {}

    def depth(n, seen=()):
        if n in layer:
            return layer[n]
        if not succ[n]:
            layer[n] = 0
            return 0
        d = 1 + max(depth(s, seen + (n,)) for s in succ[n] if s not in seen) if any(s not in seen for s in succ[n]) else 0
        layer[n] = d
        return d
    import sys
    sys.setrecursionlimit(10000)
    for n in nodes:
        depth(n)
    gi = [n for n in nodes if n.type == 'GROUP_INPUT']
    mx = max(layer.values()) if layer else 0
    for n in gi:
        layer[n] = mx + 1
    cols = {}
    for n in nodes:
        cols.setdefault(layer[n], []).append(n)
    for L in cols:                                   # стартовий порядок — як зараз (зверху вниз)
        cols[L].sort(key=lambda n: -n.location.y)
    pos = {}

    def reindex():
        for L, ns in cols.items():
            for i, n in enumerate(ns):
                pos[n] = i / max(len(ns) - 1, 1)
    reindex()
    Ls = sorted(cols)
    for _ in range(6):                               # барицентр: по наступниках, потім по попередниках
        for L in Ls[1:]:
            cols[L].sort(key=lambda n: (sum(pos[s] for s in succ[n]) / len(succ[n])) if succ[n] else pos[n])
            reindex()
        for L in reversed(Ls[:-1]):
            cols[L].sort(key=lambda n: (sum(pos[p] for p in pred[n]) / len(pred[n])) if pred[n] else pos[n])
            reindex()
    x = 0.0
    for L in Ls:                                     # колонка 0 (вихід) праворуч, далі ліворуч
        ns = cols[L]
        w = max(est_w(n) for n in ns)
        hs = [est_h(n) for n in ns]
        total = sum(hs) + GAP_Y * (len(ns) - 1)
        y = total / 2
        for n, h in zip(ns, hs):
            n.location = (x - w, y)
            y -= h + GAP_Y
        x -= w + GAP_X
    return len(nodes), len(Ls)


out = {}
for name in GROUPS:
    g = bpy.data.node_groups[name]
    before = fingerprint(g)
    n, cols = tidy(g)
    after = fingerprint(g)
    out[name] = {"nodes": n, "columns": cols, "unchanged": before == after}
print("TIDY", out)
