"""FABRIC LOOK v6 — «внутрішня / зовнішня» і «до якої деталі» вирішуємо ЦІЛОЮ ПАНЕЛЛЮ ТКАНИНИ
(UV-острів = панель, межа = шов) -> маска не заходить за шов на сусідню панель.

FACE-атрибути (сталі в межах острова):
  fz6_in   — 1 = внутрішня панель (дивиться на сидіння), 0 = зовнішня
  fz6_ts   — 1 = панель верху (кант зверху), 2 = панель сидіння, 0 = вертикальна панель
  fz6_ld   — FLOAT_VECTOR: локальний напрям деталі для внутрішньої панелі ((0,-1) спинка, (±1,0) підлокітник),
             (0,0) = брати напрям за нормаллю
Плюс fz5_* (розміри модуля, нормаль форми) з fabric_zones5 — для верху/сидіння/стиків.
Голосування: кожна грань класифікується правилами v4, острів отримує більшість (за площею).
"""
import bpy
import bmesh
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else \
    r"E:\disk_D\pROG\Thuma_prog\Blender\Sectional_Configs\fabric_look"
sys.path.insert(0, HERE)
import fabric_zones4  # noqa: E402  (правила для окремої грані)
import fabric_zones5  # noqa: E402


def uv_islands(me):
    bm = bmesh.new(); bm.from_mesh(me); bm.faces.ensure_lookup_table()
    uv = bm.loops.layers.uv.active
    comp = [-1] * len(bm.faces); n = 0
    for f in bm.faces:
        if comp[f.index] >= 0:
            continue
        st = [f]; comp[f.index] = n
        while st:
            a = st.pop()
            for l in a.loops:
                for l2 in l.edge.link_loops:
                    b = l2.face
                    if b is a or comp[b.index] >= 0:
                        continue
                    if (l[uv].uv - l2.link_loop_next[uv].uv).length < 1e-5 and \
                            (l.link_loop_next[uv].uv - l2[uv].uv).length < 1e-5:
                        comp[b.index] = n; st.append(b)
        n += 1
    bm.free()
    return comp, n


def run():
    import importlib
    importlib.reload(fabric_zones4); importlib.reload(fabric_zones5)
    info5 = fabric_zones5.run()                 # fz5_* (і прибирає старі fz_/fz4_)
    # прапорець «боковина кутового модуля на краю збірки» (для кутика біля підлокітника) — для ВСІХ кутових
    import fabric_zones
    importlib.reload(fabric_zones)
    fabric_zones.corner_arm_flags()
    out = {}
    for me in fabric_zones5.upholstery_meshes():
        fabric_zones4.classify(me)              # тимчасово: правила для кожної грані
        nf = len(me.polygons)
        inner = [0.0] * nf; ldx = [0.0] * nf; ldy = [0.0] * nf; area = [0.0] * nf
        me.attributes["fz4_inner"].data.foreach_get("value", inner)
        me.attributes["fz4_ldx"].data.foreach_get("value", ldx)
        me.attributes["fz4_ldy"].data.foreach_get("value", ldy)
        top = [0.0] * nf; seat = [0.0] * nf
        me.attributes["fz4_top"].data.foreach_get("value", top)
        me.attributes["fz4_seat"].data.foreach_get("value", seat)
        me.polygons.foreach_get("area", area)
        comp, n = uv_islands(me)
        # голосування по острову: лише вертикальні грані (верх/сидіння не голосують)
        acc = [[0.0] * 7 for _ in range(n)]   # верт., внутр., Σldx·a, Σldy·a, верх, сидіння, всього
        for i in range(nf):
            a = area[i]; c = acc[comp[i]]
            c[6] += a
            if top[i] or seat[i]:
                c[4 if top[i] else 5] += a
                continue
            c[0] += a
            if inner[i]:
                c[1] += a; c[2] += ldx[i] * a; c[3] += ldy[i] * a
        isl_in, isl_ld, isl_ts = [], [], []
        for c in acc:
            # панель верху / сидіння: більшість її площі — верх / сидіння
            isl_ts.append(1.0 if c[4] > 0.5 * c[6] else (2.0 if c[5] > 0.5 * c[6] else 0.0))
            is_in = c[0] > 0 and c[1] / c[0] > 0.5
            dx, dy = (c[2] / c[1], c[3] / c[1]) if (is_in and c[1] > 0) else (0.0, 0.0)
            if abs(dx) > abs(dy) and abs(dx) > 0.3:
                d = (1.0 if dx > 0 else -1.0, 0.0)
            elif abs(dy) > 0.3:
                d = (0.0, 1.0 if dy > 0 else -1.0)
            else:
                d = (0.0, 0.0)
            isl_in.append(1.0 if is_in else 0.0); isl_ld.append(d)
        fin = [isl_in[comp[i]] if not isl_ts[comp[i]] else 0.0 for i in range(nf)]
        fts = [isl_ts[comp[i]] for i in range(nf)]
        fld = []
        for i in range(nf):
            d = isl_ld[comp[i]]; fld += [d[0], d[1], 0.0]
        for k in [a.name for a in me.attributes if a.name.startswith(("fz4_", "fz6_"))]:
            me.attributes.remove(me.attributes[k])
        a = me.attributes.new("fz6_in", 'FLOAT', 'FACE'); a.data.foreach_set("value", fin)
        a = me.attributes.new("fz6_ts", 'FLOAT', 'FACE'); a.data.foreach_set("value", fts)
        a = me.attributes.new("fz6_ld", 'FLOAT_VECTOR', 'FACE'); a.data.foreach_set("vector", fld)
        out[me.name] = {"islands": n, "inner_islands": int(sum(isl_in)),
                        "top_islands": isl_ts.count(1.0), "seat_islands": isl_ts.count(2.0),
                        "dirs": sorted({d for d, f in zip(isl_ld, isl_in) if f})}
    return out
