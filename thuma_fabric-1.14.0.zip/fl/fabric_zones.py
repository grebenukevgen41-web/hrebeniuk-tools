"""FABRIC LOOK — розмітка зон оббивки атрибутами меша (12 мешів, спільні для всіх конфігів).

Атрибути (POINT, FLOAT, 0..1, м'які краї): fz_top fz_seat fz_back fz_arm_in fz_side_out fz_front fz_rear
+ fz_debug (FLOAT_COLOR) для перевірки в Workbench.
Все в локальних координатах меша (модуль повернутий у конфігу — спинка лишається спинкою).
Використання: import fabric_zones; fabric_zones.run()  (у відкритому файлі)
"""
import bpy
import math

ZONES = ["fz_top", "fz_top_back", "fz_top_arm", "fz_seat", "fz_back", "fz_arm_in", "fz_side_out", "fz_front", "fz_rear", "fz_bb", "fz_c2", "fz_c1"]
DEBUG_COL = {"fz_top": (0, 0, 0), "fz_top_back": (1, 1, 0), "fz_top_arm": (0.6, 1, 0.3), "fz_seat": (0, 1, 0), "fz_back": (0, 0.4, 1), "fz_arm_in": (1, 0, 1),
             "fz_side_out": (1, 0.45, 0), "fz_front": (1, 0, 0), "fz_rear": (0, 1, 1), "fz_bb": (0, 0, 0), "fz_c2": (0, 0, 0), "fz_c1": (0, 0, 0)}
BLOCK = 0.27      # глибина спинки / ширина підлокітника + запас (виміряно 0.24)


def ss(a, b, x):
    t = min(1.0, max(0.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


def upholstery_meshes():
    return sorted({o.data for o in bpy.data.objects
                   if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2},
                  key=lambda m: m.name)


def classify(me):
    vs = me.vertices
    xmin = min(v.co.x for v in vs); xmax = max(v.co.x for v in vs)
    ymin = min(v.co.y for v in vs); ymax = max(v.co.y for v in vs)
    zmin = min(v.co.z for v in vs)
    # які блоки високі (> 0.2 м над сидінням): підлокітники зліва/справа перед спинкою
    high = [v.co for v in vs if v.co.z - zmin > 0.5]
    front_high = [c for c in high if c.y < ymax - BLOCK - 0.05]
    left_block = any(c.x < xmin + BLOCK for c in front_high)
    right_block = any(c.x > xmax - BLOCK for c in front_high)
    has_back = any(c.y > ymax - BLOCK for c in high)
    corner = "Corner" in me.name          # лівий блок кутового = друга спинка, не підлокітник

    acc = {z: [0.0] * len(vs) for z in ZONES}
    wsum = [0.0] * len(vs)
    for p in me.polygons:
        n, c, a = p.normal, p.center, p.area
        zr = c.z - zmin
        up = ss(0.4, 0.75, n.z)
        fwd = ss(0.4, 0.75, -n.y)
        bwd = ss(0.4, 0.75, n.y)
        above = ss(0.27, 0.31, zr)                  # вище верху сидіння (~0.31 від низу)
        vert = 1 - ss(0.3, 0.6, abs(n.z))
        in_back = (1.0 if has_back and c.y > ymax - BLOCK else 0.0)
        in_left = 1.0 if left_block and c.x < xmin + BLOCK and c.y <= ymax - BLOCK else 0.0
        in_right = 1.0 if right_block and c.x > xmax - BLOCK and c.y <= ymax - BLOCK else 0.0
        sgn = 1.0 if c.x >= 0 else -1.0
        side_out = ss(0.4, 0.75, n.x * sgn) * (1.0 if abs(c.x) > (xmax - xmin) / 2 - 0.06 else 0.0)
        rear = bwd * (1.0 if c.y > ymax - 0.07 else 0.0)

        z = {}
        z["fz_top"] = up * ss(0.42, 0.5, zr)
        # верх спинки (у кутового — обидві спинки) vs верх підлокітників
        tb = 1.0 if (in_back or (corner and in_left)) else 0.0
        z["fz_top_back"] = z["fz_top"] * tb
        z["fz_top_arm"] = z["fz_top"] * (1 - tb)
        # блок спинки вище сидіння (для торців у щілинах між модулями)
        z["fz_bb"] = tb * above
        # друга (бічна) спинка кутового модуля — у збірці може бути підлокітником (див. corner_arm_flags)
        z["fz_c2"] = 1.0 if (corner and in_left) else 0.0
        # основна спинка кутового (+Y), без кута, де вони сходяться
        z["fz_c1"] = 1.0 if (corner and in_back and c.x > xmin + BLOCK) else 0.0
        z["fz_seat"] = up * (1 - ss(0.38, 0.45, zr)) * ss(0.2, 0.25, zr)
        back = in_back * above * vert * fwd
        arm_in = 0.0
        if corner:
            back = max(back, in_left * above * vert * ss(0.4, 0.75, n.x))
        else:
            arm_in = max(in_left * above * vert * ss(0.4, 0.75, n.x),
                         in_right * above * vert * ss(0.4, 0.75, -n.x))
        # торець спинки, що дивиться в бік сидіння (острівний модуль) — теж спинка
        back = max(back, in_back * above * vert * (1 - fwd) * (1 - bwd) * (1 - side_out))
        z["fz_back"] = back
        z["fz_arm_in"] = arm_in
        z["fz_side_out"] = side_out
        z["fz_rear"] = rear
        z["fz_front"] = fwd * (1 - in_back) * (1 - z["fz_top"])
        for vi in p.vertices:
            for k in ZONES:
                acc[k][vi] += z[k] * a
            wsum[vi] += a
    for k in ZONES:
        acc[k] = [acc[k][i] / wsum[i] if wsum[i] else 0.0 for i in range(len(vs))]

    # згладжування по сусідах (м'які переходи без сходинок по полігонах)
    nb = [[] for _ in vs]
    for e in me.edges:
        i, j = e.vertices
        nb[i].append(j); nb[j].append(i)
    for _ in range(3):
        for k in ZONES:
            src = acc[k]
            acc[k] = [0.5 * src[i] + 0.5 * (sum(src[j] for j in nb[i]) / len(nb[i]) if nb[i] else src[i])
                      for i in range(len(vs))]

    for k in ZONES:
        at = me.attributes.get(k) or me.attributes.new(k, 'FLOAT', 'POINT')
        at.data.foreach_set("value", acc[k])
    dbg = me.attributes.get("fz_debug") or me.attributes.new("fz_debug", 'FLOAT_COLOR', 'POINT')
    cols = []
    for i in range(len(vs)):
        r = g = b = 0.15
        for k in ZONES:
            w = acc[k][i]; cr = DEBUG_COL[k]
            r += w * cr[0]; g += w * cr[1]; b += w * cr[2]
        cols += [min(r, 1), min(g, 1), min(b, 1), 1.0]
    dbg.data.foreach_set("color", cols)
    return {"left": left_block, "right": right_block, "back": has_back, "corner": corner,
            "share": {k: round(sum(acc[k]) / len(vs), 3) for k in ZONES}}


def run():
    return {me.name: classify(me) for me in upholstery_meshes()}


def corner_arm_flags():
    """Об'єктна властивість fz_corner_arm: 1 = бічна спинка кутового модуля стоїть на краю збірки
    (перед нею немає модуля) -> працює як підлокітник; 0 = продовжує спинку бічної частини.
    Положення рахуються на кадрі, де збірка видима (у фоні невидимі об'єкти не перераховуються)."""
    from mathutils import Vector
    sc = bpy.context.scene
    f0 = sc.frame_current
    ups = [o for o in bpy.data.objects
           if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2]
    todo = {o.name for o in ups if "Corner" in o.data.name}
    out = {}
    for f in range(sc.frame_start, sc.frame_end + 1):
        if not todo:
            break
        sc.frame_set(f)
        vis = [o for o in ups if o.visible_get()]
        for o in [o for o in vis if o.name in todo]:
            xmin = min(v.co.x for v in o.data.vertices)
            ymax = max(v.co.y for v in o.data.vertices)

            def occupied(local):
                p = o.matrix_world @ Vector(local)
                for q in vis:
                    if q is o:
                        continue
                    lo = q.matrix_world.inverted() @ p
                    bb = q.bound_box
                    if all(min(v[i] for v in bb) - 0.02 <= lo[i] <= max(v[i] for v in bb) + 0.02 for i in range(2)):
                        return True
                return False
            # бічна спинка (-X) продовжується, якщо модуль стоїть попереду (-Y); основна (+Y) — якщо праворуч (+X)
            o["fz_corner_arm"] = 0.0 if occupied((xmin + 0.12, -0.94, 0.0)) else 1.0
            o["fz_corner_arm1"] = 0.0 if occupied((0.94, ymax - 0.12, 0.0)) else 1.0
            if o["fz_corner_arm"] and o["fz_corner_arm1"]:   # стоїть сам: основна спинка лишається спинкою
                o["fz_corner_arm1"] = 0.0
            out[o.name] = (f, o["fz_corner_arm"], o["fz_corner_arm1"])
            todo.discard(o.name)
    for n in todo:                       # ніколи не видимі — як одиночний модуль
        bpy.data.objects[n]["fz_corner_arm"] = 1.0
        bpy.data.objects[n]["fz_corner_arm1"] = 0.0
    sc.frame_set(f0)
    return out
