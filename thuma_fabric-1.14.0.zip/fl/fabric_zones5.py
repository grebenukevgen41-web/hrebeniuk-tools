"""FABRIC LOOK v5 — у меші пишемо ТІЛЬКИ сталі параметри модуля (не маски!).
Маски рахує шейдер неперервно з гладкої нормалі й точної позиції -> без «драбинки» по полігонах,
без розповзання по великих полігонах, з плавним переходом.

POINT FLOAT_VECTOR (однакові для всіх вершин меша -> інтерполюються точно):
  fz5_a = (xmin, xmax, ymin)
  fz5_b = (ymax, zmin, 0)
  fz5_c = (центр сидіння x, y, є спинка 0/1)
  fz5_d = (лівий підлокітник/2-а спинка кутового 0/1, правий 0/1, 0)
  fz5_e = (спинка від x, до x, лівий підлокітник від y)   fz5_f = (правий підлокітник від y, 0, 0)
  fz5_g = (x кутика зліва, x кутика справа, є кутик зліва)   fz5_h = (є кутик справа, 0, 0)
  fz5_n = гладка нормаль вершини (форма без рельєфу тканини)
"""
import bpy

BLOCK = 0.27
NAMES = ["fz5_a", "fz5_b", "fz5_c", "fz5_d"]


def upholstery_meshes():
    return sorted({o.data for o in bpy.data.objects
                   if o.type == 'MESH' and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2},
                  key=lambda m: m.name)


def params(me):
    vs = me.vertices
    xmin = min(v.co.x for v in vs); xmax = max(v.co.x for v in vs)
    ymin = min(v.co.y for v in vs); ymax = max(v.co.y for v in vs)
    zmin = min(v.co.z for v in vs)
    high = [v.co for v in vs if v.co.z - zmin > 0.5]
    front_high = [c for c in high if c.y < ymax - BLOCK - 0.05]
    left = any(c.x < xmin + BLOCK for c in front_high)
    right = any(c.x > xmax - BLOCK for c in front_high)
    back = any(c.y > ymax - BLOCK for c in high)
    # де саме деталь існує: спинка по X (острів — не на всю ширину), підлокітники по Y (шезлонг — не на всю довжину)
    bxs = [c.x for c in high if c.y > ymax - BLOCK]
    bx0, bx1 = (min(bxs), max(bxs)) if bxs else (0.0, 0.0)
    lys = [c.y for c in high if c.x < xmin + BLOCK]
    rys = [c.y for c in high if c.x > xmax - BLOCK]
    ayl = min(lys) if lys else ymax
    ayr = min(rys) if rys else ymax
    # кутик (щілина) на фронті: внутрішня грань підлокітника / бічної спинки, якщо її фронт урівень із сидінням
    lxs = [c.x for c in high if c.x < xmin + BLOCK and c.y < ymax - BLOCK]
    rxs = [c.x for c in high if c.x > xmax - BLOCK and c.y < ymax - BLOCK]
    nxl = max(lxs) if lxs else xmin
    nxr = min(rxs) if rxs else xmax
    nfl = 1.0 if (left and lxs and ayl - ymin < 0.05) else 0.0
    nfr = 1.0 if (right and rxs and ayr - ymin < 0.05) else 0.0
    # кутовий, у якого підлокітником працює ОСНОВНА спинка (+Y): її внутрішня грань (y) — щілина на «фронті» x = xmax
    bys = [c.y for c in high if c.y > ymax - BLOCK and c.x > xmin + BLOCK]
    nby = min(bys) if bys else ymax
    sx = sy = sw = 0.0
    for p in me.polygons:
        if p.normal.z > 0.55 and 0.2 < p.center.z - zmin <= 0.46:
            sx += p.center.x * p.area; sy += p.center.y * p.area; sw += p.area
    scx, scy = (sx / sw, sy / sw) if sw else (0.0, 0.0)
    return {"fz5_a": (xmin, xmax, ymin), "fz5_b": (ymax, zmin, 0.0),
            "fz5_c": (scx, scy, 1.0 if back else 0.0), "fz5_d": (1.0 if left else 0.0, 1.0 if right else 0.0, 0.0),
            "fz5_e": (bx0, bx1, ayl), "fz5_f": (ayr, 0.0, 0.0),
            "fz5_g": (nxl, nxr, nfl), "fz5_h": (nfr, 1.0 if "Corner" in me.name else 0.0, nby)}


def run():
    out = {}
    for me in upholstery_meshes():
        p = params(me)
        for k, v in p.items():
            at = me.attributes.get(k)
            if at and (at.domain != 'POINT' or at.data_type != 'FLOAT_VECTOR'):
                me.attributes.remove(at); at = None
            at = at or me.attributes.new(k, 'FLOAT_VECTOR', 'POINT')
            at.data.foreach_set("vector", list(v) * len(me.vertices))
        # гладка нормаль форми БЕЗ рельєфу тканини (у шейдері Geometry.Normal містить bump тканини -> шум)
        at = me.attributes.get("fz5_n")
        if at:
            me.attributes.remove(at)
        at = me.attributes.new("fz5_n", 'FLOAT_VECTOR', 'POINT')
        nv = [0.0] * (3 * len(me.vertices))
        me.vertex_normals.foreach_get("vector", nv)
        at.data.foreach_set("vector", nv)
        # старі атрибути масок (v1-v4) більше не потрібні
        for a in [a.name for a in me.attributes if a.name.startswith(("fz_", "fz4_")) and a.name != "fz_kutik"]:   # fz_kutik = пензель користувача!
            me.attributes.remove(me.attributes[a])
        out[me.name] = {k: [round(x, 3) for x in v] for k, v in p.items()}
    return out
