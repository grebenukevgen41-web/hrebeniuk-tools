"""fz7 (v7.3): відстань (м) ПО ТКАНИНІ — геодезична по ребрах меша + «містки» між деталями, що лише торкаються
(сидіння/спинка, ≤ 8 мм), щоб перехід ішов на сусідню деталь по тканині, а не крізь повітря на протилежну.
(v7.1 міряв по прямій) від кожної вершини до панелей кожного типу І напряму —
щоб «<зона>: перехід» був лише облямівкою навколо самої зони (як її показує «Показати зони»).
Напрям — у КООРДИНАТАХ МЕША (модуль у збірці повернутий на 90°*k; шейдер переводить у координати збірки).
  fz7_a = (верх, сидіння, -)
  fz7_b = (зовн. +X, зовн. -X, зовн. +Y)       fz7_c = (зовн. -Y, внутр. +X, внутр. -X)
  fz7_d = (внутр. +Y, внутр. -Y, -)
Тип панелі — fz6_ts / fz6_in; напрям внутрішньої панелі — fz6_ld (якщо є), інакше нормаль грані.
Також створює порожній шар кольору fz_kutik (R = дорисувати кутик, G = стерти) для пензля.
"""
import bpy
import numpy as np
from mathutils import kdtree

CAP = 0.4


def meshes():
    return sorted({o.data for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential-")
                   and o.dimensions.z > 0.2 and "fz6_ts" in o.data.attributes}, key=lambda m: m.name)


BRIDGE = 0.008
EDGE = 0.15


def _graph(me, co, panel):
    """Сусідство вершин: ребра меша + містки між вершинами різних панелей, що торкаються (≤ BRIDGE)."""
    import heapq  # noqa: F401
    ne = len(me.edges)
    ev = np.empty(ne * 2, np.int32); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
    a, b = list(ev[:, 0]), list(ev[:, 1])
    kd = kdtree.KDTree(len(co))
    for i, c in enumerate(co):
        kd.insert(c, i)
    kd.balance()
    for i, c in enumerate(co):
        for _, j, d in kd.find_range(c, BRIDGE):
            if j > i and panel[j] != panel[i]:
                a.append(i); b.append(j)
    a = np.array(a, np.int64); b = np.array(b, np.int64)
    w = np.linalg.norm(co[a] - co[b], axis=1)
    A = np.concatenate([a, b]); Bn = np.concatenate([b, a]); W = np.concatenate([w, w])
    o = np.argsort(A, kind='stable')
    A, Bn, W = A[o], Bn[o], W[o]
    start = np.searchsorted(A, np.arange(len(co) + 1))
    return start.tolist(), Bn.tolist(), W.tolist()


def _dist(G, n, vmask):
    import heapq
    start, nb, wt = G
    d = [CAP] * n
    h = [(0.0, int(i)) for i in np.nonzero(vmask)[0]]
    for _, i in h:
        d[i] = 0.0
    heapq.heapify(h)
    while h:
        dv, v = heapq.heappop(h)
        if dv > d[v]:
            continue
        for k in range(start[v], start[v + 1]):
            u = nb[k]; nd = dv + wt[k]
            if nd < d[u]:
                d[u] = nd
                heapq.heappush(h, (nd, u))
    return np.array(d, np.float32)


def run():
    info = {}
    for me in meshes():
        nv, nf = len(me.vertices), len(me.polygons)
        co = np.empty(nv * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ts = np.empty(nf, np.float32); me.attributes["fz6_ts"].data.foreach_get("value", ts)
        fin = np.empty(nf, np.float32); me.attributes["fz6_in"].data.foreach_get("value", fin)
        ld = np.empty(nf * 3, np.float32); me.attributes["fz6_ld"].data.foreach_get("vector", ld); ld = ld.reshape(-1, 3)
        fn = np.empty(nf * 3, np.float32); me.polygons.foreach_get("normal", fn); fn = fn.reshape(-1, 3)
        top, seat = np.abs(ts - 1) < 0.25, np.abs(ts - 2) < 0.25
        V = ~(top | seat)
        inner, ext = V & (fin > 0.5), V & ~(fin > 0.5)
        dirv = np.where((np.abs(ld[:, 0]) + np.abs(ld[:, 1]) > 0.5)[:, None] & inner[:, None], ld, fn)
        ax = np.abs(dirv[:, 0]) >= np.abs(dirv[:, 1])
        horiz = np.hypot(dirv[:, 0], dirv[:, 1]) > 0.5            # грані знизу/зверху (нормаль майже вертикальна) — без напряму
        q = {"+X": horiz & ax & (dirv[:, 0] > 0), "-X": horiz & ax & (dirv[:, 0] <= 0),
             "+Y": horiz & ~ax & (dirv[:, 1] > 0), "-Y": horiz & ~ax & (dirv[:, 1] <= 0)}
        # зовнішні грані — лише біля відповідного краю модуля (≤ EDGE): дрібні «фронтові» шматочки в кутах спинки
        # (у стиках) інакше давали перехід фронту по спинці
        fc = np.empty(nf * 3, np.float32); me.polygons.foreach_get("center", fc); fc = fc.reshape(-1, 3)
        lo, hi = co.min(0), co.max(0)
        edge = {"+X": fc[:, 0] > hi[0] - EDGE, "-X": fc[:, 0] < lo[0] + EDGE,
                "+Y": fc[:, 1] > hi[1] - EDGE, "-Y": fc[:, 1] < lo[1] + EDGE}
        lt = np.empty(nf, np.int32); me.polygons.foreach_get("loop_total", lt)
        lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
        fol = np.repeat(np.arange(nf), lt)

        vpanel = np.zeros(nv, np.int8)                      # 0 ext, 1 inner, 2 top, 3 seat (для містків)
        for code, fm in ((1, inner), (2, top), (3, seat)):
            vpanel[lv[fm[fol]]] = code
        G = _graph(me, co, vpanel)

        def vm(fmask):
            m = np.zeros(nv, bool); m[lv[fmask[fol]]] = True
            return m
        D = {k: _dist(G, nv, vm(f)) for k, f in {
            "top": top, "seat": seat,
            "e+X": ext & q["+X"] & edge["+X"], "e-X": ext & q["-X"] & edge["-X"],
            "e+Y": ext & q["+Y"] & edge["+Y"], "e-Y": ext & q["-Y"] & edge["-Y"],
            "i+X": inner & q["+X"], "i-X": inner & q["-X"], "i+Y": inner & q["+Y"], "i-Y": inner & q["-Y"]}.items()}
        z = np.zeros(nv, np.float32)
        packs = {"fz7_a": (D["top"], D["seat"], z), "fz7_b": (D["e+X"], D["e-X"], D["e+Y"]),
                 "fz7_c": (D["e-Y"], D["i+X"], D["i-X"]), "fz7_d": (D["i+Y"], D["i-Y"], z)}
        for nm, (a, b, c) in packs.items():
            at = me.attributes.get(nm) or me.attributes.new(nm, 'FLOAT_VECTOR', 'POINT')
            at.data.foreach_set("vector", np.stack([a, b, c], 1).ravel())
        for old in ("fz7_dtop", "fz7_dseat", "fz7_din", "fz7_dext"):     # v7.0
            if old in me.attributes:
                me.attributes.remove(me.attributes[old])
        if "fz_kutik" not in me.color_attributes:                          # пензель кутика: чорний = без змін
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), nv))
        me.update()
        info[me.name] = {k: int((v == 0).sum()) for k, v in D.items()}
    return info


if __name__ == "__main__":
    print("FZ7", run())
