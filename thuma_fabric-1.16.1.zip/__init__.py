bl_info = {
    "name": "Thuma Fabric",
    "author": "Hrebeniuk",
    "version": (1, 16, 1),
    "blender": (4, 2, 0),
    "location": "3D View > N > Thuma > Тканина",
    "description": "Перемикач тканини оббивки + повзунки FABRIC LOOK вибраної тканини (майстер-сцена Thuma)",
    "category": "Material",
}
ADDON_VERSION = tuple(bl_info["version"])
"""Панель з'являється лише у файлах, де є тканини з міткою thuma_fabric (майстер-сцена v30+).
Тканина ставиться прямо в слот матеріалу 12 мешів оббивки — її видно в Shader Editor.
Скриптів у самому .blend немає — Blender не питає «Allow Execution»."""
import bpy

_ITEMS = []     # Blender вимагає тримати рядки динамічного списку живими
_KEY = [None]   # набір тканин, з якого зібрано _ITEMS (перебудова лише коли він змінився)


def _meshes():
    return sorted({o.data for o in bpy.data.objects if o.type == 'MESH'
                   and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2}, key=lambda m: m.name)


def _fabrics():
    return sorted((m for m in bpy.data.materials if m.get("thuma_fabric")), key=lambda m: m.name)


def _items(self, context):
    # 1.0.1: НЕ перебудовувати список при кожному виклику — інакше Blender тримає вказівники на старі рядки
    # і в згорнутому списку показує не ту назву (у розгорнутому правильно).
    fabs = _fabrics()
    key = tuple(m.name for m in fabs)
    if key != _KEY[0] or not _ITEMS:
        _ITEMS[:] = [("STORYBOARD", "Storyboard (сірий)", "Сірий матеріал Storyboard")]
        _ITEMS.extend((m.name, m["thuma_fabric"], m.name, i + 1) for i, m in enumerate(fabs))
        _ITEMS[0] = _ITEMS[0] + (0,)
        _KEY[0] = key
    return _ITEMS


def _current():
    ms = _meshes()
    return ms[0].materials[0] if ms and ms[0].materials else None


def _get(self):
    cur = _current()
    names = [i[0] for i in _items(self, None)]
    if cur and cur.get("thuma_fabric") and cur.name in names:
        return names.index(cur.name)
    return 0


def _set(self, value):
    names = [i[0] for i in _items(self, None)]
    v = names[value] if 0 <= value < len(names) else "STORYBOARD"
    for me in _meshes():
        if "storyboard_mat" not in me and me.materials and not me.materials[0].get("thuma_fabric"):
            me["storyboard_mat"] = me.materials[0].name
        mat = bpy.data.materials.get(me.get("storyboard_mat", "")) if v == "STORYBOARD" else bpy.data.materials.get(v)
        if mat:
            me.materials[0] = mat
    try:
        _sync_cfr()                                     # 1.13.0: таблиця імен у CFRender за розцвіткою
    except Exception as e:
        print("[Thuma Fabric] CFRender sync:", e)


def _look_node(mat):
    """Нода FABRIC LOOK у матеріалі (у Textured Weave вона всередині групи кольору)."""
    if not mat or not mat.node_tree:
        return None

    def find(t, seen):
        if t.as_pointer() in seen:
            return None
        seen.add(t.as_pointer())
        for n in t.nodes:
            if n.type == 'GROUP' and n.node_tree:
                if n.node_tree.name.startswith("FABRIC LOOK"):
                    return n
                r = find(n.node_tree, seen)
                if r:
                    return r
    return find(mat.node_tree, set())


class THUMA_PT_fabric(bpy.types.Panel):
    bl_label = "Тканина"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Thuma"

    @classmethod
    def poll(cls, context):
        return any(m.get("thuma_fabric") for m in bpy.data.materials)

    def draw_header_preset(self, context):
        self.layout.label(text=".".join(map(str, ADDON_VERSION)))

    def draw(self, context):
        c = self.layout.column()
        r_ = c.row(align=True)                              # 1.10.1: перенос налаштувань тканини — на самому верху
        r_.scale_y = 1.2
        r_.operator("thuma.settings_export", text="Експорт налаштувань", icon='EXPORT')
        r_.operator("thuma.settings_import", text="Імпорт налаштувань", icon='IMPORT')
        c.separator()
        if _wood_node():
            _draw_combo(c, context)                     # 1.13.0: розцвітка клієнта -> таблиця CFRender
        c.prop(context.scene, "thuma_fabric_pick", text="")
        if _wood_node():
            c.prop(context.scene, "thuma_wood_pick", text="Дерево")
            rw = c.row(align=True)                      # 1.11.0: усі налаштування дерева одним файлом
            rw.operator("thuma.wood_export", text="Дерево: експорт", icon='EXPORT')
            rw.operator("thuma.wood_import", text="Дерево: імпорт", icon='IMPORT')
            _draw_wood_sync(c, context)                 # 1.12.0: налаштування Євгена з сайту
        if context.space_data.shading.type in {'SOLID', 'WIREFRAME'}:
            c.label(text="Вьюпорт у Solid — тканину видно в Material Preview", icon='INFO')
        _draw_parts_mask(c, context)
        _draw_update(c)                     # 1.9.0: пульт у сцені старіший за аддон -> кнопка оновлення
        node = _look_node(_current())
        if not node:
            c.label(text="Storyboard — пульта нема")
            return
        # 1.1.0: увесь пульт згортається; кожна зона — окремий блок, що згортається
        root_h, root = c.panel("thuma_fl_root", default_closed=False)
        root_h.label(text="FABRIC LOOK цієї тканини", icon='MATERIAL')
        _eye(root_h, "__ALL__", "")
        root_h.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False).scope = 'ALL'
        root_h.operator("thuma.update_look", text="", icon='FILE_REFRESH', emboss=False)
        if root is not None:
            _draw_look(root, node)
        _draw_custom(c, context)


_ANG = ("Ф", "Л", "П")
_ANG_KIND = {"яскр.": "Яскравість за ракурсом", "нас.": "Насиченість за ракурсом"}


def _draw_socks(col, socks):
    """1.7.0: звичайні повзунки — як були; «яскр. Ф/Л/П», «нас. Ф/Л/П» — одним рядком за ракурсом кадру."""
    ang = {}
    for suf, s in socks:
        k, _, a = suf.rpartition(" ")
        if a in _ANG and k in _ANG_KIND:
            ang.setdefault(k, {})[a] = s
            continue
        col.prop(s, "default_value", text=suf[:1].upper() + suf[1:])
    for k, d in ang.items():
        r = col.row(align=True)
        r.label(text=_ANG_KIND[k] + ":")
        for a in _ANG:
            if a in d:
                r.prop(d[a], "default_value", text=a)


def _draw_look(c, node):
    rows = []                      # (панель, [(зона, [(суфікс, сокет)])])
    for it in node.node_tree.interface.items_tree:
        if it.item_type == 'PANEL':
            rows.append((it, []))
        elif it.in_out == 'INPUT' and it.name != "Колір":
            s = node.inputs.get(it.name)
            if s is None or s.is_linked:
                continue
            zone, _, suf = it.name.partition(": ")
            if not suf:
                zone, suf = "", it.name
            if not rows:
                rows.append((None, []))
            zl = rows[-1][1]
            if not zl or zl[-1][0] != zone:
                zl.append((zone, []))
            zl[-1][1].append((suf, s))
    for i, (pan, zones) in enumerate(rows):
        if pan is not None:
            head, body = c.panel(f"thuma_fl_{i}", default_closed=getattr(pan, "default_closed", False))
            head.label(text=pan.name, icon=_PANEL_ICON.get(pan.name, 'NONE'))
            if body is None:
                continue
        else:
            body = c
        if pan is not None and pan.name.startswith("Кутик"):
            kb = body.box()
            kb.label(text="Пензель кутика (на виділеному модулі):", icon='BRUSH_DATA')
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Дорисувати", icon='ADD').mode = 'ADD'
            r.operator("thuma.kutik_paint", text="Стерти", icon='REMOVE').mode = 'ERASE'
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Готово", icon='CHECKMARK').mode = 'DONE'
            r.operator("thuma.kutik_paint", text="Очистити модуль", icon='TRASH').mode = 'CLEAR'
        if pan is not None and pan.name == "Шви":
            sb = body.box()
            sb.label(text="Прибрати шов там, де не треба (на модулі):", icon='BRUSH_DATA')
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Прибрати пензлем", icon='REMOVE').mode = 'PAINT_OFF'
            r.operator("thuma.seam_off", text="Повернути пензлем", icon='ADD').mode = 'PAINT_ON'
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Прибрати з виділених", icon='FACESEL').mode = 'SEL_OFF'
            r.operator("thuma.seam_off", text="Повернути виділеним", icon='FACESEL').mode = 'SEL_ON'
            r = sb.row(align=True)
            r.operator("thuma.seam_off", text="Готово", icon='CHECKMARK').mode = 'DONE'
            r.operator("thuma.seam_off", text="Усі шви на модулі", icon='LOOP_BACK').mode = 'CLEAR'
        if pan is not None and pan.name == "Шви":
            # 1.15.0: шви по зонах — одна таблиця «група | сила × | ширина ×», без окремих блоків
            glob = [(z, sk) for z, sk in zones if z == "Шви"]
            groups = [(z, sk) for z, sk in zones if z.startswith("Шви ")]
            for z, sk in glob:
                col = body.box().column(align=True)
                _draw_socks(col, sk)
            if groups:
                tb = body.box().column(align=True)
                hr = tb.row(align=True)
                hr.label(text="Множники по зонах")
                hr.label(text="Сила ×"); hr.label(text="Ширина ×")
                names = "|".join(sock.name for _, sk in groups for _, sock in sk)
                o = hr.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = names
                for z, sk in groups:
                    r = tb.row(align=True)
                    r.label(text=z[4:])
                    d = {suf: sock for suf, sock in sk}
                    for key in ("сила ×", "ширина ×"):
                        if key in d:
                            r.prop(d[key], "default_value", text="")
                        else:
                            r.label(text="")
            continue
        many = len(zones) > 1
        for j, (zone, socks) in enumerate(zones):
            if many:                                   # кожна зона окремо згортається
                zh, zb = body.panel(f"thuma_fz_{i}_{j}", default_closed=False)
                zh.label(text=zone or pan.name, icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(zh, zone or pan.name, "|".join(sock.name for _, sock in socks))
                o = zh.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                if zb is None:
                    continue
                col = zb.box().column(align=True)              # 1.8.0: рамка навколо зони
            else:
                b = body.column()
                hr = b.row()
                hr.label(text=zone or (pan.name if pan is not None else ""), icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(hr, zone or (pan.name if pan is not None else ""), "|".join(sock.name for _, sock in socks))
                o = hr.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                col = b.column(align=True)
            _draw_socks(col, socks)


# ---------------- 1.1.0: СВОЇ ЗОНИ (вибрані полігони конкретної моделі) ----------------
# Зберігаються на МЕШІ (модель): Mesh.thuma_zones (налаштування) + атрибут граней tc_z<id> (які полігони).
# Сумарний результат усіх зон моделі -> атрибут вершин tc_cust (x = яскравість-1, y = насиченість-1);
# FABRIC LOOK множить на (1+x), (1+y). Нема атрибута -> 0 -> без змін. Префікс tc_ (не fz_) — пересбірка
# пульта атрибути fz_* перераховує, а ці не чіпає.
_GRAPH = {}


def _ups_mesh(ob):
    return ob is not None and ob.type == 'MESH' and ob.data in _meshes()


def _graph(me):
    """Сусідство вершин по ребрах (кеш). У Edit Mode — з BMesh (масиви меша тоді неактуальні)."""
    import numpy as np
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        key = (me.name, "edit", len(bm.verts), len(bm.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.array([v.co[:] for v in bm.verts], np.float32)
        ev = np.array([(e.verts[0].index, e.verts[1].index) for e in bm.edges], np.int64).reshape(-1, 2)
    else:
        key = (me.name, len(me.vertices), len(me.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ev = np.empty(len(me.edges) * 2, np.int32); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
    a = np.concatenate([ev[:, 0], ev[:, 1]]); b = np.concatenate([ev[:, 1], ev[:, 0]])
    w = np.linalg.norm(co[a] - co[b], axis=1)
    o = np.argsort(a, kind='stable')
    a, b, w = a[o], b[o], w[o]
    start = np.searchsorted(a, np.arange(len(co) + 1))
    _GRAPH.clear()
    _GRAPH[key] = (start.tolist(), b.tolist(), w.tolist())
    return _GRAPH[key]


def _zone_vmask(me, z):
    """Вершини полігонів зони (у Edit Mode — з шару BMesh)."""
    import numpy as np
    name = f"tc_z{z.uid}"
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        vm = np.zeros(len(bm.verts), bool)
        lay = bm.faces.layers.bool.get(name)
        if lay is None:
            return vm
        for f in bm.faces:
            if f[lay]:
                for v in f.verts:
                    vm[v.index] = True
        return vm
    nv = len(me.vertices)
    at = me.attributes.get(name)
    vm = np.zeros(nv, bool)
    if at is None or len(at.data) != len(me.polygons):
        return vm
    fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
    vm[lv[np.repeat(fm, lt)]] = True
    return vm


def _zone_weights(me, z):
    """Вага зони на вершинах: 1 на її полігонах, плавно до 0 на відстані «Перехід» (по тканині)."""
    import heapq
    import numpy as np
    vm = _zone_vmask(me, z)
    w = vm.astype(np.float32)
    W = z.transition * 0.01
    if W <= 0.0005 or not vm.any():
        return w
    start, nb, wt = _graph(me)
    d = {int(i): 0.0 for i in np.nonzero(vm)[0]}
    h = [(0.0, i) for i in d]
    heapq.heapify(h)
    while h:
        dv, v = heapq.heappop(h)
        if dv > d.get(v, 9.0):
            continue
        for k in range(start[v], start[v + 1]):
            u = nb[k]; nd = dv + wt[k]
            if nd < W and nd < d.get(u, 9.0):
                d[u] = nd
                heapq.heappush(h, (nd, u))
    for i, dv in d.items():
        t = dv / W
        w[i] = max(w[i], 1.0 - t * t * (3 - 2 * t))
    return w


def _rebuild(me):
    import numpy as np
    if me.is_editmode:
        import bmesh
        nv = len(bmesh.from_edit_mesh(me).verts)
    else:
        nv = len(me.vertices)
    # 1.7.0: три шари за ракурсом — tc_cust = Ф, tc_cust_l = Л, tc_cust_r = П (FABRIC LOOK ≥ v7.12 бере за ракурсом кадру)
    lay_names = {"f": "tc_cust", "l": "tc_cust_l", "r": "tc_cust_r"}
    B = {a: np.ones(nv, np.float32) for a in lay_names}
    S = {a: np.ones(nv, np.float32) for a in lay_names}
    for z in me.thuma_zones:
        if not z.enabled:
            continue
        w = _zone_weights(me, z)
        for a in lay_names:
            B[a] *= 1.0 + (z.bright * getattr(z, "b_" + a) - 1.0) * w
            S[a] *= 1.0 + (z.sat * getattr(z, "s_" + a) - 1.0) * w
    vecs = {a: np.stack([B[a] - 1.0, S[a] - 1.0, np.zeros(nv, np.float32)], 1) for a in lay_names}
    if me.is_editmode:
        # 1.1.1: у Edit Mode меш живе в BMesh — пишемо туди (пряма запис падала / губилась при виході)
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        if len(bm.verts) == nv:
            for a, nm in lay_names.items():
                lay = bm.verts.layers.float_vector.get(nm) or bm.verts.layers.float_vector.new(nm)
                for v, d in zip(bm.verts, vecs[a].tolist()):
                    v[lay] = d
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return
    for a, nm in lay_names.items():
        at = me.attributes.get(nm)
        if at is not None and (at.domain != 'POINT' or at.data_type != 'FLOAT_VECTOR' or len(at.data) != nv):
            me.attributes.remove(at)             # 1.1.4: битий шар (напр. з 1.1.0, створений в Edit Mode) — перестворити
            at = None
        if at is None:
            at = me.attributes.new(nm, 'FLOAT_VECTOR', 'POINT')
        at.data.foreach_set("vector", vecs[a].ravel())
    me.update()


def _upd(self, context):
    try:
        _rebuild(self.id_data)
    except Exception as e:                      # не валити UI помилкою під час руху повзунка
        print("[Thuma Fabric] своя зона:", e)


class THUMA_Zone(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Назва", default="Зона", description="Назва зони (двічі клікни, щоб перейменувати)")
    uid: bpy.props.IntProperty()
    enabled: bpy.props.BoolProperty(name="Увімкнено", default=True, update=_upd,
                                    description="Тимчасово вимкнути цю зону (без видалення)")
    bright: bpy.props.FloatProperty(name="Яскравість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                    description="Яскравість вибраних полігонів. 1 = без змін, менше = темніше")
    sat: bpy.props.FloatProperty(name="Насиченість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість вибраних полігонів. 1 = без змін, 0 = сіре")
    transition: bpy.props.FloatProperty(name="Перехід, см", default=0.0, min=0.0, soft_max=30.0, update=_upd,
                                        description="Наскільки плавно зміна заходить на сусідні полігони (по тканині), см. 0 = різко")
    # 1.7.0: за РАКУРСОМ кадру — множники поверх яскравості/насиченості. Ф = фронт-кадри,
    # Л/П = кадри 3/4, де видно лівий/правий бік дивана. Інші ракурси не змінюються. 1 = без змін
    b_f: bpy.props.FloatProperty(name="Ф", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на ФРОНТ-кадрах. Множник, 1 = без змін")
    b_l: bpy.props.FloatProperty(name="Л", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на кадрах 3/4, де видно ЛІВИЙ бік дивана (напр. 2, 24, 27, 29). Множник, 1 = без змін")
    b_r: bpy.props.FloatProperty(name="П", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на кадрах 3/4, де видно ПРАВИЙ бік дивана (напр. 3, 23, 26, 30). Множник, 1 = без змін")
    s_f: bpy.props.FloatProperty(name="Ф", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на ФРОНТ-кадрах. Множник, 1 = без змін")
    s_l: bpy.props.FloatProperty(name="Л", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на кадрах 3/4, де видно ЛІВИЙ бік дивана. Множник, 1 = без змін")
    s_r: bpy.props.FloatProperty(name="П", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на кадрах 3/4, де видно ПРАВИЙ бік дивана. Множник, 1 = без змін")


def _mode(mode, back=False):
    """mode_set, що не падає на модулі, прихованому в цьому кадрі (видимість конфігурацій анімована).
    Вийти в Object Mode — завжди можна (на мить знімаємо приховування). Повернутись у Edit (back=True) —
    лише якщо видно; інакше тихо лишаємось в Object. Повертає True/False."""
    try:
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        pass
    ob = bpy.context.view_layer.objects.active
    if back or ob is None or mode != 'OBJECT':
        return False
    hv, hs = ob.hide_viewport, ob.hide_get()
    try:
        ob.hide_viewport = False
        ob.hide_set(False)
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        return False
    finally:
        ob.hide_viewport = hv
        ob.hide_set(hs)


def _enter_paint(op, context):
    """Увійти у Vertex Paint; на прихованому модулі — зрозуміле повідомлення замість помилки."""
    if context.mode == 'PAINT_VERTEX':
        return True
    if not _mode('VERTEX_PAINT'):
        op.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        return False
    return True


def _sel_faces(context, ob):
    """Виділені полігони (з Edit Mode синхронізуємо)."""
    import numpy as np
    was_edit = context.mode == 'EDIT_MESH'
    if was_edit:
        _mode('OBJECT')
    me = ob.data
    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
    if was_edit:
        _mode('EDIT', back=True)
    return sel


def _config_of(ob):
    """Колекція конфігурації (дочірня «Product»), у якій лежить об'єкт."""
    prod = bpy.data.collections.get("Product")
    if prod is None:
        return None
    for c in prod.children:
        if ob.name in c.all_objects:
            return c
    return None


def _split_for_config(ob):
    """Окрема копія моделі для ЦІЄЇ конфігурації (усі такі модулі в ній). Повертає новий меш."""
    cfg = _config_of(ob)
    me = ob.data
    if cfg is None:
        return None, None
    if me.get("tc_config") == cfg.name:            # уже окрема для цієї конфігурації
        return me, cfg
    new = me.copy()
    new.name = f"{me.get('tc_base', me.name)} [{cfg.name[:24]}]"
    new["tc_config"] = cfg.name
    new["tc_base"] = me.get("tc_base", me.name)
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = new
    return new, cfg


def _split_for_object(ob):
    """1.7.0: окрема копія моделі ЛИШЕ ДЛЯ ЦЬОГО МОДУЛЯ (об'єкта). У конфігурації часто стоять два однакові
    модулі (напр. два Corner) — копія на всю конфігурацію фарбувала обидва."""
    me = ob.data
    if me.get("tc_object") == ob.name and me.users == 1:      # уже окрема для цього модуля
        return me
    new = me.copy()
    base = me.get("tc_base", me.name)
    new.name = f"{base} [{ob.name[-24:]}]"
    new["tc_object"] = ob.name
    new["tc_base"] = base
    if "tc_config" in new:
        del new["tc_config"]
    ob.data = new
    return new


def _unsplit(ob):
    """Повернути модулі цієї конфігурації до спільної моделі (окрема копія видаляється, якщо більше не потрібна)."""
    me = ob.data
    base = bpy.data.meshes.get(me.get("tc_base", ""))
    if base is not None and me.get("tc_object"):             # 1.7.0: окрема копія одного модуля
        ob.data = base
        if me.users == 0:
            bpy.data.meshes.remove(me)
        return True
    cfg = _config_of(ob)
    if base is None or cfg is None or me.get("tc_config") is None:
        return False
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = base
    if me.users == 0:
        bpy.data.meshes.remove(me)
    return True


class THUMA_OT_zone(bpy.types.Operator):
    bl_idname = "thuma.custom_zone"
    bl_label = "Своя зона"
    bl_options = {'REGISTER', 'UNDO'}
    action: bpy.props.EnumProperty(items=[('ADD', "Нова", ""), ('ADD_CFG', "Нова — лише ця конфігурація", ""),
                                          ('UNSPLIT', "Повернути до спільної моделі", ""), ('ASSIGN', "Перепризначити", ""),
                                          ('SELECT', "Показати", ""), ('REMOVE', "Видалити", ""),
                                          ('SEAM', "До шва", ""), ('EDIT', "Вибрати полігони", "")])
    index: bpy.props.IntProperty(default=-1)

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Нова зона УСЮДИ: на всіх таких модулях у всіх конфігураціях (спершу виділи полігони в Edit Mode)",
                'ADD_CFG': "Нова зона ЛИШЕ НА ЦЬОМУ МОДУЛІ (виділеному об'єкті): він отримає окрему копію моделі, "
                           "однакові модулі поруч і в інших конфігураціях не зміняться. Зони «усюди», змінені пізніше, "
                           "на цю копію не перейдуть",
                'UNSPLIT': "Повернути цей модуль до спільної моделі (зони «лише цей модуль» зникнуть)",
                'ASSIGN': "Замінити полігони зони на поточне виділення",
                'SELECT': "Виділити полігони цієї зони (перейде в Edit Mode)",
                'REMOVE': "Видалити зону",
                'SEAM': "Розширити виділення до швів — увесь шматок тканини між швами",
                'EDIT': "Перейти в Edit Mode (режим полігонів), щоб виділити потрібні"}[props.action]

    def execute(self, context):
        import numpy as np
        ob = context.active_object
        if not _ups_mesh(ob):
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по тканині дивана)")
            return {'CANCELLED'}
        me = ob.data
        if self.action == 'EDIT':
            if context.mode != 'EDIT_MESH':
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except RuntimeError:
                    self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
                    return {'CANCELLED'}
            context.tool_settings.mesh_select_mode = (False, False, True)
            return {'FINISHED'}
        if self.action == 'SEAM':
            if context.mode != 'EDIT_MESH':
                self.report({'WARNING'}, "Спершу виділи хоча б один полігон у Edit Mode")
                return {'CANCELLED'}
            bpy.ops.mesh.select_linked(delimit={'SEAM'})
            return {'FINISHED'}
        # 1.1.1: усі зміни даних меша — в Object Mode, потім повертаємось у той режим, що був
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            _mode('OBJECT')
        try:
            ok = self._apply(context, me)
        except Exception as e:
            self.report({'ERROR'}, f"Своя зона: {e}")
            ok = False
        if was_edit and context.mode != 'EDIT_MESH':
            try:                                   # 1.2.1: прихований у цьому кадрі об'єкт не пускає в Edit Mode — лишаємось в Object
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                pass
        return {'FINISHED'} if ok else {'CANCELLED'}

    def _apply(self, context, me):
        import numpy as np
        if self.action == 'UNSPLIT':
            if not _unsplit(context.active_object):
                self.report({'WARNING'}, "Ця модель і так спільна")
                return False
            return True
        if self.action == 'ADD_CFG':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            me = _split_for_object(context.active_object)
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid} (лише цей модуль)"
            _rebuild(me)
            return True
        if self.action == 'ADD':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid}"
            _rebuild(me)
            return True
        if not (0 <= self.index < len(me.thuma_zones)):
            return False
        z = me.thuma_zones[self.index]
        if self.action == 'ASSIGN':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            at = me.attributes.get(f"tc_z{z.uid}") or me.attributes.new(f"tc_z{z.uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            _rebuild(me)
        elif self.action == 'SELECT':
            at = me.attributes.get(f"tc_z{z.uid}")
            if at is None:
                return False
            fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
            me.polygons.foreach_set("select", fm)
            try:
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        elif self.action == 'REMOVE':
            name = f"tc_z{z.uid}"
            me.thuma_zones.remove(self.index)
            try:                                  # 1.1.4: битий шар зони не заважає видаленню
                at = me.attributes.get(name)
                if at is not None:
                    me.attributes.remove(at)
            except Exception as e:
                print("[Thuma Fabric] видалення шару зони:", e)
            _rebuild(me)
        return True


def _draw_custom(c, context):
    head, body = c.panel("thuma_custom_root", default_closed=False)
    head.label(text="Свої зони (вибрані полігони)", icon='FACESEL')
    if body is None:
        return
    ob = context.active_object
    if not _ups_mesh(ob):
        body.label(text="Виділи модуль оббивки (клік по тканині)", icon='INFO')
        return
    me = ob.data
    if me.get("tc_object"):
        bx = body.box()
        bx.label(text=f"Окрема модель: лише цей модуль ({me['tc_object']})", icon='LINKED')
        bx.operator("thuma.custom_zone", text="Повернути до спільної моделі", icon='UNLINKED').action = 'UNSPLIT'
    elif me.get("tc_config"):
        bx = body.box()
        bx.label(text=f"Окрема модель: лише «{me['tc_config']}»", icon='LINKED')
        bx.operator("thuma.custom_zone", text="Повернути до спільної моделі", icon='UNLINKED').action = 'UNSPLIT'
    else:
        body.label(text=f"Модель: {me.name} (спільна для всіх конфігурацій)", icon='MESH_DATA')
    r = body.row(align=True)
    r.operator("thuma.custom_zone", text="Вибрати полігони", icon='EDITMODE_HLT').action = 'EDIT'
    r.operator("thuma.custom_zone", text="До шва", icon='MOD_EDGESPLIT').action = 'SEAM'
    rn = body.row(align=True)
    rn.operator("thuma.custom_zone", text="Нова зона — усюди", icon='ADD').action = 'ADD'
    rn.operator("thuma.custom_zone", text="— лише цей модуль", icon='OBJECT_DATA').action = 'ADD_CFG'
    for i, z in enumerate(me.thuma_zones):
        zh, zb = body.panel(f"thuma_cz_{z.uid}", default_closed=False)
        row = zh.row(align=True)
        row.prop(z, "enabled", text="", icon='HIDE_OFF' if z.enabled else 'HIDE_ON', emboss=False)
        row.label(text=z.name, icon='FACESEL')
        o = row.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False); o.scope = 'CUSTOM'; o.index = i
        if zb is None:
            continue
        zb.prop(z, "name", text="Назва")
        col = zb.column(align=True)
        col.prop(z, "bright"); col.prop(z, "sat"); col.prop(z, "transition")
        for lab, pre in (("Яскравість за ракурсом:", "b_"), ("Насиченість за ракурсом:", "s_")):
            r = col.row(align=True)
            r.label(text=lab)
            for a in "flr":
                r.prop(z, pre + a)
        rr = zb.row(align=True)
        o = rr.operator("thuma.custom_zone", text="Показати", icon='RESTRICT_SELECT_OFF'); o.action = 'SELECT'; o.index = i
        o = rr.operator("thuma.custom_zone", text="Перепризначити", icon='FILE_REFRESH'); o.action = 'ASSIGN'; o.index = i
        o = rr.operator("thuma.custom_zone", text="", icon='TRASH'); o.action = 'REMOVE'; o.index = i


class THUMA_OT_kutik_paint(bpy.types.Operator):
    bl_idname = "thuma.kutik_paint"
    bl_label = "Пензель кутика"
    bl_description = ("Малювати маску кутика прямо на модулі (Vertex Paint). Дорисувати — додати затемнення, "
                      "Стерти — прибрати там, де не треба. Модуль спільний: однакові модулі в сцені зміняться разом")
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('ADD', "Дорисувати", "Додати затемнення кутика пензлем"),
                                        ('ERASE', "Стерти", "Прибрати затемнення там, де не треба"),
                                        ('DONE', "Готово", "Вийти з малювання"),
                                        ('CLEAR', "Очистити модуль", "Прибрати все намальоване на цьому модулі")])

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Пензель: червоний = додати затемнення кутика (видно, якщо «Кутик: яскравість» < 1 або «Показати зони»)",
                'ERASE': "Пензель: зелений = стерти затемнення там, де воно не потрібне",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Прибрати все намальоване на виділеному модулі (повернути автоматичний кутик)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        ob = context.active_object
        if not ob or ob.type != 'MESH' or ob.data not in _meshes():
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        me = ob.data
        ca = me.color_attributes.get("fz_kutik")
        if ca is None:
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
        if self.mode == 'CLEAR':
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
            me.update()
            return {'FINISHED'}
        me.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = (1.0, 0.0, 0.0) if self.mode == 'ADD' else (0.0, 1.0, 0.0)
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по модулю. " + ("Червоний = додати" if self.mode == 'ADD' else "Зелений = стерти"))
        return {'FINISHED'}


SEAM_OFF = "tc_seam_off"


def _seam_attr(me):
    import numpy as np
    ca = me.color_attributes.get(SEAM_OFF)
    if ca is None:
        ca = me.color_attributes.new(SEAM_OFF, 'BYTE_COLOR', 'POINT')
        ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
    return ca


class THUMA_OT_seam_off(bpy.types.Operator):
    """Прибрати підкреслення шва на окремих місцях модуля (напр. ззаду, де шов не потрібен)"""
    bl_idname = "thuma.seam_off"
    bl_label = "Прибрати шов"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('PAINT_OFF', "Прибрати пензлем", ""), ('PAINT_ON', "Повернути пензлем", ""),
                                        ('PAINT_BOOST', "Посилити шов пензлем", ""),
                                        ('SEL_OFF', "Прибрати з виділених", ""), ('SEL_ON', "Повернути виділеним", ""),
                                        ('DONE', "Готово", ""), ('CLEAR', "Усі шви на модулі", "")])

    @classmethod
    def description(cls, context, props):
        return {'PAINT_OFF': "Пензель: червоний = тут шов НЕ підкреслювати. Модуль спільний: однакові модулі в сцені зміняться разом",
                'PAINT_ON': "Пензель: чорний = повернути шов як був (стирає і «прибрати», і «посилити»)",
                'PAINT_BOOST': "Пензель: зелений = зробити шов ТЕМНІШИМ саме тут (до ×3 при повному натиску), незалежно від зон. "
                               "Сила пензля = наскільки посилити. Модуль спільний: однакові модулі зміняться разом",
                'SEL_OFF': "Edit Mode: виділи полігони біля шва і натисни — шов на них прибереться",
                'SEL_ON': "Edit Mode: повернути шов на виділених полігонах",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Повернути всі шви на виділеному модулі (стерти все прибране)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        obs = [o for o in ({context.active_object} | set(context.selected_objects)) if o]
        obs = [o for o in obs if o.type == 'MESH' and o.data in _meshes()]
        if not obs:
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        if self.mode in ('SEL_OFF', 'SEL_ON', 'CLEAR'):
            was_edit = context.mode == 'EDIT_MESH'
            if was_edit:
                _mode('OBJECT')
            n = 0
            for me in {o.data for o in obs}:
                ca = _seam_attr(me)
                col = np.empty(len(ca.data) * 4, np.float32); ca.data.foreach_get("color", col); col = col.reshape(-1, 4)
                if self.mode == 'CLEAR':
                    col[:, :3] = 0.0
                else:
                    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
                    if not sel.any():
                        continue
                    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
                    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
                    vi = np.unique(lv[np.repeat(sel, lt)])
                    col[vi, 0] = 1.0 if self.mode == 'SEL_OFF' else 0.0
                    col[vi, 1:3] = 0.0
                    n += int(sel.sum())
                ca.data.foreach_set("color", col.ravel()); me.update()
            if was_edit:
                _mode('EDIT', back=True)
            if self.mode != 'CLEAR' and not n:
                self.report({'WARNING'}, "Нічого не виділено: Edit Mode, виділи полігони біля шва")
                return {'CANCELLED'}
            return {'FINISHED'}
        ob = context.active_object if context.active_object in obs else obs[0]
        context.view_layer.objects.active = ob
        ca = _seam_attr(ob.data)
        ob.data.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = {'PAINT_OFF': (1.0, 0.0, 0.0), 'PAINT_BOOST': (0.0, 1.0, 0.0)}.get(self.mode, (0.0, 0.0, 0.0))
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по шву. " + {'PAINT_OFF': "Червоний = прибрати шов", 'PAINT_BOOST': "Зелений = посилити шов"}
                    .get(self.mode, "Чорний = повернути як було"))
        return {'FINISHED'}


# ── Маска деталей для WireColor (Face) ──────────────────────────────────────────
# Меш має номер деталі на кожному полігоні (атрибут wc_part, розфарбовує скрипт wc_parts_paint.py; палітра —
# scene["wc_parts_palette"]). «По модулях»: колір деталі модуля (спинка модуля, ліва боковина модуля...).
# «По конфігураціях»: деталь — за місцем у зібраному дивані (фронт = дивиться вперед збірки, зовнішня боковина =
# лише крайня боковина збірки ...). Робиться GN-модифікатором WC_FaceConfig на кожен об'єкт (свої кольори для
# кожного номера деталі). WireColor >= 3.7 вмикає модифікатори WC_Face* лише на час Face-маски — звичайний рендер
# їх не бачить.
PARTS_MOD, PARTS_GROUP = "WC_FaceConfig", "WC Face Config"
_EXT = {"Фронт": (0, -1), "Задня стінка": (0, 1), "Боковина зовн. ліва": (-1, 0), "Боковина зовн. права": (1, 0)}
_INN = {"Спинка": (0, -1), "Боковина внутр. ліва": (1, 0), "Боковина внутр. права": (-1, 0)}
_WOOD = {"Дерево: фронт": (0, -1), "Дерево: зад": (0, 1), "Дерево: бік лівий": (-1, 0), "Дерево: бік правий": (1, 0)}


def _palette(scene):
    import json
    raw = scene.get("wc_parts_palette")
    return json.loads(raw) if raw else None


def _parts_group(pal):
    ng = bpy.data.node_groups.get(PARTS_GROUP)
    if ng and len([i for i in ng.interface.items_tree if getattr(i, "in_out", "") == 'INPUT']) == len(pal) + 1:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = bpy.data.node_groups.new(PARTS_GROUP, 'GeometryNodeTree')
    it = ng.interface
    it.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    for name, _c in pal:
        it.new_socket(name, in_out='INPUT', socket_type='NodeSocketColor')
    it.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); gi.location = (-700, 0)
    go = N.new('NodeGroupOutput'); go.location = (500, 0)
    pa = N.new('GeometryNodeInputNamedAttribute'); pa.data_type = 'INT'; pa.location = (-450, 300)
    pa.inputs["Name"].default_value = "wc_part"
    sw = N.new('GeometryNodeIndexSwitch'); sw.data_type = 'RGBA'; sw.location = (-200, 0)
    while len(sw.index_switch_items) < len(pal):
        sw.index_switch_items.new()
    L.new(pa.outputs["Attribute"], sw.inputs[0])
    for i in range(len(pal)):
        L.new(gi.outputs[i + 1], sw.inputs[i + 1])
    st = N.new('GeometryNodeStoreNamedAttribute'); st.data_type = 'FLOAT_COLOR'; st.domain = 'CORNER'
    st.location = (150, 0); st.inputs["Name"].default_value = "wc_mask_color"
    L.new(gi.outputs[0], st.inputs["Geometry"]); L.new(sw.outputs[0], st.inputs["Value"])
    L.new(st.outputs["Geometry"], go.inputs["Geometry"])
    return ng


def _set_input(mod, ident, value):
    props = getattr(mod, "properties", None)
    if props is not None and hasattr(props, "inputs"):
        getattr(props.inputs, ident).value = value
    else:
        mod[ident] = value


def _config_mapping(scene):
    """{ім'я об'єкта: {деталь модуля: деталь у збірці}} для всіх конфігурацій (колекції в «Product»)."""
    import math
    from mathutils import Vector
    cur = scene.frame_current
    first = {}
    obs_all = [o for o in scene.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential")]
    for f in range(scene.frame_start, scene.frame_end + 1):
        scene.frame_set(f)
        for o in obs_all:
            if o.name not in first and o.visible_get():
                first[o.name] = f

    def snap(x, y):
        return (int(round(x)), int(round(y)))
    out = {}
    # збірка = усе, що видно РАЗОМ у кадрі, де об'єкт з'являється вперше (в одній колекції бувають
    # кілька окремих модулів, кожен у своєму кадрі)
    for fr_ in sorted(set(first.values())):
        scene.frame_set(fr_)
        obs = [o for o in obs_all if o.visible_get()]
        targets = {o.name for o in obs_all if first.get(o.name) == fr_}
        if not obs or not targets:
            continue
        dg = bpy.context.evaluated_depsgraph_get()
        MW = {o.name: o.evaluated_get(dg).matrix_world.copy() for o in obs}
        rot = bpy.data.objects.get("Control_Rotation")
        ang = rot.evaluated_get(dg).matrix_world.to_euler().z if rot else 0.0
        yaw = {}
        for o in obs:
            vx = MW[o.name].to_3x3() @ Vector((1, 0, 0))
            yaw[o.name] = math.atan2(vx.y, vx.x) - ang
        up = [o for o in obs if o.dimensions.z > 0.2] or obs
        s4 = sum(math.sin(4 * yaw[o.name]) for o in up)
        c4 = sum(math.cos(4 * yaw[o.name]) for o in up)
        phi = math.atan2(s4, c4) / 4                      # спільний «нахил» збірки
        if len(up) == 1:                                  # один модуль (напр. шезлонг під 45°) — його власний перед
            phi = yaw[up[0].name]
        for o in obs:
            if o.name not in targets:
                continue
            a = yaw[o.name] - phi
            ex = snap(math.cos(a), math.sin(a))
            ey = snap(-math.sin(a), math.cos(a))

            def to_cfg(d, ex=ex, ey=ey):
                return (d[0] * ex[0] + d[1] * ey[0], d[0] * ex[1] + d[1] * ey[1])
            inv = MW[o.name].inverted()
            pts = [inv @ (MW[n.name] @ Vector(c)) for n in obs for c in n.bound_box]
            amn = (min(p.x for p in pts), min(p.y for p in pts))
            amx = (max(p.x for p in pts), max(p.y for p in pts))
            bb = [Vector(c) for c in o.bound_box]
            mmn = (min(c.x for c in bb), min(c.y for c in bb))
            mmx = (max(c.x for c in bb), max(c.y for c in bb))

            def extreme(d, amn=amn, amx=amx, mmn=mmn, mmx=mmx):   # бік модуля d (локально) — на краю збірки?
                k = 0 if d[0] else 1
                return abs((mmx[k] - amx[k]) if (d[0] + d[1]) > 0 else (mmn[k] - amn[k])) < 0.06
            m = {}
            for name, d in _EXT.items():
                D = to_cfg(d)
                if D == (0, -1):
                    m[name] = "Фронт"
                elif D == (0, 1):
                    m[name] = "Задня стінка"
                elif extreme(d):
                    m[name] = "Боковина зовн. ліва" if D == (-1, 0) else "Боковина зовн. права"
                else:
                    m[name] = "Фронт бічний" if name == "Фронт" else "Стик (схований бік)"
            for name, d in _INN.items():
                D = to_cfg(d)
                m[name] = ("Спинка" if D[0] == 0 else "Боковина внутр. ліва" if D == (1, 0) else "Боковина внутр. права")
            for name, d in _WOOD.items():
                D = to_cfg(d)
                if D == (0, -1):
                    m[name] = "Дерево: фронт"
                elif D == (0, 1):
                    m[name] = "Дерево: зад"
                elif extreme(d):
                    m[name] = "Дерево: бік лівий" if D == (-1, 0) else "Дерево: бік правий"
                else:
                    m[name] = "Дерево: фронт бічний" if name == "Дерево: фронт" else "Дерево: стик"
            out[o.name] = m
    scene.frame_set(cur)
    return out


def _face_mask_active(scene):
    p = getattr(scene, "wc_props", None)
    return bool(p and p.preview_active and p.preview_mode == 'FACE')


class THUMA_OT_parts_mask(bpy.types.Operator):
    """Маска деталей для WireColor Face: по модулях або по місцю в зібраній конфігурації"""
    bl_idname = "thuma.parts_mask"
    bl_label = "Маска деталей"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('MODULE', "По модулях", ""), ('CONFIG', "По конфігураціях", "")])

    @classmethod
    def description(cls, context, props):
        if props.mode == 'MODULE':
            return "Деталі як у модуля: спинка, ліва/права боковина МОДУЛЯ… Однаково на всіх моделях"
        return ("Деталі за місцем у ЗІБРАНОМУ дивані: фронт = дивиться вперед, зовнішня боковина = лише крайня, "
                "фронт бічний = фронти бокової частини L/П… Для автоматизації в Photoshop. "
                "Рахує всі конфігурації (~10-30 с)")

    def execute(self, context):
        sc = context.scene
        for o in bpy.data.objects:
            m = o.modifiers.get(PARTS_MOD)
            if m is not None:
                o.modifiers.remove(m)
        if self.mode == 'MODULE':
            self.report({'INFO'}, "Маска деталей: по модулях")
            return {'FINISHED'}
        pal = _palette(sc)
        if not pal:
            self.report({'WARNING'}, "У сцені нема розфарбування деталей (wc_parts_paint.py)")
            return {'CANCELLED'}
        idx = {n: i for i, (n, _c) in enumerate(pal)}
        ng = _parts_group(pal)
        ids = [i.identifier for i in ng.interface.items_tree
               if getattr(i, "in_out", "") == 'INPUT' and i.socket_type == 'NodeSocketColor']
        mapping = _config_mapping(sc)
        on = _face_mask_active(sc)
        n = 0
        for o in sc.objects:
            if o.type != 'MESH' or "wc_part" not in o.data.attributes:
                continue
            mp = mapping.get(o.name, {})
            mod = o.modifiers.new(PARTS_MOD, 'NODES')
            mod.node_group = ng
            mod.show_viewport = mod.show_render = on
            mod.show_in_editmode = True
            try:
                o.modifiers.move(len(o.modifiers) - 1, 0)         # першим — колір об'єкта WireColor іде після
            except Exception:
                pass
            for i, (name, _c) in enumerate(pal):
                tgt = mp.get(name, name)
                _set_input(mod, ids[i], tuple(pal[idx.get(tgt, i)][1]) + (1.0,))
            n += 1
        self.report({'INFO'}, f"Маска деталей по конфігураціях: {n} об'єктів ({len(mapping)} у конфігураціях)")
        return {'FINISHED'}


def _draw_parts_mask(c, context):
    if not _palette(context.scene):
        return
    h, b = c.panel("thuma_parts_mask", default_closed=True)
    h.label(text="Маска деталей (WireColor Face)", icon='FACESEL')
    if b is None:
        return
    cfg = any(o.modifiers.get(PARTS_MOD) for o in context.scene.objects if o.type == 'MESH')
    r = b.row(align=True)
    r.operator("thuma.parts_mask", text="По модулях", depress=not cfg).mode = 'MODULE'
    r.operator("thuma.parts_mask", text="По конфігураціях", depress=cfg).mode = 'CONFIG'
    b.label(text="Показ: WireColor → Перегляд Face", icon='INFO')


class THUMA_OT_reset(bpy.types.Operator):
    bl_idname = "thuma.reset"
    bl_label = "Скинути до стандартних"
    bl_options = {'REGISTER', 'UNDO'}
    scope: bpy.props.EnumProperty(items=[('ALL', "Увесь пульт", ""), ('ZONE', "Зона", ""), ('CUSTOM', "Своя зона", "")])
    names: bpy.props.StringProperty()
    index: bpy.props.IntProperty(default=-1)

    @classmethod
    def description(cls, context, props):
        return {'ALL': "Скинути ВСІ повзунки FABRIC LOOK цієї тканини до стандартних (Ctrl+Z — повернути)",
                'ZONE': "Скинути повзунки цієї зони до стандартних",
                'CUSTOM': "Скинути цю свою зону: яскравість 1, насиченість 1, перехід 0, за ракурсом 1 (полігони лишаються)"}[props.scope]

    def invoke(self, context, event):
        if self.scope == 'ALL':
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        if self.scope == 'CUSTOM':
            ob = context.active_object
            if not _ups_mesh(ob) or not (0 <= self.index < len(ob.data.thuma_zones)):
                return {'CANCELLED'}
            z = ob.data.thuma_zones[self.index]
            z.bright, z.sat, z.transition = 1.0, 1.0, 0.0
            z.b_f = z.b_l = z.b_r = z.s_f = z.s_l = z.s_r = 1.0
            return {'FINISHED'}
        node = _look_node(_current())
        if not node:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        only = set(self.names.split("|")) if self.scope == 'ZONE' else None
        n = 0
        for sock in node.inputs:
            if sock.name == "Колір" or sock.is_linked or sock.name not in defaults:
                continue
            if only is not None and sock.name not in only:
                continue
            try:
                sock.default_value = defaults[sock.name]; n += 1
            except Exception:
                pass
        self.report({'INFO'}, f"Скинуто повзунків: {n}")
        return {'FINISHED'}


def _eye(layout, key, names):
    mat = _current()
    off = bool(mat and mat.get(f"tc_eye_{key}"))
    o = layout.operator("thuma.eye", text="", icon='HIDE_ON' if off else 'HIDE_OFF', emboss=False, depress=off)
    o.key = key; o.names = names


class THUMA_OT_eye(bpy.types.Operator):
    """Глазик: вимкнути налаштування зони (показати «до»), повторний клік — повернути"""
    bl_idname = "thuma.eye"
    bl_label = "Порівняти до/після"
    bl_options = {'REGISTER', 'UNDO'}
    key: bpy.props.StringProperty()
    names: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, props):
        mat = _current()
        if mat and mat.get(f"tc_eye_{props.key}"):
            return "Повернути налаштування цієї зони (зараз показано «до»)"
        return ("Тимчасово вимкнути ВЕСЬ пульт цієї тканини — порівняти до/після" if props.key == "__ALL__"
                else "Тимчасово вимкнути налаштування цієї зони — порівняти до/після. Ще клік — повернути")

    def execute(self, context):
        import json
        mat = _current(); node = _look_node(mat)
        if not node:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        prop = f"tc_eye_{self.key}"
        if mat.get(prop):                                  # повернути
            stash = json.loads(mat[prop])
            for name, v in stash.items():
                sock = node.inputs.get(name)
                if sock is None or sock.is_linked:
                    continue
                cur = sock.default_value
                d = defaults.get(name)
                # якщо поки «око» було вимкнене, користувач змінив повзунок — лишаємо його нове значення
                same = (abs(cur - d) < 1e-6) if isinstance(d, (int, float)) and isinstance(cur, (int, float)) else True
                if same:
                    sock.default_value = v
            del mat[prop]
        else:                                               # вимкнути: запам'ятати і поставити стандартні
            only = None if self.key == "__ALL__" else set(self.names.split("|"))
            stash = {}
            for sock in node.inputs:
                if sock.name == "Колір" or sock.is_linked or sock.name not in defaults or sock.name == "Показати зони":
                    continue
                if only is not None and sock.name not in only:
                    continue
                v = sock.default_value
                if hasattr(v, "__len__"):
                    continue
                stash[sock.name] = v
                sock.default_value = defaults[sock.name]
            mat[prop] = json.dumps(stash, ensure_ascii=False)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# кольори = як у «Показати зони» FABRIC LOOK (приглушені значки колекцій)
_ZONE_ICON = {
    "Спинка": 'COLLECTION_COLOR_05', "Сидіння": 'COLLECTION_COLOR_04',
    "Боковина внутр. ліва": 'COLLECTION_COLOR_07', "Боковина внутр. права": 'COLLECTION_COLOR_06',
    "Боковина зовн. ліва": 'COLLECTION_COLOR_02', "Боковина зовн. права": 'COLLECTION_COLOR_08',
    "Верх": 'COLLECTION_COLOR_03', "Фронт": 'COLLECTION_COLOR_01', "Задня стінка": 'COLORSET_07_VEC',
    "Вся тканина": 'MATERIAL', "Кутик": 'MOD_LINEART',
    # 1.8.0: нові зони — кольори як у «Показати зони» (рожевий/фіолетовий відтінок своєї боковини)
    "Низ внутр. ліва": 'COLORSET_05_VEC', "Низ внутр. права": 'COLORSET_06_VEC',
    "Кут": 'LIGHT_SUN', "Шви": 'MOD_EDGESPLIT',
}
_PANEL_ICON = {"Шви": 'MOD_EDGESPLIT', "Загальне": 'MATERIAL', "Перевірка і плавність": 'HIDE_OFF',
               "Кутик біля підлокітника": 'MOD_LINEART', "Спинка й сидіння": 'MESH_PLANE',
               "Боковини ліві": 'TRIA_LEFT', "Боковини праві": 'TRIA_RIGHT', "Верх": 'TRIA_UP',
               "Фронт і зад": 'ARROW_LEFTRIGHT', "Фронт-кадри: кут біля боковини": 'LIGHT_SUN'}


# ── Дерево: перемикач порід по одній (вузол WOOD у Thuma_Wood_Finger-Joints_4K = 1..5) ─────────────
# Сам вузол Value крокує стрілками по 0.1 — тут список назв, що ставить рівно 1..5. Торці йдуть за ним драйвером.
WOOD_MAT = "Thuma_Wood_Finger-Joints_4K"
WOODS = [("1", "Natural", "Порода 1 — Natural"), ("2", "Oak", "Порода 2 — Oak"), ("3", "Walnut", "Порода 3 — Walnut"),
         ("4", "Espresso", "Порода 4 — Espresso"), ("5", "Grey", "Порода 5 — Grey")]
_WOOD_ITEMS = [(k, n, d, 'NODE_MATERIAL', i) for i, (k, n, d) in enumerate(WOODS)]


# ---------------- 1.13.0: «Розцвітка клієнта» -> тканина + порода + вкладка таблиці імен у CFRender ----------------
# Таблиця «Thuma Essential Seating - Render Names» (Google Sheets): одна вкладка = одна розцвітка = один прохід рендеру.
# Пара (порода, тканина) унікальна -> вкладка. Оновлено 2026-10-09 (клієнт змінив дерево в 06, 07, 10, 11, 12; 15 = дивани/крісло).
_SHEET_EDIT = "https://docs.google.com/spreadsheets/d/1hXnVX7JrIPy2Pw0mU9nbxp7_oin6dguNm9kVNvGlaEk/edit#gid="
_COMBOS = [   # (вкладка, порода, тип тканини в назві матеріалу, колір, gid, опис)
    ("01 es-ptwca", "Espresso", "Textured-Weave", "Carbon", "223742172", "жовта, усі ракурси"),
    ("02 gr-ptwna", "Grey", "Textured-Weave", "Natural", "618829161", "жовта, усі ракурси"),
    ("03 na-pmwllg", "Natural", "Medium-Weight-Linen", "Light-Grey", "1077433968", "жовта, усі ракурси"),
    ("04 oa-ptwiv", "Oak", "Textured-Weave", "Ivory", "619437790", "жовта, усі ракурси"),
    ("05 wa-ptwmo", "Walnut", "Textured-Weave", "Mocha", "695187515", "жовта, усі ракурси"),
    ("06 es-bouch", "Espresso", "Boucle", "Charcoal", "1822028066", "лише Front"),
    ("07 wa-boumo", "Walnut", "Boucle", "Mocha", "333760420", "лише Front"),
    ("08 gr-bouna", "Grey", "Boucle", "Natural", "1211732320", "лише Front"),
    ("09 gr-bouwh", "Grey", "Boucle", "White", "1947524051", "лише Front"),
    ("10 es-pmwlch", "Espresso", "Medium-Weight-Linen", "Charcoal", "319420377", "лише Front"),
    ("11 wa-pmwlmo", "Walnut", "Medium-Weight-Linen", "Mocha", "585179511", "лише Front"),
    ("12 oa-pmwlna", "Oak", "Medium-Weight-Linen", "Natural", "2044830885", "лише Front, без диванів/крісла"),
    ("13 gr-pmwlwh", "Grey", "Medium-Weight-Linen", "White", "1580439330", "лише Front"),
    ("14 gr-pmwllg", "Grey", "Medium-Weight-Linen", "Light-Grey", "1232537119", "лише дивани й крісло"),
    ("15 gr-pmwlna", "Grey", "Medium-Weight-Linen", "Natural", "1705406437", "лише дивани й крісло"),
]


def _combo_mat(c):
    return f"Thuma_Performance-{c[2]}_{c[3]}_4K"


def _current_combo():
    mat = _current()
    n = _wood_node()
    if mat is None or n is None:
        return None
    wood = WOODS[min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)][1]
    return next((c for c in _COMBOS if c[1] == wood and _combo_mat(c) == mat.name), None)


def _sync_cfr(scene=None):
    """Поставити в CFRender посилання на вкладку поточної розцвітки (якщо така є в таблиці)."""
    scene = scene or bpy.context.scene
    c = _current_combo()
    props = getattr(scene, "cfrender_props", None)
    if c is None or props is None:
        return None
    url = _SHEET_EDIT + c[4]
    if props.sheets_url != url:
        props.sheets_url = url
    return c


def _combo_items(self, context):
    return _COMBO_ITEMS


_COMBO_ITEMS = [(c[0], f"{c[0]}  {c[1]} + {c[3].replace('-', ' ')} ({c[2].replace('-', ' ')})",
                 f"{c[1]} + {c[3]} {c[2]} — {c[5]}. Ставить тканину, породу і вкладку таблиці імен у CFRender", i)
                for i, c in enumerate(_COMBOS)]


def _combo_get(self):
    c = _current_combo()
    return _COMBOS.index(c) if c else 0               # нема пари -> показуємо 01, але панель пише попередження


def _combo_set(self, value):
    c = _COMBOS[value]
    sc = bpy.context.scene
    if bpy.data.materials.get(_combo_mat(c)) is None:
        print("[Thuma Fabric] нема матеріалу", _combo_mat(c))
        return
    sc.thuma_fabric_pick = _combo_mat(c)
    sc.thuma_wood_pick = next(k for k, n, _d in WOODS if n == c[1])
    _sync_cfr(sc)


def _draw_combo(c, context):
    sc = context.scene
    cur = _current_combo()
    bx = c.box()
    r0 = bx.row(align=True)
    r0.prop(sc, "thuma_combo_pick", text="Розцвітка")
    r0.operator("thuma.combo_queue", text="", icon='SEQUENCE')
    if cur is None:
        r = bx.row(); r.alert = True
        r.label(text="Такої пари дерево + тканина нема в таблиці клієнта", icon='ERROR')
    else:
        props = getattr(sc, "cfrender_props", None)
        if props is None:
            bx.label(text=f"Таблиця імен: {cur[0]} (CFRender не встановлено)", icon='INFO')
        elif props.sheets_url.strip() == _SHEET_EDIT + cur[4]:
            bx.label(text=f"CFRender: вкладка {cur[0]} ({cur[5]})", icon='CHECKMARK')
        else:
            r = bx.row(); r.alert = True
            r.label(text=f"У CFRender інша таблиця", icon='ERROR')
            r.operator("thuma.combo_sync", text=f"Поставити {cur[0]}", icon='URL')


def _cfr_sheet_hook(scene, url):
    """Хук черги таблиць Frame Render (CFRender ≥1.8): перед вкладкою поставити її тканину й породу."""
    import re as _r
    m = _r.search(r"gid=(\d+)", url or "")
    c = next((x for x in _COMBOS if m and x[4] == m.group(1)), None)
    if c is None or bpy.data.materials.get(_combo_mat(c)) is None:
        return
    scene.thuma_fabric_pick = _combo_mat(c)
    scene.thuma_wood_pick = next(k for k, n, _d in WOODS if n == c[1])
    print(f"[Thuma Fabric] черга Frame Render: {c[0]} -> {c[1]} + {c[3]} {c[2]}")


class THUMA_OT_combo_queue(bpy.types.Operator):
    bl_idname = "thuma.combo_queue"
    bl_label = "Розцвітки -> черга Frame Render"
    bl_description = ("Додати всі 15 розцвіток клієнта в «Чергу таблиць» Frame Render (без галочок — відміть потрібні). "
                      "Під час рендеру черги перед кожною розцвіткою сама ставиться її тканина й порода")

    def execute(self, context):
        props = getattr(context.scene, "cfrender_props", None)
        if props is None or not hasattr(props, "sheet_queue"):
            self.report({'WARNING'}, "Потрібен Frame Render (Custom Frame Render) 1.8+")
            return {'CANCELLED'}
        have = {it.url: it for it in props.sheet_queue}
        n = 0
        for c, item in zip(_COMBOS, _COMBO_ITEMS):
            url = _SHEET_EDIT + c[4]
            it = have.get(url) or props.sheet_queue.add()
            if it.url != url:
                it.url = url; it.use = False; n += 1
            it.name = item[1]
        self.report({'INFO'}, f"Черга Frame Render: {len(_COMBOS)} розцвіток (нових {n}). Відміть потрібні й тисни Render queue")
        return {'FINISHED'}


class THUMA_OT_combo_sync(bpy.types.Operator):
    bl_idname = "thuma.combo_sync"
    bl_label = "Поставити таблицю імен у CFRender"
    bl_description = "Вставити в CFRender посилання на вкладку таблиці імен для поточної розцвітки (дерево + тканина)"

    def execute(self, context):
        c = _sync_cfr(context.scene)
        if c is None:
            self.report({'WARNING'}, "Нема такої розцвітки в таблиці або не встановлено CFRender")
            return {'CANCELLED'}
        self.report({'INFO'}, f"CFRender: {c[0]}")
        return {'FINISHED'}


def _wood_node():
    m = bpy.data.materials.get(WOOD_MAT)
    return m.node_tree.nodes.get("WOOD") if m and m.node_tree else None


def _wood_get(self):
    n = _wood_node()
    if not n:
        return 0
    return min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)


def _wood_set(self, value):
    n = _wood_node()
    if n:
        n.outputs[0].default_value = float(value + 1)
        try:
            _sync_cfr()                                 # 1.13.0: таблиця імен у CFRender за розцвіткою
        except Exception as e:
            print("[Thuma Fabric] CFRender sync:", e)
        for a in bpy.context.screen.areas if bpy.context.screen else []:
            a.tag_redraw()


# ---------------- 1.9.0: оновлення пульта FABRIC LOOK у будь-якій сцені ----------------
# Збирач пульта і розмітка зон їдуть усередині аддона (папка fl/). Номер збірки — FL_VERSION у fl/fabric_look_v7.py;
# у сцені він записаний як FABRIC LOOK["fl_version"]. Старіший -> у панелі кнопка «Оновити пульт».
import os as _os
import re as _re
_FL_DIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "fl")
_FL_FILE = _os.path.join(_FL_DIR, "fabric_look_v7.py")


def _fl_version():
    try:
        m = _re.search(r"^FL_VERSION\s*=\s*(\d+)", open(_FL_FILE, encoding="utf-8").read(), _re.M)
        return int(m.group(1)) if m else 0
    except OSError:
        return 0


_FL_VER = _fl_version()


def _scene_fl_version():
    g = bpy.data.node_groups.get("FABRIC LOOK")
    return int(g.get("fl_version", 0)) if g else None


class THUMA_OT_update_look(bpy.types.Operator):
    bl_idname = "thuma.update_look"
    bl_label = "Оновити пульт FABRIC LOOK"
    bl_description = ("Перезібрати пульт FABRIC LOOK і розмітку зон у ЦІЙ сцені до версії з аддона. Усі значення "
                      "повзунків, пензель кутика, свої зони й шви зберігаються. Займає ~30-60 с. "
                      "Після — збережи файл як нову версію")
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Оновити пульт FABRIC LOOK?",
                                                     message="~30-60 с, Blender не відповідатиме. Значення зберігаються.")

    def execute(self, context):
        if not _os.path.exists(_FL_FILE):
            self.report({'ERROR'}, "У аддоні нема збирача пульта (fl/) — перевстанови Thuma Fabric")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        wm = context.window_manager
        wm.progress_begin(0, 1)
        try:
            if _FL_DIR not in sys.path:
                sys.path.insert(0, _FL_DIR)
            ns = {"__file__": _FL_FILE, "__name__": "thuma_fl_builder"}
            exec(compile(open(_FL_FILE, encoding="utf-8").read(), _FL_FILE, "exec"), ns)
            res = ns["upgrade"]()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Оновлення пульта: {e}")
            return {'CANCELLED'}
        finally:
            wm.progress_end()
        bad = res.get("bad_links") if isinstance(res, dict) else None
        self.report({'WARNING'} if bad else {'INFO'},
                    f"Пульт оновлено до збірки {_FL_VER}" + (f"; перевір матеріали: {', '.join(bad)}" if bad else ""))
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


def _draw_update(c):
    cur = _scene_fl_version()
    if cur is None or not _FL_VER:
        return
    if cur < _FL_VER:
        bx = c.box()
        bx.alert = True
        bx.label(text=f"Пульт у сцені старіший (збірка {cur} < {_FL_VER})", icon='ERROR')
        bx.operator("thuma.update_look", text="Оновити пульт FABRIC LOOK", icon='FILE_REFRESH')


import sys  # noqa: E402


# ---------------- 1.10.0: ЕКСПОРТ / ІМПОРТ налаштувань однієї тканини (JSON) ----------------
# Що переноситься: усі повзунки FABRIC LOOK цієї тканини + незв'язані значення вузлів її матеріалу
# (і груп, що належать лише цьому матеріалу: текстура, Color Match тощо) + метод дисплейсменту.
# Старі назви повзунків — за тією ж таблицею, що й «Оновити пульт».
_FL_MIGRATE = {"Верх спинки": ["Верх"],
               "Боковини внутрішні": ["Боковина внутр. ліва", "Боковина внутр. права"],
               "Боковини зовнішні": ["Боковина зовн. ліва", "Боковина зовн. права"]}
_FL_FULL = {"Верх: колір тону": "Вся тканина: колір тону", "Верх: сила тону": "Вся тканина: сила тону",
            "Фронт: ліва боковина внутр.": "Кут: ліва боковина", "Фронт: спинка біля лівої": "Кут: спинка",
            "Фронт: ширина, см": "Кут: ширина, см", "Фронт: згасання до країв": "Кут: згасання до країв",
            "Фронт: боковина, довжина": "Кут: довжина боковини"}
_SKIP_TREES = ("FABRIC LOOK", "WOOD LOOK")
_SEP = " >> "                 # розділювач шляху група >> вузол (у назвах вузлів буває «/»)


def _jval(v):
    if isinstance(v, (bool, int, float, str)):
        return v
    try:
        return [float(x) for x in v]
    except TypeError:
        return None


def _sock_vals(socks):
    out = {}
    for sk in socks:
        if sk.is_linked or not hasattr(sk, "default_value") or getattr(sk, "hide_value", False):
            continue
        v = _jval(sk.default_value)
        if v is not None:
            out[sk.identifier] = [sk.name, v]
    return out


def _own(t):
    """Група належить лише одному матеріалу (фейковий користувач не рахується)."""
    return t.users - (1 if t.use_fake_user else 0) <= 1


def _walk_nodes(tree, prefix, look, acc, seen, own_only=True, skip_names=()):
    for n in tree.nodes:
        if n == look or n.name in skip_names:
            continue
        key = prefix + n.name
        d = {}
        iv = _sock_vals(n.inputs)
        if iv:
            d["in"] = iv
        if n.type == 'VALUE':
            d["value"] = float(n.outputs[0].default_value)
        if d:
            acc[key] = d
        t = getattr(n, "node_tree", None) if n.type == 'GROUP' else None
        if t and not t.name.startswith(_SKIP_TREES) and (not own_only or _own(t)) and t.as_pointer() not in seen:
            seen.add(t.as_pointer())
            _walk_nodes(t, key + _SEP, look, acc, seen, own_only, skip_names)


def _find_node(tree, path, own_only=True):
    parts = path.split(_SEP)
    for i, nm in enumerate(parts):
        n = tree.nodes.get(nm)
        if n is None:
            return None
        if i == len(parts) - 1:
            return n
        tree = getattr(n, "node_tree", None)
        if tree is None or (own_only and not _own(tree)) or tree.name.startswith(_SKIP_TREES):
            return None
    return None


def _apply_nodes(tree, nodes, own_only=True):
    ok = miss = 0
    for path, d in nodes.items():
        n = _find_node(tree, path, own_only)
        if n is None:
            miss += 1
            continue
        for ident, (name, v) in d.get("in", {}).items():
            sk = next((x for x in n.inputs if x.identifier == ident), None) or n.inputs.get(name)
            if sk is not None and not sk.is_linked and _set_sock(sk, v):
                ok += 1
        if "value" in d and n.type == 'VALUE':
            n.outputs[0].default_value = d["value"]; ok += 1
    return ok, miss


from bpy_extras.io_utils import ExportHelper as _EH, ImportHelper as _IH  # noqa: E402


# ---------------- 1.11.0: ДЕРЕВО — експорт/імпорт усіх налаштувань (усі породи, торці, grain, спільні групи) ----
def _wood_mats():
    return [m for m in bpy.data.materials if m.node_tree and ("Wood" in m.name or "WOOD" in m.name)]


class THUMA_OT_wood_export(bpy.types.Operator, _EH):
    bl_idname = "thuma.wood_export"
    bl_label = "Експорт налаштувань дерева"
    bl_description = ("Зберегти ВСІ налаштування дерева у файл .json: усі породи (пульти WOOD LOOK), торці (End-Grain), "
                      "grain, спільні групи (Wood Fiber Contrast+Tint) — щоб колеги завантажили їх кнопкою «Імпорт»")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = "Thuma_wood_settings.json"
        return super().invoke(context, event)

    def execute(self, context):
        import json
        mats = _wood_mats()
        if not mats:
            self.report({'WARNING'}, "У сцені нема матеріалів дерева")
            return {'CANCELLED'}
        data = {"thuma_wood_settings": 1, "addon": list(ADDON_VERSION), "materials": {}}
        n = 0
        for m in mats:
            nodes = {}
            _walk_nodes(m.node_tree, "", None, nodes, set(), own_only=False, skip_names=("WOOD",))
            data["materials"][m.name] = {"displacement_method": m.displacement_method, "nodes": nodes}
            n += len(nodes)
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        self.report({'INFO'}, f"Дерево: {len(mats)} матеріали, {n} вузлів -> {self.filepath}")
        return {'FINISHED'}


class THUMA_OT_wood_import(bpy.types.Operator, _IH):
    bl_idname = "thuma.wood_import"
    bl_label = "Імпорт налаштувань дерева"
    bl_description = ("Застосувати налаштування дерева з файлу .json (усі породи, торці, grain, спільні групи). "
                      "Вибрана порода (WOOD) не змінюється. Ctrl+Z — відмінити")
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        import json
        try:
            data = json.load(open(self.filepath, encoding="utf-8"))
        except Exception as e:
            self.report({'ERROR'}, f"Не прочитав файл: {e}")
            return {'CANCELLED'}
        if not data.get("thuma_wood_settings"):
            self.report({'ERROR'}, "Це не файл налаштувань дерева Thuma")
            return {'CANCELLED'}
        ok = miss = 0
        absent = []
        for name, md in data.get("materials", {}).items():
            m = bpy.data.materials.get(name)
            if m is None or not m.node_tree:
                absent.append(name)
                continue
            a, b = _apply_nodes(m.node_tree, md.get("nodes", {}), own_only=False)
            ok += a; miss += b
            try:
                m.displacement_method = md.get("displacement_method", m.displacement_method)
            except Exception:
                pass
        msg = f"Дерево: застосовано значень {ok}"
        if miss:
            msg += f"; вузлів нема в цій сцені: {miss}"
        if absent:
            msg += f"; матеріалів нема: {', '.join(absent)}"
        self.report({'WARNING'} if (miss or absent) else {'INFO'}, msg)
        for a_ in context.screen.areas:
            a_.tag_redraw()
        return {'FINISHED'}


def _set_sock(sk, v):
    try:
        sk.default_value = v
        return True
    except Exception:
        return False


def _export_data(mat):
    look = _look_node(mat)
    fl = {}
    if look:
        for sk in look.inputs:
            if sk.name != "Колір" and not sk.is_linked and hasattr(sk, "default_value"):
                v = _jval(sk.default_value)
                if v is not None:
                    fl[sk.name] = v
    nodes = {}
    _walk_nodes(mat.node_tree, "", look, nodes, set())
    g = bpy.data.node_groups.get("FABRIC LOOK")
    return {"thuma_fabric_settings": 1, "material": mat.name, "addon": list(ADDON_VERSION),
            "fl_version": int(g.get("fl_version", 0)) if g else 0,
            "displacement_method": mat.displacement_method, "fabric_look": fl, "nodes": nodes}


def _import_data(mat, data):
    look = _look_node(mat)
    ok = 0
    missing = []
    if look:
        for k, v in data.get("fabric_look", {}).items():
            k = _FL_FULL.get(k, k)
            base, _, kind = k.partition(": ")
            names = [f"{b}: {kind}" for b in _FL_MIGRATE[base]] if base in _FL_MIGRATE else [k]
            hit = False
            for nm in names:
                sk = look.inputs.get(nm)
                if sk is not None and not sk.is_linked and _set_sock(sk, v):
                    ok += 1; hit = True
            if not hit:
                missing.append(k)
    n_ok, n_miss = _apply_nodes(mat.node_tree, data.get("nodes", {}))
    dm = data.get("displacement_method")
    if dm:
        try:
            mat.displacement_method = dm
        except Exception:
            pass
    return ok, missing, n_ok, n_miss


from bpy_extras.io_utils import ExportHelper as _EH, ImportHelper as _IH  # noqa: E402


class THUMA_OT_settings_export(bpy.types.Operator, _EH):
    bl_idname = "thuma.settings_export"
    bl_label = "Експорт налаштувань тканини"
    bl_description = ("Зберегти ВСІ налаштування поточної тканини (повзунки FABRIC LOOK + значення вузлів її "
                      "матеріалу) у файл .json — щоб перенести в іншу сцену кнопкою «Імпорт»")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        mat = _current()
        if mat:
            self.filepath = bpy.path.clean_name(mat.name) + ".json"
        return super().invoke(context, event)

    def execute(self, context):
        import json
        mat = _current()
        if not mat or not mat.get("thuma_fabric"):
            self.report({'WARNING'}, "Нема поточної тканини Thuma")
            return {'CANCELLED'}
        data = _export_data(mat)
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        self.report({'INFO'}, f"«{mat.name}»: {len(data['fabric_look'])} повзунків, {len(data['nodes'])} вузлів -> {self.filepath}")
        return {'FINISHED'}


class THUMA_OT_settings_import(bpy.types.Operator, _IH):
    bl_idname = "thuma.settings_import"
    bl_label = "Імпорт налаштувань тканини"
    bl_description = ("Застосувати налаштування з файлу .json до ПОТОЧНОЇ тканини (вибраної вгорі). Старі назви "
                      "повзунків переносяться автоматично; нові, яких у файлі нема, лишаються як є. Ctrl+Z — відмінити")
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        import json
        mat = _current()
        if not mat or not mat.get("thuma_fabric"):
            self.report({'WARNING'}, "Нема поточної тканини Thuma")
            return {'CANCELLED'}
        try:
            data = json.load(open(self.filepath, encoding="utf-8"))
        except Exception as e:
            self.report({'ERROR'}, f"Не прочитав файл: {e}")
            return {'CANCELLED'}
        if not data.get("thuma_fabric_settings"):
            self.report({'ERROR'}, "Це не файл налаштувань тканини Thuma")
            return {'CANCELLED'}
        ok, missing, n_ok, n_miss = _import_data(mat, data)
        msg = f"«{data.get('material')}» -> «{mat.name}»: повзунків {ok}, значень вузлів {n_ok}"
        if data.get("material") != mat.name:
            msg += " (УВАГА: файл від іншої тканини)"
        if missing:
            msg += f"; не знайшов {len(missing)} повзунків: {', '.join(missing[:6])}"
            print("[Thuma Fabric] імпорт: не знайдено повзунків:", missing)
        if n_miss:
            msg += f"; вузлів нема в цьому матеріалі: {n_miss}"
        self.report({'WARNING'} if (missing or data.get('material') != mat.name) else {'INFO'}, msg)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# ---------------- 1.12.0: «Налаштування Євгена» — дерево з командного сайту ----------------
# Євген: «Дерево: опублікувати» -> presets/thuma_wood.json (значення всіх порід/торців/grain) + thuma_wood_look.blend
# (сам пульт WOOD LOOK v2, точна копія) у репозиторій сайту + git push.
# Колеги: аддон раз на 2 год / при відкритті файлу читає thuma_wood.json; якщо stamp новіший за застосований у сцені —
# у панелі «Застосувати налаштування Євгена». Застосування: (якщо пульт інший) підмінити WOOD LOOK v2 копією з .blend,
# перев'язати за іменами, об'єкти WOOD_CENTER/Control_Rotation — свої; далі значення. Порода (WOOD) не змінюється.
import hashlib as _hl
import json as _json
import tempfile as _tf
import time as _time
_SITE = "https://grebenukevgen41-web.github.io/hrebeniuk-tools/presets/"
_OWNER_DIR = r"E:\disk_D\pROG\Thuma_prog\Blender\Extensions\_repo_github"
_WOOD_GROUP = "WOOD LOOK v2"
_REMOTE = {"wood": None, "checked": 0.0, "error": ""}


def _is_owner():
    return _os.path.isdir(_os.path.join(_OWNER_DIR, ".git"))


def _group_hash(g):
    if g is None:
        return ""
    sig = [g.name, len(g.nodes)] + sorted(f"{n.bl_idname}:{n.name}" for n in g.nodes) + \
          [f"{i.in_out}:{i.name}" for i in g.interface.items_tree if i.item_type == 'SOCKET'] + \
          sorted(f"{l.from_node.name}.{l.from_socket.identifier}>{l.to_node.name}.{l.to_socket.identifier}" for l in g.links)
    return _hl.md5("|".join(map(str, sig)).encode("utf-8")).hexdigest()


def _wood_export_dict():
    data = {"thuma_wood_settings": 1, "addon": list(ADDON_VERSION), "materials": {}}
    for m in _wood_mats():
        nodes = {}
        _walk_nodes(m.node_tree, "", None, nodes, set(), own_only=False, skip_names=("WOOD",))
        data["materials"][m.name] = {"displacement_method": m.displacement_method, "nodes": nodes}
    return data


def _wood_apply_values(data):
    ok = miss = 0
    for name, md in data.get("materials", {}).items():
        m = bpy.data.materials.get(name)
        if m is None or not m.node_tree:
            continue
        a, b = _apply_nodes(m.node_tree, md.get("nodes", {}), own_only=False)
        ok += a; miss += b
        try:
            m.displacement_method = md.get("displacement_method", m.displacement_method)
        except Exception:
            pass
    return ok, miss


def _swap_group(old, new):
    """Підмінити групу old на new у всіх вузлах-інстансах: значення й зв'язки — за іменами."""
    trees = [m.node_tree for m in bpy.data.materials if m.node_tree] + \
            [t for t in bpy.data.node_groups if t.bl_idname == 'ShaderNodeTree']
    inst = [n for t in trees for n in t.nodes if n.type == 'GROUP' and n.node_tree == old]
    for n in inst:
        vals = {x.name: (tuple(x.default_value) if hasattr(x.default_value, "__len__") else x.default_value)
                for x in n.inputs if hasattr(x, "default_value") and not x.is_linked}
        links = [(l.from_node.name, l.from_socket.name, l.to_node.name, l.to_socket.name)
                 for l in n.id_data.links if l.from_node == n or l.to_node == n]
        n.node_tree = new
        for k, v in vals.items():
            if n.inputs.get(k) is not None:
                _set_sock(n.inputs[k], v)
        t = n.id_data
        for fn, fs, tn, ts in links:
            a_, b_ = t.nodes.get(fn), t.nodes.get(tn)
            if a_ and b_ and a_.outputs.get(fs) and b_.inputs.get(ts):
                if not any(l.from_socket == a_.outputs[fs] and l.to_socket == b_.inputs[ts] for l in t.links):
                    t.links.new(a_.outputs[fs], b_.inputs[ts])
    return len(inst)


def _wood_apply_look(blend_path):
    """Взяти WOOD LOOK v2 з .blend і поставити замість свого (свої об'єкти, без дублів)."""
    before_obj = set(bpy.data.objects); before_act = set(bpy.data.actions); before_grp = set(bpy.data.node_groups)
    with bpy.data.libraries.load(blend_path, link=False) as (src, dst):
        dst.node_groups = [g for g in src.node_groups if g == _WOOD_GROUP]
    new = next((g for g in bpy.data.node_groups if g not in before_grp and g.name.startswith(_WOOD_GROUP)), None)
    if new is None:
        raise RuntimeError("у файлі пульта нема WOOD LOOK v2")
    import re as _r
    for o in [o for o in bpy.data.objects if o not in before_obj]:          # WOOD_CENTER.001 -> свій WOOD_CENTER
        base = bpy.data.objects.get(_r.sub(r"\.\d{3}$", "", o.name))
        if base is not None and base not in [o]:
            o.user_remap(base)
        bpy.data.objects.remove(o)
    for a in [a for a in bpy.data.actions if a not in before_act]:
        if a.users == 0:
            bpy.data.actions.remove(a)
    for g in [g for g in bpy.data.node_groups if g not in before_grp and g != new]:   # вкладені групи-дублі
        base = bpy.data.node_groups.get(_r.sub(r"\.\d{3}$", "", g.name))
        if base is not None and base != g:
            g.user_remap(base)
            bpy.data.node_groups.remove(g)
    old = bpy.data.node_groups.get(_WOOD_GROUP)
    n = _swap_group(old, new) if old is not None else 0
    if old is not None and old.users == 0:
        bpy.data.node_groups.remove(old)
    new.name = _WOOD_GROUP
    return n


def _fetch(name, binary=False, channel=""):
    import urllib.request
    req = urllib.request.Request(_SITE + (channel + "/" if channel else "") + name + f"?t={int(_time.time())}", headers={"Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=15) as r:
        b = r.read()
    return b if binary else _json.loads(b.decode("utf-8"))


def _check_remote():
    """Таймер: прочитати thuma_wood.json з сайту (без блокування UI надовго)."""
    try:
        if getattr(bpy.app, "online_access", True) and bpy.data.materials.get(WOOD_MAT):
            _REMOTE["wood"] = _fetch("thuma_wood.json"); _REMOTE["error"] = ""
    except Exception as e:
        _REMOTE["error"] = str(e)[:120]
    _REMOTE["checked"] = _time.time()
    for w in bpy.context.window_manager.windows if bpy.context.window_manager else []:
        for a in w.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()
    return 7200.0


@bpy.app.handlers.persistent
def _on_load(*_a):
    if not bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.register(_check_remote, first_interval=2.0)
    else:
        bpy.app.timers.register(lambda: (_check_remote(), None)[1], first_interval=2.0)


class THUMA_OT_wood_publish(bpy.types.Operator):
    bl_idname = "thuma.wood_publish"
    bl_label = "Дерево: опублікувати для команди"
    bl_description = ("Опублікувати ВСІ свої налаштування дерева (пульт WOOD LOOK, усі породи, торці, grain) на "
                      "командний сайт. У колег у панелі з'явиться «Застосувати налаштування Євгена»")
    out_dir: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})     # для тесту: без git
    no_push: bpy.props.BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    channel: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})    # "test" -> presets/test/ (колеги не бачать)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Опублікувати дерево для команди?",
                                                     message="Колеги зможуть застосувати твої налаштування дерева.")

    def execute(self, context):
        g = bpy.data.node_groups.get(_WOOD_GROUP)
        if g is None or not bpy.data.materials.get(WOOD_MAT):
            self.report({'WARNING'}, "У сцені нема дерева / пульта WOOD LOOK v2")
            return {'CANCELLED'}
        out = self.out_dir or _os.path.join(_OWNER_DIR, "presets", *([self.channel] if self.channel else []))
        _os.makedirs(out, exist_ok=True)
        data = _wood_export_dict()
        stamp = _time.strftime("%Y-%m-%d %H:%M:%S")
        data.update({"stamp": stamp, "look_hash": _group_hash(g), "look_file": "thuma_wood_look.blend",
                     "source": _os.path.basename(bpy.data.filepath)})
        bpy.data.libraries.write(_os.path.join(out, "thuma_wood_look.blend"), {g}, compress=True)
        with open(_os.path.join(out, "thuma_wood.json"), "w", encoding="utf-8") as f:
            _json.dump(data, f, ensure_ascii=False, indent=1)
        if not self.channel:
            context.scene["thuma_wood_preset"] = stamp        # у себе — уже застосовано
        if self.no_push or self.out_dir:
            self.report({'INFO'}, f"Дерево збережено в {out} (без публікації)")
            return {'FINISHED'}
        import subprocess, shutil
        git = shutil.which("git") or r"C:\Program Files\Git\cmd\git.exe"
        def run(*a):
            r = subprocess.run([git, "-C", _OWNER_DIR, *a], capture_output=True, text=True, encoding="utf-8", errors="replace")
            return r.returncode, (r.stdout + r.stderr).strip()
        run("add", "presets")
        code, outp = run("commit", "-m", f"Thuma: дерево {stamp}")
        if code != 0 and "nothing to commit" not in outp:
            self.report({'ERROR'}, f"git commit: {outp[:200]}")
            return {'CANCELLED'}
        code, outp = run("push", "-u", "origin", "HEAD:main")
        if code != 0:
            self.report({'ERROR'}, f"git push: {outp[:200]}")
            return {'CANCELLED'}
        if not self.channel:
            _REMOTE["wood"] = data
        self.report({'INFO'}, f"Дерево опубліковано ({stamp}{', канал ' + self.channel if self.channel else ''}). У колег з'явиться за ~1 хв")
        return {'FINISHED'}


class THUMA_OT_wood_apply_remote(bpy.types.Operator):
    bl_idname = "thuma.wood_apply_remote"
    bl_label = "Застосувати налаштування Євгена (дерево)"
    bl_description = ("Завантажити й застосувати налаштування дерева Євгена: пульт WOOD LOOK, усі породи, торці, grain. "
                      "Твої тканини, сцена і вибрана порода не змінюються. Після — збережи файл")
    bl_options = {'REGISTER', 'UNDO'}
    src_dir: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})     # для тесту: локальна папка
    channel: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        try:
            if self.src_dir:
                data = _json.load(open(_os.path.join(self.src_dir, "thuma_wood.json"), encoding="utf-8"))
            else:
                data = _fetch("thuma_wood.json", channel=self.channel)
            n_inst = 0
            if data.get("look_hash") and data["look_hash"] != _group_hash(bpy.data.node_groups.get(_WOOD_GROUP)):
                if self.src_dir:
                    bp = _os.path.join(self.src_dir, data.get("look_file", "thuma_wood_look.blend"))
                else:
                    bp = _os.path.join(_tf.gettempdir(), "thuma_wood_look.blend")
                    open(bp, "wb").write(_fetch(data.get("look_file", "thuma_wood_look.blend"), binary=True, channel=self.channel))
                n_inst = _wood_apply_look(bp)
            ok, miss = _wood_apply_values(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Не вдалося: {e}")
            return {'CANCELLED'}
        if not self.channel:
            context.scene["thuma_wood_preset"] = data.get("stamp", "")
            _REMOTE["wood"] = data
        msg = f"Дерево Євгена ({data.get('stamp')}) застосовано: значень {ok}"
        if n_inst:
            msg += f", пульт оновлено ({n_inst} вузлів)"
        if miss:
            msg += f"; нема в цій сцені вузлів: {miss}"
        self.report({'WARNING'} if miss else {'INFO'}, msg)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


def _draw_wood_sync(c, context):
    rem = _REMOTE.get("wood")
    if rem and rem.get("stamp") and context.scene.get("thuma_wood_preset") != rem.get("stamp"):
        bx = c.box()
        bx.alert = True
        bx.label(text=f"Нові налаштування дерева від Євгена ({rem.get('stamp')})", icon='INFO')
        bx.operator("thuma.wood_apply_remote", text="Застосувати налаштування Євгена", icon='IMPORT')
    if _is_owner():
        c.operator("thuma.wood_publish", text="Дерево: опублікувати для команди", icon='WORLD')


def register():
    bpy.types.Scene.thuma_fabric_pick = bpy.props.EnumProperty(
        name="Тканина", items=_items, get=_get, set=_set,
        description="Яку тканину поставити на всю оббивку (12 мешів). Матеріал стає в слот — його видно в Shader Editor")
    bpy.types.Scene.thuma_combo_pick = bpy.props.EnumProperty(
        name="Розцвітка", items=_combo_items, get=_combo_get, set=_combo_set,
        description="Розцвітка клієнта (дерево + тканина): ставить тканину, породу і вкладку таблиці імен у CFRender")
    bpy.utils.register_class(THUMA_OT_combo_sync)
    bpy.utils.register_class(THUMA_OT_combo_queue)
    hooks = bpy.app.driver_namespace.setdefault("cfrender_sheet_hooks", [])
    for h in [h for h in hooks if getattr(h, "__name__", "") == "_cfr_sheet_hook"]:
        hooks.remove(h)                                 # стара версія після перезавантаження аддона
    hooks.append(_cfr_sheet_hook)
    bpy.types.Scene.thuma_wood_pick = bpy.props.EnumProperty(
        name="Дерево", items=_WOOD_ITEMS, get=_wood_get, set=_wood_set,
        description="Порода дерева (вузол WOOD основного матеріалу дерева: рівно 1-5). Торці перемикаються разом")
    bpy.utils.register_class(THUMA_OT_kutik_paint)
    bpy.utils.register_class(THUMA_Zone)
    bpy.types.Mesh.thuma_zones = bpy.props.CollectionProperty(type=THUMA_Zone)
    bpy.utils.register_class(THUMA_OT_zone)
    bpy.utils.register_class(THUMA_OT_reset)
    bpy.utils.register_class(THUMA_OT_eye)
    bpy.utils.register_class(THUMA_OT_seam_off)
    bpy.utils.register_class(THUMA_OT_parts_mask)
    bpy.utils.register_class(THUMA_OT_update_look)
    bpy.utils.register_class(THUMA_OT_settings_export)
    bpy.utils.register_class(THUMA_OT_settings_import)
    bpy.utils.register_class(THUMA_OT_wood_export)
    bpy.utils.register_class(THUMA_OT_wood_import)
    bpy.utils.register_class(THUMA_OT_wood_publish)
    bpy.utils.register_class(THUMA_OT_wood_apply_remote)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    if not bpy.app.background and not bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.register(_check_remote, first_interval=3.0)
    bpy.utils.register_class(THUMA_PT_fabric)


def unregister():
    bpy.utils.unregister_class(THUMA_PT_fabric)
    bpy.utils.unregister_class(THUMA_OT_update_look)
    bpy.utils.unregister_class(THUMA_OT_settings_export)
    bpy.utils.unregister_class(THUMA_OT_settings_import)
    bpy.utils.unregister_class(THUMA_OT_wood_export)
    bpy.utils.unregister_class(THUMA_OT_wood_import)
    bpy.utils.unregister_class(THUMA_OT_wood_publish)
    bpy.utils.unregister_class(THUMA_OT_wood_apply_remote)
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.unregister(_check_remote)
    bpy.utils.unregister_class(THUMA_OT_kutik_paint)
    bpy.utils.unregister_class(THUMA_OT_zone)
    bpy.utils.unregister_class(THUMA_OT_reset)
    bpy.utils.unregister_class(THUMA_OT_eye)
    bpy.utils.unregister_class(THUMA_OT_seam_off)
    bpy.utils.unregister_class(THUMA_OT_parts_mask)
    del bpy.types.Mesh.thuma_zones
    bpy.utils.unregister_class(THUMA_Zone)
    del bpy.types.Scene.thuma_fabric_pick
    del bpy.types.Scene.thuma_wood_pick
    del bpy.types.Scene.thuma_combo_pick
    bpy.utils.unregister_class(THUMA_OT_combo_sync)
    bpy.utils.unregister_class(THUMA_OT_combo_queue)
    hooks = bpy.app.driver_namespace.get("cfrender_sheet_hooks", [])
    for h in [h for h in hooks if getattr(h, "__name__", "") == "_cfr_sheet_hook"]:
        hooks.remove(h)
