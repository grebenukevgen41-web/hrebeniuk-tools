bl_info = {
    "name": "Thuma Material",
    "author": "Hrebeniuk",
    "version": (1, 34, 0),
    "blender": (4, 2, 0),
    "location": "3D View > N > Thuma > Тканина",
    "description": "Thuma Material: тканини, дерево, торці — пульти FABRIC LOOK / WOOD LOOK (майстер-сцена Thuma)",
    "category": "Material",
}
ADDON_VERSION = tuple(bl_info["version"])
# 1.29.0: «Що нового» — показується один раз після оновлення (усе, що новіше за прочитану версію).
# Нова версія з помітною для колег зміною -> дописати рядок сюди (коротко, людською мовою).
ADDON_CHANGES = {
    (1, 22, 0): "Великі кнопки «Тканина / Дерево» нагорі; пульт дерева WOOD LOOK і окремо пульт торців-вставок "
                "(кнопки «Звичайне дерево / Торці»); «Економія пам'яті» — першим рядком",
    (1, 22, 8): "Пульти тканини й дерева: розділи в рамках, у зручному порядку; кожна зона — блок з глазиком "
                "«до/після» і скиданням; ракурси — таблицею",
    (1, 23, 0): "Кнопка «Перенести налаштування на іншу тканину»: вибрати тканину і галочками — які розділи",
    (1, 24, 0): "Панель «Оновлення моделі»: поворот UV передка боковини по шву (Right Arm Chaise +5°, Left −4°)",
    (1, 25, 0): "Панель «Оновлення моделі»: м'яка частина оттоманки вище на 0.1\"",
    (1, 26, 0): "Оновлення моделі ставлять саме значення Євгена (висоту й UV), навіть якщо їх змінювали вручну",
    (1, 27, 0): "Під кнопкою «Оновити пульт» — список, що саме зміниться",
    (1, 28, 0): "Після «Оновити пульт»: у таблиці ракурсів боковин і спинки рядок «Торець» — яскравість торця за ракурсом",
    (1, 29, 0): "Цей блок «Що нового» після кожного оновлення аддона",
    (1, 30, 0): "Розділ «Шви» простіший: людські назви, таблиці відкриті; «Ребро лівого підлокітника» з ракурсами; "
                "«Свої шви» — виділи ребра в Edit Mode і зроби свій шов (яскравість, ширина), один шов на кількох "
                "моделях. Натисни «Оновити пульт», потім у «Оновлення моделі» — «Застосувати»: прийдуть повороти UV "
                "торців спинки і шви Євгена",
    (1, 30, 1): "У «Що нового» і під «Оновити пульт» тепер видно, на які кадри впливає кожна зміна",
    (1, 30, 2): "Панель «Оновлення моделі»: під кожною правкою — на яких кадрах вона, і всі кадри разом",
    (1, 30, 3): "Пульт FL68 — натисни «Оновити пульт»: «Ребро лівого підлокітника» лише на справжньому лівому "
                "підлокітнику + на всю лінію лівого крила кутових диванів; прибрано з правого кутового модуля і з "
                "Left Arm Island. Значення не змінюються",
    (1, 30, 4): "Пульт FL69 — натисни «Оновити пульт»: торець внутрішніх боковин у шезлонгів (Left/Right Arm Chaise) "
                "трохи м'якший (× 0.9, як у кадрі клієнту). Повзунки не змінюються, Corner і решта моделей — без змін",
    (1, 30, 5): "Правка клієнта: у дереві прибрано вузол Bevel (шипи з'єднань не скошені). У панелі «Оновлення моделі» "
                "натисни «Застосувати» — і в основній сцені, і в сценах деталей (Details, Detail Hardware)",
    (1, 33, 4): "Лампочка 💡: частина зони, що ховається за моделлю (ззаду), тепер видно блакитним крізь модель; "
                "видима частина — жовта, як раніше",
    (1, 33, 3): "Черга таблиць / ферма: перед кожною таблицею знову ставиться її тканина й порода (після відкриття "
                "файла це губилось — рендерилась попередня тканина з іменами іншої таблиці). Скасовано зміну 1.33.2 "
                "для Right Arm Chaise — «Оновити пульт» (збірка 73)",
    (1, 33, 2): "Right Arm Chaise: рядок «Ребро лівого підлокітника» діє і на ребро його підлокітника "
                "(у моделі він правий). Потрібно «Оновити пульт» (збірка 72). Дивани, крісло й решта — без змін",
    (1, 33, 1): "Виділив модуль — у «Усі свої зони в сцені» і «Свої шви» його зони/шви позначені, решта приглушені",
    (1, 33, 0): "«Свої зони»: «Градієнт: верх × / низ × / плавність» — яскравість плавно змінюється згори вниз по висоті зони (напр. спинка світліша вгорі)",
    (1, 32, 3): "«Усі свої зони в сцені»: хрестик біля модуля — прибрати цей модуль із зони (на інших модулях зона лишається)",
    (1, 32, 2): "«Усі свої зони в сцені»: глазик біля кожної зони вмикає/вимикає її (раніше була галочка, що не натискалась)",
    (1, 32, 1): "«Свої зони»: у назві зони тепер видно всі її кадри (було «лише кадр 2», хоча діє на 2 і 3)",
    (1, 32, 0): "Лампочка 💡 біля швів і зон пульта тканини, дерева й торців: наведи або натисни — на 2 с жовтим видно, де саме цей шов чи зона в кадрі (сховане за диваном не світиться). Червона крапка в таблиці ракурсів = стовпчик, що діє в цьому кадрі. Пульт FL71 — «Оновити все»",
    (1, 31, 6): "Після «Оновити все» можна вільно крутити свої повзунки, висоту, шви — сцена більше не просить «оновитись» і нічого не повертає назад",
    (1, 31, 5): "Аддон тепер зветься Thuma Material (раніше Thuma Fabric) — усе інше без змін",
    (1, 31, 4): "Виправлено: у Євгена блок дерева більше не просить оновитись (кнопки для нього нема — його сцена і є зразок)",
    (1, 31, 3): "«Оновити все» не чіпає моделі, на яких ти зробив свої «Свої шви» — вони лишаються як є",
    (1, 31, 2): "Кнопка «Оновити все» тепер одна — лише нагорі панелі (інші місця тільки показують, що зміниться)",
    (1, 31, 1): "Пакет 15.10. ОДНА кнопка «Оновити все» нагорі панелі — сама робить усе в правильному порядку і "
                "зберігає нову версію файлу; зелене «Сцена актуальна» = нічого не треба. Що приходить: фетр замість "
                "корка під ніжками (правка клієнта), нові текстури дерева Espresso/Natural (з сайту), тони порід, "
                "ніжки, фаска знизу без відблиску підлоги, шов ребра Corner. «Свої зони»: «Лише кадри» (2, 24, 27-29) і «лише кадр N»; "
                "«Перехід» мінусом — зона стискається всередину; «Оновити кадри» бачить усі маркери. Пульт дерева: "
                "«Загальне» першим, ракурси повними назвами; у торцях лише їхні повзунки",
    (1, 34, 0): "«Свої шви»: яскравість і ширина тепер окремі для кожної тканини (ребра шва — спільні). "
                "Ваші налаштовані шви не змінились. Новий шов з'являється без впливу (яскр. 1) — налаштуй під тканину. "
                "Кнопка 🔍 біля шва — перейти до моделі з цим швом",
    (1, 33, 8): "Крісло й дивани: фетр на підкладках під ніжками (раніше там було дерево)",
    (1, 33, 7): "Панель оновлення моделі: підпис «UV моделей як у Євгена» (шви не передаються), у копій модуля — лише їхні кадри",
    (1, 33, 6): "Оновлення моделі тепер перевіряє саму сцену: якщо висота модулів чи UV не як у Євгена — пропонує оновити (UV тепер як у фінальній сцені, з копіями мешів під окремі конфігурації); якщо все так — кнопка не з'являється. Шви, зони й повзунки не чіпає",
    (1, 33, 5): "Пульт FL74: «Низ внутр.» доходить до самого кута біля острова — без світлої смуги біля стику",
}
# 1.30.1: на які кадри майстер-сцени впливає зміна (рядок «Кадри:» під текстом; хаб теж — публікатор додає в changes.json).
# Кадри = де в кадрі є змінена модель (карта кадр -> модель з v280). Нова зміна -> дописати рядок і сюди.
ADDON_FRAMES = {
    (1, 22, 0): "жодних — лише панель",
    (1, 22, 8): "жодних — лише панель",
    (1, 23, 0): "жодних, доки не натиснеш (тоді — усі кадри цієї тканини)",
    (1, 24, 0): "8–13, 25–30, 70–72, 76–93 (Left/Right Arm Chaise)",
    (1, 25, 0): "20–21, 55–57, 61–63, 67–69 (Ottoman)",
    (1, 26, 0): "1–3, 8–51, 55–93 (Armless, Islands, Ottoman, Chaise)",
    (1, 27, 0): "жодних — лише панель",
    (1, 28, 0): "жодних, доки рядок «Торець» = 1; діє на кадри з боковинами 5–19, 22–97",
    (1, 29, 0): "жодних — лише панель",
    (1, 30, 0): "усі 1–97 (пульт: значення 13 тканин); «Оновлення моделі» — 1–3, 5–16, 20–93",
    (1, 30, 1): "жодних — лише панель",
    (1, 30, 2): "жодних — лише панель",
    (1, 30, 3): "14–16, 22–24, 28–33, 37–39, 43–69, 73–78, 82–84, 88–90 (кутові й модульні дивани, Left Arm Island); "
                "одиночні модулі, дивани й крісло без змін",
    (1, 30, 4): "8–13, 25–30, 70–72, 76–93 (де є Left/Right Arm Chaise); решта без змін",
    (1, 30, 5): "усі кадри з деревом 1–97 (на модулях майже непомітно) + деталі: Joinery 101 — помітно; Corner 100 без змін",
    (1, 33, 1): "жодних — лише панель",
    (1, 33, 4): "жодних — лише підсвітка у вʼюпорті",
    (1, 33, 3): "черга таблиць — усі кадри (правильна тканина); Right Arm Chaise 11–13, 28–30, 79–81, 85–87, 91–93 — назад як до 1.33.2",
    (1, 33, 2): "11–13, 28–30, 79–81, 85–87, 91–93 (де є Right Arm Chaise)",
    (1, 33, 0): "жодних, доки не задаси градієнт у своїй зоні",
    (1, 32, 3): "жодних, доки не натиснеш (тоді — лише кадри того модуля)",
    (1, 32, 2): "жодних — лише панель",
    (1, 32, 1): "жодних — лише панель",
    (1, 32, 0): "жодних — лише показ",
    (1, 31, 6): "жодних — лише панель",
    (1, 31, 5): "жодних",
    (1, 31, 4): "жодних",
    (1, 31, 3): "жодних",
    (1, 31, 2): "жодних — лише панель",
    (1, 31, 1): "дерево — усі кадри з деревом 1–97 (тони порід, ніжки, низ основи); фетр — тонка лінія під ніжками "
                "(помітно на 1); шов ребра Corner — 22–24; зони за кадрами і пульт — жодних, лише панель",
    (1, 34, 0): "вигляд кадрів не змінюється — змінюється лише робота панелі «Свої шви»",
    (1, 33, 8): "94–97",
    (1, 33, 7): "вигляд кадрів не змінюється — лише текст панелі",
    (1, 33, 6): "UV: Armless 1–3, 22–30, 37–51, 58–75, 82–93; Corner 5–7, 22–24, 31–69, 73–93; Left/Right Arm Chaise (тканина й дерево), Left Arm Island; висота — лише в сценах, де її ще не піднімали",
    (1, 33, 5): "26, 77, 83, 89 (кут «Низ внутр.» біля острова; перевірено рендером 1–100)",
}
_NEWS_FIRST = (1, 21, 16)     # якщо ще не читали жодного разу — показати все, починаючи з цієї версії
"""Панель з'являється лише у файлах, де є тканини з міткою thuma_fabric (майстер-сцена v30+).
Тканина ставиться прямо в слот матеріалу 12 мешів оббивки — її видно в Shader Editor.
Скриптів у самому .blend немає — Blender не питає «Allow Execution»."""
import bpy
import os as _os  # 1.29.0: потрібен уже для «Що нового» (нижче імпортується ще раз — не заважає)

_ITEMS = []     # Blender вимагає тримати рядки динамічного списку живими
_KEY = [None]   # набір тканин, з якого зібрано _ITEMS (перебудова лише коли він змінився)


def _meshes():
    # 1.21.6: лише меші з тканиною — деревʼяні деталі (у сцені детейлів вони вищі за 20 см) не чіпаємо
    return sorted({o.data for o in bpy.data.objects if o.type == 'MESH'
                   and o.name.startswith("Thuma_Essential-") and o.dimensions.z > 0.2
                   and o.data.materials and o.data.materials[0]
                   and not o.data.materials[0].name.startswith("Thuma_Wood")}, key=lambda m: m.name)


def _fabrics():
    return sorted((m for m in bpy.data.materials if m.get("thuma_fabric")), key=lambda m: m.name)


def _items(self, context):
    # 1.0.1: НЕ перебудовувати список при кожному виклику — інакше Blender тримає вказівники на старі рядки
    # і в згорнутому списку показує не ту назву (у розгорнутому правильно).
    fabs = _fabrics()
    key = tuple(m.name for m in fabs)
    if key != _KEY[0] or not _ITEMS:
        _ITEMS[:] = [("STORYBOARD", "Storyboard (сірий)", "Сірий матеріал Storyboard")]
        _ITEMS.extend((m.name, m["thuma_fabric"], m.name, i + 1) for i, m in enumerate(fabs))
        _ITEMS[0] = _ITEMS[0] + (0,)
        _KEY[0] = key
    return _ITEMS


def _current():
    ms = _meshes()
    return ms[0].materials[0] if ms and ms[0].materials else None


def _get(self):
    cur = _current()
    names = [i[0] for i in _items(self, None)]
    if cur and cur.get("thuma_fabric") and cur.name in names:
        return names.index(cur.name)
    return 0


def _set(self, value):
    names = [i[0] for i in _items(self, None)]
    v = names[value] if 0 <= value < len(names) else "STORYBOARD"
    for me in _meshes():
        if "storyboard_mat" not in me and me.materials and not me.materials[0].get("thuma_fabric"):
            me["storyboard_mat"] = me.materials[0].name
        mat = bpy.data.materials.get(me.get("storyboard_mat", "")) if v == "STORYBOARD" else bpy.data.materials.get(v)
        if mat:
            me.materials[0] = mat
    try:
        _sync_cfr()                                     # 1.13.0: таблиця імен у CFRender за розцвіткою
    except Exception as e:
        print("[Thuma Fabric] CFRender sync:", e)


def _look_node(mat):
    """Нода FABRIC LOOK у матеріалі (у Textured Weave вона всередині групи кольору)."""
    if not mat or not mat.node_tree:
        return None

    def find(t, seen):
        if t.as_pointer() in seen:
            return None
        seen.add(t.as_pointer())
        for n in t.nodes:
            if n.type == 'GROUP' and n.node_tree:
                if n.node_tree.name.startswith("FABRIC LOOK"):
                    return n
                r = find(n.node_tree, seen)
                if r:
                    return r
    return find(mat.node_tree, set())


# 1.21.15: оголошено ПЕРЕД «Тканиною» — хаб перереєстровує панелі в порядку оголошення класів (інакше панель під довгою «Тканиною»)
class THUMA_PT_geo_update(bpy.types.Panel):
    """Окрема панель (не дерево і не тканина): затверджені зміни ГЕОМЕТРІЇ моделі.
    Видно, коли є що застосувати, або одразу після застосування (звіт до «Зрозуміло»)."""
    bl_label = "Оновлення моделі"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Thuma"

    @classmethod
    def poll(cls, context):
        return bpy.data.filepath in _GEO_DONE or _geo_fix_count() > 0

    def draw_header(self, context):
        self.layout.label(icon='MOD_LENGTH')

    def draw(self, context):
        c = self.layout.column()
        n = _geo_fix_count()
        if n:
            ng, uv = _GEO_CACHE.get("geo", 0), _GEO_CACHE.get("uv", [])
            fr = _GEO_CACHE.get("fr", {})
            if ng:                                   # 1.25.0: по кожному модулю — що саме і скільки
                bx = c.box()
                bx.alert = True
                bx.label(text="М'яка частина вище (затверджено 14.10):", icon='INFO')
                per = {}
                for o, p_ in _geo_fix_todo():
                    per[p_] = per.get(p_, 0) + 1
                for p_, k in per.items():
                    bx.label(text=f"{_GEO_FIX[p_][2]}: {_GEO_FIX[p_][3]} ({k} об'єктів)")
                    _frames_label(bx, fr.get(p_))
            if uv:                                   # 1.24.0
                bx = c.box()
                bx.alert = True
                bx.label(text="Поворот UV передка боковини (по шву), 14.10:", icon='UV')
                for me, pfx, cnt in uv:
                    fx = _UV_FIX[pfx]
                    bx.label(text=f"{fx['title']}: {fx['what']} ({cnt} конфігурацій)")
                    _frames_label(bx, fr.get(me.name))
            mf = _GEO_CACHE.get("mf", [])
            if mf:                                   # 1.30.0: UV і свої шви від Євгена
                bx = c.box()
                bx.alert = True
                bx.label(text="UV моделей як у Євгена:", icon='UV')
                for me, pfx, cnt in mf:
                    bx.label(text=f"{pfx.replace('Thuma_Essential-', '').split(' [')[0]}: {cnt} конфігурацій")
                    _frames_label(bx, fr.get(pfx, fr.get(me.name)))
            if _GEO_CACHE.get("wb"):                 # 1.30.5: правка клієнта — без Bevel у дереві
                bx = c.box()
                bx.alert = True
                bx.label(text="Дерево без Bevel (правка клієнта 15.10):", icon='NODE_MATERIAL')
                bx.label(text=f"{_GEO_CACHE['wb']} вузлів Bevel у матеріалах дерева — шипи не скошені")
                _frames_label(bx, "усі кадри з деревом (1–97), найпомітніше — деталь Joinery 101")
            if _GEO_CACHE.get("wp"):                 # 1.31.0
                bx = c.box()
                bx.alert = True
                bx.label(text="Дерево 15.10: фаска знизу, «Загальне: уся деревина»", icon='NODE_MATERIAL')
                bx.label(text="Вигляд зміниться після «Застосувати налаштування Євгена»")
            if _GEO_CACHE.get("felt"):
                bx = c.box()
                bx.alert = True
                bx.label(text="Фетр замість корка (правка клієнта 15.10):", icon='MATERIAL')
                bx.label(text=f"{_GEO_CACHE['felt']} об'єктів — підкладки під ніжками")
                _frames_label(bx, fr.get("felt"))
            if _GEO_CACHE.get("pads"):               # 1.33.8
                bx = c.box()
                bx.alert = True
                bx.label(text="Фетр на підкладках ніжок (крісло, дивани):", icon='MATERIAL')
                bx.label(text=f"{_GEO_CACHE['pads']} моделей — підкладка була деревом")
                _frames_label(bx, "94–97")
            if _GEO_CACHE.get("tex"):
                bx = c.box()
                bx.alert = True
                bx.label(text="Нові текстури дерева від Євгена (з сайту):", icon='IMAGE_DATA')
                for t in _GEO_CACHE["tex"]:
                    bx.label(text=t.replace("_finger-joint-wood_basecolor", "").replace("thuma", "")[:44])
                _frames_label(bx, "усі кадри з деревом Espresso / Natural")
            if _GEO_CACHE.get("fr_all"):             # 1.30.2: усі кадри разом
                _frames_label(c.box(), _GEO_CACHE["fr_all"], "Усі кадри, що зміняться: ")
            c.label(text="Застосовується кнопкою «Оновити все»", icon='INFO')   # 1.31.2: одна кнопка — нагорі
            c.label(text="нагорі панелі «Тканина / Дерево»")
        done = _GEO_DONE.get(bpy.data.filepath)
        if done:
            bx = c.box()
            bx.label(text="Оновлення застосовано:", icon='CHECKMARK')
            for t in done:
                bx.label(text=t)
            bx.label(text="Сцена вже збережена — працюйте далі в новій версії", icon='FILE_TICK')
            bx.operator("thuma.geo_ok", text="Зрозуміло", icon='HIDE_ON')


def _frames_label(bx, s, head="   Кадри: "):
    """1.30.2: рядок «Кадри: …» (переноситься, якщо довгий)."""
    if not s:
        return
    import textwrap
    for i, line in enumerate(textwrap.wrap(head + s, 46)):
        bx.label(text=line if i == 0 else "      " + line, icon='RENDER_ANIMATION' if i == 0 else 'BLANK1')


class THUMA_PT_fabric(bpy.types.Panel):
    bl_label = "Тканина / Дерево"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Thuma"

    @classmethod
    def poll(cls, context):
        return any(m.get("thuma_fabric") for m in bpy.data.materials)

    def draw_header_preset(self, context):
        self.layout.label(text=".".join(map(str, ADDON_VERSION)))

    def draw(self, context):
        c = self.layout.column()
        wm = context.window_manager
        _draw_sync_banner(c, context)                   # 1.31.1: «Оновити все» / «актуально» — першим рядком
        _draw_news(c)                                   # 1.29.0
        has_wood = _wood_node() is not None
        c.prop(context.scene, "thuma_mem_save", icon='MEMORY')     # 1.21.0; 1.22.1: на самому верху
        if has_wood:                                    # 1.22.0: дві великі кнопки — який пульт показати
            r_ = c.row(align=True)
            r_.scale_y = 1.8
            r_.prop(wm, "thuma_mode", expand=True)
            if wm.thuma_mode == 'WOOD':                 # 1.22.2: одразу під «Дерево» — який пульт дерева показати
                _draw_wood_part(c, wm)
            c.separator()
            _draw_combo(c, context)                     # 1.13.0: розцвітка клієнта -> таблиця CFRender (спільна)
        if context.space_data.shading.type in {'SOLID', 'WIREFRAME'}:
            c.label(text="Вьюпорт у Solid — матеріали видно в Material Preview", icon='INFO')
        if has_wood and wm.thuma_mode == 'WOOD':
            _draw_wood_mode(c, context)
            return
        r_ = c.row(align=True)                              # 1.10.1: перенос налаштувань тканини
        r_.scale_y = 1.2
        r_.operator("thuma.settings_export", text="Експорт налаштувань", icon='EXPORT')
        r_.operator("thuma.settings_import", text="Імпорт налаштувань", icon='IMPORT')
        c.prop(context.scene, "thuma_fabric_pick", text="")
        c.operator("thuma.copy_look", text="Перенести налаштування на іншу тканину", icon='PASTEDOWN')   # 1.23.0
        _draw_parts_mask(c, context)
        _draw_update(c)                     # 1.9.0: пульт у сцені старіший за аддон -> кнопка оновлення
        node = _look_node(_current())
        if not node:
            c.label(text="Storyboard — пульта нема")
            return
        # 1.1.0: увесь пульт згортається; кожна зона — окремий блок, що згортається
        root_h, root = c.panel("thuma_fl_root", default_closed=False)
        root_h.label(text="FABRIC LOOK цієї тканини", icon='MATERIAL')
        _eye(root_h, "__ALL__", "")
        root_h.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False).scope = 'ALL'
        root_h.operator("thuma.update_look", text="", icon='FILE_REFRESH', emboss=False)
        if root is not None:
            _draw_look(root, node)
        _draw_custom(c, context)


# ---------------- 1.29.0: «Що нового» ----------------
_NEWS_FILE = _os.path.join(bpy.utils.user_resource('CONFIG'), "thuma_fabric_news_seen.json")
_NEWS = {"seen": None}


def _news_seen():
    if _NEWS["seen"] is None:
        import json
        try:
            with open(_NEWS_FILE, encoding="utf-8") as f:
                _NEWS["seen"] = tuple(json.load(f)["seen"])
        except Exception:
            _NEWS["seen"] = _NEWS_FIRST
    return _NEWS["seen"]


def _draw_news(c):
    seen = _news_seen()
    items = [(v, t) for v, t in sorted(ADDON_CHANGES.items()) if seen < v <= ADDON_VERSION]
    if not items:
        return
    import textwrap
    bx = c.box()
    bx.label(text=f"Що нового в аддоні (з {'.'.join(map(str, seen))}):", icon='INFO')
    col = bx.column(align=True)
    for v, t in items:
        for i, line in enumerate(textwrap.wrap(t, 48)):
            col.label(text=(f"{'.'.join(map(str, v))}: " if i == 0 else "      ") + line)
        if v in ADDON_FRAMES:                       # 1.30.1: на які кадри впливає
            for i, line in enumerate(textwrap.wrap("Кадри: " + ADDON_FRAMES[v], 46)):
                col.label(text="      " + line, icon='RENDER_ANIMATION' if i == 0 else 'BLANK1')
    r = bx.row()
    r.scale_y = 1.2
    r.operator("thuma.news_ok", text="Зрозуміло", icon='CHECKMARK')


class THUMA_OT_news_ok(bpy.types.Operator):
    bl_idname = "thuma.news_ok"
    bl_label = "Зрозуміло"
    bl_description = "Сховати «Що нового» до наступного оновлення аддона"

    def execute(self, context):
        import json
        try:
            _os.makedirs(_os.path.dirname(_NEWS_FILE), exist_ok=True)
            with open(_NEWS_FILE, "w", encoding="utf-8") as f:
                json.dump({"seen": list(ADDON_VERSION)}, f)
        except Exception as e:
            self.report({'WARNING'}, f"Не вдалось зберегти: {e}")
        _NEWS["seen"] = ADDON_VERSION
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# ---------------- 1.22.0: режим «Дерево» — пульт WOOD LOOK поточної породи + пульт торців-вставок ----------------
_MODE_ITEMS = [('FABRIC', "Тканина", "Показати тканину і пульт FABRIC LOOK", 'MATERIAL', 0),
               ('WOOD', "Дерево", "Показати породу дерева і пульт WOOD LOOK (рейки + торці-вставки)", 'NODE_MATERIAL', 1)]
_WL_PAIR = ("яскравість", "насиченість")


def _wood_name():
    n = _wood_node()
    if not n:
        return None
    i = min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)
    return WOODS[i][1]


def _wood_look_node(target):
    """WOOD LOOK поточної породи: 'RAIL' — рейки (група в Thuma_Wood_Finger-Joints_4K), 'EG' — торці-вставки
    (група в перемикачі торців). Шукаємо за назвою породи в імені групи — у колег суфікси .001 інші."""
    name = _wood_name()
    if not name:
        return None
    if target == 'RAIL':
        m = bpy.data.materials.get(WOOD_MAT)
        groups = [n.node_tree for n in m.node_tree.nodes if n.type == 'GROUP' and n.node_tree] if m else []
        key, look = f"_{name}_", "WOOD LOOK"
        groups = [g for g in groups if g.name.startswith("Thuma_Finger-Joint-Wood") and key in g.name]
    else:
        key, look = f"{_EG_PREFIX}{name}_", "WOOD LOOK (торці)"
        groups = [g for g in _eg_groups() if g.name.startswith(key)]
    for g in groups:
        n = g.nodes.get(look)
        if n is not None and n.type == 'GROUP' and n.node_tree:
            return n
    return None


def _target_node(target):
    return _wood_look_node(target) if target in {'RAIL', 'EG'} else _look_node(_current())


_PART_ITEMS = [('RAIL', "Звичайне дерево", "Пульт WOOD LOOK рейок (основне дерево)", 'NODE_MATERIAL', 0),
               ('EG', "Торці (End-Grain)", "Пульт торців-вставок у кутах (End-Grain)", 'MOD_LINEART', 1)]


def _draw_wood_part(c, wm):
    """Дві кнопки «Звичайне дерево / Торці (End-Grain)» — звичайний перемикач, вибрана синя (1.22.5)."""
    r = c.row(align=True)
    r.scale_y = 1.5
    r.prop(wm, "thuma_wood_part", expand=True)


def _draw_wood_mode(c, context):
    c.prop(context.scene, "thuma_wood_pick", text="Порода")
    rw = c.row(align=True)                              # 1.11.0: усі налаштування дерева одним файлом
    rw.operator("thuma.wood_export", text="Дерево: експорт", icon='EXPORT')
    rw.operator("thuma.wood_import", text="Дерево: імпорт", icon='IMPORT')
    _draw_wood_sync(c, context)                         # 1.12.0: налаштування Євгена з сайту
    if not _is_owner() and _REMOTE.get("wood"):
        c.label(text="Зміни пульта — лише у вашій сцені;", icon='INFO')
        c.label(text="«Застосувати налаштування Євгена» їх перезапише")
    name = _wood_name()
    part = context.window_manager.thuma_wood_part
    for target, pid, title, icon, closed in (('RAIL', "thuma_wl", "WOOD LOOK", 'NODE_MATERIAL', False),
                                             ('EG', "thuma_eg", "Торці (вставки)", 'MOD_LINEART', False)):
        if target != part:
            continue
        node = _wood_look_node(target)
        if node is None:
            c.label(text=f"{title}: пульта для {name} нема", icon='ERROR')
            continue
        h, b = c.panel(pid + "_root", default_closed=closed)
        h.label(text=f"{title} — {name}", icon=icon)
        _eye(h, f"{target}:__ALL__", "", target)
        o = h.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
        o.scope = 'ALL'; o.target = target
        if b is not None:
            _draw_wood_look(b, node, pid, target)


_WL_ANG = (("Фронт", "Фронт"), ("Ліва 30°", "Л 30°"), ("Ліва 60°", "Л 60°"), ("Права 30°", "П 30°"), ("Права 60°", "П 60°"))
_WL_PANEL_ICON = (("Загальне", 'SHADING_RENDERED'), ("Грані за кутом", 'CAMERA_DATA'), ("Кут ЛІВОРУЧ", 'TRIA_LEFT'), ("Кут ПРАВОРУЧ", 'TRIA_RIGHT'),
                  ("Лише ФРОНТ", 'LIGHT_SUN'), ("Низ", 'TRIA_DOWN'), ("Тіні", 'SHADING_SOLID'),
                  ("Калібрування", 'TOOL_SETTINGS'))
_WL_ZONE_ICON = ('COLLECTION_COLOR_05', 'COLLECTION_COLOR_04', 'COLLECTION_COLOR_03', 'COLLECTION_COLOR_02',
                 'COLLECTION_COLOR_07', 'COLLECTION_COLOR_06', 'COLLECTION_COLOR_01', 'COLLECTION_COLOR_08')


def _wl_icon(name):
    return next((ic for k, ic in _WL_PANEL_ICON if name.startswith(k)), 'DOT')


def _wl_zone_head(lay, title, icon, socks, target):
    """Шапка зони як у тканини: назва з кольоровим значком, глазик до/після, скинути."""
    names = "|".join(s.name for _, s in socks)
    _eye(lay, f"{target}:{title}", names, target)
    o = lay.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
    o.scope = 'ZONE'; o.target = target; o.names = names


def _draw_wood_look(c, node, prefix, target):
    """1.22.6: вигляд як у пульта тканини — панель групи (значок, коротка назва, підказка кадрів усередині),
    кожна зона — окремий блок, що згортається, у рамці, з глазиком і скиданням; ракурси — таблицею."""
    rows = []                      # (панель, [(зона, [(суфікс, сокет)])])
    for it in node.node_tree.interface.items_tree:
        if it.item_type == 'PANEL':
            rows.append((it, []))
        elif it.in_out == 'INPUT':
            s = node.inputs.get(it.name)
            if s is None or s.is_linked or not hasattr(s, "default_value"):
                continue
            zone, _, suf = it.name.partition(": ")
            if not suf:
                zone, suf = "", it.name
            if target == 'EG' and zone in _EG_HIDE:       # 1.31.0: на торцях-вставках не діють (перевірено рендером)
                continue
            if not rows:
                rows.append((None, []))
            zl = rows[-1][1]
            hit = next((z for z in zl if z[0] == zone), None)     # одна зона — один блок, навіть якщо сокети не поспіль
            if hit is None:
                hit = (zone, [])
                zl.append(hit)
            hit[1].append((suf, s))
    angs = {a for a, _ in _WL_ANG}
    for i, (pan, zones) in _ordered(rows, _WL_ORDER):
        if not zones:
            continue
        title, _, hint = (pan.name if pan is not None else "").partition(":")
        if pan is not None:
            c.separator(factor=1.2)                     # 1.22.7: розділи (Кут ліворуч / праворуч…) — окремою рамкою з відступом
            head, body = c.box().panel(f"{prefix}_{i}", default_closed=getattr(pan, "default_closed", False))
            _wood_lamp(head, target, title.strip(), [x for _, sk in zones for x in sk])   # 1.32.0: лампочка зліва
            head.label(text=title.strip(), icon=_wl_icon(pan.name))
            _wl_zone_head(head, title.strip(), None, [x for _, sk in zones for x in sk], target)
            if body is None:
                continue
        else:
            body = c
        if hint.strip():
            body.label(text=hint.strip(), icon='INFO')
        ang = {z: dict(sk) for z, sk in zones if z in angs}
        rest = [(z, sk) for z, sk in zones if z not in angs]
        if ang:                                        # «Грані за кутом»: загальні повзунки + таблиця ракурсів
            col = body.box().column(align=True)
            for z, sk in rest:
                for suf, s in sk:
                    col.prop(s, "default_value", text=f"{z}: {suf}" if z else suf[:1].upper() + suf[1:])
            col.separator()
            hr = col.row(align=True)
            hr.label(text="Ракурс:")
            for a, short in _WL_ANG:
                hr.label(text=short)
            lr = col.row(align=True)                       # 1.32.0: лампочка кожного ракурсу — які грані він міняє
            lr.label(text="Показати:")
            for a, _short in _WL_ANG:
                nm_ = _hlb_names(list(ang.get(a, {}).items()))
                if nm_:
                    _hl_lamp(lr, f"B:{target}:{nm_}")
                else:
                    lr.label(text="")
            for k in _WL_PAIR:
                r = col.row(align=True)
                r.label(text=k[:1].upper() + k[1:])
                for a, _ in _WL_ANG:
                    s = ang.get(a, {}).get(k)
                    if s is not None:
                        r.prop(s, "default_value", text="")
                    else:
                        r.label(text="")
            continue
        for j, (zone, sk) in enumerate(rest):
            name = zone or title.strip()
            zh, zb = body.panel(f"{prefix}_z_{i}_{j}", default_closed=False)
            if not title.startswith("Калібрування"):
                _wood_lamp(zh, target, name, sk)
            zh.label(text=name, icon=_WL_ZONE_ICON[j % len(_WL_ZONE_ICON)] if zone else 'DOT')
            _wl_zone_head(zh, name, None, sk, target)
            if zb is None:
                continue
            col = zb.box().column(align=True)
            # 1.31.0: «яскр. X» + «нас. X» — одним рядком (ракурс | яскравість | насиченість), компактніше
            sd = dict(sk)
            pairs = [(suf[6:], s, sd.get("нас. " + suf[6:])) for suf, s in sk if suf.startswith("яскр. ")]
            paired = {suf for suf, _ in sk if suf.startswith("яскр. ") or
                      (suf.startswith("нас. ") and ("яскр. " + suf[5:]) in sd)}
            for suf, s in sk:
                if suf not in paired:
                    col.prop(s, "default_value", text=suf[:1].upper() + suf[1:])
            if pairs:
                col.separator()
                hr = col.row(align=True)
                hr.label(text="Ракурс")
                hr.label(text="Яскравість")
                hr.label(text="Насиченість")
                full = {"Ф": "Фронт", "Л": "Ліво", "П": "Право", "Зад Л": "Зад ліво", "Зад П": "Зад право"}
                cur_ = {"ЗЛ": "Зад Л", "ЗП": "Зад П"}.get(_cur_ang(), _cur_ang())
                for a, sb, ss_ in pairs:
                    r = col.row(align=True)
                    if a == cur_:                              # 1.32.0: ракурс поточного кадру
                        sub = r.row(align=True); sub.alert = True
                        sub.label(text="● " + full.get(a, a))
                    else:
                        r.label(text=full.get(a, a))
                    r.prop(sb, "default_value", text="")
                    if ss_ is not None:
                        r.prop(ss_, "default_value", text="")
                    else:
                        r.label(text="")


_ANG = ("Ф", "Л", "П", "ЗЛ", "ЗП")          # 1.19.0: + задні ракурси
_ANG_HEAD = {"Ф": "Ф", "Л": "Л", "П": "П", "ЗЛ": "Зад Л", "ЗП": "Зад П"}


def _cur_ang():
    """1.32.0: який стовпчик ракурсу діє в ПОТОЧНОМУ кадрі — та сама формула, що в шейдері (FABRIC LOOK v7.50):
    Ф = |sin| < ~0.2; інакше Л (sin > 0) / П; задні (cos < 0) -> ЗЛ / ЗП. Кут = scene["cfg_angle"] (поворот збірки)."""
    import math
    sc = bpy.context.scene
    a = sc.get("cfg_angle") if sc else None
    if a is None:
        rot = bpy.data.objects.get("Control_Rotation")
        if rot is None:
            return None
        a = rot.matrix_world.to_euler().z
    sn, cs = math.sin(a), math.cos(a)
    t = min(max((abs(sn) - 0.1) / 0.2, 0.0), 1.0)
    if 1.0 - t * t * (3 - 2 * t) >= 0.5:
        return "Ф"
    return ("З" if cs < 0 else "") + ("Л" if sn > 0 else "П")


def _ang_head(col):
    """Шапка таблиці ракурсів; стовпчик поточного кадру — червоним з крапкою (його й крутиш зараз)."""
    hr = col.row(align=True)
    hr.label(text="Ракурс:")
    cur = _cur_ang()
    for a in _ANG:
        if a == cur:
            sub = hr.row(align=True); sub.alert = True
            sub.label(text="● " + _ANG_HEAD[a])
        else:
            hr.label(text=_ANG_HEAD[a])
# 1.30.0: людські назви рядків таблиці швів
_SEAM_NAMES = {"спинка": "Спинка", "сидіння": "Верх сидіння", "фронт": "Фронт (фасад сидіння)",
               "внутр. ліва": "Боковина всередині, ліва", "внутр. права": "Боковина всередині, права",
               "зовн. ліва": "Боковина зовні, ліва", "зовн. права": "Боковина зовні, права", "верх": "Верхній кант",
               "задня стінка": "Задня стінка", "інше": "Решта",
               "сидіння, ліве крило": "Сидіння лів. крила, бік — інші кадри", "сидіння, праве крило": "Сидіння прав. крила, бік — інші кадри",
               "сидіння ліве, фронт": "Сидіння лів. крила, бік — фронт-кадри", "сидіння праве, фронт": "Сидіння прав. крила, бік — фронт-кадри",
               "стик ліве крило": "Стик модулів лів. крила", "стик крила, ближній": "Стик крила, ближній модуль"}
_ANG_SHORT = {"яскр.": "Яскравість", "нас.": "Насиченість", "тор.": "Торець", "тор. см": "Торець, см"}  # 1.28.0: + торець
_ANG_KIND = {"яскр.": "Яскравість за ракурсом", "нас.": "Насиченість за ракурсом", "тор.": "Торець за ракурсом",
             "тор. см": "Ширина торця за ракурсом"}


_CORNER_GRP = {"ліва боковина": "a", "довжина боковини": "a", "спинка": "b", "ширина, см": "b", "згасання до країв": "b"}


def _draw_socks(col, socks):
    """1.7.0: звичайні повзунки — як були; «яскр. Ф/Л/П», «нас. Ф/Л/П» — одним рядком за ракурсом кадру."""
    ang = {}
    d = dict(socks)
    prev = None
    for suf, s in socks:
        grp = _CORNER_GRP.get(suf, "f" if suf.startswith("фасад") else None)
        if grp and prev and grp != prev:              # 1.18.2: «Кут» — тонка лінія між боковиною / спинкою / фасадом
            col.separator(type='LINE')
        prev = grp or prev
        k, _, a = suf.rpartition(" ")
        if a in _ANG and k in _ANG_KIND:
            ang.setdefault(k, {})[a] = s
            continue
        if suf == "сила" and "перехід" in d:
            continue
        if suf == "торець, яскр" and "торець, см" in d:
            continue
        if suf == "торець, см" and "торець, яскр" in d:     # 1.19.6: торець і його яскравість — одним рядком
            r = col.row(align=True)
            r.prop(s, "default_value", text="Торець, см")
            r.prop(d["торець, яскр"], "default_value", text="Яскр.")
            continue
        if suf == "перехід" and "сила" in d:      # 1.18.0: перехід і його сила — одним рядком навпіл
            r = col.row(align=True)
            r.prop(s, "default_value", text="Перехід")
            r.prop(d["сила"], "default_value", text="Сила")
            continue
        col.prop(s, "default_value", text=suf[:1].upper() + suf[1:])
    if ang:                                        # 1.19.0: шапка ракурсів один раз, у рядках — лише числа
        _ang_head(col)                             # 1.32.0: стовпчик поточного кадру позначено
    for k, d in ang.items():
        r = col.row(align=True)
        r.label(text=_ANG_SHORT[k])
        for a in _ANG:
            if a in d:
                r.prop(d[a], "default_value", text="")
            else:
                r.label(text="")


# 1.22.8: порядок розділів у панелі «для зручності»: загальне -> основні площини -> боковини -> кути -> шви -> перевірка.
# Лише відображення: порядок сокетів у групі (і в сцені) не змінюється. Невідомий розділ — у кінці, у своєму порядку.
_FL_ORDER = ("Загальне", "Спинка й сидіння", "Верх", "Фронт і зад", "Боковини ліві", "Боковини праві",
             "Кутик біля підлокітника", "Фронт-кадри", "Шви", "Перевірка")
# 1.31.0: зони, що на торцях-вставках нічого не міняють (рендер кадрів 5, 22, 23, 29, 46: ≤ 6 px) — у пульті торців сховані
_EG_HIDE = {"Ніжки", "Фронт-кут ніжка", "Нижня кромка", "Тінь біля кута", "Стики впритул"}
_WL_ORDER = ("Загальне", "Грані за кутом", "Низ", "Тіні", "Кут ЛІВОРУЧ", "Кут ПРАВОРУЧ", "Лише ФРОНТ", "Калібрування")


def _ordered(rows, order):
    """[(i, (pan, ...))] за списком order (за початком назви); i — справжній номер, щоб id блоків не мінялися."""
    def key(x):
        i, (pan, _z) = x
        if pan is None:
            return (-1, i)
        k = next((n for n, pre in enumerate(order) if pan.name.startswith(pre)), len(order))
        return (k, i)
    return sorted(enumerate(rows), key=key)


def _draw_look(c, node):
    rows = []                      # (панель, [(зона, [(суфікс, сокет)])])
    for it in node.node_tree.interface.items_tree:
        if it.item_type == 'PANEL':
            rows.append((it, []))
        elif it.in_out == 'INPUT' and it.name != "Колір":
            s = node.inputs.get(it.name)
            if s is None or s.is_linked:
                continue
            zone, _, suf = it.name.partition(": ")
            if not suf:
                zone, suf = "", it.name
            if not rows:
                rows.append((None, []))
            zl = rows[-1][1]
            if not zl or zl[-1][0] != zone:
                zl.append((zone, []))
            zl[-1][1].append((suf, s))
    for i, (pan, zones) in _ordered(rows, _FL_ORDER):
        if pan is not None:
            c.separator(factor=1.2)                     # 1.22.8: кожен розділ — окремою рамкою з відступом
            head, body = c.box().panel(f"thuma_fl_{i}", default_closed=getattr(pan, "default_closed", False))
            head.label(text=pan.name, icon=_PANEL_ICON.get(pan.name, 'NONE'))
            if body is None:
                continue
        else:
            body = c
        if pan is not None and pan.name.startswith("Кутик"):
            kb = body.box()
            kb.label(text="Пензель кутика (на виділеному модулі):", icon='BRUSH_DATA')
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Дорисувати", icon='ADD').mode = 'ADD'
            r.operator("thuma.kutik_paint", text="Стерти", icon='REMOVE').mode = 'ERASE'
            r = kb.row(align=True)
            r.operator("thuma.kutik_paint", text="Готово", icon='CHECKMARK').mode = 'DONE'
            r.operator("thuma.kutik_paint", text="Очистити модуль", icon='TRASH').mode = 'CLEAR'
        if pan is not None and pan.name == "Шви":
            # 1.30.0: компактна й зрозуміла панель швів — зверху головне, рідкісне згорнуте, людські назви
            body.label(text="Шов = темна лінія вздовж швів тканини", icon='INFO')
            d_all = {suf: sock for z, sk in zones if z == "Шви" for suf, sock in sk}
            r = body.row(align=True)
            r.operator("thuma.seam_flash", text="", icon='LIGHT', emboss=False).key = "ALL"
            if "сила" in d_all:
                r.prop(d_all["сила"], "default_value", text="Усі шви: темність")
            if "ширина" in d_all:
                r.prop(d_all["ширина"], "default_value", text="ширина, см")
            groups = [(z, sk) for z, sk in zones if z.startswith("Шви ") and not z.startswith("Шви ребро")]
            is_wing = lambda z: "крил" in z or "стик" in z or ", фронт" in z
            main_g = [(z, sk) for z, sk in groups if not is_wing(z)]
            wing_g = [(z, sk) for z, sk in groups if is_wing(z)]

            def seam_table(lay, grp, pid, title, closed):
                if not grp:
                    return
                th, tbody = lay.panel(pid, default_closed=closed)
                th.label(text=title)
                o = th.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sk in grp for _, sock in sk)
                if tbody is None:
                    return
                tb = tbody.column(align=True)
                tb.label(text="1 = як «Усі шви», 2 = удвічі, 0 = прибрати")
                hr = tb.row(align=True)
                hr.label(text="Де"); hr.label(text="Темніше ×"); hr.label(text="Ширше ×")
                for z, sk in grp:
                    r = tb.row(align=True)
                    if _hl_supported(z[4:]):                     # 1.32.0: лампочка — підсвітити шов
                        r.operator("thuma.seam_flash", text="", icon='LIGHT', emboss=False).key = z[4:]
                    elif _hl_shader_ok(z):                       # FL71: стики крила — показує шейдер
                        _hl_lamp(r, "S:" + z)
                    r.label(text=_SEAM_NAMES.get(z[4:], z[4:]))
                    d = {suf: sock for suf, sock in sk}
                    for keys in (("сила ×", "сила"), ("ширина ×",)):     # 1.21.8: «…: сила» — без ×
                        s_ = next((d[k] for k in keys if k in d), None)
                        if s_ is not None:
                            r.prop(s_, "default_value", text="")
                        else:
                            r.label(text="")
            seam_table(body, main_g, "thuma_seam_parts", "Шви по частинах дивана", False)
            seam_table(body, wing_g, "thuma_seam_wing2", "Кутові дивани: крило і стики модулів", False)
            # ребро лівого підлокітника — один рядок + ракурси згорнуто
            for z, sk in zones:
                if not z.startswith("Шви ребро"):
                    continue
                d = {suf: sock for suf, sock in sk}
                eb = body.box()
                hr_ = eb.row()
                hr_.alert = True                              # червоний заголовок — помітно
                _hl_lamp(hr_, "RIB")
                hr_.label(text="Ребро лівого підлокітника", icon='MOD_EDGESPLIT')
                r = eb.row(align=True)
                if "сила ×" in d:
                    r.prop(d["сила ×"], "default_value", text="Темніше ×")
                if "ширина ×" in d:
                    r.prop(d["ширина ×"], "default_value", text="Ширше ×")
                eb.label(text="0 = шва нема, мінус = світла лінія")
                if any(f"шов {a}" in d for a in _ANG):          # ракурси одразу видно (без згортання)
                    tb = eb.column(align=True)
                    _ang_head(tb)
                    for k, lab in (("шов", "Темніше"), ("шир.", "Ширше")):
                        r = tb.row(align=True)
                        r.label(text=lab)
                        for a in _ANG:
                            s_ = d.get(f"{k} {a}")
                            if s_ is not None:
                                r.prop(s_, "default_value", text="")
                            else:
                                r.label(text="")
            # свої шви
            _draw_cseams(body, bpy.context)
            ph, pb = body.panel("thuma_seam_brush", default_closed=True)
            ph.label(text="Прибрати шов у певному місці (пензель)", icon='BRUSH_DATA')
            if pb is not None:
                r = pb.row(align=True)
                r.operator("thuma.seam_off", text="Прибрати пензлем", icon='REMOVE').mode = 'PAINT_OFF'
                r.operator("thuma.seam_off", text="Повернути", icon='ADD').mode = 'PAINT_ON'
                r = pb.row(align=True)
                r.operator("thuma.seam_off", text="Прибрати з виділених", icon='FACESEL').mode = 'SEL_OFF'
                r.operator("thuma.seam_off", text="Повернути", icon='FACESEL').mode = 'SEL_ON'
                r = pb.row(align=True)
                r.operator("thuma.seam_off", text="Готово", icon='CHECKMARK').mode = 'DONE'
                r.operator("thuma.seam_off", text="Усі шви на модулі", icon='LOOP_BACK').mode = 'CLEAR'
            continue
        many = len(zones) > 1
        for j, (zone, socks) in enumerate(zones):
            if many:                                   # кожна зона окремо згортається
                zh, zb = body.panel(f"thuma_fz_{i}_{j}", default_closed=False)
                if _hl_area_ok("FAB", zone):                    # 1.32.0: лампочка — де ця зона
                    _hl_lamp(zh, "A:FAB:" + zone)
                elif _hl_shader_ok(zone):                       # FL71: показує шейдер
                    _hl_lamp(zh, "S:" + zone)
                zh.label(text=zone or pan.name, icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(zh, zone or pan.name, "|".join(sock.name for _, sock in socks))
                o = zh.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                if zb is None:
                    continue
                col = zb.box().column(align=True)              # 1.8.0: рамка навколо зони
            else:
                b = body.column()
                hr = b.row()
                if _hl_area_ok("FAB", zone):
                    _hl_lamp(hr, "A:FAB:" + zone)
                elif _hl_shader_ok(zone):
                    _hl_lamp(hr, "S:" + zone)
                hr.label(text=zone or (pan.name if pan is not None else ""), icon=_ZONE_ICON.get(zone, 'DOT'))
                _eye(hr, zone or (pan.name if pan is not None else ""), "|".join(sock.name for _, sock in socks))
                o = hr.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False)
                o.scope = 'ZONE'; o.names = "|".join(sock.name for _, sock in socks)
                col = b.column(align=True)
            _draw_socks(col, socks)


# ---------------- 1.1.0: СВОЇ ЗОНИ (вибрані полігони конкретної моделі) ----------------
# Зберігаються на МЕШІ (модель): Mesh.thuma_zones (налаштування) + атрибут граней tc_z<id> (які полігони).
# Сумарний результат усіх зон моделі -> атрибут вершин tc_cust (x = яскравість-1, y = насиченість-1);
# FABRIC LOOK множить на (1+x), (1+y). Нема атрибута -> 0 -> без змін. Префікс tc_ (не fz_) — пересбірка
# пульта атрибути fz_* перераховує, а ці не чіпає.
_GRAPH = {}


def _ups_mesh(ob):
    return ob is not None and ob.type == 'MESH' and ob.data in _meshes()


def _graph(me):
    """Сусідство вершин по ребрах (кеш). У Edit Mode — з BMesh (масиви меша тоді неактуальні)."""
    import numpy as np
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        key = (me.name, "edit", len(bm.verts), len(bm.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.array([v.co[:] for v in bm.verts], np.float32)
        ev = np.array([(e.verts[0].index, e.verts[1].index) for e in bm.edges], np.int64).reshape(-1, 2)
    else:
        key = (me.name, len(me.vertices), len(me.edges))
        if key in _GRAPH:
            return _GRAPH[key]
        co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ev = np.empty(len(me.edges) * 2, np.int32); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
    a = np.concatenate([ev[:, 0], ev[:, 1]]); b = np.concatenate([ev[:, 1], ev[:, 0]])
    w = np.linalg.norm(co[a] - co[b], axis=1)
    o = np.argsort(a, kind='stable')
    a, b, w = a[o], b[o], w[o]
    start = np.searchsorted(a, np.arange(len(co) + 1))
    _GRAPH.clear()
    _GRAPH[key] = (start.tolist(), b.tolist(), w.tolist())
    return _GRAPH[key]


def _zone_vmask(me, z):
    """Вершини полігонів зони (у Edit Mode — з шару BMesh)."""
    import numpy as np
    name = f"tc_z{z.uid}"
    if me.is_editmode:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        vm = np.zeros(len(bm.verts), bool)
        lay = bm.faces.layers.bool.get(name)
        if lay is None:
            return vm
        for f in bm.faces:
            if f[lay]:
                for v in f.verts:
                    vm[v.index] = True
        return vm
    nv = len(me.vertices)
    at = me.attributes.get(name)
    vm = np.zeros(nv, bool)
    if at is None or len(at.data) != len(me.polygons):
        return vm
    fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
    vm[lv[np.repeat(fm, lt)]] = True
    return vm


def _zone_weights(me, z):
    """Вага зони на вершинах: 1 на її полігонах, плавно до 0 на відстані «Перехід» (по тканині)."""
    import heapq
    import numpy as np
    vm = _zone_vmask(me, z)
    w = vm.astype(np.float32)
    W = z.transition * 0.01
    if W < -0.0005 and vm.any():
        # 1.31.0: МІНУС = звуження всередину (як «перехід» у пульті): у середині зони повна сила, до її країв
        # плавно 0 на відстані |перехід| по тканині; назовні зона не заходить
        Wi = -W
        start, nb, wt = _graph(me)
        d = {}
        h = []
        for i in np.nonzero(~vm)[0]:            # краї: сусіди зони поза нею, відстань 0
            i = int(i)
            for k in range(start[i], start[i + 1]):
                if vm[nb[k]]:
                    d[i] = 0.0; h.append((0.0, i)); break
        heapq.heapify(h)
        while h:
            dv, v = heapq.heappop(h)
            if dv > d.get(v, 9.0):
                continue
            for k in range(start[v], start[v + 1]):
                u = nb[k]
                if not vm[u]:
                    continue
                nd = dv + wt[k]
                if nd < Wi and nd < d.get(u, 9.0):
                    d[u] = nd
                    heapq.heappush(h, (nd, u))
        k = getattr(z, "trans_strength", 1.0)
        for i, dv in d.items():
            if vm[i]:
                t = dv / Wi
                w[i] = max(0.0, 1.0 - k * (1.0 - t * t * (3 - 2 * t)))
        return w
    if W <= 0.0005 or not vm.any():
        return w
    start, nb, wt = _graph(me)
    d = {int(i): 0.0 for i in np.nonzero(vm)[0]}
    h = [(0.0, i) for i in d]
    heapq.heapify(h)
    while h:
        dv, v = heapq.heappop(h)
        if dv > d.get(v, 9.0):
            continue
        for k in range(start[v], start[v + 1]):
            u = nb[k]; nd = dv + wt[k]
            if nd < W and nd < d.get(u, 9.0):
                d[u] = nd
                heapq.heappush(h, (nd, u))
    k = getattr(z, "trans_strength", 1.0)        # 1.18.0: сила переходу
    for i, dv in d.items():
        t = dv / W
        w[i] = max(w[i], min(1.0, k * (1.0 - t * t * (3 - 2 * t))))
    return w


def _rebuild(me):
    import numpy as np
    if me.is_editmode:
        import bmesh
        nv = len(bmesh.from_edit_mesh(me).verts)
    else:
        nv = len(me.vertices)
    # 1.7.0: три шари за ракурсом — tc_cust = Ф, tc_cust_l = Л, tc_cust_r = П (FABRIC LOOK ≥ v7.12 бере за ракурсом кадру)
    lay_names = {"f": "tc_cust", "l": "tc_cust_l", "r": "tc_cust_r"}
    B = {a: np.ones(nv, np.float32) for a in lay_names}
    S = {a: np.ones(nv, np.float32) for a in lay_names}
    FB, FS = {}, {}                                # 1.31.0: зони «лише кадр N» -> окремі шари tc_cfr1..3
    zco = None
    for z in me.thuma_zones:
        if not z.enabled:
            continue
        w = _zone_weights(me, z)
        gt, gb = getattr(z, "grad_top", 1.0), getattr(z, "grad_bot", 1.0)
        if abs(gt - 1.0) > 1e-4 or abs(gb - 1.0) > 1e-4:     # 1.33.0: градієнт по висоті зони (локальна Z моделі)
            if zco is None:
                if me.is_editmode:
                    import bmesh
                    zco = np.array([v.co.z for v in bmesh.from_edit_mesh(me).verts], np.float32)
                else:
                    zco = np.zeros(nv * 3, np.float32); me.vertices.foreach_get("co", zco); zco = zco[2::3].copy()
            core = w > 0.5
            if core.any():
                z0, z1 = float(zco[core].min()), float(zco[core].max())
                t = np.clip((zco - z0) / max(z1 - z0, 1e-6), 0.0, 1.0) ** getattr(z, "grad_curve", 1.0)
                t = t * t * (3.0 - 2.0 * t)                       # плавно, без зламу на краях
                gm = (gb + (gt - gb) * t).astype(np.float32)
            else:
                gm = np.ones(nv, np.float32)
        else:
            gm = 1.0
        frl = _zone_frames(z)
        if frl:
            for fr in frl:
                if fr not in FB and len(FB) >= _CFR_SLOTS:
                    continue                       # більше _CFR_SLOTS різних кадрів на одній моделі — пропускаємо
                FB.setdefault(fr, np.ones(nv, np.float32)); FS.setdefault(fr, np.ones(nv, np.float32))
                ak = _frame_angle_key(fr)          # ракурс цього кадру -> множник з таблиці (Ф / Л / П)
                FB[fr] *= 1.0 + (z.bright * getattr(z, "b_" + ak) * gm - 1.0) * w
                FS[fr] *= 1.0 + (z.sat * getattr(z, "s_" + ak) - 1.0) * w
            continue
        for a in lay_names:
            B[a] *= 1.0 + (z.bright * getattr(z, "b_" + a) * gm - 1.0) * w
            S[a] *= 1.0 + (z.sat * getattr(z, "s_" + a) - 1.0) * w
    vecs = {a: np.stack([B[a] - 1.0, S[a] - 1.0, np.zeros(nv, np.float32)], 1) for a in lay_names}
    # слоти кадрів: шар tc_cfrK (x = яскравість-1, y = насиченість-1) + властивість меша tc_cfrK_f = номер кадру
    for k in range(1, _CFR_SLOTS + 1):
        lay_names[f"cfr{k}"] = f"tc_cfr{k}"
        frs = sorted(FB)
        if k <= len(frs):
            fr = frs[k - 1]
            vecs[f"cfr{k}"] = np.stack([FB[fr] - 1.0, FS[fr] - 1.0, np.zeros(nv, np.float32)], 1)
            me[f"tc_cfr{k}_f"] = float(fr)
        else:
            vecs[f"cfr{k}"] = np.zeros((nv, 3), np.float32)
            me[f"tc_cfr{k}_f"] = 0.0
    if me.is_editmode:
        # 1.1.1: у Edit Mode меш живе в BMesh — пишемо туди (пряма запис падала / губилась при виході)
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        if len(bm.verts) == nv:
            for a, nm in lay_names.items():
                lay = bm.verts.layers.float_vector.get(nm) or bm.verts.layers.float_vector.new(nm)
                for v, d in zip(bm.verts, vecs[a].tolist()):
                    v[lay] = d
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return
    for a, nm in lay_names.items():
        at = me.attributes.get(nm)
        if at is not None and (at.domain != 'POINT' or at.data_type != 'FLOAT_VECTOR' or len(at.data) != nv):
            me.attributes.remove(at)             # 1.1.4: битий шар (напр. з 1.1.0, створений в Edit Mode) — перестворити
            at = None
        if at is None:
            at = me.attributes.new(nm, 'FLOAT_VECTOR', 'POINT')
        at.data.foreach_set("vector", vecs[a].ravel())
    me.update()


_ZF = ("enabled", "bright", "sat", "transition", "trans_strength", "b_f", "b_l", "b_r", "s_f", "s_l", "s_r",
       "only_frame", "frames", "grad_top", "grad_bot", "grad_curve")
_CFR_SLOTS = 6          # 1.31.0: до 6 різних кадрів «лише кадри» на одній моделі (пульт FABRIC LOOK читає tc_cfr1..6)


def _parse_frames(s):
    """'2, 24, 27-29' -> [2, 24, 27, 28, 29]"""
    out = set()
    for part in str(s).replace(";", ",").split(","):
        part = part.strip().replace("–", "-")
        if not part:
            continue
        a, _, b = part.partition("-")
        try:
            a = int(a); b = int(b) if b.strip() else a
        except ValueError:
            continue
        out.update(range(min(a, b), max(a, b) + 1))
    return sorted(f for f in out if f > 0)


def _zone_title(z):
    """1.32.1: назва зони для панелі — хвіст «(лише кадр N)» з назви при створенні замінюємо на ПОТОЧНІ кадри зони
    (додав кадр 3 до «лише кадр 2» -> «(лише кадри 2, 3)»; кадри прибрав -> без хвоста). Свою назву не чіпаємо."""
    import re
    base = re.sub(r"\s*\((лише кадр[иі]?[^)]*|усі кадри)\)\s*$", "", z.name)
    fl = _zone_frames(z)
    if not fl:
        return base
    return f"{base} (лише кадр {fl[0]})" if len(fl) == 1 else f"{base} (лише кадри {_frames_str(fl)})"


def _zone_frames(z):
    fl = _parse_frames(getattr(z, "frames", ""))
    if not fl and getattr(z, "only_frame", 0) > 0:
        fl = [z.only_frame]
    return fl


def _frame_angle_key(fr):
    """1.31.0: ракурс кадру за поворотом Control_Rotation на цьому кадрі (без frame_set): 'f' фронт, 'l' — видно лівий
    бік (поворот > +10°, напр. кадри 2, 24), 'r' — правий (< −10°, напр. 3, 23)."""
    import math
    rot = bpy.data.objects.get("Control_Rotation")
    ad = rot.animation_data if rot else None
    fc = None
    if ad and ad.action:
        try:
            for L_ in ad.action.layers:
                for st in L_.strips:
                    for cb in st.channelbags:
                        fc = fc or next((c for c in cb.fcurves if c.data_path == "rotation_euler" and c.array_index == 2), None)
        except Exception:
            fc = ad.action.fcurves.find("rotation_euler", index=2)
    a = fc.evaluate(fr) if fc else (rot.rotation_euler.z if rot else 0.0)
    a = math.atan2(math.sin(a), math.cos(a))
    return 'f' if abs(a) < math.radians(10) else ('l' if a > 0 else 'r')


class THUMA_OT_zone_this_frame(bpy.types.Operator):
    bl_idname = "thuma.zone_this_frame"
    bl_label = "Лише цей кадр"
    bl_description = "Ця зона діятиме ЛИШЕ на поточному кадрі (на інших кадрах — без змін). Ще раз — на всіх кадрах"
    bl_options = {'REGISTER', 'UNDO'}
    mesh: bpy.props.StringProperty()
    uid: bpy.props.IntProperty()

    def execute(self, context):
        me = bpy.data.meshes.get(self.mesh)
        z = next((q for q in me.thuma_zones if q.uid == self.uid), None) if me else None
        if z is None:
            return {'CANCELLED'}
        cur = context.scene.frame_current
        fl = _zone_frames(z)
        fl = [f for f in fl if f != cur] if cur in fl else sorted(fl + [cur])
        z.only_frame = 0
        z.frames = ", ".join(map(str, fl))
        self.report({'INFO'}, f"Зона «{_zone_title(z)}»: " + (f"лише кадри {z.frames}" if fl else "усі кадри"))
        return {'FINISHED'}
_SYNC = [False]


def _upd(self, context):
    try:
        _rebuild(self.id_data)
    except Exception as e:                      # не валити UI помилкою під час руху повзунка
        print("[Thuma Fabric] своя зона:", e)
    # 1.17.1: зона, розширена на інші модулі («Додати»), — ті самі повзунки на всіх її частинах
    if self.link and not _SYNC[0]:
        _SYNC[0] = True
        try:
            for me in bpy.data.meshes:
                if me == self.id_data:
                    continue
                for z in me.thuma_zones:
                    if z.link == self.link:
                        for f in _ZF:
                            if getattr(z, f) != getattr(self, f):
                                setattr(z, f, getattr(self, f))
        finally:
            _SYNC[0] = False


class THUMA_Zone(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Назва", default="Зона", description="Назва зони (двічі клікни, щоб перейменувати)")
    uid: bpy.props.IntProperty()
    link: bpy.props.StringProperty()           # 1.17.1: спільний ключ частин однієї зони на різних модулях
    enabled: bpy.props.BoolProperty(name="Увімкнено", default=True, update=_upd,
                                    description="Тимчасово вимкнути цю зону (без видалення)")
    # 1.31.0: зона лише на ОДНОМУ кадрі (0 = на всіх кадрах, як було)
    only_frame: bpy.props.IntProperty(name="Лише кадр", default=0, min=0, update=_upd,
                                      description="(старе поле, одне число) — тепер використовуй «Лише кадри»")
    frames: bpy.props.StringProperty(name="Лише кадри", default="", update=_upd,
                                     description="Порожньо = зона діє на всіх кадрах. Інакше лише на цих кадрах, через кому, "
                                                 "можна діапазони: 2, 24 або 22-24, 49")
    bright: bpy.props.FloatProperty(name="Яскравість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                    description="Яскравість вибраних полігонів. 1 = без змін, менше = темніше")
    sat: bpy.props.FloatProperty(name="Насиченість", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість вибраних полігонів. 1 = без змін, 0 = сіре")
    transition: bpy.props.FloatProperty(name="Перехід, см", default=0.0, soft_min=-30.0, soft_max=30.0, update=_upd,
                                        description="Плюс: зміна плавно заходить на сусідні полігони (по тканині), см. "
                                                    "Мінус: звуження всередину — у середині повна сила, до країв зони плавно "
                                                    "зникає. 0 = різко")
    trans_strength: bpy.props.FloatProperty(name="Сила", default=1.0, min=0.0, soft_max=2.0, update=_upd,
                                            description="Наскільки сильно зміна заходить на сусідні полігони: 1 = як було, "
                                                        "0.5 = удвічі слабше, 0 = без переходу, 2 = сильніше")
    # 1.33.0: градієнт яскравості згори вниз по висоті самої зони (правка клієнта: «спинка плоска»)
    grad_top: bpy.props.FloatProperty(name="Градієнт: верх ×", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                      description="Яскравість ВЕРХУ зони (множник поверх «Яскравість»). Плавно переходить "
                                                  "до «низ ×» донизу зони. 1 = без градієнта")
    grad_bot: bpy.props.FloatProperty(name="низ ×", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                      description="Яскравість НИЗУ зони (множник поверх «Яскравість»). 1 = без градієнта")
    grad_curve: bpy.props.FloatProperty(name="плавність", default=1.0, min=0.2, soft_max=5.0, update=_upd,
                                        description="Як швидко наростає перехід (завжди на всю висоту зони). 1 = рівномірно; "
                                                    "більше (2-3) = низ довго майже без змін, наростає ближче до верху; "
                                                    "менше (0.5) = змінюється одразу від низу, до верху вирівнюється")
    # 1.7.0: за РАКУРСОМ кадру — множники поверх яскравості/насиченості. Ф = фронт-кадри,
    # Л/П = кадри 3/4, де видно лівий/правий бік дивана. Інші ракурси не змінюються. 1 = без змін
    b_f: bpy.props.FloatProperty(name="Ф", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на ФРОНТ-кадрах. Множник, 1 = без змін")
    b_l: bpy.props.FloatProperty(name="Л", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на кадрах 3/4, де видно ЛІВИЙ бік дивана (напр. 2, 24, 27, 29). Множник, 1 = без змін")
    b_r: bpy.props.FloatProperty(name="П", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Яскравість зони лише на кадрах 3/4, де видно ПРАВИЙ бік дивана (напр. 3, 23, 26, 30). Множник, 1 = без змін")
    s_f: bpy.props.FloatProperty(name="Ф", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на ФРОНТ-кадрах. Множник, 1 = без змін")
    s_l: bpy.props.FloatProperty(name="Л", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на кадрах 3/4, де видно ЛІВИЙ бік дивана. Множник, 1 = без змін")
    s_r: bpy.props.FloatProperty(name="П", default=1.0, min=0.0, soft_max=3.0, update=_upd,
                                 description="Насиченість зони лише на кадрах 3/4, де видно ПРАВИЙ бік дивана. Множник, 1 = без змін")


def _mode(mode, back=False):
    """mode_set, що не падає на модулі, прихованому в цьому кадрі (видимість конфігурацій анімована).
    Вийти в Object Mode — завжди можна (на мить знімаємо приховування). Повернутись у Edit (back=True) —
    лише якщо видно; інакше тихо лишаємось в Object. Повертає True/False."""
    try:
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        pass
    ob = bpy.context.view_layer.objects.active
    if back or ob is None or mode != 'OBJECT':
        return False
    hv, hs = ob.hide_viewport, ob.hide_get()
    try:
        ob.hide_viewport = False
        ob.hide_set(False)
        bpy.ops.object.mode_set(mode=mode)
        return True
    except RuntimeError:
        return False
    finally:
        ob.hide_viewport = hv
        ob.hide_set(hs)


def _enter_paint(op, context):
    """Увійти у Vertex Paint; на прихованому модулі — зрозуміле повідомлення замість помилки."""
    if context.mode == 'PAINT_VERTEX':
        return True
    if not _mode('VERTEX_PAINT'):
        op.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        return False
    return True


def _sel_faces(context, ob):
    """Виділені полігони (з Edit Mode синхронізуємо)."""
    import numpy as np
    was_edit = context.mode == 'EDIT_MESH'
    if was_edit:
        _mode('OBJECT')
    me = ob.data
    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
    if was_edit:
        _mode('EDIT', back=True)
    return sel


def _config_of(ob):
    """Колекція конфігурації (дочірня «Product»), у якій лежить об'єкт."""
    prod = bpy.data.collections.get("Product")
    if prod is None:
        return None
    for c in prod.children:
        if ob.name in c.all_objects:
            return c
    return None


def _split_for_config(ob):
    """Окрема копія моделі для ЦІЄЇ конфігурації (усі такі модулі в ній). Повертає новий меш."""
    cfg = _config_of(ob)
    me = ob.data
    if cfg is None:
        return None, None
    if me.get("tc_config") == cfg.name:            # уже окрема для цієї конфігурації
        return me, cfg
    new = me.copy()
    new.name = f"{me.get('tc_base', me.name)} [{cfg.name[:24]}]"
    new["tc_config"] = cfg.name
    new["tc_base"] = me.get("tc_base", me.name)
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = new
    return new, cfg


def _split_for_object(ob):
    """1.7.0: окрема копія моделі ЛИШЕ ДЛЯ ЦЬОГО МОДУЛЯ (об'єкта). У конфігурації часто стоять два однакові
    модулі (напр. два Corner) — копія на всю конфігурацію фарбувала обидва."""
    me = ob.data
    if me.get("tc_object") == ob.name and me.users == 1:      # уже окрема для цього модуля
        return me
    new = me.copy()
    base = me.get("tc_base", me.name)
    new.name = f"{base} [{ob.name[-24:]}]"
    new["tc_object"] = ob.name
    new["tc_base"] = base
    if "tc_config" in new:
        del new["tc_config"]
    ob.data = new
    return new


def _unsplit(ob):
    """Повернути модулі цієї конфігурації до спільної моделі (окрема копія видаляється, якщо більше не потрібна)."""
    me = ob.data
    base = bpy.data.meshes.get(me.get("tc_base", ""))
    if base is not None and me.get("tc_object"):             # 1.7.0: окрема копія одного модуля
        ob.data = base
        if me.users == 0:
            bpy.data.meshes.remove(me)
        return True
    cfg = _config_of(ob)
    if base is None or cfg is None or me.get("tc_config") is None:
        return False
    for o in cfg.all_objects:
        if o.type == 'MESH' and o.data == me:
            o.data = base
    if me.users == 0:
        bpy.data.meshes.remove(me)
    return True


class THUMA_OT_zone(bpy.types.Operator):
    bl_idname = "thuma.custom_zone"
    bl_label = "Своя зона"
    bl_options = {'REGISTER', 'UNDO'}
    action: bpy.props.EnumProperty(items=[('ADD', "Нова", ""), ('ADD_CFG', "Нова — лише ця конфігурація", ""),
                                          ('UNSPLIT', "Повернути до спільної моделі", ""), ('ASSIGN', "Перепризначити", ""),
                                          ('APPEND', "Додати", ""), ('APPEND_GO', "Додати виділене", ""),
                                          ('APPEND_END', "Готово", ""), ('SELECT', "Показати", ""), ('REMOVE', "Видалити", ""),
                                          ('SEAM', "До шва", ""), ('EDIT', "Вибрати полігони", ""),
                                          ('ADD_FRAME', "Нова — лише цей кадр", "")])
    index: bpy.props.IntProperty(default=-1)

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Нова зона УСЮДИ: на всіх таких модулях у всіх конфігураціях (спершу виділи полігони в Edit Mode)",
                'ADD_CFG': "Нова зона ЛИШЕ НА ЦЬОМУ МОДУЛІ (виділеному об'єкті): він отримає окрему копію моделі, "
                           "однакові модулі поруч і в інших конфігураціях не зміняться. Зони «усюди», змінені пізніше, "
                           "на цю копію не перейдуть",
                'ADD_FRAME': "Нова зона ЛИШЕ НА ПОТОЧНОМУ КАДРІ (напр. правка клієнта «тільки на цьому рендері»). "
                             "На інших кадрах — без змін. Яскравість — повзунками зони і таблицею ракурсів",
                'UNSPLIT': "Повернути цей модуль до спільної моделі (зони «лише цей модуль» зникнуть)",
                'ASSIGN': "Замінити полігони зони на поточне виділення",
                'APPEND': "Додати до цієї зони полігони з будь-якого модуля: натисни, потім виділи полігони "
                          "на іншому модулі (або на цьому) і натисни «Додати виділене». Інший модуль отримає власну "
                          "копію моделі — однакові модулі поруч не зміняться. Повзунки спільні",
                'APPEND_GO': "Додати виділені полігони до зони (усі модулі в Edit Mode). Те, що вже в зоні, лишається",
                'APPEND_END': "Закінчити додавання до зони",
                'SELECT': "Виділити полігони цієї зони (перейде в Edit Mode)",
                'REMOVE': "Видалити зону",
                'SEAM': "Розширити виділення до швів — увесь шматок тканини між швами",
                'EDIT': "Перейти в Edit Mode (режим полігонів), щоб виділити потрібні"}[props.action]

    def execute(self, context):
        import numpy as np
        wm = context.window_manager
        if self.action == 'APPEND_END':
            wm.thuma_add_to = ""
            return {'FINISHED'}
        if self.action == 'APPEND_GO':
            return self._append_go(context)
        ob = context.active_object
        if not _ups_mesh(ob):
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по тканині дивана)")
            return {'CANCELLED'}
        me = ob.data
        if self.action == 'EDIT':
            if context.mode != 'EDIT_MESH':
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except RuntimeError:
                    self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
                    return {'CANCELLED'}
            context.tool_settings.mesh_select_mode = (False, False, True)
            return {'FINISHED'}
        if self.action == 'SEAM':
            if context.mode != 'EDIT_MESH':
                self.report({'WARNING'}, "Спершу виділи хоча б один полігон у Edit Mode")
                return {'CANCELLED'}
            bpy.ops.mesh.select_linked(delimit={'SEAM'})
            return {'FINISHED'}
        # 1.1.1: усі зміни даних меша — в Object Mode, потім повертаємось у той режим, що був
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            _mode('OBJECT')
        try:
            ok = self._apply(context, me)
        except Exception as e:
            self.report({'ERROR'}, f"Своя зона: {e}")
            ok = False
        if was_edit and context.mode != 'EDIT_MESH':
            try:                                   # 1.2.1: прихований у цьому кадрі об'єкт не пускає в Edit Mode — лишаємось в Object
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                pass
        return {'FINISHED'} if ok else {'CANCELLED'}

    def _apply(self, context, me):
        import numpy as np
        if self.action == 'UNSPLIT':
            if not _unsplit(context.active_object):
                self.report({'WARNING'}, "Ця модель і так спільна")
                return False
            return True
        if self.action == 'ADD_CFG':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            me = _split_for_object(context.active_object)
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid} (лише цей модуль)"
            _rebuild(me)
            return True
        if self.action in ('ADD', 'ADD_FRAME'):
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
                return False
            uid = max([z.uid for z in me.thuma_zones], default=0) + 1
            at = me.attributes.get(f"tc_z{uid}") or me.attributes.new(f"tc_z{uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            z = me.thuma_zones.add(); z.uid = uid; z.name = f"Зона {uid}"
            if self.action == 'ADD_FRAME':                # 1.31.0: зона лише на поточному кадрі
                z.name = f"Зона {uid} (лише кадр {context.scene.frame_current})"
                z.frames = str(context.scene.frame_current)
            _rebuild(me)
            return True
        if not (0 <= self.index < len(me.thuma_zones)):
            return False
        z = me.thuma_zones[self.index]
        if self.action == 'ASSIGN':
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            at = me.attributes.get(f"tc_z{z.uid}") or me.attributes.new(f"tc_z{z.uid}", 'BOOLEAN', 'FACE')
            at.data.foreach_set("value", sel)
            _rebuild(me)
        elif self.action == 'APPEND':             # 1.17.1: «Додати» — запам'ятати зону, полігони беремо з будь-якого модуля
            context.window_manager.thuma_add_to = f"{me.name}|{z.uid}"
        elif self.action == 'SELECT':
            at = me.attributes.get(f"tc_z{z.uid}")
            if at is None:
                return False
            fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
            me.polygons.foreach_set("select", fm)
            try:
                bpy.ops.object.mode_set(mode='EDIT')
                context.tool_settings.mesh_select_mode = (False, False, True)
            except RuntimeError:
                self.report({'WARNING'}, "Модуль прихований у цьому кадрі — перейди на кадр, де він видимий")
        elif self.action == 'REMOVE':
            name = f"tc_z{z.uid}"
            me.thuma_zones.remove(self.index)
            try:                                  # 1.1.4: битий шар зони не заважає видаленню
                at = me.attributes.get(name)
                if at is not None:
                    me.attributes.remove(at)
            except Exception as e:
                print("[Thuma Fabric] видалення шару зони:", e)
            _rebuild(me)
        return True

    def _append_go(self, context):
        import numpy as np
        import time
        wm = context.window_manager
        mname, _, uid = wm.thuma_add_to.rpartition("|")
        src_me = bpy.data.meshes.get(mname)
        src = next((q for q in src_me.thuma_zones if str(q.uid) == uid), None) if src_me else None
        if src is None:
            wm.thuma_add_to = ""
            self.report({'WARNING'}, "Зону, до якої додавали, не знайдено")
            return {'CANCELLED'}
        obs = [o for o in (context.objects_in_mode or [context.active_object]) if _ups_mesh(o)]
        if not obs:
            self.report({'WARNING'}, "Виділи модуль оббивки і його полігони в Edit Mode")
            return {'CANCELLED'}
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            _mode('OBJECT')
        if not src.link:
            src.link = f"z{int(time.time() * 1000)}"
        n = 0
        mes = []
        for o in obs:
            me = o.data
            if me != src_me:
                sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
                if sel.any() and me.users > 1:     # лише ЦЕЙ модуль: однакові модулі мають спільну модель
                    me = _split_for_object(o)
            if me not in mes:
                mes.append(me)
        for me in mes:
            sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
            if not sel.any():
                continue
            z = src if me == src_me else next((q for q in me.thuma_zones if q.link == src.link), None)
            if z is None:                          # частина зони на іншій моделі: ті самі назва й повзунки
                z = me.thuma_zones.add()
                z.uid = max([q.uid for q in me.thuma_zones], default=0) + 1
                z.name = src.name
                z.link = src.link
                _SYNC[0] = True
                try:
                    for f in _ZF:
                        setattr(z, f, getattr(src, f))
                finally:
                    _SYNC[0] = False
            at = me.attributes.get(f"tc_z{z.uid}") or me.attributes.new(f"tc_z{z.uid}", 'BOOLEAN', 'FACE')
            fm = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", fm)
            at.data.foreach_set("value", fm | sel)
            _rebuild(me)
            n += 1
        if was_edit:
            _mode('EDIT', back=True)
        if not n:
            self.report({'WARNING'}, "Нема виділених полігонів: Edit Mode -> виділи полігони")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Додано до «{src.name}» ({n} мод.)")
        return {'FINISHED'}


def _draw_zone_sliders(lay, z):
    col = lay.column(align=True)
    col.prop(z, "bright"); col.prop(z, "sat")
    r = col.row(align=True)                        # 1.18.0: перехід і сила — навпіл
    r.prop(z, "transition", text="Перехід, см"); r.prop(z, "trans_strength")
    r = col.row(align=True)                        # 1.33.0: градієнт згори вниз
    r.prop(z, "grad_top"); r.prop(z, "grad_bot"); r.prop(z, "grad_curve")
    for lab, pre in (("Яскравість за ракурсом:", "b_"), ("Насиченість за ракурсом:", "s_")):
        r = col.row(align=True)
        r.label(text=lab)
        ca = {"Ф": "f", "Л": "l", "ЗЛ": "l", "П": "r", "ЗП": "r"}.get(_cur_ang())
        for a in "flr":
            sub = r.row(align=True); sub.alert = a == ca    # 1.32.0: ракурс поточного кадру — червоним
            sub.prop(z, pre + a)


def _draw_add_box(c, context):
    """1.17.1: зона в режимі «Додати» — на самому верху панелі, на будь-якому модулі."""
    wm = context.window_manager
    if wm.thuma_add_to:                            # 1.17.1: режим «Додати» до зони з будь-якого модуля
        mname, _, uid = wm.thuma_add_to.rpartition("|")
        sm = bpy.data.meshes.get(mname)
        sz = next((q for q in sm.thuma_zones if str(q.uid) == uid), None) if sm else None
        bx = c.box()
        bx.alert = True
        bx.label(text=f"Додаю до «{sz.name if sz else '?'}»: виділи полігони на будь-якому модулі", icon='ADD')
        bx.label(text="Порада: виділи кілька модулів і Tab — полігони на всіх без перемикання", icon='INFO')
        r = bx.row(align=True)
        r.scale_y = 1.3
        r.operator("thuma.custom_zone", text="Додати виділене", icon='CHECKMARK').action = 'APPEND_GO'
        r.operator("thuma.custom_zone", text="Готово", icon='X').action = 'APPEND_END'
        if sz is not None:                         # зона видна, на якому б модулі не був
            bx.alert = False
            row = bx.row(align=True)
            row.prop(sz, "enabled", text="", icon='HIDE_OFF' if sz.enabled else 'HIDE_ON', emboss=False)
            row.prop(sz, "name", text="")
            _draw_zone_sliders(bx, sz)


def _zone_tuned(z):
    return any(abs(getattr(z, f) - 1.0) > 1e-4 for f in ("bright", "sat", "b_f", "b_l", "b_r", "s_f", "s_l", "s_r",
                                                          "grad_top", "grad_bot"))


class THUMA_OT_zone_part_remove(bpy.types.Operator):
    """1.32.3: прибрати ОДИН модуль зі звʼязаної своєї зони (решта модулів зони лишаються)"""
    bl_idname = "thuma.zone_part_remove"
    bl_label = "Прибрати модуль із зони"
    bl_description = ("Прибрати цей модуль із зони: на ньому зона зникне, на інших модулях лишиться як є. "
                      "Якщо модуль у зоні один — зона видаляється. Можна повернути Ctrl+Z")
    bl_options = {'REGISTER', 'UNDO'}
    mesh: bpy.props.StringProperty()
    uid: bpy.props.IntProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Прибрати модуль із зони?",
                                                     message="На інших модулях зона лишиться")

    def execute(self, context):
        me = bpy.data.meshes.get(self.mesh)
        i = next((i for i, q in enumerate(me.thuma_zones) if q.uid == self.uid), None) if me else None
        if i is None:
            self.report({'WARNING'}, "Зону на цьому модулі не знайдено")
            return {'CANCELLED'}
        name = me.thuma_zones[i].name
        me.thuma_zones.remove(i)
        try:
            at = me.attributes.get(f"tc_z{self.uid}")
            if at is not None:
                me.attributes.remove(at)
        except Exception as e:
            print("[Thuma Material] прибрати модуль із зони:", e)
        _rebuild(me)
        nm = me.name.replace("Thuma_Essential-Sectional_", "").replace("Thuma_Essential-", "")
        self.report({'INFO'}, f"«{name}»: модуль {nm} прибрано із зони")
        for a in (context.screen.areas if context.screen else []):
            a.tag_redraw()
        return {'FINISHED'}


class THUMA_OT_zone_owner(bpy.types.Operator):
    bl_idname = "thuma.zone_owner"
    bl_label = "Вибрати модуль зі своєю зоною"
    bl_description = "Виділити модуль (об'єкт), на моделі якого є ця своя зона — її повзунки з'являться нижче"
    bl_options = {'REGISTER', 'UNDO'}
    mesh: bpy.props.StringProperty()

    def execute(self, context):
        me = bpy.data.meshes.get(self.mesh)
        obs = [o for o in context.view_layer.objects if o.type == 'MESH' and o.data == me]
        if not obs:
            self.report({'WARNING'}, "Модуль не знайдено")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        sc = context.scene
        vis = [o for o in obs if o.visible_get()]
        if not vis:
            # 1.19.9: НЕ робити активним прихований у кадрі об'єкт (Blender падав) — спершу перейти на його кадр
            fr = None
            for part in str(me.get("tc_frames", "")).split(","):
                part = part.strip().split("-")[0]
                if part.isdigit():
                    fr = int(part); break
            if fr is None:
                for f in _scan_frames(sc):
                    sc.frame_set(f)
                    if any(o.visible_get() for o in obs):
                        fr = f; break
            if fr is None:
                self.report({'WARNING'}, "Модуль не видно на жодному кадрі")
                return {'CANCELLED'}
            sc.frame_set(fr)
            vis = [o for o in obs if o.visible_get()]
            if not vis:
                self.report({'WARNING'}, f"Модуль не видно на кадрі {fr} — натисни «Оновити кадри»")
                return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        o = vis[0]
        o.select_set(True)
        context.view_layer.objects.active = o
        self.report({'INFO'}, f"Кадр {sc.frame_current}: вибрано {o.name}")
        return {'FINISHED'}


def _scan_frames(sc):
    """1.31.0: які кадри перебирати — усі маркери сцени + діапазон рендера (діапазон часто 1..1, коли рендерять
    один кадр, — тоді «Оновити кадри» писало «не видно»)."""
    mk = [m.frame for m in sc.timeline_markers]
    return range(min([sc.frame_start] + mk), max([sc.frame_end] + mk) + 1)


def _frames_str(fr):
    """[22, 23, 24, 49] -> '22-24, 49'"""
    out, i = [], 0
    while i < len(fr):
        j = i
        while j + 1 < len(fr) and fr[j + 1] == fr[j] + 1:
            j += 1
        out.append(str(fr[i]) if i == j else f"{fr[i]}-{fr[j]}")
        i = j + 1
    return ", ".join(out)


class THUMA_OT_zone_arm(bpy.types.Operator):
    bl_idname = "thuma.zone_arm"
    bl_label = "Додати до цієї зони"
    bl_description = ("Додати полігони з БУДЬ-ЯКОГО модуля до цієї зони: натисни, виділи модуль і його полігони "
                      "в Edit Mode, потім «Додати виділене» вгорі «Своїх зон». Повзунки спільні")
    mesh: bpy.props.StringProperty()
    uid: bpy.props.IntProperty()

    def execute(self, context):
        context.window_manager.thuma_add_to = f"{self.mesh}|{self.uid}"
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


class THUMA_OT_zone_frames(bpy.types.Operator):
    bl_idname = "thuma.zone_frames"
    bl_label = "Оновити кадри своїх зон"
    bl_description = "Пройти всі кадри і записати, на яких видно модулі зі своїми зонами (~7 с, Blender на цей час зависне)"
    bl_options = {'REGISTER'}

    def execute(self, context):
        sc = context.scene
        cur = sc.frame_current
        meshes = [me for me in bpy.data.meshes if me.users and len(me.thuma_zones)]
        users = {me.name: [o for o in sc.objects if o.type == 'MESH' and o.data == me] for me in meshes}
        fr = {me.name: [] for me in meshes}
        try:
            for f in _scan_frames(sc):
                sc.frame_set(f)
                for me in meshes:
                    if any(o.visible_get() for o in users[me.name]):
                        fr[me.name].append(f)
        finally:
            sc.frame_set(cur)
        for me in meshes:
            me["tc_frames"] = _frames_str(fr[me.name]) or "не видно"
        self.report({'INFO'}, f"Кадри оновлено для {len(meshes)} моделей")
        return {'FINISHED'}


def _draw_custom(c, context):
    head, body = c.panel("thuma_custom_root", default_closed=False)
    head.label(text="Свої зони (вибрані полігони)", icon='FACESEL')
    if body is None:
        return
    _draw_add_box(body, context)                   # 1.17.1: зона в режимі «Додати» — тут, на будь-якому модулі
    # 1.19.3: усі свої зони сцени — видно, що й де налаштовано, без кліків по модулях
    allz = [(me, z) for me in bpy.data.meshes if me.users for z in me.thuma_zones]
    # 1.19.11: звʼязані частини (одна зона на кількох модулях) — ОДИН рядок «Зона · N модулі · кадри …»
    groups = {}
    for me, z in allz:
        groups.setdefault(z.link or f"{me.name}|{z.uid}", []).append((me, z))
    abox = body.box()                              # 1.19.4: виділено рамкою
    lh, lb = abox.panel("thuma_cz_all", default_closed=True)
    n_t = sum(1 for parts in groups.values() if any(z.enabled and _zone_tuned(z) for _, z in parts))
    # 1.33.1: виділений модуль — його зони яскраві з позначкою, решта приглушені
    ob_ = context.active_object
    sel_me = ob_.data if ob_ is not None and ob_.type == 'MESH' else None
    n_mine = sum(1 for parts in groups.values() if any(me == sel_me for me, _ in parts)) if sel_me else 0
    lh.label(text=f"Усі свої зони в сцені: {len(groups)} (діють: {n_t})"
                  + (f" · на виділеному: {n_mine}" if sel_me is not None and n_mine else ""), icon='OUTLINER')
    if lb is not None:
        if not groups:
            lb.label(text="Своїх зон нема")
        for key, parts in groups.items():
            me0, z0 = parts[0]
            on = z0.enabled and _zone_tuned(z0)
            mine = sel_me is not None and any(me == sel_me for me, _ in parts)
            col = lb.box().column(align=True)
            col.active = mine or sel_me is None or n_mine == 0
            r = col.row(align=True)
            if mine:
                r.label(text="", icon='LAYER_ACTIVE')
            # 1.32.2: глазик — справжня кнопка (раніше значок-галочка, клік нічого не робив); звʼязана зона — на всіх модулях
            r.prop(z0, "enabled", text="", icon='HIDE_OFF' if z0.enabled else 'HIDE_ON', emboss=False)
            _hl_lamp(r, "CZ:" + ";".join(f"{me.name}|{z.uid}" for me, z in parts))
            frs = ", ".join(str(me.get("tc_frames", "?")) for me, _ in parts)
            many = len(parts) > 1
            r.label(text=(f"{_zone_title(z0)}  ·  {len(parts)} модулі, звʼязані" if many else _zone_title(z0))
                    + ("" if on else ("  (вимкнена)" if not z0.enabled else "  (повзунки = 1)")),
                    icon='LINKED' if many else 'FACESEL')
            o = r.operator("thuma.zone_arm", text="Додати", icon='ADD'); o.mesh = me0.name; o.uid = z0.uid
            for me, z in parts:
                rr = col.row(align=True)
                rr.label(text="", icon='LAYER_ACTIVE' if me == sel_me else 'BLANK1')
                nm = me.name.replace("Thuma_Essential-Sectional_", "").replace("Thuma_Essential-", "")
                rr.label(text=f"кадр {me.get('tc_frames', '?')} · {nm}" + ("  ← виділений" if me == sel_me else ""))
                rr.operator("thuma.zone_owner", text="", icon='RESTRICT_SELECT_OFF').mesh = me.name
                o = rr.operator("thuma.zone_part_remove", text="", icon='X')    # 1.32.3: прибрати модуль із зони
                o.mesh = me.name; o.uid = z.uid
        if allz:
            lb.operator("thuma.zone_frames", text="Оновити кадри (~7 с)", icon='TIME')
    ob = context.active_object
    if not _ups_mesh(ob):
        body.label(text="Виділи модуль оббивки (клік по тканині)", icon='INFO')
        return
    me = ob.data
    if me.get("tc_object"):
        bx = body.box()
        bx.label(text=f"Окрема модель: лише цей модуль ({me['tc_object']})", icon='LINKED')
        bx.operator("thuma.custom_zone", text="Повернути до спільної моделі", icon='UNLINKED').action = 'UNSPLIT'
    elif me.get("tc_config"):
        bx = body.box()
        bx.label(text=f"Окрема модель: лише «{me['tc_config']}»", icon='LINKED')
        bx.operator("thuma.custom_zone", text="Повернути до спільної моделі", icon='UNLINKED').action = 'UNSPLIT'
    else:
        body.label(text=f"Модель: {me.name} (спільна для всіх конфігурацій)", icon='MESH_DATA')
    r = body.row(align=True)
    r.operator("thuma.custom_zone", text="Вибрати полігони", icon='EDITMODE_HLT').action = 'EDIT'
    r.operator("thuma.custom_zone", text="До шва", icon='MOD_EDGESPLIT').action = 'SEAM'
    rn = body.row(align=True)
    rn.scale_x = 0.9
    rn.operator("thuma.custom_zone", text="Нова: усюди", icon='ADD').action = 'ADD'
    rn.operator("thuma.custom_zone", text="лише модуль", icon='OBJECT_DATA').action = 'ADD_CFG'
    rn.operator("thuma.custom_zone", text=f"лише кадр {context.scene.frame_current}", icon='RENDER_STILL').action = 'ADD_FRAME'
    for i, z in enumerate(me.thuma_zones):
        zh, zb = body.panel(f"thuma_cz_{z.uid}", default_closed=False)
        row = zh.row(align=True)
        row.prop(z, "enabled", text="", icon='HIDE_OFF' if z.enabled else 'HIDE_ON', emboss=False)
        _hl_lamp(row, f"CZ:{me.name}|{z.uid}")
        row.label(text=_zone_title(z), icon='LINKED' if z.link else 'FACESEL')
        if z.link:                                   # 1.19.11: де ще ця зона
            others = [m2 for m2 in bpy.data.meshes if m2 != me and m2.users and any(q.link == z.link for q in m2.thuma_zones)]
            if others:
                row.label(text="також: кадри " + ", ".join(str(m2.get("tc_frames", "?")) for m2 in others))
        o = row.operator("thuma.reset", text="", icon='LOOP_BACK', emboss=False); o.scope = 'CUSTOM'; o.index = i
        if zb is None:
            continue
        zb.prop(z, "name", text="Назва")
        fr_ = zb.row(align=True)                     # 1.31.0: лише кадри (через кому)
        fl_ = _zone_frames(z)
        fr_.prop(z, "frames", text="Лише кадри", placeholder="усі (напр. 2, 24)")
        cur_ = context.scene.frame_current
        o = fr_.operator("thuma.zone_this_frame", text=("− " if cur_ in fl_ else "+ ") + f"кадр {cur_}",
                         icon='RENDER_STILL', depress=cur_ in fl_)
        o.mesh = me.name; o.uid = z.uid
        if fl_:
            nm_ = {'f': "Ф", 'l': "Л", 'r': "П"}
            zb.label(text="Діє лише на: " + ", ".join(f"{f} ({nm_[_frame_angle_key(f)]})" for f in fl_[:8])
                     + (" …" if len(fl_) > 8 else "") + " — яскравість × стовпчик ракурсу", icon='INFO')
            if len(fl_) > _CFR_SLOTS:
                zb.label(text=f"Увага: на одній моделі діють лише перші {_CFR_SLOTS} різних кадрів", icon='ERROR')
        _draw_zone_sliders(zb, z)
        rr = zb.row(align=True)
        o = rr.operator("thuma.custom_zone", text="Показати", icon='RESTRICT_SELECT_OFF'); o.action = 'SELECT'; o.index = i
        o = rr.operator("thuma.custom_zone", text="Додати", icon='ADD'); o.action = 'APPEND'; o.index = i
        o = rr.operator("thuma.custom_zone", text="Перепризначити", icon='FILE_REFRESH'); o.action = 'ASSIGN'; o.index = i
        o = rr.operator("thuma.custom_zone", text="", icon='TRASH'); o.action = 'REMOVE'; o.index = i


class THUMA_OT_kutik_paint(bpy.types.Operator):
    bl_idname = "thuma.kutik_paint"
    bl_label = "Пензель кутика"
    bl_description = ("Малювати маску кутика прямо на модулі (Vertex Paint). Дорисувати — додати затемнення, "
                      "Стерти — прибрати там, де не треба. Модуль спільний: однакові модулі в сцені зміняться разом")
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('ADD', "Дорисувати", "Додати затемнення кутика пензлем"),
                                        ('ERASE', "Стерти", "Прибрати затемнення там, де не треба"),
                                        ('DONE', "Готово", "Вийти з малювання"),
                                        ('CLEAR', "Очистити модуль", "Прибрати все намальоване на цьому модулі")])

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Пензель: червоний = додати затемнення кутика (видно, якщо «Кутик: яскравість» < 1 або «Показати зони»)",
                'ERASE': "Пензель: зелений = стерти затемнення там, де воно не потрібне",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Прибрати все намальоване на виділеному модулі (повернути автоматичний кутик)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        ob = context.active_object
        if not ob or ob.type != 'MESH' or ob.data not in _meshes():
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        me = ob.data
        ca = me.color_attributes.get("fz_kutik")
        if ca is None:
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
        if self.mode == 'CLEAR':
            ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
            me.update()
            return {'FINISHED'}
        me.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = (1.0, 0.0, 0.0) if self.mode == 'ADD' else (0.0, 1.0, 0.0)
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по модулю. " + ("Червоний = додати" if self.mode == 'ADD' else "Зелений = стерти"))
        return {'FINISHED'}


# ---------------- 1.30.0: СВОЇ ШВИ (виділені ребра конкретної моделі) ----------------
# Mesh.thuma_cseams (налаштування) + атрибут ребер tc_cs<uid> (INT, 1 = ребро шва). Результат усіх швів моделі ->
# атрибут вершин tc_cseam (x = відстань до найближчого шва, м; y = півширина, м; z = яскравість). FABRIC LOOK ≥ 67
# робить smoothstep по пікселях — шов рівний навіть 2-3 мм. Модель спільна: однакові модулі в сцені змінюються разом.
def _cs_rebuild(me):
    import numpy as np
    from mathutils.kdtree import KDTree
    edit = me.is_editmode
    if edit:
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table()
        co = np.array([v.co[:] for v in bm.verts], np.float64)
        ev = np.array([(e.verts[0].index, e.verts[1].index) for e in bm.edges], np.int64).reshape(-1, 2)
    else:
        co = np.empty(len(me.vertices) * 3); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        ev = np.empty(len(me.edges) * 2, np.int64); me.edges.foreach_get("vertices", ev); ev = ev.reshape(-1, 2)
    nv = len(co)
    out = np.zeros((nv, 3), np.float32); out[:, 0] = 1.0; out[:, 2] = 1.0
    best = np.full(nv, 9.0)
    any_on = False
    fab = _cs_fab(me)                              # 1.34.0: яскравість/ширина — тієї тканини, що зараз на моделі
    me["tc_cs_fab"] = fab
    for s in me.thuma_cseams:
        if not s.enabled:
            continue
        nm = f"tc_cs{s.uid}"
        if edit:
            lay = bm.edges.layers.int.get(nm)
            flags = np.array([e[lay] for e in bm.edges], bool) if lay is not None else np.zeros(len(ev), bool)
        else:
            at = me.attributes.get(nm)
            flags = np.zeros(len(ev), np.int32)
            if at is not None and at.domain == 'EDGE' and len(at.data) == len(ev):
                at.data.foreach_get("value", flags)
            flags = flags.astype(bool)
        if not flags.any():
            continue
        any_on = True
        pts = []
        for a, b in ev[flags]:
            pa, pb = co[a], co[b]
            n = max(1, int(np.linalg.norm(pb - pa) / 0.0005))
            pts.extend(pa + (pb - pa) * (k / n) for k in range(n + 1))
        kd = KDTree(len(pts))
        for i, p in enumerate(pts):
            kd.insert(p, i)
        kd.balance()
        s_bright, s_width = _cs_vals(s, fab)
        hw = max(s_width * 0.01 * 0.5, 0.00002)
        reach = max(4 * hw, 0.03)
        for i in range(nv):
            d = kd.find(co[i])[2]
            if d < reach and d < best[i]:
                best[i] = d
                out[i] = (d, hw, s_bright)
    if edit:
        lay = bm.verts.layers.float_vector.get("tc_cseam")
        if not any_on and lay is None:
            return
        lay = lay or bm.verts.layers.float_vector.new("tc_cseam")
        if not any_on:
            out[:] = (1.0, 0.0, 1.0)
        for v, d in zip(bm.verts, out.tolist()):
            v[lay] = d
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return
    at = me.attributes.get("tc_cseam")
    if not any_on:
        if at is not None:
            me.attributes.remove(at); me.update()
        return
    if at is not None and (at.domain != 'POINT' or at.data_type != 'FLOAT_VECTOR' or len(at.data) != nv):
        me.attributes.remove(at); at = None
    if at is None:
        at = me.attributes.new("tc_cseam", 'FLOAT_VECTOR', 'POINT')
    at.data.foreach_set("vector", out.ravel())
    me.update()


_CS_SYNC = [False]
_CS_F = ("name", "bright", "width", "enabled", "fab_json")


# 1.34.0: ребра шва — спільні для моделі (усі тканини), а яскравість і ширина — свої для кожної тканини.
# fab_json = {"<матеріал тканини>": [яскравість, ширина]}. Тканина без свого запису бере bright/width шва
# (як було до 1.34.0) — тому в сценах колег після оновлення нічого не змінюється.
def _cs_fab_map():
    """{меш: назва матеріалу тканини} — за першим об'єктом з цим мешем."""
    out = {}
    for o in bpy.data.objects:
        if o.type != 'MESH' or o.data in out:
            continue
        for sl in o.material_slots:
            m = sl.material
            if m is not None and m.get("thuma_fabric"):
                out[o.data] = m.name
                break
    return out


def _cs_fab(me):
    for o in bpy.data.objects:
        if o.data == me:
            for sl in o.material_slots:
                m = sl.material
                if m is not None and m.get("thuma_fabric"):
                    return m.name
    return ""


def _cs_fd(s):
    import json
    try:
        d = json.loads(s.fab_json or "{}")
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _cs_vals(s, fab):
    v = _cs_fd(s).get(fab) if fab else None
    return (float(v[0]), float(v[1])) if v else (s.bright, s.width)


def _cs_cur_fab(me):
    f = me.get("tc_cs_fab")
    return f if isinstance(f, str) else _cs_fab(me)


def _cs_fget(i):
    def g(self):
        return _cs_vals(self, _cs_cur_fab(self.id_data))[i]
    return g


def _cs_fset(i):
    def st(self, val):
        import json
        fab = _cs_cur_fab(self.id_data)
        if not fab:                                   # модель без тканини Thuma — як раніше, одне значення
            setattr(self, ("bright", "width")[i], val)
            return
        d = _cs_fd(self)
        cur = list(_cs_vals(self, fab)); cur[i] = round(val, 4)
        d[fab] = cur
        self.fab_json = json.dumps(d, ensure_ascii=False)   # update -> перебудова + той самий шов на інших моделях
    return st


@bpy.app.handlers.persistent                       # інакше Blender знімає обробник при відкритті файлу
def _cs_on_dg(scene, depsgraph=None):
    """Тканину на моделі поміняли — підставити яскравість/ширину швів цієї тканини (лише якщо вони різні)."""
    if _CS_SYNC[0]:
        return
    try:
        if depsgraph is not None and not any(isinstance(u.id, (bpy.types.Object, bpy.types.Material, bpy.types.Mesh))
                                             for u in depsgraph.updates):
            return
        mes = [me for me in bpy.data.meshes if me.users and len(getattr(me, "thuma_cseams", []))]
        if not mes:
            return
        fm = _cs_fab_map()
        for me in mes:
            f = fm.get(me, "")
            if me.get("tc_cs_fab") == f:
                continue
            _CS_SYNC[0] = True
            try:
                if any(s.fab_json not in ("", "{}") for s in me.thuma_cseams):
                    _cs_rebuild(me)
                else:
                    me["tc_cs_fab"] = f               # своїх значень під тканини нема — шов однаковий, не перебудовуємо
            finally:
                _CS_SYNC[0] = False
    except Exception as e:
        print("[Thuma Fabric] шви під тканину:", e)


def _cs_hidden_at(o, f):
    """Об'єкт (або батько) прихований у кадрі f — за ключами hide_viewport/hide_render, без frame_set."""
    for x in (o, o.parent):
        if x is None:
            continue
        ad = x.animation_data
        fcs = []
        if ad and ad.action:
            try:
                for L_ in ad.action.layers:
                    for st in L_.strips:
                        for cb in st.channelbags:
                            fcs += [c for c in cb.fcurves if c.data_path in ("hide_viewport", "hide_render")]
            except Exception:
                fcs = [c for c in ad.action.fcurves if c.data_path in ("hide_viewport", "hide_render")]
        if fcs:
            if any(c.evaluate(f) > 0.5 for c in fcs):
                return True
        elif x.hide_render or x.hide_viewport:
            return True
    return False


def _cs_key(me, s):
    return s.link or f"{me.name}#{s.uid}"


def _cs_upd(self, context):
    try:
        _cs_rebuild(self.id_data)
    except Exception as e:
        print("[Thuma Fabric] свій шов:", e)
    # 1.30.0: той самий шов на інших моделях (спільний link) — ті самі налаштування
    if self.link and not _CS_SYNC[0]:
        _CS_SYNC[0] = True
        try:
            for me in bpy.data.meshes:
                if me == self.id_data:
                    continue
                for q in me.thuma_cseams:
                    if q.link == self.link and any(getattr(q, f) != getattr(self, f) for f in _CS_F):
                        for f in _CS_F:
                            setattr(q, f, getattr(self, f))
                        try:
                            _cs_rebuild(me)
                        except Exception as e:
                            print("[Thuma Fabric] свій шов:", e)
        finally:
            _CS_SYNC[0] = False


class THUMA_CSeam(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Назва", default="Шов", update=_cs_upd,
                                   description="Назва шва (двічі клікни, щоб перейменувати)")
    uid: bpy.props.IntProperty()
    link: bpy.props.StringProperty()           # спільний ключ одного шва на різних моделях
    enabled: bpy.props.BoolProperty(name="Увімкнено", default=True, update=_cs_upd,
                                    description="Тимчасово вимкнути цей шов (без видалення)")
    bright: bpy.props.FloatProperty(name="Яскравість", default=0.6, min=0.0, soft_max=2.0, update=_cs_upd,
                                    description="Яскравість лінії шва. Менше 1 = темніший шов (0.6 = помітний), "
                                                "1 = без змін, більше 1 = світла лінія")
    width: bpy.props.FloatProperty(name="Ширина, см", default=0.4, min=0.02, soft_max=3.0, update=_cs_upd,
                                   description="Повна ширина лінії шва, см (по половині з кожного боку ребра)")
    fab_json: bpy.props.StringProperty(update=_cs_upd)   # 1.34.0: {тканина: [яскравість, ширина]}
    f_bright: bpy.props.FloatProperty(name="Яскравість", min=0.0, soft_max=2.0, get=_cs_fget(0), set=_cs_fset(0),
                                      description="Яскравість шва ЛИШЕ для тканини на цій моделі (інші тканини — свої "
                                                  "значення). Менше 1 = темніший шов, 1 = шва не видно, більше 1 = світла лінія")
    f_width: bpy.props.FloatProperty(name="Ширина, см", min=0.02, soft_max=3.0, get=_cs_fget(1), set=_cs_fset(1),
                                     description="Ширина лінії шва, см — ЛИШЕ для тканини на цій моделі")


def _cs_all():
    """{ключ шва: [(меш, шов)]} по всій сцені — список не залежить від виділеної моделі."""
    out = {}
    for me in bpy.data.meshes:
        if not me.users or not len(getattr(me, "thuma_cseams", [])):
            continue
        for q in me.thuma_cseams:
            out.setdefault(_cs_key(me, q), []).append((me, q))
    return out


class THUMA_OT_cseam(bpy.types.Operator):
    """Свій шов на виділених ребрах"""
    bl_idname = "thuma.cseam"
    bl_label = "Свій шов"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('ADD', "Новий", ""), ('APPEND', "Додати ребра", ""),
                                        ('REMOVE', "Прибрати ребра", ""), ('SEL', "Показати", ""), ('DEL', "Видалити", ""),
                                        ('GO', "Перейти до моделі", "")])
    key: bpy.props.StringProperty(options={'SKIP_SAVE'})   # 1.33.9: не запам'ятовувати ключ минулого шва

    @classmethod
    def description(cls, context, props):
        return {'ADD': "Edit Mode, режим ребер (2): виділи ребра — новий шов. Можна на кількох моделях одразу. "
                       "Модель спільна: однакові модулі в сцені отримають шов разом",
                'APPEND': "Edit Mode, ребра: ДОДАТИ виділені ребра до цього шва — на БУДЬ-ЯКІЙ моделі "
                          "(на іншій моделі шов зʼявиться з тими самими налаштуваннями)",
                'REMOVE': "Edit Mode, ребра: ПРИБРАТИ виділені ребра з цього шва",
                'SEL': "Виділити ребра цього шва на моделях у Edit Mode (або на виділеній моделі)",
                'DEL': "Видалити шов з усіх моделей",
                'GO': "Виділити модель з цим швом (видиму в цьому кадрі; якщо в цьому кадрі її нема — "
                      "перейти на найближчий кадр, де вона є)"}[props.mode]

    def _go(self, context, parts):
        sc = context.scene
        mes = {me for me, _ in parts}
        obs = [o for o in sc.objects if o.type == 'MESH' and o.data in mes]
        if not obs:
            self.report({'WARNING'}, "Модель з цим швом не знайдено")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        f0 = sc.frame_current
        order = [f0] + list(range(f0 + 1, sc.frame_end + 1)) + list(range(sc.frame_start, f0))
        for f in order:
            vis = [o for o in obs if not _cs_hidden_at(o, f)]
            if vis:
                break
        else:
            self.report({'WARNING'}, "Модель з цим швом не видно в жодному кадрі")
            return {'CANCELLED'}
        if f != f0:
            sc.frame_set(f)
        for o in context.selected_objects:
            o.select_set(False)
        ob = vis[0]
        ob.select_set(True)
        context.view_layer.objects.active = ob
        self.report({'INFO'}, f"Кадр {f}: {ob.name}")
        return {'FINISHED'}

    def execute(self, context):
        import numpy as np
        import time
        was_edit = context.mode == 'EDIT_MESH'
        obs = [o for o in (context.objects_in_mode if was_edit else [context.active_object]) if _ups_mesh(o)]
        meshes = list({o.data: None for o in obs})
        groups = _cs_all()
        if self.mode == 'GO':
            return self._go(context, groups.get(self.key, []))
        if self.mode in ('ADD', 'APPEND', 'REMOVE') and not was_edit:
            self.report({'WARNING'}, "Перейди в Edit Mode (Tab), режим ребер (2) і виділи ребра шва")
            return {'CANCELLED'}
        if self.mode != 'DEL' and not meshes:
            self.report({'WARNING'}, "Виділи модуль оббивки")
            return {'CANCELLED'}
        if was_edit:
            _mode('OBJECT')
        try:
            if self.mode == 'DEL':
                for me, q in groups.get(self.key, []):
                    at = me.attributes.get(f"tc_cs{q.uid}")
                    if at is not None:
                        me.attributes.remove(at)
                    i = next(i for i, x in enumerate(me.thuma_cseams) if x.uid == q.uid)
                    me.thuma_cseams.remove(i)
                    _cs_rebuild(me)
                return {'FINISHED'}
            # 1.33.9: новий шов — завжди з налаштувань за замовчуванням, не копія останнього шва
            tmpl = None if self.mode == 'ADD' else groups.get(self.key, [(None, None)])[0][1]
            key = self.key if self.mode != 'ADD' else f"cs{int(time.time() * 1000)}"
            total = 0
            for me in meshes:
                sel = np.zeros(len(me.edges), bool); me.edges.foreach_get("select", sel)
                q = next((x for x in me.thuma_cseams if _cs_key(me, x) == key), None)
                if self.mode == 'SEL':
                    if q is None:
                        continue
                    at = me.attributes.get(f"tc_cs{q.uid}")
                    fl = np.zeros(len(me.edges), np.int32)
                    if at is not None:
                        at.data.foreach_get("value", fl)
                    for coll in (me.polygons, me.edges, me.vertices):
                        coll.foreach_set("select", np.zeros(len(coll), bool))
                    me.edges.foreach_set("select", fl.astype(bool))
                    ev = np.empty(len(me.edges) * 2, np.int32); me.edges.foreach_get("vertices", ev)
                    vs = np.zeros(len(me.vertices), bool); vs[ev.reshape(-1, 2)[fl.astype(bool)].ravel()] = True
                    me.vertices.foreach_set("select", vs)
                    me.update()
                    context.tool_settings.mesh_select_mode = (False, True, False)
                    continue
                if not sel.any():
                    continue
                if q is None:
                    if self.mode == 'REMOVE':
                        continue
                    q = me.thuma_cseams.add()
                    q.uid = max([x.uid for x in me.thuma_cseams], default=0) + 1
                    _CS_SYNC[0] = True
                    try:
                        q.link = key
                        if tmpl is not None:
                            for f in _CS_F:
                                setattr(q, f, getattr(tmpl, f))
                        else:
                            q.name = f"Шов {len(groups) + 1}"
                            q.bright = 1.0            # 1.34.0: новий шов без впливу на всіх тканинах — налаштовуєш сам
                    finally:
                        _CS_SYNC[0] = False
                elif not q.link:
                    q.link = key
                nm = f"tc_cs{q.uid}"
                at = me.attributes.get(nm) or me.attributes.new(nm, 'INT', 'EDGE')
                cur = np.zeros(len(me.edges), np.int32); at.data.foreach_get("value", cur)
                cur = cur.astype(bool)
                new = cur & ~sel if self.mode == 'REMOVE' else cur | sel
                at.data.foreach_set("value", new.astype(np.int32))
                _cs_rebuild(me)
                total += int(sel.sum())
            if self.mode in ('ADD', 'APPEND', 'REMOVE') and not total:
                self.report({'WARNING'}, "Нічого не виділено: режим ребер (2), виділи ребра шва")
                return {'CANCELLED'}
            if total:
                self.report({'INFO'}, f"Ребер: {total}")
            was_edit = was_edit or self.mode == 'SEL'
        finally:
            if was_edit:
                _mode('EDIT', back=True)
        return {'FINISHED'}


def _draw_cseams(layout, context):
    b = layout.box()
    hr = b.row()
    hr.label(text="Свої шви", icon='MOD_EDGESPLIT')
    hr.operator("thuma.cseam", text="Новий шов з виділених ребер", icon='ADD').mode = 'ADD'
    groups = _cs_all()
    if not groups:
        b.label(text="Edit Mode → ребра (2) → виділи → «Новий шов…»", icon='INFO')
        return
    b.label(text="Яскр.: менше 1 = темна лінія, більше 1 = світла · См = ширина")
    ob_ = context.active_object                    # 1.33.1: шви виділеного модуля — яскраві з позначкою, решта приглушені
    sel_me = ob_.data if ob_ is not None and ob_.type == 'MESH' else None
    n_mine = sum(1 for parts in groups.values() if any(me == sel_me for me, _ in parts)) if sel_me else 0
    if sel_me is not None and n_mine:
        b.label(text=f"На виділеному модулі: {n_mine} шв.", icon='LAYER_ACTIVE')
    if sel_me is not None:                          # 1.34.0: яскравість/ширина — під тканину виділеного модуля
        fm = bpy.data.materials.get(_cs_cur_fab(sel_me) or "")
        if fm is not None:
            b.label(text=f"Яскр. і См — лише для тканини: {fm.get('thuma_fabric', fm.name)}", icon='MATERIAL')
    for key, parts in groups.items():
        me0, q = parts[0]
        mine = sel_me is not None and any(me == sel_me for me, _ in parts)
        col = b.column(align=True)
        col.active = mine or sel_me is None or n_mine == 0
        r = col.row(align=True)
        if mine:
            r.label(text="", icon='LAYER_ACTIVE')
        r.prop(q, "enabled", text="", icon='HIDE_OFF' if q.enabled else 'HIDE_ON', emboss=False)
        r.operator("thuma.seam_flash", text="", icon='LIGHT', emboss=False).key = "CS:" + key
        r.prop(q, "name", text="")
        qv = next((x for m_, x in parts if m_ == sel_me), q)   # значення — тканини виділеного модуля
        r.prop(qv, "f_bright", text="Яскр.")
        r.prop(qv, "f_width", text="См")
        o = r.operator("thuma.cseam", text="", icon='VIEWZOOM'); o.mode = 'GO'; o.key = key
        o = r.operator("thuma.cseam", text="", icon='RESTRICT_SELECT_OFF'); o.mode = 'SEL'; o.key = key
        o = r.operator("thuma.cseam", text="", icon='X'); o.mode = 'DEL'; o.key = key
        r2 = col.row(align=True)
        o = r2.operator("thuma.cseam", text="Додати виділені", icon='ADD'); o.mode = 'APPEND'; o.key = key
        o = r2.operator("thuma.cseam", text="Прибрати виділені", icon='REMOVE'); o.mode = 'REMOVE'; o.key = key
        names = sorted({me.name.replace("Thuma_Essential-", "").split(" [")[0].split(".")[0] for me, _ in parts})
        col.label(text="Моделі: " + ", ".join(names))
        col.separator(factor=0.6)


# ── 1.32.0: підсвітка шва у в'юпорті ─────────────────────────────────────────────
# Навів на лампочку біля рядка шва (або натиснув) — ребра цього шва в поточному кадрі блимають ~2 с і зникають.
# Малюється ПОВЕРХ в'юпорта (gpu), сцену/матеріали не змінює, у рендер не потрапляє, рендер у в'юпорті не перезапускає.
# Шви = ребра UV-шва (як у пульті, fz8_seam); до якої зони належить шов — за маскою деталей wc_part полігонів поруч,
# переведеною у сторони ЗІБРАНОГО дивана (_cfg_map_obs). Зони пульта рахуються в шейдері за нормалями, маска — за
# розфарбуванням деталей: майже завжди збігаються, але на дрібних шматках можуть трохи відрізнятися.
_HL = {"handler": None, "batch": None, "t0": 0.0, "key": "", "last": ("", 0.0)}
_HL_DUR = 2.2
_HL_COLOR = (1.0, 0.8, 0.0)
_HL_HIDDEN = (0.25, 0.75, 1.0)      # 1.33.4: та частина зони, що за моделлю (ззаду) — блакитна крізь модель
_HL_ZONES = {"спинка": {"Спинка"}, "сидіння": {"Сидіння"}, "фронт": {"Фронт", "Фронт бічний"},
             "внутр. ліва": {"Боковина внутр. ліва"}, "внутр. права": {"Боковина внутр. права"},
             "зовн. ліва": {"Боковина зовн. ліва"}, "зовн. права": {"Боковина зовн. права"}, "верх": {"Верх"},
             "задня стінка": {"Задня стінка"},
             "інше": {"Скруглення (тканина)", "Низ (тканина)", "Щілини (тканина)", "Стик (схований бік)"}}
_HL_WING = {"сидіння, ліве крило": -1, "сидіння ліве, фронт": -1, "сидіння, праве крило": 1, "сидіння праве, фронт": 1}


_HL_FABRIC = set().union(*_HL_ZONES.values())
_HL_WOOD = {"Дерево: фронт", "Дерево: зад", "Дерево: бік лівий", "Дерево: бік правий", "Дерево: верх", "Дерево: низ",
            "Дерево: фаска", "Дерево: внутрішня", "Дерево: фронт бічний", "Дерево: стик", "Ніжки"}
# Зони пульта -> деталі маски. Лише зони, які маска описує ТОЧНО; зони за кутом камери / ракурсом / кутиком
# (рахуються в шейдері) — без лампочки, щоб не показувати неправду.
_HL_AREA = {
    "FAB": {"Вся тканина": _HL_FABRIC, "Спинка": {"Спинка"}, "Сидіння": {"Сидіння"}, "Верх": {"Верх"},
            "Фронт": {"Фронт", "Фронт бічний"}, "Задня стінка": {"Задня стінка"},
            "Боковина внутр. ліва": {"Боковина внутр. ліва"}, "Боковина внутр. права": {"Боковина внутр. права"},
            "Боковина зовн. ліва": {"Боковина зовн. ліва"}, "Боковина зовн. права": {"Боковина зовн. права"}},
    "RAIL": {"Вся деревина": _HL_WOOD, "Загальне": _HL_WOOD, "Ніжки": {"Ніжки"}, "Фаска знизу": {"Дерево: фаска"}},
    "EG": {"Вся деревина": {"Торці (вставки)"}, "Загальне": {"Торці (вставки)"}},
}
_HL_CACHE = {"mesh": {}, "tris": {}}


def _hl_area_ok(target, zone):
    return zone in _HL_AREA.get(target, {})


# FL71: зони, яких нема в масці (Кут, Кутик, Низ внутр., стики крила), показує САМ шейдер FABRIC LOOK: номер зони
# -> властивість сцени thuma_hl (атрибут VIEW_LAYER, як cur_frame) на ~2 с. Видно лише в Material Preview / Rendered.
# Перед рендером і збереженням thuma_hl -> 0 (_hl_reset_prop), тож у рендер/файл/ферму не потрапляє.
_HL_PROP = "thuma_hl"


# 1.32.0: дерево/торці — зони пульта рахуються в шейдері без підписаних масок. Лампочка на ~2 с ВИКРУЧУЄ яскравість
# цієї зони (×2 або +1.5) і повертає: світліє рівно те, що міняє повзунок, і лише якщо він діє в цьому кадрі.
# Структуру пульта не змінює (нічого публікувати). Повернення: таймер, перед рендером/збереженням (_hl_reset_prop),
# а якщо Blender впав під час спалаху — при відкритті файлу (scene["thuma_hl_restore"], _hlb_recover).
_HLB = {"items": []}
_HLB_KEY = "thuma_hl_restore"


def _hlb_names(socks):
    """Сокети яскравості зони (за суфіксом), «|»-рядком; порожньо = лампочки не буде."""
    return "|".join(sk.name for suf, sk in socks if "яскр" in suf.lower())


def _hlb_restore():
    for it in _HLB["items"]:
        try:
            it[0].default_value = it[1]
        except Exception:
            pass
    _HLB["items"] = []
    for sc in bpy.data.scenes:
        if _HLB_KEY in sc:
            del sc[_HLB_KEY]


@bpy.app.handlers.persistent
def _hlb_recover(*_a):
    import json
    _HLB["items"] = []
    for sc in bpy.data.scenes:
        raw = sc.get(_HLB_KEY)
        if not raw:
            continue
        try:
            for gname, nname, sname, v in json.loads(raw):
                g = bpy.data.node_groups.get(gname) or (bpy.data.materials.get(gname) or None)
                tree = g if isinstance(g, bpy.types.NodeTree) else (g.node_tree if g else None)
                nd = tree.nodes.get(nname) if tree else None
                if nd is not None and nname and sname in nd.inputs:
                    nd.inputs[sname].default_value = v
        except Exception as e:
            print("[Thuma Material] відновлення після спалаху:", e)
        del sc[_HLB_KEY]


def _hlb_start(key):
    import json
    tg, _s, names = key[2:].partition(":")
    node = _wood_look_node(tg)
    if node is None:
        return 0
    items = []                                     # (сокет, було, спалах)

    def add(nm, lo):
        sk = node.inputs.get(nm)
        if sk is not None and not sk.is_linked and hasattr(sk, "default_value") and all(i[0] != sk for i in items):
            v = float(sk.default_value)
            items.append((sk, v, min(max(v * 3.0, lo), 10.0)))
    for nm in names.split("|"):
        add(nm, 3.5)                               # яскравість
        # + насиченість тієї ж зони: коричневе дерево стає яскраво-оранжево-жовтим (як підсвітка решти пульта)
        add(nm.replace("яскравість", "насиченість").replace("яскр.", "нас."), 3.0)
    if not items:
        return 0
    tree = node.id_data
    owner = tree.name if not getattr(tree, "is_embedded_data", False) else next(
        (m.name for m in bpy.data.materials if m.node_tree == tree), tree.name)
    bpy.context.scene[_HLB_KEY] = json.dumps([(owner, node.name, sk.name, v) for sk, v, _b in items])
    for sk, _v, b in items:
        sk.default_value = b
    _HLB["items"] = items
    _HLB["on"] = True
    return 1 if _hl_shaded_view() else -1


def _hl_shader_list():
    g = bpy.data.node_groups.get("FABRIC LOOK")
    return list(g.get("hl_zones", [])) if g else []


def _hl_shader_ok(zone):
    return zone in _hl_shader_list()


def _hl_prop_set(v, prop=_HL_PROP):
    for sc in bpy.data.scenes:
        if float(sc.get(prop, 0.0)) != v:
            sc[prop] = float(v)
            sc.update_tag()


_HLW_PROP = "thuma_hl_w"          # дерево: біти зон (wood_hl_patch.py, g["hl_zones"] у WOOD LOOK v2)


def _hlw_bits(names):
    g = bpy.data.node_groups.get("WOOD LOOK v2")
    lst = list(g.get("hl_zones", [])) if g else []
    return sum(2 ** lst.index(n) for n in set(names.split("|")) if n in lst)


@bpy.app.handlers.persistent
def _hl_reset_prop(*_a):
    _HL["shader_t0"] = 0.0
    for sc in bpy.data.scenes:
        if sc.get(_HLW_PROP):
            sc[_HLW_PROP] = 0.0
    if _HLB["items"]:
        _hlb_restore()
    for sc in bpy.data.scenes:
        if sc.get(_HL_PROP):
            sc[_HL_PROP] = 0.0


def _hl_shaded_view():
    try:
        return any(sp.shading.type in {'MATERIAL', 'RENDERED'} for w in bpy.context.window_manager.windows
                   for ar in w.screen.areas if ar.type == 'VIEW_3D' for sp in ar.spaces if sp.type == 'VIEW_3D')
    except Exception:
        return False


def _hl_lamp(lay, key):
    lay.operator("thuma.seam_flash", text="", icon='LIGHT', emboss=False).key = key


def _wood_lamp(lay, target, title, socks):
    """Лампочка зони дерева: шейдерна підсвітка (whl_*, точно те, що міняє повзунок — і сховані ніжки) ->
    інакше контур за маскою деталей -> інакше спалах яскравістю."""
    if title.startswith("Калібрування"):
        return
    nm = _hlb_names(socks)
    if nm and _hlw_bits(nm):
        _hl_lamp(lay, f"B:{target}:{nm}")
    elif _hl_area_ok(target, title):
        _hl_lamp(lay, f"A:{target}:{title}")
    elif nm:
        _hl_lamp(lay, f"B:{target}:{nm}")


def _hl_tris(me):
    """Трикутники меша (вершини, номер полігона) — для легкої заливки зони."""
    import numpy as np
    k = (bpy.data.filepath, len(me.vertices), len(me.polygons))
    c = _HL_CACHE["tris"].get(me.name)
    if c is not None and c[0] == k:
        return c[1]
    me.calc_loop_triangles()
    nt = len(me.loop_triangles)
    tv = np.zeros(nt * 3, np.int32); me.loop_triangles.foreach_get("vertices", tv)
    tp = np.zeros(nt, np.int32); me.loop_triangles.foreach_get("polygon_index", tp)
    arr = (tv.reshape(-1, 3), tp)
    _HL_CACHE["tris"][me.name] = (k, arr)
    return arr


def _hl_mesh(me):
    """Масиви меша для підсвітки (кеш за іменем і розміром; шви/деталі/форма тканини під час тюнінгу не міняються)."""
    import numpy as np
    k = (bpy.data.filepath, len(me.vertices), len(me.edges), len(me.polygons))
    c = _HL_CACHE["mesh"].get(me.name)
    if c is not None and c[0] == k:
        return c[1]
    ne, npl, nv = len(me.edges), len(me.polygons), len(me.vertices)
    seam = np.zeros(ne, bool); me.edges.foreach_get("use_seam", seam)
    part = np.full(npl, -1, np.int32)
    if "wc_part" in me.attributes:
        me.attributes["wc_part"].data.foreach_get("value", part)
    lt = np.zeros(npl, np.int32); me.polygons.foreach_get("loop_total", lt)
    ce = np.zeros(len(me.loops), np.int32); me.loops.foreach_get("edge_index", ce)
    co = np.zeros(nv * 3, np.float32); me.vertices.foreach_get("co", co)
    nr = np.zeros(nv * 3, np.float32); me.vertex_normals.foreach_get("vector", nr)
    raw = co.reshape(-1, 3)
    co = raw + nr.reshape(-1, 3) * 0.002                     # 2 мм над тканиною — не ховається в поверхні
    ev = np.zeros(ne * 2, np.int32); me.edges.foreach_get("vertices", ev)
    arr = (seam, part, lt, ce, co, ev.reshape(-1, 2), raw)
    _HL_CACHE["mesh"][me.name] = (k, arr)
    return arr


def _hl_eye():
    """Точка, звідки дивиться в'юпорт у Rendered / Material Preview (там оверлей не має глибини сцени —
    сховане малювалося б поверх). None = Solid (глибина є, перевірка не потрібна)."""
    from mathutils import Vector
    try:
        for w in bpy.context.window_manager.windows:
            for ar in w.screen.areas:
                if ar.type != 'VIEW_3D':
                    continue
                sp = ar.spaces.active
                if sp.shading.type not in {'MATERIAL', 'RENDERED'}:
                    continue
                r3 = sp.region_3d
                if r3.view_perspective == 'CAMERA' and bpy.context.scene.camera:
                    return bpy.context.scene.camera.matrix_world.translation.copy()
                return r3.view_matrix.inverted().translation.copy()
    except Exception:
        pass
    return None


def _hl_supported(z):
    return z == "ALL" or z in _HL_ZONES


def _hl_coords(key):
    """(відрізки ліній, трикутники заливки або None) у світових координатах для key у поточному кадрі.
    key: «ALL»/зона шва — ребра шва; «CS:…» — свій шов; «A:<пульт>:<зона>» — зона пульта (контур + заливка);
    «CZ:<меш>|<uid>» — своя зона (вибрані полігони)."""
    import numpy as np
    sc = bpy.context.scene
    obs = [o for o in sc.objects if o.type == 'MESH' and o.visible_get() and o.name.startswith("Thuma_Essential")]
    cs = cz = area = None
    if key.startswith("CS:"):
        cs = key[3:]
        obs = [o for o in obs if any(_cs_key(o.data, q) == cs for q in o.data.thuma_cseams)]
    elif key.startswith("CZ:"):                              # «CZ:меш|uid;меш2|uid2» — одна зона на кількох модулях
        cz = {}
        for it_ in key[3:].split(";"):
            m_, _s, u_ = it_.rpartition("|")
            cz.setdefault(m_, []).append(u_)
        obs = [o for o in obs if o.data.name in cz]
    elif key.startswith("A:"):
        tg, _s, zn = key[2:].partition(":")
        area = _HL_AREA.get(tg, {}).get(zn, set())
    if key == "RIB":
        return _hl_rib(obs), None
    names = [n for n, _c in (_palette(sc) or [])]
    cmap = {}
    if cs is None and cz is None and key != "ALL":
        ck = (bpy.data.filepath, sc.frame_current, tuple(o.name for o in obs))
        if _HL_CACHE.get("cmap_key") != ck:                  # збірка кадру рахується раз (~0.4 с на кутовому)
            try:
                _HL_CACHE["cmap"] = _cfg_map_obs(obs, {o.name for o in obs})
            except Exception as e:
                print("[Thuma Material] підсвітка, збірка:", e)
                _HL_CACHE["cmap"] = {}
            _HL_CACHE["cmap_key"] = ck
        cmap = _HL_CACHE["cmap"]
    want = area if area is not None else _HL_FABRIC if key == "ALL" else _HL_ZONES.get(key, {"Сидіння"})
    out, tris = [], []
    for o in obs:
        me = o.data
        if me.is_editmode:
            continue
        ne = len(me.edges)
        mw = np.array(o.matrix_world, np.float32)
        if area is not None or cz is not None:
            seam, part, lt, ce, co, ev = _hl_mesh(me)[:6]
            if cz is not None:
                face = np.zeros(len(me.polygons), bool)
                for u_ in cz.get(me.name, []):
                    at = me.attributes.get(f"tc_z{u_}")
                    if at is not None and len(at.data) == len(me.polygons):
                        f_ = np.zeros(len(me.polygons), bool); at.data.foreach_get("value", f_)
                        face |= f_
            else:
                m = cmap.get(o.name, {})
                ids = [i for i, n in enumerate(names) if m.get(n, n) in want]
                if not ids:
                    continue
                face = np.isin(part, ids)
            if not face.any():
                continue
            cnt = np.bincount(ce[np.repeat(face, lt)], minlength=ne)
            p = co[ev[cnt == 1].ravel()]                       # контур зони = ребра з одним полігоном зони
            out.append(p @ mw[:3, :3].T + mw[:3, 3])
            tv, tp = _hl_tris(me)
            t_ = co[tv[face[tp]].ravel()]
            tris.append(t_ @ mw[:3, :3].T + mw[:3, 3])
            continue
        if cs is not None:
            q = next(q for q in me.thuma_cseams if _cs_key(me, q) == cs)
            at = me.attributes.get(f"tc_cs{q.uid}")
            if at is None or len(at.data) != ne:
                continue
            fl = np.zeros(ne, np.int32); at.data.foreach_get("value", fl)
            sel = fl > 0
        else:
            if "wc_part" not in me.attributes:
                continue
            if key in _HL_WING and int(round(float(o.get("fz_wing", 0)))) != _HL_WING[key]:
                continue
            seam, part, lt, ce, _co, _ev = _hl_mesh(me)[:6]
            m = cmap.get(o.name, {})
            ids = [i for i, n in enumerate(names) if m.get(n, n) in want]
            if not ids:
                continue
            hit = np.zeros(ne, bool)
            hit[ce[np.repeat(np.isin(part, ids), lt)]] = True
            sel = seam & hit
        if not sel.any():
            continue
        co, ev = _hl_mesh(me)[4:6]
        p = co[ev[sel].ravel()]
        out.append(p @ mw[:3, :3].T + mw[:3, 3])
    lines = np.concatenate(out) if out else None
    fill = np.concatenate(tris) if tris else None
    return (lines if lines is not None and len(lines) else None), (fill if fill is not None and len(fill) else None)


def _hl_rib(obs):
    """Ребро лівого підлокітника — як у шейдері: fz_edge_al (крім модулів фронтом ліворуч, де «підлокітник» ззаду)
    + fz_edge_bt (верх спинки) на модулях ЛІВОГО крила. Ребра, обидві вершини яких > 0.5."""
    import numpy as np, math
    sc = bpy.context.scene
    a = sc.get("cfg_angle")
    if a is None:
        rot = bpy.data.objects.get("Control_Rotation")
        a = rot.matrix_world.to_euler().z if rot else 0.0
    out = []
    for o in obs:
        me = o.data
        al, bt = me.attributes.get("fz_edge_al"), me.attributes.get("fz_edge_bt")
        if me.is_editmode or (al is None and bt is None):
            continue
        mw = np.array(o.matrix_world, np.float32)
        vx, vy = -mw[0, 1], -mw[1, 1]                         # фронт модуля (локальний −Y) у світі
        wfx = vx * math.cos(a) + vy * math.sin(a)             # без повороту збірки
        nv = len(me.vertices)
        on = np.zeros(nv, bool)
        if al is not None and al.domain == 'POINT' and wfx > -0.65:
            v = np.zeros(nv, np.float32); al.data.foreach_get("value", v); on |= v > 0.5
        if bt is not None and bt.domain == 'POINT' and wfx > 0.65:
            v = np.zeros(nv, np.float32); bt.data.foreach_get("value", v); on |= v > 0.5
        if not on.any():
            continue
        co, ev = _hl_mesh(me)[4:6]
        sel = on[ev[:, 0]] & on[ev[:, 1]]
        if sel.any():
            p = co[ev[sel].ravel()]
            out.append(p @ mw[:3, :3].T + mw[:3, 3])
    return np.concatenate(out) if out else None


def _hl_occ_batch():
    """1.32.0: у Rendered / Material Preview оверлей не має глибини сцени -> малюємо НЕВИДИМУ глибину всіх видимих
    у кадрі мешів (кеш на кадр), і підсвітка ховається за ними, як у Solid."""
    import numpy as np
    from gpu_extras.batch import batch_for_shader
    import gpu
    sc = bpy.context.scene
    obs = [o for o in sc.objects if o.type == 'MESH' and o.visible_get() and not o.data.is_editmode]
    ck = (bpy.data.filepath, sc.frame_current, tuple(o.name for o in obs))
    if _HL_CACHE.get("occ_key") == ck:
        return _HL_CACHE.get("occ")
    parts = []
    for o in obs:
        me = o.data
        if not len(me.polygons):
            continue
        raw = _hl_mesh(me)[6]
        tv, _tp = _hl_tris(me)
        mw = np.array(o.matrix_world, np.float32)
        parts.append(raw[tv.ravel()] @ mw[:3, :3].T + mw[:3, 3])
    b = batch_for_shader(gpu.shader.from_builtin('UNIFORM_COLOR'), 'TRIS', {"pos": np.concatenate(parts)}) if parts else None
    _HL_CACHE["occ_key"], _HL_CACHE["occ"] = ck, b
    return b


def _hl_draw():
    import gpu, math
    t = _time.time() - _HL["t0"]
    if (_HL["batch"] is None and _HL.get("fill") is None) or t > _HL_DUR:
        return
    a = 0.45 + 0.55 * abs(math.cos(t * math.pi * 1.6))      # м'яке блимання
    occ = _HL.get("occ")
    if occ is not None:                                      # Rendered: невидима глибина сцени
        so = gpu.shader.from_builtin('UNIFORM_COLOR')
        so.bind(); so.uniform_float("color", (0, 0, 0, 0))
        gpu.state.color_mask_set(False, False, False, False)
        gpu.state.depth_mask_set(True); gpu.state.depth_test_set('LESS_EQUAL')
        occ.draw(so)
        gpu.state.color_mask_set(True, True, True, True)
        gpu.state.depth_mask_set(False)
    if _HL.get("fill") is not None:                          # легка заливка зони — тканину видно крізь неї
        sf = gpu.shader.from_builtin('UNIFORM_COLOR')
        sf.bind()
        gpu.state.blend_set('ALPHA'); gpu.state.depth_mask_set(False)
        # 1.33.4: частина зони ЗА моделлю (ззаду / перекрита) — блакитна заливка крізь модель, щоб було видно де вона
        gpu.state.depth_test_set('GREATER')
        sf.uniform_float("color", (*_HL_HIDDEN, (0.10 if _HL["batch"] is not None else 0.22) * a))
        _HL["fill"].draw(sf)
        gpu.state.depth_test_set('LESS_EQUAL')
        sf.uniform_float("color", (*_HL_COLOR, (0.16 if _HL["batch"] is not None else 0.4) * a))
        _HL["fill"].draw(sf)
    if _HL["batch"] is None:
        gpu.state.depth_test_set('NONE'); gpu.state.blend_set('NONE')
        return
    sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    sh.bind()
    sh.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_mask_set(False)
    # 1.33.4: ребра за моделлю — блакитні, тонші (і в Rendered, і в Solid); видимі — жовті поверх
    gpu.state.depth_test_set('GREATER')
    sh.uniform_float("lineWidth", 1.6); sh.uniform_float("color", (*_HL_HIDDEN, 0.75 * a))
    _HL["batch"].draw(sh)
    gpu.state.depth_test_set('LESS_EQUAL')                   # видимі ребра — яскраво
    sh.uniform_float("lineWidth", 2.2); sh.uniform_float("color", (*_HL_COLOR, a))
    _HL["batch"].draw(sh)
    gpu.state.depth_test_set('NONE')
    gpu.state.blend_set('NONE')


def _hl_redraw():
    for w in bpy.context.window_manager.windows:
        for ar in w.screen.areas:
            if ar.type == 'VIEW_3D':
                ar.tag_redraw()


def _hl_tick():
    _hl_redraw()
    t = _time.time() - _HL["t0"]
    if _HLB["items"] and t <= _HL_DUR:              # дерево: блимання — 3 пульси (увімк 0.45 с / вимк 0.3 с)
        on = (t % 0.75) < 0.45
        if on != _HLB.get("on"):
            _HLB["on"] = on
            for sk, v, b in _HLB["items"]:
                try:
                    sk.default_value = b if on else v
                except Exception:
                    pass
    if t <= _HL_DUR:
        return 0.04
    _hl_stop()
    if _HL.get("shader_t0"):
        _HL["shader_t0"] = 0.0
        _hl_prop_set(0.0)
        _hl_prop_set(0.0, _HLW_PROP)
    if _HLB["items"]:
        _hlb_restore()
    return None


def _hl_stop():
    if _HL["handler"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_HL["handler"], 'WINDOW')
        _HL["handler"] = None
    _HL["batch"] = None
    _HL["fill"] = None
    try:
        _hl_redraw()
    except Exception:
        pass


def _hl_prune():
    """Кеш підсвітки — лише на ПОТОЧНИЙ кадр: при зміні кадру викидаємо меші інших кадрів і стару глибину сцени
    (інакше за довгу сесію з перемиканням кадрів пам'ять росла б)."""
    sc = bpy.context.scene
    fk = (bpy.data.filepath, sc.frame_current)
    if _HL_CACHE.get("prune_key") == fk:
        return
    _HL_CACHE["prune_key"] = fk
    keep = {o.data.name for o in sc.objects if o.type == 'MESH' and o.visible_get()}
    for k in ("mesh", "tris"):
        d = _HL_CACHE.get(k, {})
        for nm in [nm for nm in d if nm not in keep]:
            del d[nm]
    if _HL_CACHE.get("occ_key") and _HL_CACHE["occ_key"][:2] != fk:
        _HL_CACHE["occ"] = _HL_CACHE["occ_key"] = None
        _HL["occ"] = None


def _hl_start(key):
    """Почати блимання; повертає к-сть ребер (0 = у цьому кадрі такого шва нема)."""
    _hl_prune()
    from gpu_extras.batch import batch_for_shader
    import gpu
    if _HLB["items"]:                                         # попередній спалах дерева — повернути
        _hlb_restore()
    if key.startswith("B:"):                                  # дерево/торці: спалах яскравості зони
        _hl_stop()
        if _HL.get("shader_t0"):
            _HL["shader_t0"] = 0.0
            _hl_prop_set(0.0)
            _hl_prop_set(0.0, _HLW_PROP)
        bits = _hlw_bits(key[2:].partition(":")[2])
        if bits:                                              # пульт дерева з whl_* — жовтим, як решта
            _hl_prop_set(float(bits), _HLW_PROP)
            _HL["t0"] = _HL["shader_t0"] = _time.time(); _HL["key"] = key
            if not bpy.app.timers.is_registered(_hl_tick):
                bpy.app.timers.register(_hl_tick, first_interval=0.04)
            return 1 if _hl_shaded_view() else -1
        n = _hlb_start(key)                                   # старий пульт дерева — спалах яскравістю
        if n:
            _HL["t0"] = _time.time(); _HL["key"] = key
            if not bpy.app.timers.is_registered(_hl_tick):
                bpy.app.timers.register(_hl_tick, first_interval=0.04)
        return n
    if key.startswith("S:"):                                  # FL71: зону показує шейдер
        lst = _hl_shader_list()
        if key[2:] not in lst:
            return 0
        _hl_stop()
        _hl_prop_set(0.0, _HLW_PROP)
        _hl_prop_set(float(lst.index(key[2:]) + 1))
        _HL["t0"] = _HL["shader_t0"] = _time.time(); _HL["key"] = key
        if not bpy.app.timers.is_registered(_hl_tick):
            bpy.app.timers.register(_hl_tick, first_interval=0.04)
        return 1 if _hl_shaded_view() else -1
    if _HL.get("shader_t0"):                                  # інша лампочка — шейдерну зону гасимо
        _HL["shader_t0"] = 0.0
        _hl_prop_set(0.0)
        _hl_prop_set(0.0, _HLW_PROP)
    pts, tri = _hl_coords(key)
    if pts is None and tri is None:
        _hl_stop()
        return 0
    # закриті деталі (ніжки, цілі модулі) контуру не мають — тоді лише заливка, яскравіша
    _HL["batch"] = (batch_for_shader(gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR'), 'LINES', {"pos": pts})
                    if pts is not None else None)
    _HL["fill"] = (batch_for_shader(gpu.shader.from_builtin('UNIFORM_COLOR'), 'TRIS', {"pos": tri})
                   if tri is not None else None)
    _HL["occ"] = None
    if _hl_eye() is not None:
        try:
            _HL["occ"] = _hl_occ_batch()
        except Exception as e:
            print("[Thuma Material] глибина сцени:", e)
    _HL["t0"] = _time.time(); _HL["key"] = key
    if _HL["handler"] is None:
        _HL["handler"] = bpy.types.SpaceView3D.draw_handler_add(_hl_draw, (), 'WINDOW', 'POST_VIEW')
    if not bpy.app.timers.is_registered(_hl_tick):
        bpy.app.timers.register(_hl_tick, first_interval=0.04)
    return max(len(pts) // 2 if pts is not None else 0, len(tri) // 3 if tri is not None else 0)


def _hl_safe(key):
    try:
        return _hl_start(key)
    except Exception as e:
        print("[Thuma Material] підсвітка:", e)
        return 0


def _hl_hover(key):
    _hl_safe(key)
    return None


class THUMA_OT_seam_flash(bpy.types.Operator):
    bl_idname = "thuma.seam_flash"
    bl_label = "Показати шов"
    bl_options = {'INTERNAL'}
    key: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, props):
        last, t = _HL["last"]                                 # наведення = показ (підказка викликає цей метод)
        if last != props.key or _time.time() - t > _HL_DUR:
            _HL["last"] = (props.key, _time.time())
            k = props.key
            bpy.app.timers.register(lambda: _hl_hover(k), first_interval=0.01)
        if props.key.startswith("B:"):
            return ("Де діє ця зона: наведи або натисни — на ~2 с вона стане жовтою (саме те, що міняє повзунок; "
                    "якщо нічого не загорілось — у цьому кадрі зона не діє). Видно в Material Preview / Rendered")
        if props.key.startswith("S:"):
            return ("Де ця зона: наведи або натисни — на ~2 с стане жовтою саме та ділянка, яку міняє повзунок "
                    "(видно лише в Material Preview / Rendered). У рендер не потрапляє")
        return ("Де це: наведи або натисни — у поточному кадрі блимне жовтим ~2 с (шов — лінією, зона — контуром і "
                "легкою заливкою). Сцену не змінює, у рендер не потрапляє")

    def execute(self, context):
        _HL["last"] = (self.key, _time.time())
        n = _hl_safe(self.key)
        if n == -1:
            self.report({'WARNING'}, "Цю зону видно лише в Material Preview або Rendered (не в Solid)")
        elif not n:
            self.report({'INFO'}, "У цьому кадрі цього не видно")
        return {'FINISHED'}


SEAM_OFF = "tc_seam_off"


def _seam_attr(me):
    import numpy as np
    ca = me.color_attributes.get(SEAM_OFF)
    if ca is None:
        ca = me.color_attributes.new(SEAM_OFF, 'BYTE_COLOR', 'POINT')
        ca.data.foreach_set("color", np.tile(np.array([0, 0, 0, 1], np.float32), len(ca.data)))
    return ca


class THUMA_OT_seam_off(bpy.types.Operator):
    """Прибрати підкреслення шва на окремих місцях модуля (напр. ззаду, де шов не потрібен)"""
    bl_idname = "thuma.seam_off"
    bl_label = "Прибрати шов"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('PAINT_OFF', "Прибрати пензлем", ""), ('PAINT_ON', "Повернути пензлем", ""),
                                        ('PAINT_BOOST', "Посилити шов пензлем", ""),
                                        ('SEL_OFF', "Прибрати з виділених", ""), ('SEL_ON', "Повернути виділеним", ""),
                                        ('DONE', "Готово", ""), ('CLEAR', "Усі шви на модулі", "")])

    @classmethod
    def description(cls, context, props):
        return {'PAINT_OFF': "Пензель: червоний = тут шов НЕ підкреслювати. Модуль спільний: однакові модулі в сцені зміняться разом",
                'PAINT_ON': "Пензель: чорний = повернути шов як був (стирає і «прибрати», і «посилити»)",
                'PAINT_BOOST': "Пензель: зелений = зробити шов ТЕМНІШИМ саме тут (до ×3 при повному натиску), незалежно від зон. "
                               "Сила пензля = наскільки посилити. Модуль спільний: однакові модулі зміняться разом",
                'SEL_OFF': "Edit Mode: виділи полігони біля шва і натисни — шов на них прибереться",
                'SEL_ON': "Edit Mode: повернути шов на виділених полігонах",
                'DONE': "Вийти з малювання в Object Mode",
                'CLEAR': "Повернути всі шви на виділеному модулі (стерти все прибране)"}[props.mode]

    def execute(self, context):
        import numpy as np
        if self.mode == 'DONE':
            if context.mode != 'OBJECT':
                _mode('OBJECT')
            return {'FINISHED'}
        obs = [o for o in ({context.active_object} | set(context.selected_objects)) if o]
        obs = [o for o in obs if o.type == 'MESH' and o.data in _meshes()]
        if not obs:
            self.report({'WARNING'}, "Виділи модуль оббивки (клікни по дивану)")
            return {'CANCELLED'}
        if self.mode in ('SEL_OFF', 'SEL_ON', 'CLEAR'):
            was_edit = context.mode == 'EDIT_MESH'
            if was_edit:
                _mode('OBJECT')
            n = 0
            for me in {o.data for o in obs}:
                ca = _seam_attr(me)
                col = np.empty(len(ca.data) * 4, np.float32); ca.data.foreach_get("color", col); col = col.reshape(-1, 4)
                if self.mode == 'CLEAR':
                    col[:, :3] = 0.0
                else:
                    sel = np.zeros(len(me.polygons), bool); me.polygons.foreach_get("select", sel)
                    if not sel.any():
                        continue
                    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
                    lv = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", lv)
                    vi = np.unique(lv[np.repeat(sel, lt)])
                    col[vi, 0] = 1.0 if self.mode == 'SEL_OFF' else 0.0
                    col[vi, 1:3] = 0.0
                    n += int(sel.sum())
                ca.data.foreach_set("color", col.ravel()); me.update()
            if was_edit:
                _mode('EDIT', back=True)
            if self.mode != 'CLEAR' and not n:
                self.report({'WARNING'}, "Нічого не виділено: Edit Mode, виділи полігони біля шва")
                return {'CANCELLED'}
            return {'FINISHED'}
        ob = context.active_object if context.active_object in obs else obs[0]
        context.view_layer.objects.active = ob
        ca = _seam_attr(ob.data)
        ob.data.color_attributes.active_color = ca
        if not _enter_paint(self, context):
            return {'CANCELLED'}
        col = {'PAINT_OFF': (1.0, 0.0, 0.0), 'PAINT_BOOST': (0.0, 1.0, 0.0)}.get(self.mode, (0.0, 0.0, 0.0))
        ts = context.tool_settings
        for holder in (getattr(ts, "unified_paint_settings", None), getattr(ts.vertex_paint, "unified_paint_settings", None),
                       getattr(ts.vertex_paint, "brush", None)):
            if holder is not None and hasattr(holder, "color"):
                try:
                    holder.color = col
                except Exception:
                    pass
        self.report({'INFO'}, "Малюй по шву. " + {'PAINT_OFF': "Червоний = прибрати шов", 'PAINT_BOOST': "Зелений = посилити шов"}
                    .get(self.mode, "Чорний = повернути як було"))
        return {'FINISHED'}


# ── Маска деталей для WireColor (Face) ──────────────────────────────────────────
# Меш має номер деталі на кожному полігоні (атрибут wc_part, розфарбовує скрипт wc_parts_paint.py; палітра —
# scene["wc_parts_palette"]). «По модулях»: колір деталі модуля (спинка модуля, ліва боковина модуля...).
# «По конфігураціях»: деталь — за місцем у зібраному дивані (фронт = дивиться вперед збірки, зовнішня боковина =
# лише крайня боковина збірки ...). Робиться GN-модифікатором WC_FaceConfig на кожен об'єкт (свої кольори для
# кожного номера деталі). WireColor >= 3.7 вмикає модифікатори WC_Face* лише на час Face-маски — звичайний рендер
# їх не бачить.
PARTS_MOD, PARTS_GROUP = "WC_FaceConfig", "WC Face Config"
_EXT = {"Фронт": (0, -1), "Задня стінка": (0, 1), "Боковина зовн. ліва": (-1, 0), "Боковина зовн. права": (1, 0)}
_INN = {"Спинка": (0, -1), "Боковина внутр. ліва": (1, 0), "Боковина внутр. права": (-1, 0)}
_WOOD = {"Дерево: фронт": (0, -1), "Дерево: зад": (0, 1), "Дерево: бік лівий": (-1, 0), "Дерево: бік правий": (1, 0)}


def _palette(scene):
    import json
    raw = scene.get("wc_parts_palette")
    return json.loads(raw) if raw else None


def _parts_group(pal):
    ng = bpy.data.node_groups.get(PARTS_GROUP)
    if ng and len([i for i in ng.interface.items_tree if getattr(i, "in_out", "") == 'INPUT']) == len(pal) + 1:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = bpy.data.node_groups.new(PARTS_GROUP, 'GeometryNodeTree')
    it = ng.interface
    it.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    for name, _c in pal:
        it.new_socket(name, in_out='INPUT', socket_type='NodeSocketColor')
    it.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); gi.location = (-700, 0)
    go = N.new('NodeGroupOutput'); go.location = (500, 0)
    pa = N.new('GeometryNodeInputNamedAttribute'); pa.data_type = 'INT'; pa.location = (-450, 300)
    pa.inputs["Name"].default_value = "wc_part"
    sw = N.new('GeometryNodeIndexSwitch'); sw.data_type = 'RGBA'; sw.location = (-200, 0)
    while len(sw.index_switch_items) < len(pal):
        sw.index_switch_items.new()
    L.new(pa.outputs["Attribute"], sw.inputs[0])
    for i in range(len(pal)):
        L.new(gi.outputs[i + 1], sw.inputs[i + 1])
    st = N.new('GeometryNodeStoreNamedAttribute'); st.data_type = 'FLOAT_COLOR'; st.domain = 'CORNER'
    st.location = (150, 0); st.inputs["Name"].default_value = "wc_mask_color"
    L.new(gi.outputs[0], st.inputs["Geometry"]); L.new(sw.outputs[0], st.inputs["Value"])
    L.new(st.outputs["Geometry"], go.inputs["Geometry"])
    return ng


def _set_input(mod, ident, value):
    props = getattr(mod, "properties", None)
    if props is not None and hasattr(props, "inputs"):
        getattr(props.inputs, ident).value = value
    else:
        mod[ident] = value


def _cfg_map_obs(obs, targets):
    """1.32.0: {об'єкт: {деталь модуля: деталь у збірці}} для збірки obs (видно разом у поточному кадрі)."""
    import math
    from mathutils import Vector

    def snap(x, y):
        return (int(round(x)), int(round(y)))
    out = {}
    dg = bpy.context.evaluated_depsgraph_get()
    MW = {o.name: o.evaluated_get(dg).matrix_world.copy() for o in obs}
    rot = bpy.data.objects.get("Control_Rotation")
    ang = rot.evaluated_get(dg).matrix_world.to_euler().z if rot else 0.0
    yaw = {}
    for o in obs:
        vx = MW[o.name].to_3x3() @ Vector((1, 0, 0))
        yaw[o.name] = math.atan2(vx.y, vx.x) - ang
    up = [o for o in obs if o.dimensions.z > 0.2] or obs
    s4 = sum(math.sin(4 * yaw[o.name]) for o in up)
    c4 = sum(math.cos(4 * yaw[o.name]) for o in up)
    phi = math.atan2(s4, c4) / 4                      # спільний «нахил» збірки
    if len(up) == 1:                                  # один модуль (напр. шезлонг під 45°) — його власний перед
        phi = yaw[up[0].name]
    for o in obs:
        if o.name not in targets:
            continue
        a = yaw[o.name] - phi
        ex = snap(math.cos(a), math.sin(a))
        ey = snap(-math.sin(a), math.cos(a))

        def to_cfg(d, ex=ex, ey=ey):
            return (d[0] * ex[0] + d[1] * ey[0], d[0] * ex[1] + d[1] * ey[1])
        inv = MW[o.name].inverted()
        pts = [inv @ (MW[n.name] @ Vector(c)) for n in obs for c in n.bound_box]
        amn = (min(p.x for p in pts), min(p.y for p in pts))
        amx = (max(p.x for p in pts), max(p.y for p in pts))
        bb = [Vector(c) for c in o.bound_box]
        mmn = (min(c.x for c in bb), min(c.y for c in bb))
        mmx = (max(c.x for c in bb), max(c.y for c in bb))

        def extreme(d, amn=amn, amx=amx, mmn=mmn, mmx=mmx):   # бік модуля d (локально) — на краю збірки?
            k = 0 if d[0] else 1
            return abs((mmx[k] - amx[k]) if (d[0] + d[1]) > 0 else (mmn[k] - amn[k])) < 0.06
        m = {}
        for name, d in _EXT.items():
            D = to_cfg(d)
            if D == (0, -1):
                m[name] = "Фронт"
            elif D == (0, 1):
                m[name] = "Задня стінка"
            elif extreme(d):
                m[name] = "Боковина зовн. ліва" if D == (-1, 0) else "Боковина зовн. права"
            else:
                m[name] = "Фронт бічний" if name == "Фронт" else "Стик (схований бік)"
        for name, d in _INN.items():
            D = to_cfg(d)
            m[name] = ("Спинка" if D[0] == 0 else "Боковина внутр. ліва" if D == (1, 0) else "Боковина внутр. права")
        for name, d in _WOOD.items():
            D = to_cfg(d)
            if D == (0, -1):
                m[name] = "Дерево: фронт"
            elif D == (0, 1):
                m[name] = "Дерево: зад"
            elif extreme(d):
                m[name] = "Дерево: бік лівий" if D == (-1, 0) else "Дерево: бік правий"
            else:
                m[name] = "Дерево: фронт бічний" if name == "Дерево: фронт" else "Дерево: стик"
        out[o.name] = m
    return out


def _config_mapping(scene):
    """{ім'я об'єкта: {деталь модуля: деталь у збірці}} для всіх конфігурацій (колекції в «Product»)."""
    import math
    from mathutils import Vector
    cur = scene.frame_current
    first = {}
    obs_all = [o for o in scene.objects if o.type == 'MESH' and o.name.startswith("Thuma_Essential")]
    for f in _scan_frames(scene):                          # 1.32.0: + маркери (діапазон рендера буває 1..1)
        scene.frame_set(f)
        for o in obs_all:
            if o.name not in first and o.visible_get():
                first[o.name] = f

    def snap(x, y):
        return (int(round(x)), int(round(y)))
    out = {}
    # збірка = усе, що видно РАЗОМ у кадрі, де об'єкт з'являється вперше (в одній колекції бувають
    # кілька окремих модулів, кожен у своєму кадрі)
    for fr_ in sorted(set(first.values())):
        scene.frame_set(fr_)
        obs = [o for o in obs_all if o.visible_get()]
        targets = {o.name for o in obs_all if first.get(o.name) == fr_}
        if not obs or not targets:
            continue
        out.update(_cfg_map_obs(obs, targets))
    scene.frame_set(cur)
    return out


def _face_mask_active(scene):
    p = getattr(scene, "wc_props", None)
    return bool(p and p.preview_active and p.preview_mode == 'FACE')


class THUMA_OT_parts_mask(bpy.types.Operator):
    """Маска деталей для WireColor Face: по модулях або по місцю в зібраній конфігурації"""
    bl_idname = "thuma.parts_mask"
    bl_label = "Маска деталей"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('MODULE', "По модулях", ""), ('CONFIG', "По конфігураціях", "")])

    @classmethod
    def description(cls, context, props):
        if props.mode == 'MODULE':
            return "Деталі як у модуля: спинка, ліва/права боковина МОДУЛЯ… Однаково на всіх моделях"
        return ("Деталі за місцем у ЗІБРАНОМУ дивані: фронт = дивиться вперед, зовнішня боковина = лише крайня, "
                "фронт бічний = фронти бокової частини L/П… Для автоматизації в Photoshop. "
                "Рахує всі конфігурації (~10-30 с)")

    def execute(self, context):
        sc = context.scene
        for o in bpy.data.objects:
            m = o.modifiers.get(PARTS_MOD)
            if m is not None:
                o.modifiers.remove(m)
        if self.mode == 'MODULE':
            self.report({'INFO'}, "Маска деталей: по модулях")
            return {'FINISHED'}
        pal = _palette(sc)
        if not pal:
            self.report({'WARNING'}, "У сцені нема розфарбування деталей (wc_parts_paint.py)")
            return {'CANCELLED'}
        idx = {n: i for i, (n, _c) in enumerate(pal)}
        ng = _parts_group(pal)
        ids = [i.identifier for i in ng.interface.items_tree
               if getattr(i, "in_out", "") == 'INPUT' and i.socket_type == 'NodeSocketColor']
        mapping = _config_mapping(sc)
        on = _face_mask_active(sc)
        n = 0
        for o in sc.objects:
            if o.type != 'MESH' or "wc_part" not in o.data.attributes:
                continue
            mp = mapping.get(o.name, {})
            mod = o.modifiers.new(PARTS_MOD, 'NODES')
            mod.node_group = ng
            mod.show_viewport = mod.show_render = on
            mod.show_in_editmode = True
            try:
                o.modifiers.move(len(o.modifiers) - 1, 0)         # першим — колір об'єкта WireColor іде після
            except Exception:
                pass
            for i, (name, _c) in enumerate(pal):
                tgt = mp.get(name, name)
                _set_input(mod, ids[i], tuple(pal[idx.get(tgt, i)][1]) + (1.0,))
            n += 1
        self.report({'INFO'}, f"Маска деталей по конфігураціях: {n} об'єктів ({len(mapping)} у конфігураціях)")
        return {'FINISHED'}


def _draw_parts_mask(c, context):
    if not _palette(context.scene):
        return
    h, b = c.panel("thuma_parts_mask", default_closed=True)
    h.label(text="Маска деталей (WireColor Face)", icon='FACESEL')
    if b is None:
        return
    cfg = any(o.modifiers.get(PARTS_MOD) for o in context.scene.objects if o.type == 'MESH')
    r = b.row(align=True)
    r.operator("thuma.parts_mask", text="По модулях", depress=not cfg).mode = 'MODULE'
    r.operator("thuma.parts_mask", text="По конфігураціях", depress=cfg).mode = 'CONFIG'
    b.label(text="Показ: WireColor → Перегляд Face", icon='INFO')


class THUMA_OT_reset(bpy.types.Operator):
    bl_idname = "thuma.reset"
    bl_label = "Скинути до стандартних"
    bl_options = {'REGISTER', 'UNDO'}
    scope: bpy.props.EnumProperty(items=[('ALL', "Увесь пульт", ""), ('ZONE', "Зона", ""), ('CUSTOM', "Своя зона", "")])
    names: bpy.props.StringProperty()
    index: bpy.props.IntProperty(default=-1)
    target: bpy.props.StringProperty()      # 1.22.0: '' = тканина, 'RAIL' = WOOD LOOK рейок, 'EG' = торців

    @classmethod
    def description(cls, context, props):
        if props.target in {'RAIL', 'EG'}:
            what = "торців-вставок" if props.target == 'EG' else "WOOD LOOK"
            return (f"Скинути ВСІ повзунки {what} цієї породи до стандартних (Ctrl+Z — повернути)"
                    if props.scope == 'ALL' else "Скинути повзунки цього блоку до стандартних")
        return {'ALL': "Скинути ВСІ повзунки FABRIC LOOK цієї тканини до стандартних (Ctrl+Z — повернути)",
                'ZONE': "Скинути повзунки цієї зони до стандартних",
                'CUSTOM': "Скинути цю свою зону: яскравість 1, насиченість 1, перехід 0, сила 1, за ракурсом 1 (полігони лишаються)"}[props.scope]

    def invoke(self, context, event):
        if self.scope == 'ALL' or self.target in {'RAIL', 'EG'}:     # 1.22.0: дерево — завжди питати
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        if self.scope == 'CUSTOM':
            ob = context.active_object
            if not _ups_mesh(ob) or not (0 <= self.index < len(ob.data.thuma_zones)):
                return {'CANCELLED'}
            z = ob.data.thuma_zones[self.index]
            z.bright, z.sat, z.transition, z.trans_strength = 1.0, 1.0, 0.0, 1.0
            z.b_f = z.b_l = z.b_r = z.s_f = z.s_l = z.s_r = 1.0
            z.grad_top = z.grad_bot = 1.0                # 1.33.0
            z.grad_curve = 1.0
            return {'FINISHED'}
        node = _target_node(self.target)
        if not node:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        only = set(self.names.split("|")) if self.scope == 'ZONE' else None
        n = 0
        for sock in node.inputs:
            if sock.name == "Колір" or sock.is_linked or sock.name not in defaults:
                continue
            if only is not None and sock.name not in only:
                continue
            try:
                sock.default_value = defaults[sock.name]; n += 1
            except Exception:
                pass
        self.report({'INFO'}, f"Скинуто повзунків: {n}")
        return {'FINISHED'}


def _eye_holder(target):
    """Де зберігати «до/після»: тканина — її матеріал, дерево — група породи з WOOD LOOK (1.22.6)."""
    if target in {'RAIL', 'EG'}:
        n = _wood_look_node(target)
        return n.id_data if n is not None else None
    return _current()


def _eye(layout, key, names, target=""):
    mat = _eye_holder(target)
    off = bool(mat and mat.get(f"tc_eye_{key}"))
    o = layout.operator("thuma.eye", text="", icon='HIDE_ON' if off else 'HIDE_OFF', emboss=False, depress=off)
    o.key = key; o.names = names; o.target = target


class THUMA_OT_eye(bpy.types.Operator):
    """Глазик: вимкнути налаштування зони (показати «до»), повторний клік — повернути"""
    bl_idname = "thuma.eye"
    bl_label = "Порівняти до/після"
    bl_options = {'REGISTER', 'UNDO'}
    key: bpy.props.StringProperty()
    names: bpy.props.StringProperty()
    target: bpy.props.StringProperty()      # 1.22.6: '' = тканина, 'RAIL' / 'EG' = дерево

    @classmethod
    def description(cls, context, props):
        mat = _eye_holder(props.target)
        if mat and mat.get(f"tc_eye_{props.key}"):
            return "Повернути налаштування цієї зони (зараз показано «до»)"
        if props.key.endswith("__ALL__"):
            return ("Тимчасово вимкнути ВЕСЬ пульт цієї породи — порівняти до/після" if props.target
                    else "Тимчасово вимкнути ВЕСЬ пульт цієї тканини — порівняти до/після")
        return ("Тимчасово вимкнути ВЕСЬ пульт цієї тканини — порівняти до/після" if props.key == "__ALL__"
                else "Тимчасово вимкнути налаштування цієї зони — порівняти до/після. Ще клік — повернути")

    def execute(self, context):
        import json
        mat = _eye_holder(self.target); node = _target_node(self.target)
        if not node or mat is None:
            return {'CANCELLED'}
        defaults = {it.name: it.default_value for it in node.node_tree.interface.items_tree
                    if getattr(it, "in_out", None) == 'INPUT' and hasattr(it, "default_value")}
        prop = f"tc_eye_{self.key}"
        if mat.get(prop):                                  # повернути
            stash = json.loads(mat[prop])
            for name, v in stash.items():
                sock = node.inputs.get(name)
                if sock is None or sock.is_linked:
                    continue
                cur = sock.default_value
                d = defaults.get(name)
                # якщо поки «око» було вимкнене, користувач змінив повзунок — лишаємо його нове значення
                same = (abs(cur - d) < 1e-6) if isinstance(d, (int, float)) and isinstance(cur, (int, float)) else True
                if same:
                    sock.default_value = v
            del mat[prop]
        else:                                               # вимкнути: запам'ятати і поставити стандартні
            only = None if self.key.endswith("__ALL__") else set(self.names.split("|"))
            stash = {}
            for sock in node.inputs:
                if sock.name == "Колір" or sock.is_linked or sock.name not in defaults or sock.name == "Показати зони":
                    continue
                if only is not None and sock.name not in only:
                    continue
                v = sock.default_value
                if hasattr(v, "__len__"):
                    continue
                stash[sock.name] = v
                sock.default_value = defaults[sock.name]
            mat[prop] = json.dumps(stash, ensure_ascii=False)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# кольори = як у «Показати зони» FABRIC LOOK (приглушені значки колекцій)
_ZONE_ICON = {
    "Спинка": 'COLLECTION_COLOR_05', "Сидіння": 'COLLECTION_COLOR_04',
    "Боковина внутр. ліва": 'COLLECTION_COLOR_07', "Боковина внутр. права": 'COLLECTION_COLOR_06',
    "Боковина зовн. ліва": 'COLLECTION_COLOR_02', "Боковина зовн. права": 'COLLECTION_COLOR_08',
    "Верх": 'COLLECTION_COLOR_03', "Фронт": 'COLLECTION_COLOR_01', "Задня стінка": 'COLORSET_07_VEC',
    "Вся тканина": 'MATERIAL', "Кутик": 'MOD_LINEART',
    # 1.8.0: нові зони — кольори як у «Показати зони» (рожевий/фіолетовий відтінок своєї боковини)
    "Низ внутр. ліва": 'COLORSET_05_VEC', "Низ внутр. права": 'COLORSET_06_VEC',
    "Кут": 'LIGHT_SUN', "Шви": 'MOD_EDGESPLIT',
}
_PANEL_ICON = {"Шви": 'MOD_EDGESPLIT', "Загальне": 'MATERIAL', "Перевірка і плавність": 'HIDE_OFF',
               "Кутик біля підлокітника": 'MOD_LINEART', "Спинка й сидіння": 'MESH_PLANE',
               "Боковини ліві": 'TRIA_LEFT', "Боковини праві": 'TRIA_RIGHT', "Верх": 'TRIA_UP',
               "Фронт і зад": 'ARROW_LEFTRIGHT', "Фронт-кадри: кут біля боковини": 'LIGHT_SUN'}


# ── Дерево: перемикач порід по одній (вузол WOOD у Thuma_Wood_Finger-Joints_4K = 1..5) ─────────────
# Сам вузол Value крокує стрілками по 0.1 — тут список назв, що ставить рівно 1..5. Торці йдуть за ним драйвером.
WOOD_MAT = "Thuma_Wood_Finger-Joints_4K"
WOODS = [("1", "Natural", "Порода 1 — Natural"), ("2", "Oak", "Порода 2 — Oak"), ("3", "Walnut", "Порода 3 — Walnut"),
         ("4", "Espresso", "Порода 4 — Espresso"), ("5", "Grey", "Порода 5 — Grey")]
_WOOD_ITEMS = [(k, n, d, 'NODE_MATERIAL', i) for i, (k, n, d) in enumerate(WOODS)]


# ---------------- 1.13.0: «Розцвітка клієнта» -> тканина + порода + вкладка таблиці імен у CFRender ----------------
# Таблиця «Thuma Essential Seating - Render Names» (Google Sheets): одна вкладка = одна розцвітка = один прохід рендеру.
# Пара (порода, тканина) унікальна -> вкладка. Оновлено 2026-10-09 (клієнт змінив дерево в 06, 07, 10, 11, 12; 15 = дивани/крісло).
_SHEET_EDIT = "https://docs.google.com/spreadsheets/d/1hXnVX7JrIPy2Pw0mU9nbxp7_oin6dguNm9kVNvGlaEk/edit#gid="
_COMBOS = [   # (вкладка, порода, тип тканини в назві матеріалу, колір, gid, опис)
    ("01 es-ptwca", "Espresso", "Textured-Weave", "Carbon", "223742172", "жовта, усі ракурси"),
    ("02 gr-ptwna", "Grey", "Textured-Weave", "Natural", "618829161", "жовта, усі ракурси"),
    ("03 na-pmwllg", "Natural", "Medium-Weight-Linen", "Light-Grey", "1077433968", "жовта, усі ракурси"),
    ("04 oa-ptwiv", "Oak", "Textured-Weave", "Ivory", "619437790", "жовта, усі ракурси"),
    ("05 wa-ptwmo", "Walnut", "Textured-Weave", "Mocha", "695187515", "жовта, усі ракурси"),
    ("06 es-bouch", "Espresso", "Boucle", "Charcoal", "1822028066", "лише Front"),
    ("07 wa-boumo", "Walnut", "Boucle", "Mocha", "333760420", "лише Front"),
    ("08 gr-bouna", "Grey", "Boucle", "Natural", "1211732320", "лише Front"),
    ("09 gr-bouwh", "Grey", "Boucle", "White", "1947524051", "лише Front"),
    ("10 es-pmwlch", "Espresso", "Medium-Weight-Linen", "Charcoal", "319420377", "лише Front"),
    ("11 wa-pmwlmo", "Walnut", "Medium-Weight-Linen", "Mocha", "585179511", "лише Front"),
    ("12 oa-pmwlna", "Oak", "Medium-Weight-Linen", "Natural", "2044830885", "лише Front, без диванів/крісла"),
    ("13 gr-pmwlwh", "Grey", "Medium-Weight-Linen", "White", "1580439330", "лише Front"),
    ("14 gr-pmwllg", "Grey", "Medium-Weight-Linen", "Light-Grey", "1232537119", "лише дивани й крісло"),
    ("15 gr-pmwlna", "Grey", "Medium-Weight-Linen", "Natural", "1705406437", "лише дивани й крісло"),
]


def _combo_mat(c):
    return f"Thuma_Performance-{c[2]}_{c[3]}_4K"


def _current_combo():
    mat = _current()
    n = _wood_node()
    if mat is None or n is None:
        return None
    wood = WOODS[min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)][1]
    return next((c for c in _COMBOS if c[1] == wood and _combo_mat(c) == mat.name), None)


def _sync_cfr(scene=None):
    """Поставити в CFRender посилання на вкладку поточної розцвітки (якщо така є в таблиці)."""
    scene = scene or bpy.context.scene
    c = _current_combo()
    props = getattr(scene, "cfrender_props", None)
    if c is None or props is None:
        return None
    url = _SHEET_EDIT + c[4]
    if props.sheets_url != url:
        props.sheets_url = url
    return c


def _combo_items(self, context):
    return _COMBO_ITEMS


_COMBO_ITEMS = [(c[0], f"{c[0]}  {c[1]} + {c[3].replace('-', ' ')} ({c[2].replace('-', ' ')})",
                 f"{c[1]} + {c[3]} {c[2]} — {c[5]}. Ставить тканину, породу і вкладку таблиці імен у CFRender", i)
                for i, c in enumerate(_COMBOS)]


def _combo_get(self):
    c = _current_combo()
    return _COMBOS.index(c) if c else 0               # нема пари -> показуємо 01, але панель пише попередження


def _combo_set(self, value):
    c = _COMBOS[value]
    sc = bpy.context.scene
    if bpy.data.materials.get(_combo_mat(c)) is None:
        print("[Thuma Fabric] нема матеріалу", _combo_mat(c))
        return
    sc.thuma_fabric_pick = _combo_mat(c)
    sc.thuma_wood_pick = next(k for k, n, _d in WOODS if n == c[1])
    _sync_cfr(sc)


def _draw_combo(c, context):
    sc = context.scene
    cur = _current_combo()
    bx = c.box()
    r0 = bx.row(align=True)
    r0.prop(sc, "thuma_combo_pick", text="Розцвітка")
    r0.operator("thuma.combo_queue", text="", icon='SEQUENCE')
    if cur is None:
        r = bx.row(); r.alert = True
        r.label(text="Такої пари дерево + тканина нема в таблиці клієнта", icon='ERROR')
    else:
        props = getattr(sc, "cfrender_props", None)
        if props is None:
            bx.label(text=f"Таблиця імен: {cur[0]} (CFRender не встановлено)", icon='INFO')
        elif props.sheets_url.strip() == _SHEET_EDIT + cur[4]:
            bx.label(text=f"CFRender: вкладка {cur[0]} ({cur[5]})", icon='CHECKMARK')
        else:
            r = bx.row(); r.alert = True
            r.label(text=f"У CFRender інша таблиця", icon='ERROR')
            r.operator("thuma.combo_sync", text=f"Поставити {cur[0]}", icon='URL')


def _cfr_sheet_hook(scene, url):
    """Хук черги таблиць Frame Render (CFRender ≥1.8): перед вкладкою поставити її тканину й породу."""
    import re as _r
    m = _r.search(r"gid=(\d+)", url or "")
    c = next((x for x in _COMBOS if m and x[4] == m.group(1)), None)
    if c is None or bpy.data.materials.get(_combo_mat(c)) is None:
        return
    scene.thuma_fabric_pick = _combo_mat(c)
    scene.thuma_wood_pick = next(k for k, n, _d in WOODS if n == c[1])
    print(f"[Thuma Fabric] черга Frame Render: {c[0]} -> {c[1]} + {c[3]} {c[2]}")


class THUMA_OT_combo_queue(bpy.types.Operator):
    bl_idname = "thuma.combo_queue"
    bl_label = "Розцвітки -> черга Frame Render"
    bl_description = ("Додати всі 15 розцвіток клієнта в «Чергу таблиць» Frame Render (без галочок — відміть потрібні). "
                      "Під час рендеру черги перед кожною розцвіткою сама ставиться її тканина й порода")

    def execute(self, context):
        props = getattr(context.scene, "cfrender_props", None)
        if props is None or not hasattr(props, "sheet_queue"):
            self.report({'WARNING'}, "Потрібен Frame Render (Custom Frame Render) 1.8+")
            return {'CANCELLED'}
        have = {it.url: it for it in props.sheet_queue}
        n = 0
        for c, item in zip(_COMBOS, _COMBO_ITEMS):
            url = _SHEET_EDIT + c[4]
            it = have.get(url) or props.sheet_queue.add()
            if it.url != url:
                it.url = url; it.use = False; n += 1
            it.name = item[1]
        self.report({'INFO'}, f"Черга Frame Render: {len(_COMBOS)} розцвіток (нових {n}). Відміть потрібні й тисни Render queue")
        return {'FINISHED'}


class THUMA_OT_combo_sync(bpy.types.Operator):
    bl_idname = "thuma.combo_sync"
    bl_label = "Поставити таблицю імен у CFRender"
    bl_description = "Вставити в CFRender посилання на вкладку таблиці імен для поточної розцвітки (дерево + тканина)"

    def execute(self, context):
        c = _sync_cfr(context.scene)
        if c is None:
            self.report({'WARNING'}, "Нема такої розцвітки в таблиці або не встановлено CFRender")
            return {'CANCELLED'}
        self.report({'INFO'}, f"CFRender: {c[0]}")
        return {'FINISHED'}


def _wood_node():
    m = bpy.data.materials.get(WOOD_MAT)
    return m.node_tree.nodes.get("WOOD") if m and m.node_tree else None


def _wood_get(self):
    n = _wood_node()
    if not n:
        return 0
    return min(max(int(round(n.outputs[0].default_value)) - 1, 0), len(WOODS) - 1)


def _wood_set(self, value):
    n = _wood_node()
    if n:
        n.outputs[0].default_value = float(value + 1)
        try:
            _sync_cfr()                                 # 1.13.0: таблиця імен у CFRender за розцвіткою
        except Exception as e:
            print("[Thuma Fabric] CFRender sync:", e)
        for a in bpy.context.screen.areas if bpy.context.screen else []:
            a.tag_redraw()


# ---------------- 1.9.0: оновлення пульта FABRIC LOOK у будь-якій сцені ----------------
# Збирач пульта і розмітка зон їдуть усередині аддона (папка fl/). Номер збірки — FL_VERSION у fl/fabric_look_v7.py;
# у сцені він записаний як FABRIC LOOK["fl_version"]. Старіший -> у панелі кнопка «Оновити пульт».
import os as _os
import re as _re
_FL_DIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "fl")
_FL_FILE = _os.path.join(_FL_DIR, "fabric_look_v7.py")


def _fl_version():
    try:
        m = _re.search(r"^FL_VERSION\s*=\s*(\d+)", open(_FL_FILE, encoding="utf-8").read(), _re.M)
        return int(m.group(1)) if m else 0
    except OSError:
        return 0


_FL_VER = _fl_version()


def _fl_changes(name="FL_CHANGES"):
    """1.27.0: {збірка: опис} з FL_CHANGES збирача (без виконання коду — лише читання словника).
    1.30.1: те саме для FL_FRAMES (на які кадри впливає збірка)."""
    import ast
    try:
        src = open(_FL_FILE, encoding="utf-8").read()
        for node in ast.parse(src).body:
            if isinstance(node, ast.Assign) and any(getattr(t, "id", "") == name for t in node.targets):
                return ast.literal_eval(node.value)
    except Exception:
        pass
    return {}


_FL_CHANGES = _fl_changes()
_FL_FRAMES = _fl_changes("FL_FRAMES")


def _scene_fl_version():
    g = bpy.data.node_groups.get("FABRIC LOOK")
    return int(g.get("fl_version", 0)) if g else None


class THUMA_OT_update_look(bpy.types.Operator):
    bl_idname = "thuma.update_look"
    bl_label = "Оновити пульт FABRIC LOOK"
    bl_description = ("Перезібрати пульт FABRIC LOOK і розмітку зон у ЦІЙ сцені до версії з аддона. Усі значення "
                      "повзунків, пензель кутика, свої зони й шви зберігаються. Займає ~30-60 с. "
                      "Після — збережи файл як нову версію")
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Оновити пульт FABRIC LOOK?",
                                                     message="~30-60 с, Blender не відповідатиме. Значення зберігаються.")

    def execute(self, context):
        if not _os.path.exists(_FL_FILE):
            self.report({'ERROR'}, "У аддоні нема збирача пульта (fl/) — перевстанови Thuma Material")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        wm = context.window_manager
        wm.progress_begin(0, 1)
        try:
            if _FL_DIR not in sys.path:
                sys.path.insert(0, _FL_DIR)
            ns = {"__file__": _FL_FILE, "__name__": "thuma_fl_builder"}
            exec(compile(open(_FL_FILE, encoding="utf-8").read(), _FL_FILE, "exec"), ns)
            res = ns["upgrade"]()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Оновлення пульта: {e}")
            return {'CANCELLED'}
        finally:
            wm.progress_end()
        bad = res.get("bad_links") if isinstance(res, dict) else None
        self.report({'WARNING'} if bad else {'INFO'},
                    f"Пульт оновлено до збірки {_FL_VER}" + (f"; перевір матеріали: {', '.join(bad)}" if bad else ""))
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


def _draw_update(c):
    cur = _scene_fl_version()
    if cur is None or not _FL_VER:
        return
    if cur < _FL_VER:
        bx = c.box()
        bx.alert = True
        bx.label(text=f"Пульт у сцені старіший (збірка {cur} < {_FL_VER})", icon='ERROR')
        bx.label(text="Оновиться кнопкою «Оновити все» нагорі", icon='INFO')   # 1.31.2
        news = [(v, t) for v, t in sorted(_FL_CHANGES.items()) if cur < v <= _FL_VER]   # 1.27.0: що саме зміниться
        if news:
            import textwrap
            col = bx.column(align=True)
            col.alert = False
            col.label(text="Що зміниться:", icon='INFO')
            for v, t in news:
                for i, line in enumerate(textwrap.wrap(t, 46)):
                    col.label(text=("• " if i == 0 else "   ") + line)
                if v in _FL_FRAMES:                  # 1.30.1: на які кадри впливає
                    for i, line in enumerate(textwrap.wrap("Кадри: " + _FL_FRAMES[v], 44)):
                        col.label(text="   " + line, icon='RENDER_ANIMATION' if i == 0 else 'BLANK1')
            if cur + 1 < min(_FL_CHANGES):           # є збірки старші за записані зміни
                col.label(text="• та попередні покращення пульта")


import sys  # noqa: E402


# ---------------- 1.10.0: ЕКСПОРТ / ІМПОРТ налаштувань однієї тканини (JSON) ----------------
# Що переноситься: усі повзунки FABRIC LOOK цієї тканини + незв'язані значення вузлів її матеріалу
# (і груп, що належать лише цьому матеріалу: текстура, Color Match тощо) + метод дисплейсменту.
# Старі назви повзунків — за тією ж таблицею, що й «Оновити пульт».
_FL_MIGRATE = {"Верх спинки": ["Верх"],
               "Боковини внутрішні": ["Боковина внутр. ліва", "Боковина внутр. права"],
               "Боковини зовнішні": ["Боковина зовн. ліва", "Боковина зовн. права"]}
_FL_FULL = {"Верх: колір тону": "Вся тканина: колір тону", "Верх: сила тону": "Вся тканина: сила тону",
            "Фронт: ліва боковина внутр.": "Кут: ліва боковина", "Фронт: спинка біля лівої": "Кут: спинка",
            "Фронт: ширина, см": "Кут: ширина, см", "Фронт: згасання до країв": "Кут: згасання до країв",
            "Фронт: боковина, довжина": "Кут: довжина боковини"}
_SKIP_TREES = ("FABRIC LOOK", "WOOD LOOK")
_SEP = " >> "                 # розділювач шляху група >> вузол (у назвах вузлів буває «/»)


def _jval(v):
    if isinstance(v, (bool, int, float, str)):
        return v
    try:
        return [float(x) for x in v]
    except TypeError:
        return None


def _sock_vals(socks):
    out = {}
    for sk in socks:
        if sk.is_linked or not hasattr(sk, "default_value") or getattr(sk, "hide_value", False):
            continue
        v = _jval(sk.default_value)
        if v is not None:
            out[sk.identifier] = [sk.name, v]
    return out


def _own(t):
    """Група належить лише одному матеріалу (фейковий користувач не рахується)."""
    return t.users - (1 if t.use_fake_user else 0) <= 1


def _walk_nodes(tree, prefix, look, acc, seen, own_only=True, skip_names=()):
    for n in tree.nodes:
        if n == look or n.name in skip_names:
            continue
        key = prefix + n.name
        d = {}
        iv = _sock_vals(n.inputs)
        if iv:
            d["in"] = iv
        if n.type == 'VALUE':
            d["value"] = float(n.outputs[0].default_value)
        if d:
            acc[key] = d
        t = getattr(n, "node_tree", None) if n.type == 'GROUP' else None
        if t and not t.name.startswith(_SKIP_TREES) and (not own_only or _own(t)) and t.as_pointer() not in seen:
            seen.add(t.as_pointer())
            _walk_nodes(t, key + _SEP, look, acc, seen, own_only, skip_names)


def _find_node(tree, path, own_only=True):
    parts = path.split(_SEP)
    for i, nm in enumerate(parts):
        n = tree.nodes.get(nm)
        if n is None:
            return None
        if i == len(parts) - 1:
            return n
        tree = getattr(n, "node_tree", None)
        if tree is None or (own_only and not _own(tree)) or tree.name.startswith(_SKIP_TREES):
            return None
    return None


def _apply_nodes(tree, nodes, own_only=True):
    ok = miss = 0
    for path, d in nodes.items():
        n = _find_node(tree, path, own_only)
        if n is None:
            miss += 1
            continue
        for ident, (name, v) in d.get("in", {}).items():
            sk = next((x for x in n.inputs if x.identifier == ident), None) or n.inputs.get(name)
            if sk is not None and not sk.is_linked and _set_sock(sk, v):
                ok += 1
        if "value" in d and n.type == 'VALUE':
            n.outputs[0].default_value = d["value"]; ok += 1
    return ok, miss


from bpy_extras.io_utils import ExportHelper as _EH, ImportHelper as _IH  # noqa: E402


# ---------------- 1.11.0: ДЕРЕВО — експорт/імпорт усіх налаштувань (усі породи, торці, grain, спільні групи) ----
def _wood_mats():
    return [m for m in bpy.data.materials if m.node_tree and ("Wood" in m.name or "WOOD" in m.name)]


class THUMA_OT_wood_export(bpy.types.Operator, _EH):
    bl_idname = "thuma.wood_export"
    bl_label = "Експорт налаштувань дерева"
    bl_description = ("Зберегти ВСІ налаштування дерева у файл .json: усі породи (пульти WOOD LOOK), торці (End-Grain), "
                      "grain, спільні групи (Wood Fiber Contrast+Tint) — щоб колеги завантажили їх кнопкою «Імпорт»")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = "Thuma_wood_settings.json"
        return super().invoke(context, event)

    def execute(self, context):
        import json
        mats = _wood_mats()
        if not mats:
            self.report({'WARNING'}, "У сцені нема матеріалів дерева")
            return {'CANCELLED'}
        data = {"thuma_wood_settings": 1, "addon": list(ADDON_VERSION), "materials": {}}
        n = 0
        for m in mats:
            nodes = {}
            _walk_nodes(m.node_tree, "", None, nodes, set(), own_only=False, skip_names=("WOOD",))
            data["materials"][m.name] = {"displacement_method": m.displacement_method, "nodes": nodes}
            n += len(nodes)
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        self.report({'INFO'}, f"Дерево: {len(mats)} матеріали, {n} вузлів -> {self.filepath}")
        return {'FINISHED'}


class THUMA_OT_wood_import(bpy.types.Operator, _IH):
    bl_idname = "thuma.wood_import"
    bl_label = "Імпорт налаштувань дерева"
    bl_description = ("Застосувати налаштування дерева з файлу .json (усі породи, торці, grain, спільні групи). "
                      "Вибрана порода (WOOD) не змінюється. Ctrl+Z — відмінити")
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        import json
        try:
            data = json.load(open(self.filepath, encoding="utf-8"))
        except Exception as e:
            self.report({'ERROR'}, f"Не прочитав файл: {e}")
            return {'CANCELLED'}
        if not data.get("thuma_wood_settings"):
            self.report({'ERROR'}, "Це не файл налаштувань дерева Thuma")
            return {'CANCELLED'}
        ok = miss = 0
        absent = []
        for name, md in data.get("materials", {}).items():
            m = bpy.data.materials.get(name)
            if m is None or not m.node_tree:
                absent.append(name)
                continue
            a, b = _apply_nodes(m.node_tree, md.get("nodes", {}), own_only=False)
            ok += a; miss += b
            try:
                m.displacement_method = md.get("displacement_method", m.displacement_method)
            except Exception:
                pass
        msg = f"Дерево: застосовано значень {ok}"
        if miss:
            msg += f"; вузлів нема в цій сцені: {miss}"
        if absent:
            msg += f"; матеріалів нема: {', '.join(absent)}"
        self.report({'WARNING'} if (miss or absent) else {'INFO'}, msg)
        for a_ in context.screen.areas:
            a_.tag_redraw()
        return {'FINISHED'}


def _set_sock(sk, v):
    try:
        sk.default_value = v
        return True
    except Exception:
        return False


def _export_data(mat):
    look = _look_node(mat)
    fl = {}
    if look:
        for sk in look.inputs:
            if sk.name != "Колір" and not sk.is_linked and hasattr(sk, "default_value"):
                v = _jval(sk.default_value)
                if v is not None:
                    fl[sk.name] = v
    nodes = {}
    _walk_nodes(mat.node_tree, "", look, nodes, set())
    g = bpy.data.node_groups.get("FABRIC LOOK")
    return {"thuma_fabric_settings": 1, "material": mat.name, "addon": list(ADDON_VERSION),
            "fl_version": int(g.get("fl_version", 0)) if g else 0,
            "displacement_method": mat.displacement_method, "fabric_look": fl, "nodes": nodes}


def _import_data(mat, data):
    look = _look_node(mat)
    ok = 0
    missing = []
    if look:
        for k, v in data.get("fabric_look", {}).items():
            k = _FL_FULL.get(k, k)
            base, _, kind = k.partition(": ")
            names = [f"{b}: {kind}" for b in _FL_MIGRATE[base]] if base in _FL_MIGRATE else [k]
            hit = False
            for nm in names:
                sk = look.inputs.get(nm)
                if sk is not None and not sk.is_linked and _set_sock(sk, v):
                    ok += 1; hit = True
            if not hit:
                missing.append(k)
    n_ok, n_miss = _apply_nodes(mat.node_tree, data.get("nodes", {}))
    dm = data.get("displacement_method")
    if dm:
        try:
            mat.displacement_method = dm
        except Exception:
            pass
    return ok, missing, n_ok, n_miss


from bpy_extras.io_utils import ExportHelper as _EH, ImportHelper as _IH  # noqa: E402


# ---------------- 1.23.0: перенести налаштування FABRIC LOOK на іншу тканину (по розділах, галочками) ----------------
_CL_TARGETS = []    # рядки списку тканин-цілей тримаємо живими (як _ITEMS)


def _look_sections(node):
    """[(назва розділу, [імена сокетів])] у порядку панелі; без «Колір» і «Показати зони»."""
    secs = []
    for it in node.node_tree.interface.items_tree:
        if it.item_type == 'PANEL':
            secs.append((it.name, []))
        elif it.in_out == 'INPUT' and it.name not in {"Колір", "Показати зони"}:
            if not secs:
                secs.append(("Інше", []))
            secs[-1][1].append(it.name)
    return [(n, s) for n, s in secs if s]


def _cl_target_items(self, context):
    cur = _current()
    fabs = [m for m in _fabrics() if m != cur and _look_node(m)]
    _CL_TARGETS[:] = [("__ALL__", "Усі інші тканини", f"На всі {len(fabs)} інших тканин", 'DUPLICATE', 0)]
    _CL_TARGETS.extend((m.name, m["thuma_fabric"], m.name, 'MATERIAL', i + 1) for i, m in enumerate(fabs))
    return _CL_TARGETS


class THUMA_CopySection(bpy.types.PropertyGroup):
    on: bpy.props.BoolProperty(name="", default=False)
    names: bpy.props.StringProperty()


class THUMA_OT_copy_look(bpy.types.Operator):
    """Перенести повзунки FABRIC LOOK цієї тканини на іншу: вибрати тканину і галочками — які розділи"""
    bl_idname = "thuma.copy_look"
    bl_label = "Перенести налаштування на іншу тканину"
    bl_options = {'REGISTER', 'UNDO'}
    target: bpy.props.EnumProperty(name="На тканину", items=_cl_target_items,
                                   description="Куди перенести налаштування пульта")
    sections: bpy.props.CollectionProperty(type=THUMA_CopySection)

    @classmethod
    def poll(cls, context):
        return _look_node(_current()) is not None

    def invoke(self, context, event):
        self.sections.clear()
        for name, socks in _look_sections(_look_node(_current())):
            it = self.sections.add()
            it.name = name; it.names = "|".join(socks); it.on = False
        return context.window_manager.invoke_props_dialog(self, width=360, confirm_text="Перенести")

    def draw(self, context):
        lay = self.layout
        lay.label(text=f"З тканини: {_current()['thuma_fabric']}", icon='MATERIAL')
        lay.prop(self, "target", text="На")
        lay.separator()
        lay.label(text="Які розділи перенести:")
        col = lay.box().column(align=True)
        for it in sorted(self.sections, key=lambda x: next((n for n, p in enumerate(_FL_ORDER)
                                                           if x.name.startswith(p)), len(_FL_ORDER))):
            col.prop(it, "on", text=it.name)
        lay.label(text="Своя розмітка зон (на моделі) не переноситься", icon='INFO')

    def execute(self, context):
        import json
        src_mat = _current(); src = _look_node(src_mat)
        names = {n for it in self.sections if it.on for n in it.names.split("|") if n}
        if not src or not names:
            self.report({'WARNING'}, "Не вибрано жодного розділу")
            return {'CANCELLED'}
        # якщо в джерелі зараз вимкнене «око» — беремо збережені (справжні) значення, а не тимчасові стандартні
        stash = {}
        for k in src_mat.keys():
            if k.startswith("tc_eye_"):
                try:
                    stash.update(json.loads(src_mat[k]))
                except Exception:
                    pass
        tgts = ([m for m in _fabrics() if m != src_mat and _look_node(m)] if self.target == "__ALL__"
                else [bpy.data.materials.get(self.target)])
        n_set = 0
        for m in tgts:
            dst = _look_node(m) if m else None
            if dst is None or dst == src:
                continue
            for name in names:
                a, b = src.inputs.get(name), dst.inputs.get(name)
                if a is None or b is None or b.is_linked or not hasattr(a, "default_value"):
                    continue
                v = stash.get(name, a.default_value)
                try:
                    b.default_value = v if not hasattr(v, "__len__") else tuple(v)
                    n_set += 1
                except Exception:
                    pass
        for a in context.screen.areas:
            a.tag_redraw()
        self.report({'INFO'}, f"Перенесено повзунків: {n_set} (тканин: {len(tgts)}). Ctrl+Z — повернути")
        return {'FINISHED'}


class THUMA_OT_settings_export(bpy.types.Operator, _EH):
    bl_idname = "thuma.settings_export"
    bl_label = "Експорт налаштувань тканини"
    bl_description = ("Зберегти ВСІ налаштування поточної тканини (повзунки FABRIC LOOK + значення вузлів її "
                      "матеріалу) у файл .json — щоб перенести в іншу сцену кнопкою «Імпорт»")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        mat = _current()
        if mat:
            self.filepath = bpy.path.clean_name(mat.name) + ".json"
        return super().invoke(context, event)

    def execute(self, context):
        import json
        mat = _current()
        if not mat or not mat.get("thuma_fabric"):
            self.report({'WARNING'}, "Нема поточної тканини Thuma")
            return {'CANCELLED'}
        data = _export_data(mat)
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        self.report({'INFO'}, f"«{mat.name}»: {len(data['fabric_look'])} повзунків, {len(data['nodes'])} вузлів -> {self.filepath}")
        return {'FINISHED'}


class THUMA_OT_settings_import(bpy.types.Operator, _IH):
    bl_idname = "thuma.settings_import"
    bl_label = "Імпорт налаштувань тканини"
    bl_description = ("Застосувати налаштування з файлу .json до ПОТОЧНОЇ тканини (вибраної вгорі). Старі назви "
                      "повзунків переносяться автоматично; нові, яких у файлі нема, лишаються як є. Ctrl+Z — відмінити")
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        import json
        mat = _current()
        if not mat or not mat.get("thuma_fabric"):
            self.report({'WARNING'}, "Нема поточної тканини Thuma")
            return {'CANCELLED'}
        try:
            data = json.load(open(self.filepath, encoding="utf-8"))
        except Exception as e:
            self.report({'ERROR'}, f"Не прочитав файл: {e}")
            return {'CANCELLED'}
        if not data.get("thuma_fabric_settings"):
            self.report({'ERROR'}, "Це не файл налаштувань тканини Thuma")
            return {'CANCELLED'}
        ok, missing, n_ok, n_miss = _import_data(mat, data)
        msg = f"«{data.get('material')}» -> «{mat.name}»: повзунків {ok}, значень вузлів {n_ok}"
        if data.get("material") != mat.name:
            msg += " (УВАГА: файл від іншої тканини)"
        if missing:
            msg += f"; не знайшов {len(missing)} повзунків: {', '.join(missing[:6])}"
            print("[Thuma Fabric] імпорт: не знайдено повзунків:", missing)
        if n_miss:
            msg += f"; вузлів нема в цьому матеріалі: {n_miss}"
        self.report({'WARNING'} if (missing or data.get('material') != mat.name) else {'INFO'}, msg)
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


# ---------------- 1.12.0: «Налаштування Євгена» — дерево з командного сайту ----------------
# Євген: «Дерево: опублікувати» -> presets/thuma_wood.json (значення всіх порід/торців/grain) + thuma_wood_look.blend
# (сам пульт WOOD LOOK v2, точна копія) у репозиторій сайту + git push.
# Колеги: аддон раз на 2 год / при відкритті файлу читає thuma_wood.json; якщо stamp новіший за застосований у сцені —
# у панелі «Застосувати налаштування Євгена». Застосування: (якщо пульт інший) підмінити WOOD LOOK v2 копією з .blend,
# перев'язати за іменами, об'єкти WOOD_CENTER/Control_Rotation — свої; далі значення. Порода (WOOD) не змінюється.
import hashlib as _hl
import json as _json
import tempfile as _tf
import time as _time
_SITE = "https://grebenukevgen41-web.github.io/hrebeniuk-tools/presets/"
_OWNER_DIR = r"E:\disk_D\pROG\Thuma_prog\Blender\Extensions\_repo_github"
_WOOD_GROUP = "WOOD LOOK v2"
# 1.21.3: нове імʼя файлу пресету — старі аддони (≤1.21.2) читають thuma_wood.json, який більше не оновлюється,
# тож нове дерево їм не приходить раніше за оновлення аддона. min_addon — у самому пресеті на майбутнє.
_WOOD_JSON = "thuma_wood_v2.json"
_WOOD_LOOK_FILE = "thuma_wood_look_v2.blend"
_WOOD_MIN_ADDON = (1, 31, 1)   # 1.31.0: дерево 15.10 потребує «Оновлення моделі» (рейки, fz_hb)
_REMOTE = {"wood": None, "checked": 0.0, "error": ""}


def _is_owner():
    return _os.path.isdir(_os.path.join(_OWNER_DIR, ".git"))


def _group_hash(g):
    if g is None:
        return ""
    sig = [len(g.nodes)] + sorted(f"{n.bl_idname}:{n.name}" for n in g.nodes) + \
          [f"{i.in_out}:{i.name}" for i in g.interface.items_tree if i.item_type == 'SOCKET'] + \
          sorted(f"{l.from_node.name}.{l.from_socket.identifier}>{l.to_node.name}.{l.to_socket.identifier}" for l in g.links)
    return _hl.md5("|".join(map(str, sig)).encode("utf-8")).hexdigest()


def _wood_export_dict():
    data = {"thuma_wood_settings": 1, "addon": list(ADDON_VERSION), "materials": {}}
    for m in _wood_mats():
        nodes = {}
        _walk_nodes(m.node_tree, "", None, nodes, set(), own_only=False, skip_names=("WOOD",))
        data["materials"][m.name] = {"displacement_method": m.displacement_method, "nodes": nodes}
    return data


def _wood_apply_values(data):
    ok = miss = 0
    for name, md in data.get("materials", {}).items():
        m = bpy.data.materials.get(name)
        if m is None or not m.node_tree:
            continue
        a, b = _apply_nodes(m.node_tree, md.get("nodes", {}), own_only=False)
        ok += a; miss += b
        try:
            m.displacement_method = md.get("displacement_method", m.displacement_method)
        except Exception:
            pass
    return ok, miss


def _swap_group(old, new):
    """Підмінити групу old на new у всіх вузлах-інстансах: значення й зв'язки — за іменами."""
    trees = [m.node_tree for m in bpy.data.materials if m.node_tree] + \
            [t for t in bpy.data.node_groups if t.bl_idname == 'ShaderNodeTree']
    inst = [n for t in trees for n in t.nodes if n.type == 'GROUP' and n.node_tree == old]
    for n in inst:
        vals = {x.name: (tuple(x.default_value) if hasattr(x.default_value, "__len__") else x.default_value)
                for x in n.inputs if hasattr(x, "default_value") and not x.is_linked}
        # 1.21.1: зі сторони підмінюваної групи сокет шукаємо за ІМЕНЕМ (ідентифікатори нової групи інші), з другого
        # боку — за ІДЕНТИФІКАТОРОМ (у Mix Shader обидва входи звуться «Shader» — за іменем звʼязки плутались)
        links = [(l.from_node.name, l.from_socket.identifier, l.from_socket.name,
                  l.to_node.name, l.to_socket.identifier, l.to_socket.name)
                 for l in n.id_data.links if l.from_node == n or l.to_node == n]
        t = n.id_data
        for l in [l for l in t.links if l.from_node == n or l.to_node == n]:
            t.links.remove(l)
        n.node_tree = new
        for k, v in vals.items():
            if n.inputs.get(k) is not None:
                _set_sock(n.inputs[k], v)

        def _sock(coll, node, ident, name):
            if node == n:
                return coll.get(name)
            return next((x for x in coll if x.identifier == ident), None)
        for fn, fi, fs, tn, ti, ts in links:
            a_, b_ = t.nodes.get(fn), t.nodes.get(tn)
            if not (a_ and b_):
                continue
            so, si = _sock(a_.outputs, a_, fi, fs), _sock(b_.inputs, b_, ti, ts)
            if so is not None and si is not None and not any(l.from_socket == so and l.to_socket == si for l in t.links):
                t.links.new(so, si)
    return len(inst)


_EG_PREFIX = "Thuma_End-Grain_"


def _r_strip(name):
    import re as _r
    return _r.sub(r"\.\d{3}$", "", name)


def _eg_groups():
    """Торцеві групи, які реально стоять у матеріалі-перемикачі торців."""
    m = bpy.data.materials.get("Thuma_Wood_End-Grain_SWITCH")
    if not m or not m.node_tree:
        return []
    return sorted({n.node_tree for n in m.node_tree.nodes if n.type == 'GROUP' and n.node_tree
                   and n.node_tree.name.startswith(_EG_PREFIX)}, key=lambda g: g.name)


def _eg_node_map():
    """1.21.3: вузол перемикача торців -> імʼя торцевої групи (зіставляємо за вузлом, бо імена груп у колег інші)."""
    m = bpy.data.materials.get("Thuma_Wood_End-Grain_SWITCH")
    if not m or not m.node_tree:
        return {}
    return {n.name: n.node_tree.name for n in m.node_tree.nodes
            if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith(_EG_PREFIX)}


def _eg_local_by_node(node_name):
    m = bpy.data.materials.get("Thuma_Wood_End-Grain_SWITCH")
    n = m.node_tree.nodes.get(node_name) if m and m.node_tree else None
    return n.node_tree if n is not None and n.type == 'GROUP' else None


def _relink_missing_images():
    """1.21.5: картинка зі шляхом, якого нема на цьому ПК (напр. D:/Work з ПК Євгена, а колега відкрив сцену з
    мережі) -> шукаємо файл з тією ж назвою у папці textures поруч зі сценою. Повертає к-сть перепривʼязаних."""
    if not bpy.data.filepath:
        return 0
    root = _os.path.join(_os.path.dirname(bpy.data.filepath), "textures")
    miss = [im for im in bpy.data.images if im.source == 'FILE' and im.filepath and not im.packed_file
            and not im.library and not _os.path.exists(bpy.path.abspath(im.filepath))]
    if not miss or not _os.path.isdir(root):
        return 0
    found = {}
    for dp, _dn, fn in _os.walk(root):
        for f in fn:
            found.setdefault(_os.path.normcase(f), _os.path.join(dp, f))
    n = 0
    for im in miss:
        f = found.get(_os.path.normcase(_os.path.basename(bpy.path.abspath(im.filepath).replace("\\", "/"))))
        if f:
            try:
                im.filepath = bpy.path.relpath(f)
            except ValueError:
                im.filepath = f
            im.reload()
            n += 1
    if n:
        print(f"Thuma: перепривʼязано текстур з папки textures: {n}")
    return n


def _wood_relink_images(new_imgs, old_imgs):
    """1.21.5: текстури з файлу публікації мають шлях з ПК Євгена (D:/Work/...). У колег такого шляху нема ->
    торці помаранчеві/рожеві. Беремо ту саму картинку, що вже є у сцені (той самий файл), або шукаємо файл у
    //textures поруч зі сценою."""
    ap = lambda im: _os.path.normcase(_os.path.abspath(bpy.path.abspath(im.filepath))) if im.filepath else ""
    have = {}
    for im in old_imgs:
        try:
            if im.filepath and _os.path.exists(ap(im)):
                have.setdefault(_os.path.basename(ap(im)), im)
        except ReferenceError:
            pass
    root = _os.path.join(_os.path.dirname(bpy.data.filepath), "textures") if bpy.data.filepath else ""
    found = {}
    if root and _os.path.isdir(root):
        for dp, _dn, fn in _os.walk(root):
            for f in fn:
                found.setdefault(_os.path.normcase(f), _os.path.join(dp, f))
    for im in new_imgs:
        bn = _os.path.basename(ap(im))
        if not bn:
            continue
        same = have.get(bn)
        if same is not None:                              # та сама текстура вже є у сцені -> без дубля
            im.user_remap(same)
            bpy.data.images.remove(im)
        elif not _os.path.exists(ap(im)) and bn in found:
            try:
                im.filepath = bpy.path.relpath(found[bn])
            except ValueError:                            # інший диск -> абсолютний шлях
                im.filepath = found[bn]
            im.reload()


def _wood_apply_look(blend_path, eg_nodes=None):
    """Взяти WOOD LOOK v2 з .blend і поставити замість свого (свої об'єкти, без дублів)."""
    before_obj = set(bpy.data.objects); before_act = set(bpy.data.actions); before_grp = set(bpy.data.node_groups)
    before_img = set(bpy.data.images)
    with bpy.data.libraries.load(blend_path, link=False) as (src, dst):
        eg_names = [g for g in src.node_groups if g.startswith(_EG_PREFIX)]
        req = [g for g in src.node_groups if g == _WOOD_GROUP] + eg_names
        dst.node_groups = list(req)
    loaded = dict(zip(req, dst.node_groups))             # імʼя у файлі публікації -> завантажена група (.001 тощо)
    new = loaded.get(_WOOD_GROUP)
    new_eg = {k: v for k, v in loaded.items() if k in eg_names and v is not None}   # 1.21.1: точне імʼя -> група
    if new is None:
        raise RuntimeError("у файлі пульта нема WOOD LOOK v2")
    import re as _r
    _wood_relink_images([i for i in bpy.data.images if i not in before_img], before_img)
    for o in [o for o in bpy.data.objects if o not in before_obj]:          # WOOD_CENTER.001 -> свій WOOD_CENTER
        base = bpy.data.objects.get(_r.sub(r"\.\d{3}$", "", o.name))
        if base is not None and base not in [o]:
            o.user_remap(base)
        bpy.data.objects.remove(o)
    for a in [a for a in bpy.data.actions if a not in before_act]:
        if a.users == 0:
            bpy.data.actions.remove(a)
    for g in [g for g in bpy.data.node_groups if g not in before_grp and g != new and g not in new_eg.values()]:   # вкладені групи-дублі
        base = bpy.data.node_groups.get(_r.sub(r"\.\d{3}$", "", g.name))
        if base is not None and base != g:
            g.user_remap(base)
            bpy.data.node_groups.remove(g)
    old = bpy.data.node_groups.get(_WOOD_GROUP)
    n = _swap_group(old, new) if old is not None else 0
    if old is not None and old.users == 0:
        bpy.data.node_groups.remove(old)
    new.name = _WOOD_GROUP
    eg_nodes = eg_nodes or {}
    node_by_group = {gname: nname for nname, gname in eg_nodes.items()}
    for base, ng in new_eg.items():                      # 1.21.1: торцеві групи — так само, значення за іменами
        # 1.21.3: стару групу шукаємо за ВУЗЛОМ перемикача (у колег імена груп інші: Oak_4K / Oak_4K.001 …)
        old_eg = _eg_local_by_node(node_by_group[base]) if base in node_by_group else bpy.data.node_groups.get(base)
        if old_eg is not None and old_eg != ng:
            n += _swap_group(old_eg, ng)
            if old_eg.users == 0:
                bpy.data.node_groups.remove(old_eg)
        other = bpy.data.node_groups.get(base)            # 1.21.4: імʼя зайняте зайвою копією -> звільнити
        if other is not None and other != ng:
            other.name = base + "_old"
        ng.name = base
    return n


def _fetch(name, binary=False, channel=""):
    import urllib.request
    req = urllib.request.Request(_SITE + (channel + "/" if channel else "") + name + f"?t={int(_time.time())}", headers={"Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=15) as r:
        b = r.read()
    return b if binary else _json.loads(b.decode("utf-8"))


def _check_remote():
    """Таймер: прочитати thuma_wood.json з сайту (без блокування UI надовго)."""
    try:
        if getattr(bpy.app, "online_access", True) and bpy.data.materials.get(WOOD_MAT):
            _REMOTE["wood"] = _fetch(_WOOD_JSON); _REMOTE["error"] = ""
    except Exception as e:
        _REMOTE["error"] = str(e)[:120]
    _REMOTE["checked"] = _time.time()
    for w in bpy.context.window_manager.windows if bpy.context.window_manager else []:
        for a in w.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()
    return 7200.0


# 1.21.0: «Економія памʼяті». Модулі вмикаються ключами hide_viewport, тож вʼюпорт тримає ГОТОВУ (Subdivision 2)
# модель кожної конфігурації, яку хоч раз показав: +1.5-2 ГБ на конфігурацію, 36 конфігурацій > 64 ГБ -> виліт.
# На кожному кадрі у ПРИХОВАНИХ модулів вимикаємо Subdivision у вʼюпорті (кеш звільняється), у видимих — як було.
# Рендер не чіпаємо (він бере show_render / render_levels). Що вимкнули — у scene["tc_mem_off"], щоб повернути.
def _mem_objects(scene):
    return [o for o in scene.objects if o.type == 'MESH' and any(m.type == 'SUBSURF' for m in o.modifiers)]


def _mem_apply(scene):
    off = set(scene.get("tc_mem_off", []))
    changed = False
    for o in _mem_objects(scene):
        if o.mode == 'EDIT':
            continue
        vis = o.visible_get()
        for m in o.modifiers:
            if m.type != 'SUBSURF':
                continue
            key = f"{o.name}|{m.name}"
            if not vis and m.show_viewport:
                m.show_viewport = False; off.add(key); changed = True
            elif vis and key in off:
                m.show_viewport = True; off.discard(key); changed = True
    if changed:
        scene["tc_mem_off"] = sorted(off)


def _mem_restore(scene):
    for key in scene.get("tc_mem_off", []):
        on, _, mn = key.partition("|")
        o = scene.objects.get(on)
        m = o.modifiers.get(mn) if o else None
        if m is not None:
            m.show_viewport = True
    if "tc_mem_off" in scene:
        del scene["tc_mem_off"]


@bpy.app.handlers.persistent
def _mem_on_frame(scene, depsgraph=None):
    try:
        if getattr(scene, "thuma_mem_save", False):
            _mem_apply(scene)
    except Exception as e:                       # не валити зміну кадру
        print("[Thuma Fabric] економія памʼяті:", e)


def _mem_toggle(self, context):
    if self.thuma_mem_save:
        _mem_apply(self)
    else:
        _mem_restore(self)


def _add_cfr_hook():
    """Хук черги таблиць CFRender / ферми. 1.33.3: Blender очищає driver_namespace при відкритті файла —
    без повторного додавання черга рендерила стару тканину з іменами іншої таблиці."""
    hooks = bpy.app.driver_namespace.setdefault("cfrender_sheet_hooks", [])
    for h in [h for h in hooks if getattr(h, "__name__", "") == "_cfr_sheet_hook"]:
        hooks.remove(h)                                 # стара версія після перезавантаження аддона
    hooks.append(_cfr_sheet_hook)


@bpy.app.handlers.persistent
def _on_load(*_a):
    try:
        _add_cfr_hook()                                  # 1.33.3
    except Exception:
        pass
    try:
        _relink_missing_images()                         # 1.21.5
    except Exception:
        pass
    try:
        sc = bpy.context.scene
        if sc is not None and getattr(sc, "thuma_mem_save", False):
            _mem_apply(sc)
    except Exception:
        pass
    if not bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.register(_check_remote, first_interval=2.0)
    else:
        bpy.app.timers.register(lambda: (_check_remote(), None)[1], first_interval=2.0)


class THUMA_OT_wood_publish(bpy.types.Operator):
    bl_idname = "thuma.wood_publish"
    bl_label = "Дерево: опублікувати для команди"
    bl_description = ("Опублікувати ВСІ свої налаштування дерева (пульт WOOD LOOK, усі породи, торці, grain) на "
                      "командний сайт. У колег у панелі з'явиться «Застосувати налаштування Євгена»")
    out_dir: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})     # для тесту: без git
    no_push: bpy.props.BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    channel: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})    # "test" -> presets/test/ (колеги не бачать)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Опублікувати дерево для команди?",
                                                     message="Колеги зможуть застосувати твої налаштування дерева.")

    def execute(self, context):
        g = bpy.data.node_groups.get(_WOOD_GROUP)
        if g is None or not bpy.data.materials.get(WOOD_MAT):
            self.report({'WARNING'}, "У сцені нема дерева / пульта WOOD LOOK v2")
            return {'CANCELLED'}
        out = self.out_dir or _os.path.join(_OWNER_DIR, "presets", *([self.channel] if self.channel else []))
        _os.makedirs(out, exist_ok=True)
        data = _wood_export_dict()
        stamp = _time.strftime("%Y-%m-%d %H:%M:%S")
        egs = _eg_groups()                                  # 1.21.1: і торцеві групи (їхня будова теж мінялась)
        data.update({"stamp": stamp, "look_hash": _group_hash(g), "look_file": _WOOD_LOOK_FILE,
                     "min_addon": list(_WOOD_MIN_ADDON),
                     "eg_hashes": {e.name: _group_hash(e) for e in egs},
                     "eg_nodes": _eg_node_map(),
                     "source": _os.path.basename(bpy.data.filepath)})
        bpy.data.libraries.write(_os.path.join(out, _WOOD_LOOK_FILE), {g, *egs}, compress=True)
        with open(_os.path.join(out, _WOOD_JSON), "w", encoding="utf-8") as f:
            _json.dump(data, f, ensure_ascii=False, indent=1)
        if not self.channel:
            context.scene["thuma_wood_preset"] = stamp        # у себе — уже застосовано
        if self.no_push or self.out_dir:
            self.report({'INFO'}, f"Дерево збережено в {out} (без публікації)")
            return {'FINISHED'}
        import subprocess, shutil
        git = shutil.which("git") or r"C:\Program Files\Git\cmd\git.exe"
        def run(*a):
            r = subprocess.run([git, "-C", _OWNER_DIR, *a], capture_output=True, text=True, encoding="utf-8", errors="replace")
            return r.returncode, (r.stdout + r.stderr).strip()
        run("add", "presets")
        code, outp = run("commit", "-m", f"Thuma: дерево {stamp}")
        if code != 0 and "nothing to commit" not in outp:
            self.report({'ERROR'}, f"git commit: {outp[:200]}")
            return {'CANCELLED'}
        code, outp = run("push", "-u", "origin", "HEAD:main")
        if code != 0:
            self.report({'ERROR'}, f"git push: {outp[:200]}")
            return {'CANCELLED'}
        if not self.channel:
            _REMOTE["wood"] = data
        self.report({'INFO'}, f"Дерево опубліковано ({stamp}{', канал ' + self.channel if self.channel else ''}). У колег з'явиться за ~1 хв")
        return {'FINISHED'}


class THUMA_OT_wood_apply_remote(bpy.types.Operator):
    bl_idname = "thuma.wood_apply_remote"
    bl_label = "Застосувати налаштування Євгена (дерево)"
    bl_description = ("Завантажити й застосувати налаштування дерева Євгена: пульт WOOD LOOK, усі породи, торці, grain. "
                      "Твої тканини, сцена і вибрана порода не змінюються. Після — збережи файл")
    bl_options = {'REGISTER', 'UNDO'}
    src_dir: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})     # для тесту: локальна папка
    channel: bpy.props.StringProperty(default="", options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        try:
            if self.src_dir:
                data = _json.load(open(_os.path.join(self.src_dir, _WOOD_JSON), encoding="utf-8"))
            else:
                data = _fetch(_WOOD_JSON, channel=self.channel)
            if tuple(data.get("min_addon", (0,))) > ADDON_VERSION:
                self.report({'ERROR'}, "Спершу онови аддон: хаб -> «Оновити все», перезапусти Blender")
                return {'CANCELLED'}
            n_inst = 0
            eg_diff = _eg_differs(data)
            if data.get("look_hash") and (data["look_hash"] != _group_hash(bpy.data.node_groups.get(_WOOD_GROUP)) or eg_diff):
                if self.src_dir:
                    bp = _os.path.join(self.src_dir, data.get("look_file", _WOOD_LOOK_FILE))
                else:
                    bp = _os.path.join(_tf.gettempdir(), _WOOD_LOOK_FILE)
                    open(bp, "wb").write(_fetch(data.get("look_file", _WOOD_LOOK_FILE), binary=True, channel=self.channel))
                n_inst = _wood_apply_look(bp, data.get("eg_nodes"))
            ok, miss = _wood_apply_values(data)
            n_rel = _relink_missing_images()              # 1.21.5: текстури зі шляхом з чужого ПК
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Не вдалося: {e}")
            return {'CANCELLED'}
        if not self.channel:
            context.scene["thuma_wood_preset"] = data.get("stamp", "")
            _REMOTE["wood"] = data
        msg = f"Дерево Євгена ({data.get('stamp')}) застосовано: значень {ok}"
        if n_inst:
            msg += f", пульт оновлено ({n_inst} вузлів)"
        if n_rel:
            msg += f", текстур знайдено заново: {n_rel}"
        if miss:
            msg += f"; нема в цій сцені вузлів: {miss}"
        self.report({'WARNING'} if miss else {'INFO'}, msg)
        for a in (context.screen.areas if context.screen else []):
            a.tag_redraw()
        return {'FINISHED'}


_WSYNC = {"t": 0.0, "stamp": None, "diff": False}


def _eg_differs(data):
    """1.21.3: торцеві групи у перемикачі не такі, як опубліковані (порівняння за вузлом перемикача)."""
    hashes = data.get("eg_hashes", {})
    nodes = data.get("eg_nodes")
    if nodes:
        return any(_group_hash(_eg_local_by_node(nn)) != hashes.get(gn) for nn, gn in nodes.items())
    return any(_group_hash(bpy.data.node_groups.get(k)) != v for k, v in hashes.items())


def _wood_struct_diff(rem):
    """1.21.2: чи відрізняється БУДОВА пульта/торців від опублікованої (кеш на 5 с — хеш групи не безкоштовний)."""
    now = _time.time()
    if _WSYNC["stamp"] == rem.get("stamp") and now - _WSYNC["t"] < 5.0:
        return _WSYNC["diff"]
    diff = False
    try:
        lh = rem.get("look_hash")
        if lh and lh != _group_hash(bpy.data.node_groups.get(_WOOD_GROUP)):
            diff = True
        if _eg_differs(rem):
            diff = True
    except Exception:
        diff = False
    _WSYNC.update(t=now, stamp=rem.get("stamp"), diff=diff)
    return diff


def _draw_wood_sync(c, context):
    rem = _REMOTE.get("wood")
    mine = context.scene.get("thuma_wood_preset", "")
    if rem and tuple(rem.get("min_addon", (0,))) > ADDON_VERSION:
        bx = c.box(); bx.alert = True
        bx.label(text=f"Нове дерево ({rem.get('stamp')}) потребує новішого аддона", icon='ERROR')
        bx.label(text="Хаб -> «Оновити все», перезапусти Blender")
    elif rem and rem.get("stamp"):
        stale = mine != rem.get("stamp")
        struct = (not stale) and not _is_owner() and _wood_struct_diff(rem)
        if _is_owner():                               # 1.31.4: у Євгена сцена — еталон, не просимо оновлювати
            c.label(text=f"Дерево на сайті: {rem.get('stamp')}" + ("" if not stale else f" · у сцені: {mine or 'нема'}"),
                    icon='WORLD')
        elif stale or struct:
            bx = c.box()
            bx.alert = True
            if stale:
                bx.label(text=f"Нове дерево від Євгена: {rem.get('stamp')}", icon='INFO')
            else:
                bx.label(text="Дерево не збігається з версією Євгена (пульт/торці)", icon='ERROR')
            bx.label(text=f"У цій сцені: {mine or 'не застосовано'}")
            bx.label(text="Оновиться кнопкою «Оновити все» нагорі", icon='INFO')   # 1.31.2
        else:
            c.label(text=f"Дерево: версія {mine} — актуальна", icon='CHECKMARK')
    elif mine:
        c.label(text=f"Дерево: версія {mine}", icon='INFO')
    if _is_owner():
        c.operator("thuma.wood_publish", text="Дерево: опублікувати для команди", icon='WORLD')


# 1.21.14: затверджені клієнтом зміни геометрії (2026-10-14) — м'яка частина модулів вище.
# Ставимо абсолютний Z лише об'єктам на СТАРІЙ висоті; нестандартні не чіпаємо. Кнопка зникає, коли все застосовано.
# Нова затверджена зміна -> додати рядок у _GEO_FIX (old_z, new_z) і опублікувати аддон.
_GEO_FIX = {      # prefix: (old_z, new_z, назва в звіті, підйом)
    "Thuma_Essential-Sectional_Armless_05": (0.39478, 0.396554, "Armless", '+0.07"'),
    "Thuma_Essential-Sectional_Right-Arm-Island_05": (0.394751, 0.395767, "Right Arm Island", '+0.04"'),
    "Thuma_Essential-Sectional_Left-Arm-Island_05": (0.394751, 0.395767, "Left Arm Island", '+0.04"'),
    # 1.25.0 (2026-10-14, Євген): м'яка частина оттоманки вище на 0.1"
    "Thuma_Essential-Sectional_Ottoman_05": (0.250445, 0.252985, "Ottoman", '+0.1"'),
}
_GEO_TOL = 2e-5
_GEO_CACHE = {"t": 0.0, "n": 0, "file": None, "geo": 0, "uv": []}
_GEO_DONE = {}          # filepath -> рядки звіту після застосування (поки не натиснуть «Зрозуміло»)

# 1.24.0: затверджений поворот UV передка внутрішньої боковини по шву (2026-10-14, Євген): Right Arm Chaise +5°,
# Left Arm Chaise −4°. Меш модуля спільний для всіх конфігурацій -> правимо меш один раз. Застосовуємо лише якщо UV
# цих петель РІВНО як були (контрольна сума «old») — змінені колегою вручну не чіпаємо; «new» = вже застосовано.
_UV_FIX = {      # префікс об'єкта: петлі UV (діапазони [початок, кількість]), афінне old->new, контрольні суми
    "Thuma_Essential-Sectional_Right-Arm-Chaise_05": {"key": "R", "title": "Right Arm Chaise", "what": "+5°", "polys": 62636,
        "M": [[0.99619473, -0.08715575], [0.08715573, 0.996194724], [-0.018721501, 0.039170597]], "old": [5221.6494, 2776.4418], "new": [5222.6989, 2773.3063],
        "ranges": [[416, 16], [512, 384], [944, 80], [12816, 256], [13904, 16], [16656, 256], [18784, 48], [24436, 32], [24596, 256], [25364, 256], [26212, 48], [26388, 96], [26516, 128], [40728, 16], [40904, 16], [41272, 32], [41400, 16], [41944, 256], [42456, 176], [42680, 32], [43480, 256], [44248, 512], [55048, 32], [55096, 16], [57376, 48], [59968, 32], [60016, 16], [60768, 32], [63568, 16], [63600, 16], [66196, 16], [66276, 16], [66452, 16], [66676, 16], [67652, 16], [82796, 32], [90100, 16], [96676, 16], [112568, 16], [114324, 16], [116636, 16], [119244, 256], [130252, 512], [137932, 512], [142380, 32], [143052, 512], [146700, 16], [146860, 16], [149900, 16], [150220, 512], [151996, 112], [152124, 16], [152172, 80], [157084, 16], [183100, 16], [183548, 16], [187644, 16], [187788, 32], [195884, 16], [195916, 16], [197884, 16], [198044, 16], [204988, 160], [205212, 32], [205408, 16], [205568, 16], [205760, 64], [205840, 128], [209024, 16], [212164, 64], [212292, 80], [212420, 64], [212500, 128], [212932, 64], [213012, 144], [213444, 224], [215748, 704], [220152, 16], [224792, 512], [227864, 512], [228888, 112], [229064, 80], [229912, 16], [231064, 128], [231320, 64], [232648, 64], [232840, 64], [232984, 48], [233096, 112], [233240, 16], [233272, 16], [233400, 16], [233528, 16], [233768, 32], [233864, 32], [233928, 16], [233960, 16], [234008, 32], [234104, 16], [234268, 16], [234316, 32], [234364, 16], [234444, 16], [234476, 16], [234508, 16], [234652, 16], [234768, 16], [237668, 64], [237796, 16], [237988, 64], [239236, 192], [239700, 48], [239812, 64], [240228, 16], [240436, 16], [240612, 16], [240644, 16], [240932, 16], [240964, 16], [241092, 16], [241152, 16], [241216, 48], [241296, 16], [241344, 32], [241440, 64], [241520, 32], [241568, 48], [241632, 32], [241680, 16], [241712, 16], [241776, 16], [241824, 16], [241968, 48], [242032, 16], [242064, 16], [242144, 16], [242176, 16], [242208, 16], [242240, 16], [242304, 16], [242384, 16], [244712, 240], [245224, 64], [245400, 48], [245912, 16], [245976, 16], [246056, 16]]},
    "Thuma_Essential-Sectional_Left-Arm-Chaise_05": {"key": "L", "title": "Left Arm Chaise", "what": "−4°", "polys": 62636,
        "M": [[0.997564081, 0.069756474], [-0.069756466, 0.997564079], [0.005236593, -0.041917308]], "old": [7082.4281, 651.4528], "new": [7081.5666, 648.9516],
        "ranges": [[416, 16], [512, 384], [944, 80], [12816, 256], [13904, 16], [16656, 256], [18784, 48], [24436, 32], [24596, 256], [25364, 256], [26212, 48], [26388, 96], [26516, 128], [40728, 16], [40904, 16], [41272, 32], [41400, 16], [41944, 256], [42456, 176], [42680, 32], [43480, 256], [44248, 512], [55048, 32], [55096, 16], [57376, 48], [59968, 32], [60016, 16], [60768, 32], [63568, 16], [63600, 16], [66196, 16], [66276, 16], [66452, 16], [66676, 16], [67652, 16], [82796, 32], [90100, 16], [96676, 16], [112568, 16], [114324, 16], [116636, 16], [119244, 256], [130252, 512], [137932, 512], [142380, 32], [143052, 512], [146700, 16], [146860, 16], [149900, 16], [150220, 512], [151996, 112], [152124, 16], [152172, 80], [157084, 16], [183100, 16], [183548, 16], [187644, 16], [187788, 32], [195884, 16], [195916, 16], [197884, 16], [198044, 16], [204988, 160], [205212, 32], [205408, 16], [205568, 16], [205760, 64], [205840, 128], [209024, 16], [212164, 64], [212292, 80], [212420, 64], [212500, 128], [212932, 64], [213012, 144], [213444, 224], [215748, 704], [220152, 16], [224792, 512], [227864, 512], [228888, 112], [229064, 80], [229912, 16], [231064, 128], [231320, 64], [232648, 64], [232840, 64], [232984, 48], [233096, 112], [233240, 16], [233272, 16], [233400, 16], [233528, 16], [233768, 32], [233864, 32], [233928, 16], [233960, 16], [234008, 32], [234104, 16], [234268, 16], [234316, 32], [234364, 16], [234444, 16], [234476, 16], [234508, 16], [234652, 16], [234768, 16], [237668, 64], [237796, 16], [237988, 64], [239236, 192], [239700, 48], [239812, 64], [240228, 16], [240436, 16], [240612, 16], [240644, 16], [240932, 16], [240964, 16], [241092, 16], [241152, 16], [241216, 48], [241296, 16], [241344, 32], [241440, 64], [241520, 32], [241568, 48], [241632, 32], [241680, 16], [241712, 16], [241776, 16], [241824, 16], [241968, 48], [242032, 16], [242064, 16], [242144, 16], [242176, 16], [242208, 16], [242240, 16], [242304, 16], [242384, 16], [244712, 240], [245224, 64], [245400, 48], [245912, 16], [245976, 16], [246056, 16]]},
}
_UV_TOL = 0.01
# 1.26.0: самі UV Євгена для цих петель (float32) — ставимо ЗАВЖДИ, якщо в сцені не вони (не лише зі старого стану)
_UV_DATA = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "thuma_fabric_uv_2026-10-14.npz")


# 1.30.0: ЗАГАЛЬНИЙ пакет правок мешів від Євгена (UV будь-яких петель + «Свої шви») — збирає скрипт
# Sectional_Configs\pack_meshfix.py порівнянням з базовою сценою. json: {ІМ'Я МЕША: {"polys", "uv": ключ|null,
# "uv_idx": ключ індексів петель, "cseams": [{"name","bright","width","enabled","edges": ключ}]}}; масиви — у npz.
_MF_JSON = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "thuma_fabric_meshfix.json")
_MF_NPZ = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "thuma_fabric_meshfix.npz")
_MF = {"t": None, "spec": None}


def _mf_spec():
    import json
    if not (_os.path.exists(_MF_JSON) and _os.path.exists(_MF_NPZ)):
        return {}
    t = _os.path.getmtime(_MF_JSON)
    if _MF["t"] != t:
        try:
            _MF["spec"] = json.load(open(_MF_JSON, encoding="utf-8"))
        except Exception:
            _MF["spec"] = {}
        _MF["t"] = t
    return _MF["spec"] or {}


def _mf_state(me, sp, d):
    """True — меш уже як у Євгена (UV і свої шви)."""
    import numpy as np
    if len(me.polygons) != sp["polys"] or me.is_editmode or "UVMap" not in me.attributes:
        return True                                   # інша модель / Edit Mode — не чіпаємо
    if sp.get("uv"):
        a = np.empty(len(me.loops) * 2, np.float32); me.attributes["UVMap"].data.foreach_get("vector", a)
        if np.abs(a.reshape(-1, 2)[d[sp["uv_idx"]]] - d[sp["uv"]]).max() > 1e-5:
            return False
    if "cseams" not in sp:                            # 1.33.6: пакет лише UV — шви колеги не чіпаємо
        return True
    want = sp.get("cseams", [])
    have = list(me.thuma_cseams)
    if {h.name for h in have} - {w["name"] for w in want}:
        return True                                   # 1.31.3: у колеги свої шви на цьому меші — не перезаписуємо
    if len(want) != len(have):
        return False
    for w, h in zip(want, have):
        if (w["name"], round(w["bright"], 4), round(w["width"], 4), w["enabled"]) != \
                (h.name, round(h.bright, 4), round(h.width, 4), h.enabled):
            return False
        at = me.attributes.get(f"tc_cs{h.uid}")
        if at is None or len(at.data) != len(me.edges):
            return False
        fl = np.zeros(len(me.edges), np.int32); at.data.foreach_get("value", fl)
        if not np.array_equal(np.nonzero(fl)[0], d[w["edges"]]):
            return False
    return True


def _mf_todo():
    """[(меш, ключ, к-сть об'єктів)] — меші (за ІМЕНЕМ меша), де UV/свої шви ще не як у Євгена."""
    import numpy as np
    spec = _mf_spec()                                 # 1.33.6: без позначок версії — лише реальна перевірка мешів
    if not spec:
        return []
    out = []
    with np.load(_MF_NPZ) as d:
        for name, sp in spec.items():
            me = bpy.data.meshes.get(name)
            if (me is None or not me.users) and sp.get("base"):
                objs = _mf_split_objs(sp)             # 1.33.6: копії меша під одну конфігурацію («Ім'я [об'єкт]»)
                if objs:
                    out.append((objs[0].data, name, len(objs)))
                continue
            if me is None or not me.users:
                continue
            if not _mf_state(me, sp, d):
                out.append((me, name, sum(1 for o in bpy.data.objects if o.data == me)))
    return out


def _mf_split_objs(sp):
    """Об'єкти, яким ще треба окрему копію меша: стоять на спільному меші sp["base"] з тією ж кількістю полігонів."""
    b = bpy.data.meshes.get(sp["base"])
    if b is None or len(b.polygons) != sp["polys"] or b.is_editmode:
        return []
    return [o for o in (bpy.data.objects.get(n) for n in sp.get("objs", [])) if o is not None and o.data == b]


def _mf_apply(me, pfx):
    import numpy as np
    sp = _mf_spec()[pfx]
    if me.name != pfx and sp.get("base"):             # 1.33.6: окрема копія для своїх конфігурацій
        objs = _mf_split_objs(sp)
        if not objs:
            return
        me = me.copy(); me.name = pfx
        for o in objs:
            o.data = me
    with np.load(_MF_NPZ) as d:
        if sp.get("uv"):
            a = np.empty(len(me.loops) * 2, np.float32); me.attributes["UVMap"].data.foreach_get("vector", a)
            a = a.reshape(-1, 2); a[d[sp["uv_idx"]]] = d[sp["uv"]]
            me.attributes["UVMap"].data.foreach_set("vector", a.ravel())
        if "cseams" not in sp:                        # 1.33.6: пакет лише UV
            me.update()
            return me
        for s in list(me.thuma_cseams):
            at = me.attributes.get(f"tc_cs{s.uid}")
            if at is not None:
                me.attributes.remove(at)
        me.thuma_cseams.clear()
        for i, w in enumerate(sp.get("cseams", []), 1):
            s = me.thuma_cseams.add(); s.uid = i
            _CS_SYNC[0] = True
            try:
                s.link = w.get("link", ""); s.name = w["name"]
            finally:
                _CS_SYNC[0] = False
            fl = np.zeros(len(me.edges), np.int32); fl[d[w["edges"]]] = 1
            at = me.attributes.new(f"tc_cs{i}", 'INT', 'EDGE'); at.data.foreach_set("value", fl)
            _CS_SYNC[0] = True
            try:
                s.bright, s.width, s.enabled = w["bright"], w["width"], w["enabled"]
            finally:
                _CS_SYNC[0] = False
    _cs_rebuild(me)
    me.update()
    return me


def _uv_loops(fx):
    import numpy as np
    return np.concatenate([np.arange(a, a + n) for a, n in fx["ranges"]])


def _uv_state(me, fx):
    """'OLD' — як до правки, 'NEW' — уже повернуто, None — інше (не чіпаємо)."""
    import numpy as np
    if len(me.polygons) != fx["polys"] or "UVMap" not in me.attributes or me.is_editmode:
        return None
    a = np.empty(len(me.loops) * 2, np.float32)
    me.attributes["UVMap"].data.foreach_get("vector", a)
    sel = a.reshape(-1, 2)[_uv_loops(fx)].astype(np.float64)
    sx, sy = sel[:, 0].sum(), sel[:, 1].sum()
    for st in ("old", "new"):
        if abs(sx - fx[st][0]) < _UV_TOL and abs(sy - fx[st][1]) < _UV_TOL:
            return st.upper()
    return None


def _uv_fix_todo():
    """[(меш, префікс, к-сть об'єктів)] — меші, у яких UV ще старі."""
    out = {}                                          # 1.33.6: без позначок — лише якщо UV справді ще старі
    for o in bpy.data.objects:
        if o.type != 'MESH':
            continue
        for pfx, fx in _UV_FIX.items():
            if o.name.startswith(pfx):
                k = (o.data.name, pfx)
                if k not in out:
                    ok = (len(o.data.polygons) == fx["polys"] and not o.data.is_editmode
                          and _os.path.exists(_UV_DATA))
                    out[k] = [o.data, pfx, 0, ok and _uv_state(o.data, fx) == 'OLD']
                out[k][2] += 1
    return [(me, pfx, n) for me, pfx, n, todo in out.values() if todo]


def _uv_fix_apply(me, fx):
    import numpy as np
    a = np.empty(len(me.loops) * 2, np.float32)
    me.attributes["UVMap"].data.foreach_get("vector", a)
    a = a.reshape(-1, 2)
    idx = _uv_loops(fx)
    with np.load(_UV_DATA) as d:
        a[idx] = d[fx["key"]]
    me.attributes["UVMap"].data.foreach_set("vector", a.ravel())
    me.update()


def _geo_fix_todo():
    out = []                                          # 1.33.6: лише модулі РІВНО на старій висоті; свою висоту колеги не чіпаємо
    for o in bpy.data.objects:
        for p, v in _GEO_FIX.items():
            if o.name.startswith(p) and abs(o.location.z - v[0]) <= _GEO_TOL:
                out.append((o, p))
    return out


def _frames_str(fs):
    """[1,2,3,8] -> «1–3, 8»."""
    fs, out = sorted(set(fs)), []
    for f in fs:
        if out and f == out[-1][1] + 1:
            out[-1][1] = f
        else:
            out.append([f, f])
    return ", ".join(str(a) if a == b else f"{a}–{b}" for a, b in out)


def _frames_list(objs):
    """1.30.2: на яких кадрах ці об'єкти. Колекція «NN_..» = NN-й маркер сцени (36 колекцій = 36 маркерів по порядку);
    кадри маркера — від нього до наступного маркера − 1 (останній — лише свій кадр)."""
    mk = sorted(m.frame for m in bpy.context.scene.timeline_markers)
    fs = set()
    for o in objs:
        for c in o.users_collection:
            m = _re.match(r"^(\d+)_", c.name)
            if m and 1 <= int(m.group(1)) <= len(mk):
                i = int(m.group(1)) - 1
                fs.update(range(mk[i], (mk[i + 1] if i + 1 < len(mk) else mk[i] + 1)))
    return fs


def _frames_of(objs):
    fs = _frames_list(objs)
    return _frames_str(fs) if fs else "—"


def _mesh_objs(me):
    return [o for o in bpy.data.objects if o.data == me]


def _mesh_frames(me):
    return _frames_of(_mesh_objs(me))


# 1.30.5: правка клієнта 15.10 — прибрати вузол Bevel у матеріалах ДЕРЕВА (шипи з'єднань виглядали скошеними).
# Нормаль, що йшла в Bevel (Normal Map / Bump), підключаємо далі напряму — рельєф текстури лишається.
_WOOD_TREES = ("Thuma_Finger-Joint-Wood", "Thuma_End-Grain", "Thuma_Wood", "Chair_GRAIN")


def _wood_bevel_todo():
    trees = [g for g in bpy.data.node_groups if g.bl_idname == 'ShaderNodeTree' and g.name.startswith(_WOOD_TREES)]
    trees += [m.node_tree for m in bpy.data.materials if m.node_tree and m.name.startswith(_WOOD_TREES)]
    return [(t, n) for t in trees for n in t.nodes if n.type == 'BEVEL']


def _wood_bevel_apply():
    done = 0
    for t, n in _wood_bevel_todo():
        src = n.inputs["Normal"].links[0].from_socket if n.inputs["Normal"].is_linked else None
        for to in [l.to_socket for l in n.outputs[0].links]:
            if src is not None:
                t.links.new(src, to)
            else:
                for l in list(to.links):
                    t.links.remove(l)
        t.nodes.remove(n)
        done += 1
    return done


# 1.31.0: дерево Євгена 15.10 — фаска знизу (без відблиску підлоги), «Загальне: уся деревина», тон/заливка в усіх
# групах дерева, атрибут fz_hb на основах. Сам код — fl/wood_patch_2026_10_15.py (ідемпотентний, нейтральний:
# картинка не змінюється, доки не застосовано «налаштування Євгена (дерево)»).
_PKG = _os.path.dirname(_os.path.abspath(__file__))
_WP = {"mod": None}


def _wood_patch():
    if _WP["mod"] is None:
        import importlib.util
        p = _os.path.join(_PKG, "fl", "wood_patch_2026_10_15.py")
        if not _os.path.exists(p):
            p = _os.path.join(_PKG, "..", "Sectional_Configs", "wood_look", "wood_patch_2026_10_15.py")   # dev-копія
        spec = importlib.util.spec_from_file_location("thuma_wood_patch", p)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        _WP["mod"] = m
    return _WP["mod"]


def _wood_patch_todo():
    try:
        return _wood_patch().todo()
    except Exception as e:
        print("[Thuma Fabric] wood patch:", e)
        return []


# 1.31.0: правка клієнта 15.10 — фетр (Felt_Black) замість корка на підкладках ніжок. Копія 1K з аддона
# (thuma_felt_1k.blend, текстури запаковані; 4K клієнта — надто важкий для аддона). Корок лишається у файлі (fake user).
_FELT = "Felt_Black_01_4K"
_CORK = "Thuma_Cork_4K"
_FELT_LIB = _os.path.join(_PKG, "thuma_felt_1k.blend")


def _felt_todo():
    cork = bpy.data.materials.get(_CORK)
    if cork is None or (bpy.data.materials.get(_FELT) is None and not _os.path.exists(_FELT_LIB)):
        return []
    return [o for o in bpy.data.objects if any(s.material == cork for s in o.material_slots)]


def _felt_apply():
    objs = _felt_todo()
    if not objs:
        return 0, []
    felt = bpy.data.materials.get(_FELT)
    if felt is None:
        with bpy.data.libraries.load(_FELT_LIB, link=False) as (src, dst):
            dst.materials = [_FELT]
        felt = dst.materials[0]
    cork = bpy.data.materials[_CORK]
    for o in objs:
        for s in o.material_slots:
            if s.material == cork:
                s.material = felt
    cork.use_fake_user = True
    return len(objs), objs


# 1.33.8: кадри 94–97 (крісло, дивани) — підкладка під ніжками не окремий об'єкт, а низ меша ніжок. Євген призначив
# цим граням слот фетру; у колег — ті самі меші (89088 полігонів, той самий порядок). Ставимо фетр лише на грані
# підкладки, де його ще нема; інших граней не чіпаємо.
_PAD_MESHES = ("Thuma_Essential-Armchair_03", "Thuma_Essential-Sofa_72in_03",
               "Thuma_Essential-Sofa_84in_04", "Thuma_Essential-Sofa_96in_04")
_PAD_NPZ = _os.path.join(_PKG, "thuma_fabric_feltpads.npz")
_PAD = {"idx": None}


def _pad_idx():
    import numpy as np
    if _PAD["idx"] is None:
        with np.load(_PAD_NPZ) as d:
            _PAD["idx"] = (d["idx"].copy(), int(d["polys"][0]))
    return _PAD["idx"]


def _pad_todo():
    """[(меш, індекс слота фетру)] — меші ніжок, де частина граней підкладки ще не фетр."""
    import numpy as np
    if not _os.path.exists(_PAD_NPZ):
        return []
    idx, polys = _pad_idx()
    out = []
    for name in _PAD_MESHES:
        me = bpy.data.meshes.get(name)
        if me is None or not me.users or me.is_editmode or len(me.polygons) != polys:
            continue
        k = next((i for i, m in enumerate(me.materials) if m and m.name in (_FELT, _CORK)), None)
        if k is None:
            continue
        mi = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("material_index", mi)
        if (mi[idx] != k).any():
            out.append((me, k))
    return out


def _pad_apply():
    import numpy as np
    idx, _p = _pad_idx() if _os.path.exists(_PAD_NPZ) else (None, 0)
    done = []
    for me, k in _pad_todo():
        mi = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("material_index", mi)
        mi[idx] = k
        me.polygons.foreach_set("material_index", mi); me.update()
        done.append(me)
    return done


# 1.31.0: текстури дерева, перемальовані Євгеном (15.10). Файли — на командному сайті (presets/tex), не в аддоні
# (8–17 МБ кожен). Качаємо лише перелічені у //textures поруч зі сценою і перепривʼязуємо картинку.
_TEX_V2 = {     # стара назва файлу -> нова
    "thuma_finger-joint-wood_basecolor_espresso_4k.png": "thuma_finger-joint-wood_basecolor_espresso_4k_v2.png",
    "260423_thuma_finger-joint-wood_basecolor_natural_4k.png": "260423_thuma_finger-joint-wood_basecolor_natural_4k_v2.png",
}


def _tex_todo():
    out = []
    for im in bpy.data.images:
        if im.source != 'FILE' or im.library:
            continue
        keys = {im.name.lower(), _os.path.basename(im.filepath.replace("\\", "/")).lower()}
        k = next((k for k in keys if k in _TEX_V2), None)
        if k and _os.path.basename(im.filepath.replace("\\", "/")).lower() != _TEX_V2[k].lower():
            out.append((im, _TEX_V2[k]))
    return out


def _tex_apply():
    todo = _tex_todo()
    if not todo:
        return [], ""
    if not bpy.data.filepath:
        return [], "сцена не збережена — текстури нікуди класти"
    root = _os.path.join(_os.path.dirname(bpy.data.filepath), "textures")
    _os.makedirs(root, exist_ok=True)
    done, err = [], ""
    for im, new in todo:
        dst = _os.path.join(root, new)
        try:
            if not _os.path.exists(dst):
                b = _fetch("tex/" + new, binary=True)
                with open(dst + ".part", "wb") as f:
                    f.write(b)
                _os.replace(dst + ".part", dst)
            im.filepath = "//textures/" + new
            im.name = new
            im.reload()
            done.append(new)
        except Exception as e:
            err = f"{new}: {e}"[:160]
    return done, err


# 1.31.6: правки моделі (висота, UV, «Свої шви» Євгена) — ОДИН раз. Після «Оновити все» у сцені позначка версії;
# далі колега крутить свої повзунки/висоту — банер НЕ просить оновитись і не перезаписує. Нова правка геометрії/UV/швів
# у майбутньому -> підняти _FIXES_VER до версії аддона з нею.
_FIXES_VER = (1, 31, 1)
_FIXES_KEY = "thuma_fixes_ver"


def _fixes_done():
    sc = bpy.context.scene
    if sc is None:
        return False
    v = sc.get(_FIXES_KEY)
    if v is not None:
        return tuple(v) >= _FIXES_VER
    try:                                         # сцени, оновлені 1.31.1–1.31.5 (позначки ще не було)
        return (_scene_fl_version() or 0) >= 70 and bool(sc.get("thuma_wood_preset"))
    except Exception:
        return False


def _mark_fixes_done():
    for sc in bpy.data.scenes:
        sc[_FIXES_KEY] = list(ADDON_VERSION)


def _geo_fix_count():
    now = _time.time()
    if _GEO_CACHE["file"] == bpy.data.filepath and now - _GEO_CACHE["t"] < 3.0:
        return _GEO_CACHE["n"]
    try:
        wb = len(_wood_bevel_todo())             # 1.30.5
    except Exception:
        wb = 0
    try:
        n = len(_geo_fix_todo())
    except Exception:
        n = 0
    try:
        uv = _uv_fix_todo()                      # 1.24.0
    except Exception:
        uv = []
    try:
        mf = _mf_todo()                          # 1.30.0
    except Exception as e:
        print("[Thuma Fabric] meshfix:", e)
        mf = []
    wp = 1 if _wood_patch_todo() else 0          # 1.31.0
    try:
        felt = _felt_todo()
    except Exception:
        felt = []
    try:
        pads = _pad_todo()                       # 1.33.8
    except Exception as e:
        print("[Thuma Fabric] pads:", e)
        pads = []
    try:
        tex = [n for _im, n in _tex_todo()]
    except Exception:
        tex = []
    ext = wp + (1 if felt else 0) + len(tex) + (1 if pads else 0)
    fr, fr_all = {}, ""                          # 1.30.2: кадри для кожного рядка панелі + усі разом
    if n or uv or mf:
        try:
            groups = {}
            for o, p_ in _geo_fix_todo():
                groups.setdefault(p_, []).append(o)
            for me, pfx, cnt in uv:
                groups[me.name] = _mesh_objs(me)
            spec = _mf_spec()
            for me, pfx, cnt in mf:                  # 1.33.7: копія під конфігурацію — лише її кадри
                sp = spec.get(pfx, {})
                groups[pfx] = _mf_split_objs(sp) if me.name != pfx and sp.get("base") else _mesh_objs(me)
            sets = {k: _frames_list(v) for k, v in groups.items()}
            fr = {k: (_frames_str(s) if s else "—") for k, s in sets.items()}
            fr_all = _frames_str(set().union(*sets.values())) if sets else ""
        except Exception as e:
            print("[Thuma Fabric] frames:", e)
    if felt:
        try:
            fr["felt"] = _frames_of(felt)
        except Exception:
            pass
    tot = n + len(uv) + len(mf) + wb + ext
    _GEO_CACHE.update(t=now, n=tot, file=bpy.data.filepath, geo=n, uv=uv, mf=mf,
                      fr=fr, fr_all=fr_all, wb=wb, wp=wp, felt=len(felt), tex=tex, pads=len(pads))
    return tot


def _next_version_path(path):
    """…_v90.blend -> …_v91.blend (зберігає кількість цифр); без _vNN -> …_geo-2026-10-14.blend; ніколи не перезаписує."""
    d, f = _os.path.split(path)
    m = _re.match(r"^(.*_v)(\d+)(\.blend)$", f, _re.I)
    if m:
        n, w = int(m.group(2)), len(m.group(2))
        while True:
            n += 1
            cand = _os.path.join(d, f"{m.group(1)}{n:0{w}d}{m.group(3)}")
            if not _os.path.exists(cand):
                return cand
    stem = f[:-6] if f.lower().endswith(".blend") else f
    cand, k = _os.path.join(d, f"{stem}_geo-2026-10-14.blend"), 2
    while _os.path.exists(cand):
        cand = _os.path.join(d, f"{stem}_geo-2026-10-14_{k}.blend"); k += 1
    return cand


class THUMA_OT_geo_fix(bpy.types.Operator):
    bl_idname = "thuma.geo_fix"
    bl_label = "Застосувати затверджений підйом модулів"
    bl_description = ("Затверджено 14.10: м'яка частина вище — Armless на 0.07\", Right/Left Arm Island на 0.04\", "
                      "Ottoman на 0.1\"; "
                      "поворот UV передка внутрішньої боковини по шву — Right Arm Chaise +5°, Left Arm Chaise −4°; "
                      "15.10: повороти UV торців спинки (Corner, Armless, Island, Right Arm Chaise) і «Свої шви» Євгена — "
                      "у ВСІХ конфігураціях. 15.10 (1.31.0): фетр замість корка під ніжками, нові текстури дерева "
                      "Espresso/Natural (з сайту), будова пульта дерева (фаска знизу, «Загальне»). "
                      "Ставить саме значення Євгена, яка б висота/UV не були. Сцена одразу зберігається НОВОЮ версією (_vNN+1), "
                      "старий файл лишається як був")
    bl_options = {'REGISTER'}

    def execute(self, context):
        lines = _apply_model_fixes(context)
        old = bpy.data.filepath
        if old:
            new = _next_version_path(old)
            bpy.ops.wm.save_as_mainfile(filepath=new, compress=True)   # 1.30.2: стиснено (без — ~940 МБ замість ~190)
            lines.append(f"Збережено як: {_os.path.basename(new)}")
            lines.append(f"Старий файл без змін: {_os.path.basename(old)}")
        else:
            lines.append("Сцена ще не збережена — збережіть її вручну")
        _GEO_DONE[bpy.data.filepath] = lines
        _GEO_CACHE["t"] = 0.0
        self.report({'INFO'}, " | ".join(lines))
        return {'FINISHED'}


def _apply_model_fixes(context):
    """1.31.1: усі правки «Оновлення моделі» без збереження (спільне для geo_fix і «Оновити все»)."""
    if True:
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        cnt, objs = {}, {}
        for o, p in _geo_fix_todo():
            o.location.z = _GEO_FIX[p][1]
            cnt[p] = cnt.get(p, 0) + 1
            objs.setdefault(p, []).append(o)
        uv_lines = []
        for me, pfx, n in _uv_fix_todo():             # 1.24.0: поворот UV (меш спільний — один раз на всі конфігурації)
            _uv_fix_apply(me, _UV_FIX[pfx])
            uv_lines.append(f"UV {_UV_FIX[pfx]['title']} {_UV_FIX[pfx]['what']}: {n} конфігурацій, "
                            f"кадри {_mesh_frames(me)}")
        for me, pfx, n in _mf_todo():                 # 1.30.0: UV (1.33.6: лише UV) від Євгена
            me = _mf_apply(me, pfx) or me
            uv_lines.append(f"Правки {pfx.replace('Thuma_Essential-', '').split(' [')[0]}: {n} конф., "
                            f"кадри {_mesh_frames(me)}")
        wb = _wood_bevel_apply()                      # 1.30.5: правка клієнта — без Bevel у дереві
        if wb:
            uv_lines.append(f"Дерево: прибрано {wb} вузлів Bevel, усі кадри з деревом")
        if _wood_patch_todo():                        # 1.31.0
            _wood_patch().apply()
            uv_lines.append("Дерево: фаска знизу і «Загальне: уся деревина» додано (вигляд — після налаштувань Євгена)")
        nf, fobjs = _felt_apply()
        pads = _pad_apply()                           # 1.33.8: після фетру (корок -> фетр спершу)
        if pads:
            uv_lines.append(f"Фетр на підкладках ніжок: {len(pads)} моделей, кадри 94–97")
        if nf:
            uv_lines.append(f"Фетр замість корка: {nf} об'єктів, кадри {_frames_of(fobjs)}")
        tex, terr = _tex_apply()
        if tex:
            uv_lines.append(f"Нові текстури дерева: {', '.join(tex)}")
        if terr:
            uv_lines.append(f"Текстури НЕ завантажено ({terr}) — перевір інтернет і натисни ще раз")
        _mark_fixes_done()                            # 1.31.6
        sc = context.scene
        sc.frame_set(sc.frame_current)
        _GEO_CACHE["t"] = 0.0
        return [f"{_GEO_FIX[p][2]}: {n} об'єктів {_GEO_FIX[p][3]}, кадри {_frames_of(objs[p])}"
                for p, n in cnt.items()] + uv_lines


# 1.31.1: ОДНА кнопка «Оновити все» замість трьох кроків по інструкції (колеги кілька разів робили не в тому
# порядку / пропускали крок -> дерево чи правки не доходили). Порядок фіксований: пульт FABRIC LOOK -> правки моделі
# -> дерево Євгена -> перевірка -> одне збереження НОВОЮ версією. Старий файл не чіпаємо ніколи.
def _sync_status():
    """[(ключ, текст)] — чого бракує сцені до стану Євгена. Порожньо = актуально. ('?', …) = не вдалося перевірити."""
    out = []
    try:
        cur = _scene_fl_version()
        if cur is not None and _FL_VER and cur < _FL_VER:
            out.append(("fl", f"пульт тканини: збірка {cur} → {_FL_VER}"))
    except Exception:
        pass
    try:
        if _geo_fix_count() > 0:
            out.append(("geo", "правки моделі (геометрія, UV, фетр, текстури, дерево)"))
    except Exception:
        pass
    if bpy.data.materials.get(WOOD_MAT) and not _is_owner():
        rem = _REMOTE.get("wood")
        mine = bpy.context.scene.get("thuma_wood_preset", "") if bpy.context.scene else ""
        if rem and rem.get("stamp"):
            if tuple(rem.get("min_addon", (0,))) > ADDON_VERSION:
                out.append(("addon", "потрібен новіший аддон: хаб → «Оновити все», перезапуск Blender"))
            elif mine != rem.get("stamp") or _wood_struct_diff(rem):
                out.append(("wood", f"дерево Євгена {rem.get('stamp')} (у сцені: {mine or 'нема'})"))
        elif _REMOTE.get("error"):
            out.append(("?", "не вдалося перевірити дерево на сайті (інтернет?)"))
    return out


_SYNC_DONE = {}     # filepath -> (ok, рядки звіту)


def _draw_sync_banner(c, context):
    """1.31.1: на самому верху панелі — або зелений «актуально», або червоне «Оновити все»."""
    rep = _SYNC_DONE.get(bpy.data.filepath)
    st = _sync_status()
    todo = [t for k, t in st if k not in ("?",)]
    if todo:
        bx = c.box()
        bx.alert = True
        bx.label(text="Сцена НЕ оновлена до версії Євгена:", icon='ERROR')
        for t in todo:
            bx.label(text="• " + t)
        if any(k == "addon" for k, _t in st):
            return
        r = bx.row()
        r.scale_y = 1.8
        r.operator("thuma.update_all", text="Оновити все (один клік)", icon='FILE_REFRESH')
        bx.label(text="Збереже НОВУ версію файлу, старий лишиться", icon='FILE_TICK')
    else:
        r = c.row()
        r.label(text=f"Сцена актуальна (аддон {'.'.join(map(str, ADDON_VERSION))}, пульт {_FL_VER})", icon='CHECKMARK')
        if any(k == "?" for k, _t in st):
            c.label(text="Дерево не перевірено — нема зв'язку з сайтом", icon='QUESTION')
    if rep:
        bx = c.box()
        ok, lines = rep
        bx.label(text="Оновлення виконано:" if ok else "Оновлення: НЕ все вдалося", icon='CHECKMARK' if ok else 'ERROR')
        for t in lines:
            bx.label(text=t[:70])
        bx.operator("thuma.update_all_ok", text="Зрозуміло", icon='HIDE_ON')


class THUMA_OT_update_all(bpy.types.Operator):
    bl_idname = "thuma.update_all"
    bl_label = "Оновити все"
    bl_description = ("Одним кліком у правильному порядку: пульт тканини (FABRIC LOOK) → правки моделі (геометрія, UV, "
                      "шви, фетр, нові текстури) → налаштування дерева Євгена → перевірка. Потім сцена зберігається "
                      "НОВОЮ версією (_vNN+1), старий файл не змінюється. Займає 1-2 хв, Blender не відповідатиме")
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, title="Оновити все до версії Євгена?",
                                                     message="1-2 хв. Збережеться нова версія файлу, стара лишиться.")

    def execute(self, context):
        if context.mode != 'OBJECT':
            _mode('OBJECT')
        lines, ok = [], True
        st = dict(_sync_status())
        if "fl" in st:                                    # 1) пульт — першим (зони/атрибути, на які спираються правки)
            try:
                if _FL_DIR not in sys.path:
                    sys.path.insert(0, _FL_DIR)
                ns = {"__file__": _FL_FILE, "__name__": "thuma_fl_builder"}
                exec(compile(open(_FL_FILE, encoding="utf-8").read(), _FL_FILE, "exec"), ns)
                ns["upgrade"]()
                lines.append(f"Пульт тканини: збірка {_FL_VER}")
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.report({'ERROR'}, f"Пульт не оновився: {e}. Нічого не збережено — напиши Євгену")
                return {'CANCELLED'}
        _GEO_CACHE["t"] = 0.0
        if _geo_fix_count() > 0:                          # 2) правки моделі
            lines += _apply_model_fixes(context)
        if "wood" in st or (bpy.data.materials.get(WOOD_MAT) and not _is_owner() and not _REMOTE.get("wood")):
            try:                                          # 3) дерево — після правок (рейкам потрібні нові вузли)
                if not _REMOTE.get("wood"):
                    _REMOTE["wood"] = _fetch(_WOOD_JSON)
                r = bpy.ops.thuma.wood_apply_remote()
                if 'FINISHED' in r:
                    lines.append(f"Дерево Євгена: {_REMOTE['wood'].get('stamp')}")
                else:
                    ok = False; lines.append("Дерево НЕ застосовано — натисни «Оновити все» ще раз")
            except Exception as e:
                ok = False; lines.append(f"Дерево НЕ застосовано ({str(e)[:60]}) — перевір інтернет, натисни ще раз")
        _GEO_CACHE["t"] = 0.0; _WSYNC["t"] = 0.0          # 4) перевірка: чи справді нічого не лишилось
        left = [t for k, t in _sync_status() if k != "?"]
        if left:
            ok = False
            lines += ["Не застосувалось: " + t for t in left]
        elif _geo_fix_count() == 0:
            _mark_fixes_done()                            # 1.31.6
        old = bpy.data.filepath
        if old:
            new = _next_version_path(old)
            bpy.ops.wm.save_as_mainfile(filepath=new, compress=True)
            lines.append(f"Збережено як: {_os.path.basename(new)} (старий без змін)")
        else:
            ok = False; lines.append("Сцена ще не збережена — збережіть її вручну")
        _SYNC_DONE[bpy.data.filepath] = (ok, lines)
        _GEO_DONE.pop(bpy.data.filepath, None)
        self.report({'INFO'} if ok else {'WARNING'}, " | ".join(lines))
        return {'FINISHED'}


class THUMA_OT_update_all_ok(bpy.types.Operator):
    bl_idname = "thuma.update_all_ok"
    bl_label = "Зрозуміло"
    bl_description = "Сховати звіт про оновлення"

    def execute(self, context):
        _SYNC_DONE.pop(bpy.data.filepath, None)
        return {'FINISHED'}


class THUMA_OT_geo_ok(bpy.types.Operator):
    bl_idname = "thuma.geo_ok"
    bl_label = "Зрозуміло"
    bl_description = "Сховати звіт про оновлення моделі"

    def execute(self, context):
        _GEO_DONE.pop(bpy.data.filepath, None)
        return {'FINISHED'}


def register():
    bpy.utils.register_class(THUMA_OT_geo_fix)
    bpy.utils.register_class(THUMA_OT_geo_ok)
    bpy.utils.register_class(THUMA_OT_update_all)
    bpy.utils.register_class(THUMA_OT_update_all_ok)
    bpy.types.Scene.thuma_fabric_pick = bpy.props.EnumProperty(
        name="Тканина", items=_items, get=_get, set=_set,
        description="Яку тканину поставити на всю оббивку (12 мешів). Матеріал стає в слот — його видно в Shader Editor")
    bpy.types.Scene.thuma_combo_pick = bpy.props.EnumProperty(
        name="Розцвітка", items=_combo_items, get=_combo_get, set=_combo_set,
        description="Розцвітка клієнта (дерево + тканина): ставить тканину, породу і вкладку таблиці імен у CFRender")
    bpy.utils.register_class(THUMA_OT_combo_sync)
    bpy.utils.register_class(THUMA_OT_combo_queue)
    _add_cfr_hook()
    bpy.types.Scene.thuma_mem_save = bpy.props.BoolProperty(
        name="Економія памʼяті", default=True, update=_mem_toggle,
        description="Прихованим у кадрі модулям вимикати Subdivision у вʼюпорті — Blender не тримає в памʼяті готові "
                    "моделі всіх конфігурацій (інакше +1.5-2 ГБ на кожну й виліт). Видимі й рендер — без змін")
    if _mem_on_frame not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(_mem_on_frame)
    bpy.types.Scene.thuma_wood_pick = bpy.props.EnumProperty(
        name="Дерево", items=_WOOD_ITEMS, get=_wood_get, set=_wood_set,
        description="Порода дерева (вузол WOOD основного матеріалу дерева: рівно 1-5). Торці перемикаються разом")
    bpy.utils.register_class(THUMA_OT_kutik_paint)
    bpy.utils.register_class(THUMA_Zone)
    bpy.types.Mesh.thuma_zones = bpy.props.CollectionProperty(type=THUMA_Zone)
    bpy.utils.register_class(THUMA_CSeam)
    bpy.types.Mesh.thuma_cseams = bpy.props.CollectionProperty(type=THUMA_CSeam)
    bpy.utils.register_class(THUMA_OT_cseam)
    for h in [h for h in bpy.app.handlers.depsgraph_update_post if getattr(h, "__name__", "") == "_cs_on_dg"]:
        bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_cs_on_dg)
    bpy.types.WindowManager.thuma_add_to = bpy.props.StringProperty()
    bpy.types.WindowManager.thuma_mode = bpy.props.EnumProperty(name="Пульт", items=_MODE_ITEMS, default='FABRIC')
    bpy.types.WindowManager.thuma_wood_part = bpy.props.EnumProperty(name="Пульт дерева", items=_PART_ITEMS, default='RAIL')
    bpy.utils.register_class(THUMA_OT_zone)
    bpy.utils.register_class(THUMA_OT_zone_owner)
    bpy.utils.register_class(THUMA_OT_zone_frames)
    bpy.utils.register_class(THUMA_OT_zone_this_frame)
    bpy.utils.register_class(THUMA_OT_zone_arm)
    bpy.utils.register_class(THUMA_OT_reset)
    bpy.utils.register_class(THUMA_OT_news_ok)
    bpy.utils.register_class(THUMA_CopySection)
    bpy.utils.register_class(THUMA_OT_copy_look)
    bpy.utils.register_class(THUMA_OT_eye)
    bpy.utils.register_class(THUMA_OT_seam_off)
    bpy.utils.register_class(THUMA_OT_seam_flash)
    bpy.utils.register_class(THUMA_OT_zone_part_remove)
    bpy.utils.register_class(THUMA_OT_parts_mask)
    bpy.utils.register_class(THUMA_OT_update_look)
    bpy.utils.register_class(THUMA_OT_settings_export)
    bpy.utils.register_class(THUMA_OT_settings_import)
    bpy.utils.register_class(THUMA_OT_wood_export)
    bpy.utils.register_class(THUMA_OT_wood_import)
    bpy.utils.register_class(THUMA_OT_wood_publish)
    bpy.utils.register_class(THUMA_OT_wood_apply_remote)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    for hl_ in (bpy.app.handlers.render_init, bpy.app.handlers.render_pre, bpy.app.handlers.save_pre):
        if _hl_reset_prop not in hl_:                 # FL71: лампочка не потрапляє в рендер і файл
            hl_.append(_hl_reset_prop)
    if _hlb_recover not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_hlb_recover)
    if not bpy.app.background and not bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.register(_check_remote, first_interval=3.0)
    bpy.utils.register_class(THUMA_PT_geo_update)     # 1.21.14: вище за «Тканину»
    bpy.utils.register_class(THUMA_PT_fabric)


def unregister():
    bpy.utils.unregister_class(THUMA_PT_fabric)
    bpy.utils.unregister_class(THUMA_PT_geo_update)
    bpy.utils.unregister_class(THUMA_OT_update_look)
    bpy.utils.unregister_class(THUMA_OT_settings_export)
    bpy.utils.unregister_class(THUMA_OT_settings_import)
    bpy.utils.unregister_class(THUMA_OT_wood_export)
    bpy.utils.unregister_class(THUMA_OT_wood_import)
    bpy.utils.unregister_class(THUMA_OT_wood_publish)
    bpy.utils.unregister_class(THUMA_OT_wood_apply_remote)
    bpy.utils.unregister_class(THUMA_OT_geo_fix)
    bpy.utils.unregister_class(THUMA_OT_geo_ok)
    bpy.utils.unregister_class(THUMA_OT_update_all)
    bpy.utils.unregister_class(THUMA_OT_update_all_ok)
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    for hl_ in (bpy.app.handlers.render_init, bpy.app.handlers.render_pre, bpy.app.handlers.save_pre):
        for h in [h for h in hl_ if getattr(h, "__name__", "") == "_hl_reset_prop"]:
            hl_.remove(h)
    for h in [h for h in bpy.app.handlers.load_post if getattr(h, "__name__", "") == "_hlb_recover"]:
        bpy.app.handlers.load_post.remove(h)
    _hlb_restore()
    _hl_prop_set(0.0)
    _hl_prop_set(0.0, _HLW_PROP)
    for h in [h for h in bpy.app.handlers.frame_change_post if getattr(h, "__name__", "") == "_mem_on_frame"]:
        bpy.app.handlers.frame_change_post.remove(h)
    if bpy.app.timers.is_registered(_check_remote):
        bpy.app.timers.unregister(_check_remote)
    bpy.utils.unregister_class(THUMA_OT_kutik_paint)
    bpy.utils.unregister_class(THUMA_OT_zone)
    bpy.utils.unregister_class(THUMA_OT_zone_owner)
    bpy.utils.unregister_class(THUMA_OT_zone_frames)
    bpy.utils.unregister_class(THUMA_OT_zone_this_frame)
    bpy.utils.unregister_class(THUMA_OT_zone_arm)
    bpy.utils.unregister_class(THUMA_OT_reset)
    bpy.utils.unregister_class(THUMA_OT_news_ok)
    bpy.utils.unregister_class(THUMA_OT_copy_look)
    bpy.utils.unregister_class(THUMA_CopySection)
    bpy.utils.unregister_class(THUMA_OT_eye)
    _hl_stop()
    bpy.utils.unregister_class(THUMA_OT_seam_flash)
    bpy.utils.unregister_class(THUMA_OT_zone_part_remove)
    bpy.utils.unregister_class(THUMA_OT_seam_off)
    bpy.utils.unregister_class(THUMA_OT_parts_mask)
    del bpy.types.Mesh.thuma_zones
    for h in [h for h in bpy.app.handlers.depsgraph_update_post if getattr(h, "__name__", "") == "_cs_on_dg"]:
        bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.utils.unregister_class(THUMA_OT_cseam)
    del bpy.types.Mesh.thuma_cseams
    bpy.utils.unregister_class(THUMA_CSeam)
    del bpy.types.WindowManager.thuma_add_to
    del bpy.types.WindowManager.thuma_mode
    del bpy.types.WindowManager.thuma_wood_part
    bpy.utils.unregister_class(THUMA_Zone)
    del bpy.types.Scene.thuma_fabric_pick
    del bpy.types.Scene.thuma_wood_pick
    del bpy.types.Scene.thuma_mem_save
    del bpy.types.Scene.thuma_combo_pick
    bpy.utils.unregister_class(THUMA_OT_combo_sync)
    bpy.utils.unregister_class(THUMA_OT_combo_queue)
    hooks = bpy.app.driver_namespace.get("cfrender_sheet_hooks", [])
    for h in [h for h in hooks if getattr(h, "__name__", "") == "_cfr_sheet_hook"]:
        hooks.remove(h)
