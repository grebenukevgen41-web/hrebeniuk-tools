"""
CreateProject for Blender v1.0
Port of ProjectCreator_v1.6.ms (3ds Max) — same folder layout, same
name-sanitizing rules, same "remember last drive/sub/client" behaviour,
same texture-collecting step. Layers -> Collections.
"""

bl_info = {
    "name": "Create Project",
    "author": "CreateProject Tool",
    "version":     (1, 0, 2),
    "blender": (3, 6, 0),
    "location": "View3D > N-Panel > Project",
    "description": "Create a standard project folder structure, collect textures, save the .blend",
    "category": "System",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


import bpy
import os
import re
import json
import shutil
import string
from bpy.props import StringProperty, EnumProperty
from bpy.types import Panel, Operator, PropertyGroup

SETTINGS_FILE = os.path.join(bpy.utils.user_resource('CONFIG', create=True), "create_project_settings.json")

LAYER_NAMES = ("_0_GUIDES", "_01_ARCH", "_02_FURNITURE", "_03_LIGHT", "_04_DECOR", "_05_CAMERAS", "_99_TEMP")

_ENUM_CACHE = {}  # keeps generated (id, name, desc) tuples alive for Blender's dynamic EnumProperty


# ============================================================
# UTIL
# ============================================================

def force_clean_input(s):
    if not s:
        return ""
    s = s.replace(" ", "_").replace("-", "_")
    allowed = string.ascii_letters + string.digits + "_"
    s = "".join(ch for ch in s if ch in allowed)
    while "__" in s:
        s = s.replace("__", "_")
    return s


def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as exc:
        print("[CreateProject] could not save settings:", exc)


def list_subdirs(path):
    """Visible (non-hidden/system) subdirectories of path, or [] if path is invalid."""
    if not path or not os.path.isdir(path):
        return []
    out = []
    try:
        with os.scandir(path) as it:
            for entry in it:
                if not entry.is_dir():
                    continue
                try:
                    attrs = entry.stat().st_file_attributes
                    if attrs & (0x2 | 0x4):  # HIDDEN | SYSTEM
                        continue
                except Exception:
                    pass
                out.append(entry.name)
    except Exception:
        return []
    return sorted(out)


def available_drives():
    return [f"{letter}:\\" for letter in string.ascii_uppercase if os.path.exists(f"{letter}:\\")]


# ============================================================
# DYNAMIC ENUM CALLBACKS
# ============================================================

def _enum(key, items):
    if not items:
        items = [("NONE", "---", "")]
    else:
        items = [(name, name, "") for name in items]
    _ENUM_CACHE[key] = items
    return _ENUM_CACHE[key]


def drive_items(self, context):
    return _enum("drive", available_drives())


def sub_items(self, context):
    props = context.scene.create_project_props
    return _enum("sub", list_subdirs(props.drive))


def client_items(self, context):
    props = context.scene.create_project_props
    if not props.drive or props.drive == "NONE" or not props.sub or props.sub == "NONE":
        return _enum("client", [])
    return _enum("client", list_subdirs(os.path.join(props.drive, props.sub)))


# ============================================================
# PROPERTIES
# ============================================================

def _update_name(self, context):
    cleaned = force_clean_input(self.project_name)
    if cleaned != self.project_name:
        self.project_name = cleaned


def _update_new_client(self, context):
    cleaned = force_clean_input(self.new_client)
    if cleaned != self.new_client:
        self.new_client = cleaned


class CREATEPROJECT_Props(PropertyGroup):
    project_name: StringProperty(
        name="Project Name", description="Назва проекту: тільки a-z, 0-9, _ (пробіли й дефіси стануть _)",
        default="", update=_update_name)
    drive: EnumProperty(description="Диск проекту", name="Drive", items=drive_items)
    sub: EnumProperty(description="Підпапка на диску", name="Subfolder", items=sub_items)
    client: EnumProperty(description="Клієнт (папка клієнта)", name="Client", items=client_items)
    new_client: StringProperty(
        name="Or new client", description="Або новий клієнт: a-z, 0-9, _ (папка створиться)",
        default="", update=_update_new_client)


# ============================================================
# CORE
# ============================================================

def collect_textures(maps_path, file_project_dir):
    """
    Copy every used image into maps_path AND relink the image datablock to
    point at the new copy. Unlike 3ds Max, Blender has no global "map search
    path" fallback — an image keeps whatever single filepath it's given, so
    without relinking the copied textures would just sit unused and the
    saved .blend would still point at the original (often foreign-machine)
    paths.
    """
    copied = 0
    for img in bpy.data.images:
        if img.source == 'GENERATED' or not img.filepath:
            continue
        try:
            src = bpy.path.abspath(img.filepath, library=img.library)
        except Exception:
            continue
        if not src or not os.path.isfile(src):
            continue
        target = os.path.join(maps_path, os.path.basename(src))
        if not os.path.exists(target):
            try:
                shutil.copyfile(src, target)
                copied += 1
            except Exception as exc:
                print("[CreateProject] texture copy failed:", src, exc)
                continue
        rel = os.path.relpath(target, file_project_dir).replace("\\", "/")
        img.filepath = "//" + rel
    return copied


def setup_collections(scene):
    root = scene.collection
    existing = {c.name: c for c in bpy.data.collections}
    for name in LAYER_NAMES:
        if name not in existing:
            col = bpy.data.collections.new(name)
            root.children.link(col)
    # tidy up: remove other EMPTY user collections not in the list.
    # "Collection" is Blender's own default scene collection — keep it,
    # same as the Max script protects layer "0"/"0 (default)".
    protected = set(LAYER_NAMES) | {"Collection"}
    for col in list(bpy.data.collections):
        if col.name in protected:
            continue
        if len(col.objects) == 0 and len(col.children) == 0:
            try:
                bpy.data.collections.remove(col)
            except Exception:
                pass


class CREATEPROJECT_OT_create(Operator):
    bl_idname = "createproject.create"
    bl_description = "Створити папки проекту, зібрати текстури в maps і зберегти .blend як <назва>_v001"
    bl_label = "Save Project & Collect Maps"
    bl_options = {'REGISTER'}

    def execute(self, context):
        print("=" * 60)
        print("  create_project_blender START")
        print("=" * 60)
        props = context.scene.create_project_props
        sn = force_clean_input(props.project_name)
        new_client = force_clean_input(props.new_client)
        cn = new_client if new_client else (props.client if props.client != "NONE" else "")

        if not sn or not cn:
            self.report({'ERROR'}, "Fill project name and client!")
            return {'CANCELLED'}
        if not props.drive or props.drive == "NONE" or not props.sub or props.sub == "NONE":
            self.report({'ERROR'}, "Pick a drive and subfolder!")
            return {'CANCELLED'}

        project_root = os.path.join(props.drive, props.sub, cn, sn)
        file_project_dir = os.path.join(project_root, "file_project")
        maps_path = os.path.join(file_project_dir, "maps")

        dir_list = [
            project_root,
            os.path.join(project_root, "sow"),
            os.path.join(project_root, "archive"),
            file_project_dir,
            os.path.join(file_project_dir, "models"),
            maps_path,
        ]
        for v in ("v01", "v02", "v03"):
            dir_list.append(os.path.join(project_root, "render", v))
            dir_list.append(os.path.join(project_root, "render", "out", v))
        for d in dir_list:
            os.makedirs(d, exist_ok=True)

        copied = collect_textures(maps_path, file_project_dir)
        setup_collections(context.scene)

        save_settings({"drive": props.drive, "sub": props.sub, "client": cn})

        final_path = os.path.join(file_project_dir, f"{sn}_v001.blend")
        try:
            bpy.ops.wm.save_as_mainfile(filepath=final_path, copy=False)
        except Exception as exc:
            self.report({'ERROR'}, f"Save failed: {exc}")
            return {'CANCELLED'}

        try:
            os.startfile(project_root)
        except Exception:
            pass

        self.report({'INFO'}, f"Project saved: {final_path} ({copied} textures collected)")
        return {'FINISHED'}


class CREATEPROJECT_OT_pick_drive(Operator):
    """Refresh subfolder/client lists after picking a drive (Blender doesn't
    auto-refresh dependent enums without a redraw trigger)."""
    bl_idname = "createproject.refresh"
    bl_description = "Оновити списки підпапок і клієнтів після вибору диска"
    bl_label = ""
    bl_options = {'INTERNAL'}

    def execute(self, context):
        return {'FINISHED'}


# ============================================================
# UI
# ============================================================

class CREATEPROJECT_PT_panel(Panel):
    bl_label = "Create Project"
    bl_idname = "CREATEPROJECT_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Project'

    def draw(self, context):
        layout = self.layout
        props = context.scene.create_project_props

        layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))
        layout.prop(props, "project_name")
        layout.prop(props, "drive")
        layout.prop(props, "sub")
        layout.prop(props, "client")
        layout.prop(props, "new_client")

        layout.separator()
        row = layout.row()
        row.scale_y = 1.6
        row.operator("createproject.create", icon='FILE_TICK')


# ============================================================
# REGISTRATION
# ============================================================

classes = [
    CREATEPROJECT_Props,
    CREATEPROJECT_OT_create,
    CREATEPROJECT_OT_pick_drive,
    CREATEPROJECT_PT_panel,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.create_project_props = bpy.props.PointerProperty(type=CREATEPROJECT_Props)

    # restore last-used drive/sub/client
    settings = load_settings()
    if settings:
        def _restore():
            try:
                scene = bpy.context.scene
                if scene is None:
                    return None
                props = scene.create_project_props
                if settings.get("drive") in [d for d in available_drives()]:
                    props.drive = settings["drive"]
                if settings.get("sub") in list_subdirs(props.drive):
                    props.sub = settings["sub"]
                if settings.get("client") in list_subdirs(os.path.join(props.drive, props.sub)):
                    props.client = settings["client"]
            except Exception as exc:
                print("[CreateProject] restore settings failed:", exc)
            return None
        bpy.app.timers.register(_restore, first_interval=0.1)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.create_project_props


if __name__ == "__main__":
    register()
