bl_info = {
    "name":        "Hrebeniuk Hub",
    "author":      "Hrebeniuk Tools",
    "version":     (1, 2, 1),
    "blender":     (4, 4, 0),
    "location":    "3D Viewport › N-Panel › Hrebeniuk",
    "description": "Всі аддони Hrebeniuk в одній вкладці + автооновлення",
    "category":    "Interface",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


"""
Хаб НЕ змінює файли аддонів. При старті він знаходить їхні N-панелі, перевішує
на вкладку 'Hrebeniuk' і показує тільки панелі вибраного інструменту.
Оновлення — через репозиторій Blender Extensions «Hrebeniuk Tools» (папка на Google Drive):
Blender сам перевіряє його при запуску, тут — лічильник і кнопка «Оновити все».
Старі ручні копії наших аддонів (scripts/addons) прибираються автоматично,
якщо вже стоїть нова версія з репозиторію (резервна копія — addons/_hrb_backup).
Новий аддон додати — один рядок у TOOLS (+ пакет у packages.json публікатора).
"""

import bpy
import addon_utils
import json
import os
import re
import shutil
import subprocess
import textwrap
import time
from bpy.props import EnumProperty, BoolProperty
from bpy.types import Panel, Operator

HUB_TAB = "Hrebeniuk"
SITE_URL = "https://grebenukevgen41-web.github.io/hrebeniuk-tools/"
PUBLISH_BAT = r"E:\disk_D\pROG\Thuma_prog\Blender\Extensions\ОПУБЛІКУВАТИ.bat"   # є тільки на ПК автора

# key, назва, іконка, id аддона (= ім'я модуля / id пакета), що це
TOOLS = [
    ("shots",   "Shot List",        'SEQUENCE',     "shot_list",              "Збірка сцен клієнта, список кадрів"),
    ("cfr",     "Frame Render",     'RENDER_STILL', "custom_frame_render",    "Рендер вибраних кадрів + неймінг"),
    ("clean",   "Texture Cleaner",  'BRUSH_DATA',   "texture_cleaner",        "Зайві / дублі / відсутні текстури"),
    ("wire",    "WireColor Masks",  'IMAGE_DATA',   "wirecolor_mask_addon",   "Маски object/face/material"),
    ("seam",    "Seam Shadow",      'MOD_SMOOTH',   "seam_shadow",            "Фейкові тіні швів"),
    ("shift",   "Keyframe Shift",   'KEYFRAME_HLT', "keyframe_shift_addon",   "Зсув ключів до кадру"),
    ("project", "Create Project",   'FILE_FOLDER',  "create_project_blender", "Структура папок проекту"),
    ("share",   "Quick Share",      'FORWARD',      "quick_share_telegram",   "Скинути обране в Telegram"),
    ("exbg",    "Exact BG",         'WORLD',        "exact_bg",               "Фон рівно #F0F0F0 прямо з рендеру"),
]
# id -> назва в bl_info: так знаходимо старі копії з будь-яким іменем файлу (seam_shadow_v337.py…)
KNOWN = {
    "hrebeniuk_hub": "Hrebeniuk Hub", "seam_shadow": "Seam Shadow Painter",
    "wirecolor_mask_addon": "WireColor Masks", "custom_frame_render": "Custom Frame Render",
    "create_project_blender": "Create Project", "shot_list": "Shot List",
    "texture_cleaner": "Texture Cleaner", "keyframe_shift_addon": "Keyframe Shift",
    "quick_share_telegram": "Quick Share", "exact_bg": "Exact BG",
}

_adopted = {}          # panel class -> (original category, original poll or None)
_cleanup_note = [""]   # що прибрали при старті (показується в панелі)


# ─────────────────────────────────────────────────────────────────────────────
#  МОДУЛІ: старий аддон (seam_shadow) або extension (bl_ext.hrebeniuk.seam_shadow)
# ─────────────────────────────────────────────────────────────────────────────

def _short(module_name):
    parts = module_name.split(".")
    return parts[2] if module_name.startswith("bl_ext.") and len(parts) > 2 else parts[0]


def _find_module(short):
    """Повне ім'я модуля для id: спершу extension, потім старий аддон. None — не встановлено."""
    ext = legacy = None
    for m in addon_utils.modules():
        n = m.__name__
        if n.startswith("bl_ext.") and _short(n) == short:
            if ext is None or addon_utils.check(n)[1]:
                ext = n
        elif n == short:
            legacy = n
    return ext or legacy


def _enabled(short):
    full = _find_module(short)
    return bool(full) and addon_utils.check(full)[1]


def _make_poll(key, orig):
    def poll(cls, context):
        wm = context.window_manager
        if getattr(wm, "hrb_hub_on", True) and wm.hrb_hub_active != key:
            return False
        return orig(context) if orig else True
    return classmethod(poll)


def _panels_of(short):
    out = []
    for cls in bpy.types.Panel.__subclasses__():
        if _short(cls.__module__) == short \
                and getattr(cls, "bl_space_type", "") == 'VIEW_3D' \
                and getattr(cls, "bl_region_type", "") == 'UI' \
                and getattr(cls, "is_registered", False):
            out.append(cls)
    return out


def adopt_all():
    """Перевісити панелі всіх увімкнених інструментів на вкладку хабу."""
    moved = 0
    for key, _label, _icon, short, _desc in TOOLS:
        panels = [c for c in _panels_of(short) if c not in _adopted]
        if not panels:
            continue
        parents = [c for c in panels if not getattr(c, "bl_parent_id", "")]
        children = [c for c in panels if getattr(c, "bl_parent_id", "")]
        for c in children + parents:
            bpy.utils.unregister_class(c)
        for c in parents + children:
            orig_poll = c.__dict__.get("poll")
            orig = (lambda ctx, f=orig_poll.__func__, k=c: f(k, ctx)) if orig_poll else None
            _adopted[c] = (c.bl_category, orig_poll)
            c.bl_category = HUB_TAB
            c.poll = _make_poll(key, orig)
            bpy.utils.register_class(c)
            moved += 1
    return moved


def release_all():
    """Повернути всі панелі на свої вкладки (при вимкненні хабу)."""
    items = list(_adopted.items())
    parents = [(c, v) for c, v in items if not getattr(c, "bl_parent_id", "")]
    children = [(c, v) for c, v in items if getattr(c, "bl_parent_id", "")]
    for c, _v in children + parents:
        if c.is_registered:
            bpy.utils.unregister_class(c)
    for c, (cat, orig_poll) in parents + children:
        c.bl_category = cat
        if orig_poll is not None:
            c.poll = orig_poll
        elif "poll" in c.__dict__:
            del c.poll
        try:
            bpy.utils.register_class(c)
        except Exception as e:
            print("Hrebeniuk Hub: restore", c.__name__, e)
    _adopted.clear()


# ─────────────────────────────────────────────────────────────────────────────
#  ПРИБИРАННЯ СТАРИХ КОПІЙ
# ─────────────────────────────────────────────────────────────────────────────

def _legacy_id(mod):
    for pid, title in KNOWN.items():
        if re.fullmatch(rf"{pid}(_v\d+)?", mod.__name__) or getattr(mod, "bl_info", {}).get("name") == title:
            return pid
    return None


def cleanup_legacy():
    """Старі ручні копії (scripts/addons) тих аддонів, які вже стоять з репозиторію —
    вимкнути, перенести в addons/_hrb_backup/<дата>, extension перевантажити.
    Аддон без встановленої нової версії НЕ чіпаємо ніколи."""
    try:
        user_addons = os.path.normcase(os.path.abspath(bpy.utils.user_resource('SCRIPTS', path="addons")))
    except Exception:
        return []
    ext_on = {_short(m.__name__) for m in addon_utils.modules()
              if m.__name__.startswith("bl_ext.") and addon_utils.check(m.__name__)[1]}
    backup = os.path.join(user_addons, "_hrb_backup", time.strftime("%Y%m%d_%H%M%S"))
    removed, reload_ext = [], set()
    for mod in addon_utils.modules():
        name = mod.__name__
        if name.startswith("bl_ext."):
            continue
        path = os.path.normcase(os.path.abspath(mod.__file__))
        if not path.startswith(user_addons) or "_hrb_backup" in path:
            continue
        pid = _legacy_id(mod)
        if pid is None or pid not in ext_on:
            continue
        try:
            addon_utils.disable(name, default_set=True)
        except Exception:
            pass
        target = os.path.dirname(path) if os.path.basename(path) == "__init__.py" else path
        try:
            os.makedirs(backup, exist_ok=True)
            shutil.move(target, os.path.join(backup, os.path.basename(target)))
            removed.append(name)
            reload_ext.add(pid)
        except Exception as e:
            print("Hrebeniuk Hub: не вдалось прибрати", name, e)
    # старий і новий могли конфліктувати при реєстрації — перевантажуємо нові
    for pid in reload_ext:
        full = _find_module(pid)
        if full and full.startswith("bl_ext.") and pid != "hrebeniuk_hub":
            try:
                addon_utils.disable(full, default_set=False)
                addon_utils.enable(full, default_set=True)
            except Exception as e:
                print("Hrebeniuk Hub: reload", full, e)
    if removed:
        addon_utils.modules(refresh=True)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        print("Hrebeniuk Hub: прибрано старі копії:", removed, "→", backup)
    return removed


def _startup():
    try:
        removed = cleanup_legacy()
        if removed:
            _cleanup_note[0] = "Прибрано старі копії: " + ", ".join(removed)
            release_all()
    except Exception as e:
        print("Hrebeniuk Hub: cleanup error:", e)
    try:
        adopt_all()
    except Exception as e:
        print("Hrebeniuk Hub: adopt error:", e)
    # власна перевірка оновлень при запуску (штатна перевірка Blender на старті
    # на PC2 не спрацьовувала — лічильник з'являвся тільки після кліку 🔄)
    bpy.app.timers.register(lambda: (_check_now(), None)[1], first_interval=3.0)
    return None


def _deferred_adopt():
    try:
        adopt_all()
    except Exception as e:
        print("Hrebeniuk Hub: adopt error:", e)
    return None


@bpy.app.handlers.persistent
def _on_load(_a=None, _b=None):
    bpy.app.timers.register(_deferred_adopt, first_interval=0.3)


# ─────────────────────────────────────────────────────────────────────────────
#  ОПЕРАТОРИ
# ─────────────────────────────────────────────────────────────────────────────

class HRB_OT_pick(Operator):
    bl_idname = "hrb_hub.pick"
    bl_label = "Open Tool"
    bl_description = "Відкрити панель інструменту (якщо аддон вимкнений — увімкнути)"
    key: bpy.props.StringProperty()

    def execute(self, context):
        tool = next(t for t in TOOLS if t[0] == self.key)
        full = _find_module(tool[3])
        if not full:
            self.report({'ERROR'}, f"{tool[1]} не встановлено")
            return {'CANCELLED'}
        if not addon_utils.check(full)[1]:
            try:
                addon_utils.enable(full, default_set=True, persistent=True)
            except Exception as e:
                self.report({'ERROR'}, f"Не вдалось увімкнути {tool[1]}: {e}")
                return {'CANCELLED'}
            adopt_all()
            self.report({'INFO'}, f"{tool[1]} увімкнено")
        context.window_manager.hrb_hub_active = self.key
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}


class HRB_OT_refresh(Operator):
    bl_idname = "hrb_hub.refresh"
    bl_label = "Refresh"
    bl_description = "Знову зібрати панелі (якщо щось увімкнув окремо)"

    def execute(self, context):
        n = adopt_all()
        self.report({'INFO'}, f"Додано панелей: {n}")
        return {'FINISHED'}


class HRB_OT_check_updates(Operator):
    bl_idname = "hrb_hub.check_updates"
    bl_label = "Перевірити оновлення"
    bl_description = "Перевірити сайт Hrebeniuk Tools на нові версії (автоматично — при запуску і раз на 2 години)"

    def execute(self, context):
        try:
            bpy.ops.extensions.repo_sync_all()
        except Exception as e:
            self.report({'ERROR'}, f"Не вдалось перевірити: {e}")
            return {'CANCELLED'}
        _watch_until[0] = time.time() + 60
        if not bpy.app.timers.is_registered(_watch_counter):
            bpy.app.timers.register(_watch_counter, first_interval=2.0)
        return {'FINISHED'}


# Оновлення ставить ШТАТНА кнопка Blender (extensions.package_upgrade_all) прямо з панелі.
# НЕ обгортаємо її своїм оператором: якщо серед оновлень є сам хаб, Blender вивантажує хаб
# посеред виконання його ж оператора — і падає (так і сталося на PC2 з 1.1.2 → 1.1.3).
# Що оновилось — рахуємо, порівнюючи версії «до» (знімок у driver_namespace, переживає
# перезавантаження хаба) і «після».

AUTO_CHECK_SECONDS = 2 * 60 * 60        # тиха перевірка оновлень раз на 2 години
_NS = bpy.app.driver_namespace


def _our_versions():
    """id -> версія (з addon_utils: там bl_info лишається навіть у extensions)."""
    out = {}
    for m in addon_utils.modules(refresh=True):
        if m.__name__.startswith("bl_ext.") and _short(m.__name__) in KNOWN:
            out[_short(m.__name__)] = tuple(m.bl_info.get("version", ()))
    return out


def _note_changes():
    """Порівняти з останнім знімком; якщо щось оновилось — записати підказку в панель."""
    before = _NS.get("hrb_versions_seen")
    now = _our_versions()
    _NS["hrb_versions_seen"] = now
    if not before:
        return
    changed = [f"{KNOWN.get(k, k)} {'.'.join(map(str, before.get(k, ()))) or 'нове'} → {'.'.join(map(str, v))}"
               for k, v in now.items() if v != before.get(k)]
    if changed:
        _NS["hrb_update_note"] = "Оновлено: " + ", ".join(changed)
        print("Hrebeniuk Hub:", _NS["hrb_update_note"])


def _sync_repos():
    """Тиха перевірка репозиторіїв (качає лише index.json — кілька КБ)."""
    wm = bpy.context.window_manager
    win = wm.windows[0] if wm and wm.windows else None
    try:
        if win:
            with bpy.context.temp_override(window=win):
                bpy.ops.extensions.repo_sync_all()
        else:
            bpy.ops.extensions.repo_sync_all()
    except Exception as e:
        print("Hrebeniuk Hub: auto-check failed:", e)


_watch_until = [0.0]


def _redraw_ui():
    try:
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                if a.type == 'VIEW_3D':
                    a.tag_redraw()
    except Exception:
        pass


def _watch_counter():
    """Після перевірки лічильник оновлень змінюється у фоні, а панель сама не
    перемальовується — тож хвилину її «штовхаємо», щоб кнопка з'явилась без кліків."""
    _redraw_ui()
    return 2.0 if time.time() < _watch_until[0] else None


def _check_now():
    """Перевірити сайт і хвилину стежити за відповіддю."""
    if bpy.app.background:
        return
    _sync_repos()
    _watch_until[0] = time.time() + 60
    if not bpy.app.timers.is_registered(_watch_counter):
        bpy.app.timers.register(_watch_counter, first_interval=2.0)


def _auto_check():
    _check_now()
    return AUTO_CHECK_SECONDS


class HRB_OT_publish(Operator):
    bl_idname = "hrb_hub.publish"
    bl_label = "Опублікувати мої аддони"
    bl_description = ("Зібрати свіжі версії з папки розробки і викласти в репозиторії "
                      "(колеги отримають при запуску Blender). Відкриється консоль зі звітом")

    @classmethod
    def poll(cls, context):
        return os.path.exists(PUBLISH_BAT)

    def execute(self, context):
        subprocess.Popen(["cmd", "/c", "start", "Hrebeniuk publish", PUBLISH_BAT], shell=False)
        self.report({'INFO'}, "Публікація запущена — дивись вікно консолі")
        return {'FINISHED'}


# ── Нові інструменти в наших наборах ─────────────────────────────────────────
# Blender оновлює лише те, що вже встановлено. Новий аддон на сайті сам не з'явиться —
# тому хаб порівнює список пакетів набору (index.json, Blender качає його при перевірці
# оновлень) з тим, що стоїть, і показує кнопку «Встановити: …». Кнопка — ШТАТНИЙ оператор
# Blender (extensions.package_install), без нашої обгортки (див. примітку про падіння вище).
OUR_REPOS = ("hrebeniuk", "hrebeniuk_personal")
_IGNORE_FILE = os.path.join(bpy.utils.user_resource('CONFIG'), "hrebeniuk_hub_ignored.json")


def _ignored():
    try:
        with open(_IGNORE_FILE, encoding="utf-8") as f:
            return set(json.load(f))
    except Exception:
        return set()


def _index_ids(path):
    """Пакети з index.json (кеш за часом зміни файлу — draw() викликається часто)."""
    cache = _NS.setdefault("hrb_index_cache", {})
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return []
    hit = cache.get(path)
    if hit and hit[0] == mt:
        return hit[1]
    out = []
    try:
        with open(path, encoding="utf-8") as f:
            for p in json.load(f).get("data", []):
                vmin = tuple(int(x) for x in str(p.get("blender_version_min", "0")).split(".")[:3] if x.isdigit())
                if vmin and vmin > tuple(bpy.app.version):
                    continue                                   # не для цієї версії Blender
                out.append((p.get("id"), p.get("name") or p.get("id")))
    except Exception as e:
        print("Hrebeniuk Hub: index read failed:", e)
    cache[path] = (mt, out)
    return out


def _new_packages():
    """[(repo_index, id, назва)] — є в наборі, але не встановлені й не приховані."""
    res, ign = [], _ignored()
    try:
        repos = bpy.context.preferences.extensions.repos
    except Exception:
        return res
    for i, r in enumerate(repos):
        ours = r.module in OUR_REPOS or 'hrebeniuk-tools' in (r.remote_url or '')   # і якщо набір підключили вручну під іншою назвою
        if not r.enabled or not ours:
            continue
        d = r.directory
        for pid, name in _index_ids(os.path.join(d, ".blender_ext", "index.json")):
            if pid and pid not in ign and not os.path.isdir(os.path.join(d, pid)):
                res.append((i, pid, name))
    return res


class HRB_OT_ignore_new(Operator):
    bl_idname = "hrb_hub.ignore_new"
    bl_label = "Не показувати"
    bl_description = "Не пропонувати цей інструмент (можна встановити пізніше: Edit › Preferences › Get Extensions)"
    pkg_id: bpy.props.StringProperty()

    def execute(self, context):
        ign = _ignored()
        ign.add(self.pkg_id)
        try:
            os.makedirs(os.path.dirname(_IGNORE_FILE), exist_ok=True)
            with open(_IGNORE_FILE, "w", encoding="utf-8") as f:
                json.dump(sorted(ign), f)
        except Exception as e:
            self.report({'ERROR'}, f"Не вдалось зберегти: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ПАНЕЛЬ
# ─────────────────────────────────────────────────────────────────────────────

class HRB_PT_hub(Panel):
    bl_label = "Hrebeniuk Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = HUB_TAB
    bl_order = -100

    def draw_header_preset(self, context):
        self.layout.label(text="v" + ".".join(map(str, ADDON_VERSION)))

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        active = wm.hrb_hub_active
        installed = [t for t in TOOLS if _find_module(t[3])]     # у колег — тільки те, що стоїть
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
        for key, label, icon, short, _desc in installed:
            op = grid.operator("hrb_hub.pick", text=label,
                               icon=icon if _enabled(short) else 'ADD', depress=(key == active))
            op.key = key
        tool = next((t for t in installed if t[0] == active), None)
        if tool:
            # опис переносимо по ширині панелі, а не обрізаємо «...»
            px = context.region.width / context.preferences.system.ui_scale
            lines = textwrap.wrap(tool[4], max(12, int((px - 70) / 7))) or [""]
            row = layout.row()
            col = row.column(align=True)
            for i, line in enumerate(lines):
                col.label(text=line, icon='INFO' if i == 0 else 'BLANK1')
            row.operator("hrb_hub.refresh", text="", icon='FILE_REFRESH')
            if not _enabled(tool[3]):
                layout.label(text="Аддон вимкнений — натисни кнопку вище", icon='ERROR')
        layout.prop(wm, "hrb_hub_on", text="Тільки вибраний інструмент")

        box = layout.box()
        n = getattr(wm, "extensions_updates", -1)
        last_n = _NS.get("hrb_last_updates_n", n)
        if last_n > 0 and n == 0:                 # щойно оновились (без перезавантаження хаба)
            _note_changes()
        _NS["hrb_last_updates_n"] = n
        row = box.row(align=True)
        if n > 0:
            sub = row.row(align=True)
            sub.alert = True
            sub.scale_y = 1.3
            sub.operator("extensions.package_upgrade_all", text=f"Оновити все ({n})", icon='IMPORT')
        elif n == 0:
            row.label(text="Все актуально", icon='CHECKMARK')
        else:
            row.label(text="Оновлення не перевірені", icon='QUESTION')
        row.operator("hrb_hub.check_updates", text="", icon='FILE_REFRESH')
        op = row.operator("wm.url_open", text="", icon='URL')
        op.url = SITE_URL
        for ri, pid, name in _new_packages():               # нові інструменти в наборі
            r2 = box.row(align=True)
            sub = r2.row(align=True)
            sub.scale_y = 1.2
            op = sub.operator("extensions.package_install", text=f"Встановити: {name}", icon='ADD')
            op.repo_index = ri
            op.pkg_id = pid
            op.enable_on_install = True
            r2.operator("hrb_hub.ignore_new", text="", icon='X').pkg_id = pid
        upd = bpy.app.driver_namespace.get("hrb_update_note")
        if upd:
            col = box.column(align=True)
            for i in range(0, len(upd), 60):                 # довгий текст — на кілька рядків
                col.label(text=upd[i:i + 60], icon='CHECKMARK' if i == 0 else 'BLANK1')
        if _cleanup_note[0]:
            col = box.column(align=True)
            col.label(text=_cleanup_note[0][:70], icon='TRASH')
            col.label(text="Резервна копія: scripts/addons/_hrb_backup")
        if os.path.exists(PUBLISH_BAT):
            box.operator("hrb_hub.publish", icon='EXPORT')


def _enum_items(self, context):
    return [(k, l, d, ic, i) for i, (k, l, ic, _m, d) in enumerate(TOOLS)]


classes = (HRB_OT_pick, HRB_OT_refresh, HRB_OT_check_updates, HRB_OT_publish, HRB_OT_ignore_new, HRB_PT_hub)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.WindowManager.hrb_hub_active = EnumProperty(items=_enum_items, name="Tool")
    bpy.types.WindowManager.hrb_hub_on = BoolProperty(
        default=True, description="Вимкни — побачиш панелі всіх інструментів одразу")
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    # аддони, що завантажуються після хабу, — підхопити трохи пізніше; там же прибирання старих копій
    bpy.app.timers.register(_startup, first_interval=1.0)
    # якщо хаб перезавантажився через власне оновлення — показати, що оновилось
    bpy.app.timers.register(lambda: (_note_changes(), None)[1], first_interval=2.0)
    # тиха перевірка оновлень раз на 2 години (при старті Blender перевіряє сам)
    if not bpy.app.timers.is_registered(_auto_check):
        bpy.app.timers.register(_auto_check, first_interval=AUTO_CHECK_SECONDS, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_auto_check):
        bpy.app.timers.unregister(_auto_check)
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    release_all()
    del bpy.types.WindowManager.hrb_hub_on
    del bpy.types.WindowManager.hrb_hub_active
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
