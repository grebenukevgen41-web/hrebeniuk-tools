"""FABRIC LOOK v7 — + «<зона>: перехід» (см): правка зони плавно заходить на сусідні деталі; зони змішуються
зваженим середнім (при всіх переходах 0 = як v6). Відстані до панелей — fabric_zones7 (атрибути вершин fz7_d*).
FABRIC LOOK v6 — тип зони цілою ПАНЕЛЛЮ тканини (UV-острів), межа = шов; напрями плавно.
Було v5 — маски неперервні в шейдері (fabric_zones5: у меші лише розміри модуля).
Було v4 — зони по гранях, сума всіх зон = 1 у кожній точці (повзунок діє тільки на свою зону).

Зони: Спинка, Сидіння, Боковина внутр. ліва/права, Боковина зовн. ліва/права, Верх, Фронт, Задня стінка.
  * Верх / Сидіння / «внутрішня» — атрибути граней (fabric_zones4.py, локально, без розмазування).
  * Внутрішні грані ділимо за напрямом ВІДНОСНО ЗБІРКИ: дивиться вперед/назад -> Спинка,
    вбік -> Боковина внутр. ліва (дивиться праворуч) / права (дивиться ліворуч).
    Тож спинка бічної частини кутового дивана = внутрішня боковина (вона дивиться вбік).
  * Зовнішні грані за напрямом відносно збірки: Фронт / Задня стінка / Боковина зовн. ліва / права.
  * Грань, що дивиться на інший модуль далі ніж 12 см (через П-подібну збірку) -> внутрішня.
  * Стик між модулями (сусід ближче 12 см) -> продовження своєї великої грані.
  * Перехід між напрямами на скругленнях — вузький (±0.1), без подвійної дії.

У відкритому файлі:  ns={}; exec(open(this).read(), ns); ns["upgrade"]()
"""
import bpy
import math as _m
import os
import sys

# v7.28: шляхи відносно цього файлу — той самий код працює і з папки скриптів, і зсередини аддона Thuma Fabric
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else \
    r"E:\disk_D\pROG\Thuma_prog\Blender\Sectional_Configs\fabric_look"
FL_VERSION = 62          # номер збірки пульта; аддон порівнює з g["fl_version"] і пропонує «Оновити пульт»


def _tidy():
    """Акуратна розкладка вузлів (лише координати)."""
    for path in (os.path.join(HERE, "tidy_pults.py"), os.path.join(os.path.dirname(HERE), "tidy_pults.py")):
        if os.path.exists(path):
            try:
                exec(open(path, encoding="utf-8").read(), {"__name__": "tidy", "HRB_GROUPS": [GROUP]})
            except Exception as e:
                print("tidy:", e)
            return


def ensure_front_flag():
    """Прапорець сцени fabric_front: 1 на фронт-кадрах (поворот збірки 0°), 0 на інших; ключі CONSTANT.
    Раніше ставився вручну — тепер завжди відповідає поточним маркерам/повороту."""
    sc = bpy.context.scene
    rot = bpy.data.objects.get(ROT_OBJ)
    if rot is None:
        return 0
    cur = sc.frame_current
    sc["fabric_front"] = 0.0
    if sc.animation_data and sc.animation_data.action:
        try:
            for L_ in sc.animation_data.action.layers:
                for st in L_.strips:
                    for cb in st.channelbags:
                        for fc in [c for c in cb.fcurves if c.data_path == '["fabric_front"]']:
                            cb.fcurves.remove(fc)
        except Exception:
            fc = sc.animation_data.action.fcurves.find('["fabric_front"]')
            if fc:
                sc.animation_data.action.fcurves.remove(fc)
    n = 0
    for f in range(sc.frame_start, sc.frame_end + 1):
        sc.frame_set(f)
        v = 1.0 if abs(_m.sin(rot.matrix_world.to_euler().z)) < 0.1 else 0.0
        sc["fabric_front"] = v
        sc.keyframe_insert('["fabric_front"]', frame=f)
        n += int(v)
    try:
        for L_ in sc.animation_data.action.layers:
            for st in L_.strips:
                for cb in st.channelbags:
                    for fc in cb.fcurves:
                        if fc.data_path == '["fabric_front"]':
                            for k in fc.keyframe_points:
                                k.interpolation = 'CONSTANT'
    except Exception:
        pass
    sc.frame_set(cur)
    return n
GROUP = "FABRIC LOOK"
ROT_OBJ = "Control_Rotation"
RAY_LEN = 3.0
STAGE_Y = 2.8

ZONES = [
    ("back", "Спинка", "Спинка й сидіння",
     "Внутрішні грані, що дивляться вперед: подушки спинки з боку сидіння", (0, 0.4, 1)),
    ("seat", "Сидіння", "Спинка й сидіння", "Верх сидіння (і пуфа)", (0, 1, 0)),
    # v7.25: меню — ліві боковини разом, праві разом (користувач)
    ("in_l", "Боковина внутр. ліва", "Боковини ліві",
     "Внутрішня грань ЛІВОЇ боковини (дивиться праворуч). Ліво = якщо дивитись на диван спереду. "
     "У кутовому дивані сюди ж — спинка лівої бічної частини", (1, 0, 1)),
    # v7.22-23: бортик ніжки Г/П усередині кута (за типом деталі, на всю висоту)
    ("low_l", "Низ внутр. ліва", "Боковини ліві",
     "Бортик ніжки Г/П усередині кута, що дивиться ПРАВОРУЧ (ліва ніжка), на всю висоту "
     "(напр. кадри 44, 70, 73). Зовнішні боки дивана, стики, спинки сюди не входять", (1, 0.6, 0.8)),
    ("out_l", "Боковина зовн. ліва", "Боковини ліві", "Зовнішній бік дивана ЗЛІВА (дивиться назовні вліво)", (1, 0.45, 0)),
    ("in_r", "Боковина внутр. права", "Боковини праві",
     "Внутрішня грань ПРАВОЇ боковини (дивиться ліворуч). Право = якщо дивитись на диван спереду. "
     "У кутовому дивані сюди ж — спинка правої бічної частини", (0.55, 0, 1)),
    ("low_r", "Низ внутр. права", "Боковини праві",
     "Бортик ніжки Г/П усередині кута, що дивиться ЛІВОРУЧ (права ніжка), на всю висоту "
     "(напр. кадри 70, 73). Зовнішні боки дивана, стики, спинки сюди не входять", (0.6, 0.4, 1)),
    ("out_r", "Боковина зовн. права", "Боковини праві", "Зовнішній бік дивана СПРАВА (дивиться назовні вправо)", (0.55, 0.3, 0)),
    ("top", "Верх", "Верх", "Верхній кант спинки й підлокітників", (1, 1, 0)),
    ("front", "Фронт", "Фронт і зад", "Зовнішні грані, що дивляться вперед відносно всієї збірки", (1, 0, 0)),
    ("rear", "Задня стінка", "Фронт і зад", "Зовнішні грані, що дивляться назад (видно на 3/4 ззаду)", (0, 1, 1)),
]
MIGRATE = {"Верх спинки": ["Верх"],
           "Боковини внутрішні": ["Боковина внутр. ліва", "Боковина внутр. права"],
           "Боковини зовнішні": ["Боковина зовн. ліва", "Боковина зовн. права"]}


def _instances(g):
    out = []
    trees = [m.node_tree for m in bpy.data.materials if m.node_tree] + \
            [t for t in bpy.data.node_groups if t.bl_idname == 'ShaderNodeTree']
    for t in trees:
        for n in t.nodes:
            if n.type == 'GROUP' and n.node_tree == g:
                out.append(n)
    return out


def _snapshot(g):
    snap = []
    for n in _instances(g):
        vals = {}
        for s in n.inputs:
            if hasattr(s, "default_value") and not s.is_linked:
                v = s.default_value
                vals[s.name] = tuple(v) if hasattr(v, "__len__") else v
        snap.append((n, vals, [(l.from_node.name, l.from_socket.name, l.to_node.name, l.to_socket.name)
                               for l in n.id_data.links if l.to_node == n or l.from_node == n]))
    return snap


FULL_MIGRATE = {"Верх: колір тону": "Вся тканина: колір тону", "Верх: сила тону": "Вся тканина: сила тону",
                # v7.25: блок «Фронт-кадри: кут» — «Фронт: …» плутався з зоною «Фронт»
                "Фронт: ліва боковина внутр.": "Кут: ліва боковина",
                "Фронт: спинка біля лівої": "Кут: спинка",
                "Фронт: ширина, см": "Кут: ширина, см",
                "Фронт: згасання до країв": "Кут: згасання до країв",
                "Фронт: боковина, довжина": "Кут: довжина боковини",
}


def _restore(snap):
    for n, vals, links in snap:
        # нові повзунки в уже наявних нодах Blender ставить у 0 — виставити значення за замовчуванням
        for it in n.node_tree.interface.items_tree:
            if it.item_type == 'SOCKET' and it.in_out == 'INPUT' and hasattr(it, "default_value"):
                s = n.inputs.get(it.name)
                if s is not None and hasattr(s, "default_value") and not s.is_linked:
                    try:
                        s.default_value = it.default_value
                    except Exception:
                        pass
        for k, v in vals.items():
            k = FULL_MIGRATE.get(k, k)
            base, _, kind = k.partition(": ")
            names = [f"{b}: {kind}" for b in MIGRATE[base]] if base in MIGRATE else [k]
            for nm in names:
                s = n.inputs.get(nm)
                if s is not None and hasattr(s, "default_value"):
                    try:
                        s.default_value = v
                    except Exception:
                        pass
        # v7.50: нові задні ракурси ЗЛ/ЗП беруть значення Л/П (раніше задні кадри були в Л/П -> вигляд не змінюється)
        for k_, v_ in vals.items():
            for a_, z_ in ((" Л", " ЗЛ"), (" П", " ЗП")):
                if (k_.endswith(": яскр." + a_) or k_.endswith(": нас." + a_)):
                    nk = k_[:-len(a_)] + z_
                    s_z = n.inputs.get(nk)
                    if nk not in vals and s_z is not None:
                        s_z.default_value = v_
        # v7.49: нове «Кут: фасад, згасання до країв» бере значення «Кут: згасання до країв» (вигляд не змінюється)
        s_new = n.inputs.get("Кут: фасад, згасання до країв")
        if "Кут: згасання до країв" in vals and "Кут: фасад, згасання до країв" not in vals and s_new is not None:
            s_new.default_value = vals["Кут: згасання до країв"]
        # v7.45: нові «…, фронт» повзунки крил беруть значення старих «крило» (на фронті вигляд не змінюється)
        for side in ("ліве", "праве"):
            for kind in ("сила ×", "ширина ×"):
                old, new = f"Шви сидіння, {side} крило: {kind}", f"Шви сидіння {side}, фронт: {kind}"
                s_new = n.inputs.get(new)
                if old in vals and new not in vals and s_new is not None:
                    s_new.default_value = vals[old]
        t = n.id_data
        for fn, fs, tn, ts in links:          # перев'язати ЗА ІМЕНАМИ
            a, b = t.nodes.get(fn), t.nodes.get(tn)
            if a and b and a.outputs.get(fs) and b.inputs.get(ts):
                if not any(l.from_socket == a.outputs[fs] and l.to_socket == b.inputs[ts] for l in t.links):
                    t.links.new(a.outputs[fs], b.inputs[ts])
        for l in list(t.links):
            if (l.to_node == n or l.from_node == n) and \
                    (l.from_node.name, l.from_socket.name, l.to_node.name, l.to_socket.name) not in links:
                t.links.remove(l)


SEAM_GROUPS_UI = [("спинка", "спинці"), ("сидіння", "верху сидіння"), ("фронт", "фронті (фасад сидіння, передні панелі)"),
                  ("внутр. ліва", "ЛІВІЙ внутрішній боковині (і низу всередині кута зліва)"),
                  ("внутр. права", "ПРАВІЙ внутрішній боковині (і низу всередині кута справа)"),
                  ("зовн. ліва", "ЛІВІЙ зовнішній боковині дивана"),
                  ("зовн. права", "ПРАВІЙ зовнішній боковині дивана"), ("верх", "верхньому канті"),
                  ("задня стінка", "задній стінці (видно на 3/4 ззаду)"),
                  ("інше", "гранях, що не потрапили в жодну зону (дрібні шматочки)")]
SEAM_GROUP_KEYS = {"спинка": ("back",), "сидіння": ("seat",), "фронт": ("front",),
                   "внутр. ліва": ("in_l", "low_l"), "внутр. права": ("in_r", "low_r"),
                   "зовн. ліва": ("out_l",), "зовн. права": ("out_r",), "верх": ("top",), "задня стінка": ("rear",),
                   "інше": ()}                               # «інше» = решта (1 − Σ зон)


# v7.42: значення швів за замовчуванням = налаштування Євгена 2026-10-10 (нові повзунки в колег одразу такі)
SEAM_DEFAULTS = {"Шви: сила": 0.3, "Шви: ширина": 0.35, "Шви сидіння: сила ×": 1.5, "Шви сидіння: ширина ×": 1.2,
                 "Шви фронт: ширина ×": 1.4, "Шви внутр. права: сила ×": 2.0, "Шви сидіння, ліве крило: сила ×": 0.0,
                 "Шви сидіння ліве, фронт: сила ×": 0.0}


def build_interface(g):
    g.interface.clear()
    it = g.interface
    s = it.new_socket("Колір", in_out='INPUT', socket_type='NodeSocketColor')
    s.default_value = (0.5, 0.5, 0.5, 1); s.hide_value = True
    s.description = "Колір тканини (з Color Match) — не чіпати"
    it.new_socket("Колір", in_out='OUTPUT', socket_type='NodeSocketColor')

    def fsock(name, d, tip, panel, mn=0.0, mx=3.0):
        assert len(name.encode()) < 64, name
        d = SEAM_DEFAULTS.get(name, d)
        s = it.new_socket(name, in_out='INPUT', socket_type='NodeSocketFloat', parent=panel)
        s.default_value = d; s.min_value = mn; s.max_value = mx; s.description = tip

    def angle_socks(nm, what, panel):
        # v7.12: множники за РАКУРСОМ кадру: Ф = фронт-кадри, Л/П = кадри 3/4 з лівим/правим боком дивана. 1 = без змін
        for kind, kname in (("яскр.", "Яскравість"), ("нас.", "Насиченість")):
            # v7.50: задні ракурси окремо (користувач: «Л» на кадрі 24 (ззаду) міняв і 29 (спереду))
            for a, aname in (("Ф", "ФРОНТ-кадрах (інші ракурси не змінюються)"),
                             ("Л", "кадрах 3/4 СПЕРЕДУ, де видно ЛІВИЙ бік дивана (напр. 2, 29, 32)"),
                             ("П", "кадрах 3/4 СПЕРЕДУ, де видно ПРАВИЙ бік дивана (напр. 3, 23, 26)"),
                             ("ЗЛ", "кадрах ЗЗАДУ, де видно ЛІВИЙ бік дивана (напр. 10, 24, 27)"),
                             ("ЗП", "кадрах ЗЗАДУ, де видно ПРАВИЙ бік дивана (напр. 7, 30, 33)")):
                fsock(f"{nm}: {kind} {a}", 1.0, f"{what}: {kname.lower()} лише на {aname}. "
                      "Множник поверх основного значення, 1 = без змін", panel)

    p = it.new_panel("Загальне")
    fsock("Вся тканина: яскравість", 1.0, "Яскравість усієї тканини. 1 = без змін, менше = темніше", p)
    fsock("Вся тканина: насиченість", 1.0, "Насиченість усієї тканини. 1 = без змін, 0 = сіра", p)
    angle_socks("Вся тканина", "Уся тканина", p)
    fsock("Вся тканина: відтінок", 0.5, "Зсув відтінку. 0.5 = без змін; ±0.02 вже помітно", p, 0.0, 1.0)
    s = it.new_socket("Вся тканина: колір тону", in_out='INPUT', socket_type='NodeSocketColor', parent=p)
    s.default_value = (0.8, 0.7, 0.55, 1)
    s.description = ("Яким кольором дотонувати всю тканину. Береться відтінок — "
                     "яскравість тканини зберігається")
    fsock("Вся тканина: сила тону", 0.0, "Наскільки дотонувати всю тканину в колір тону. "
          "0 = без тону, 1 = повністю", p, 0.0, 1.0)
    # v7.24: звичайна заливка кольором (без збереження яскравості тканини) + відсоток змішування
    s = it.new_socket("Вся тканина: колір заливки", in_out='INPUT', socket_type='NodeSocketColor', parent=p)
    s.default_value = (0.5, 0.5, 0.5, 1)
    s.description = ("Простий колір, яким заливається вся текстура тканини (як шар кольору зверху). "
                     "На відміну від «колір тону» яскравість тканини НЕ зберігається")
    fsock("Вся тканина: сила заливки", 0.0, "Скільки змішати заливку з тканиною: 0 = без заливки, "
          "0.1 = 10 %, 1 = повністю цей колір", p, 0.0, 1.0)
    def corner_panel():
        p = it.new_panel("Фронт-кадри: кут біля боковини")
        fsock("Кут: ліва боковина", 1.0, "Лише на ФРОНТ-кадрах (3/4 не змінюються): яскравість внутрішньої "
              "грані ЛІВОГО підлокітника. 1 = без змін, більше = світліше (клієнт: кут не такий темний)", p)
        fsock("Кут: довжина боковини", 1.0, "Лише на ФРОНТ-кадрах: докуди внизу доходить підсвітка лівої боковини "
              "від стику зі спинкою вперед. 1 = майже до краю сидіння (без 2 см), 0.5 = до половини", p, 0.1, 2.0)
        fsock("Кут: спинка", 1.0, "Лише на ФРОНТ-кадрах: яскравість спинки поруч із ЛІВИМ підлокітником "
              "(тінь від нього). 1 = без змін; тінь дуже темна, тому тут потрібні великі значення (4-8)", p, 0.0, 12.0)
        fsock("Кут: ширина, см", 40.0, "Лише на ФРОНТ-кадрах: ширина трикутника біля СИДІННЯ, см від лівого "
              "підлокітника. Угорі трикутник сходиться в кут стику", p, 2.0, 100.0)
        fsock("Кут: згасання до країв", 0.0, "Лише на ФРОНТ-кадрах: як світло кута спадає до нуля В ТИХ САМИХ межах "
              "(ширина не змінюється). 0 = як було: біля кута рівна яскрава пляма, далі спад. 10 = світло починає "
              "зменшуватись одразу від кута і рівномірно, плавно доходить до 0 на краю", p, 0.0, 10.0)
        # v7.32: фасад сидіння біля виступу зліва (Г/П: модуль, що виступає вперед ЛІВОРУЧ, кадри 22, 25, 49, 76…)
        fsock("Кут: фасад сидіння", 1.0, "Лише на ФРОНТ-кадрах: яскравість фасаду сидіння (і низу під ним) біля "
              "модуля, що виступає вперед ЛІВОРУЧ (Г/П). 1 = без змін, більше = світліше", p)
        fsock("Кут: фасад, насиченість", 1.0, "Лише на ФРОНТ-кадрах: насиченість фасаду сидіння біля виступу "
              "ліворуч. 1 = без змін, менше = сіріше", p)
        fsock("Кут: фасад, ширина, см", 30.0, "На скільки см від кута плавно згасає підсвітка фасаду (до 0). "
              "Форма спаду — «Кут: фасад, згасання до країв»", p, 2.0, 100.0)

        # v7.49: власне згасання фасаду (користувач: «нема згасання по краю»); при оновленні бере значення спинки
        fsock("Кут: фасад, згасання до країв", 0.0, "Лише на ФРОНТ-кадрах: як підсвітка фасаду спадає до 0 у межах "
              "«фасад, ширина». 0 = м'який хвіст (світло швидко тане біля кута), 10 = рівномірно від кута до краю", p, 0.0, 10.0)
    def kutik_panel():
        p = it.new_panel("Кутик біля підлокітника")
        fsock("Кутик: яскравість", 1.0, "Вертикальна щілина на фронті між сидінням і підлокітником (боковиною). "
              "Менше 1 = темніше (клієнт просить затемнити)", p)
        fsock("Кутик: насиченість", 1.0, "Насиченість у щілині між сидінням і підлокітником. 1 = без змін", p)
        fsock("Кутик: розмір", 1.0, "Ширина затемнення в щілині. 1 = звичайна, 2 = ширше, 0.5 = вужче", p, 0.2, 4.0)
        fsock("Кутик: висота", 1.0, "До якої висоти доходить затемнення в щілині. 1 = до шва сидіння, "
              "менше = нижче, більше = вище", p, 0.3, 1.5)

    panels = {}
    for key, nm, pn, tip, _ in ZONES:
        if pn not in panels:
            if "Боковини праві" in panels:            # v7.25: блок «кут» одразу під боковинами
                if "_corner" not in panels:
                    corner_panel(); kutik_panel(); panels["_corner"] = True
            panels[pn] = it.new_panel(pn)
        fsock(f"{nm}: яскравість", 1.0, f"{tip}. Яскравість, 1 = без змін", panels[pn])
        fsock(f"{nm}: насиченість", 1.0, f"{tip}. Насиченість, 1 = без змін", panels[pn])
        fsock(f"{nm}: перехід", 0.0, f"{tip}. Плюс: наскільки плавно зміна цієї зони заходить на сусідні деталі, см "
              "(5-15 = м'який перехід). Мінус: зміна звужується до центру зони — від країв зони плавно до 0 "
              "на цій відстані, см. 0 = різко по шву", panels[pn], -30.0, 30.0)
        # v7.47: сила переходу (користувач: «перехід і сила переходу») — 1 = як було, 0 = переходу нема
        fsock(f"{nm}: сила", 1.0, f"{tip}. Наскільки сильно діє «перехід»: 1 = як було, 0.5 = удвічі слабше "
              "(плюс — менше заходить на сусідні деталі; мінус — менше звужує), 0 = переходу нема, 2 = сильніше",
              panels[pn], 0.0, 2.0)
        if key in ("in_l", "in_r", "back"):    # v7.51 (+v7.54 спинка: бічна частина кутового/одиночного модуля)
            fsock(f"{nm}: торець, см", 0.0, ("Біля ВІЛЬНОГО бічного краю спинки (одиночний модуль, край дивана) грань і так "
                  "освітлена — посилення робить там світлу смугу. " if key == "back" else
                  "Біля ПЕРЕДНЬОГО торця підлокітника внутрішня грань і так освітлена — посилення робило там світлу смугу. ")
                  + "На скільки см від краю зміна цієї зони плавно сходить на 0. 0 = вимкнено", panels[pn], 0.0, 40.0)
            # v7.56: яскравість самої смуги біля краю (край і без зони світлий — його треба ПРИГЛУШИТИ, напр. 0.85)
            fsock(f"{nm}: торець, яскр", 1.0, "Яскравість смуги біля цього краю (ширина — «торець, см»). 1 = без змін, "
                  "0.85 = трохи темніше: прибирає світлу смугу, яку дає саме світло, а не зона", panels[pn], 0.0, 2.0)
        angle_socks(nm, tip, panels[pn])
    p = it.new_panel("Шви")
    fsock("Шви: сила", 0.0, "Наскільки підкреслити ВСІ шви тканини (тінь у шві). 0 = вимкнено, 0.3 = як у файлі "
          "диванів, 1 = чорний шов. Діє на всі моделі сцени", p, 0.0, 1.0)
    fsock("Шви: ширина", 0.35, "Повна ширина тіні шва, см (по половині з кожного боку). Напр. 0.35", p, 0.02, 3.0)
    # v7.33: шви по зонах (користувач: на Г-диванах фронт — дуже темний шов на внутр. боковині, слабкий на сидінні)
    for nm, what in SEAM_GROUPS_UI:
        fsock(f"Шви {nm}: сила ×", 1.0, f"Множник сили шва на {what}. 1 = як «Шви: сила», 0.5 = вдвічі слабше, "
              "2 = вдвічі темніше", p, 0.0, 4.0)
        fsock(f"Шви {nm}: ширина ×", 1.0, f"Множник ширини тіні шва на {what}. 1 = як «Шви: ширина», "
              "2 = удвічі ширше", p, 0.1, 4.0)
    # v7.35: швів СИДІННЯ на крилі кутового дивана (модуль, що виступає вперед за задній ряд) — окремо від решти сидінь
    for nm, what in (("ліве крило", "ЛІВОГО крила кутового дивана (модулі, що виступають уперед зліва; кадри 22, 49, 76…)"),
                     ("праве крило", "ПРАВОГО крила кутового дивана (виступ справа; кадри 28, 46, 79…)")):
        fsock(f"Шви сидіння, {nm}: сила ×", 1.0, f"Сила шва СИДІННЯ лише ЗБОКУ (край сидіння біля бічної грані, не фронт) на сидіннях {what}. Множиться на «Шви сидіння». "
              "Інші шви крила не змінює. 1 = як решта сидінь", p, 0.0, 4.0)
        fsock(f"Шви сидіння, {nm}: ширина ×", 1.0, f"Ширина шва СИДІННЯ лише ЗБОКУ (не фронт) на сидіннях {what}. 1 = як решта сидінь",
              p, 0.1, 4.0)
    # v7.45: ті самі повзунки лише для ФРОНТ-кадрів (верхні діють на всі кадри крім фронту)
    for nm, what in (("ліве", "ЛІВОГО крила кутового дивана (кадри 22, 49, 76…)"),
                     ("праве", "ПРАВОГО крила кутового дивана (кадри 28, 46, 79…)")):
        fsock(f"Шви сидіння {nm}, фронт: сила ×", 1.0, f"Лише на ФРОНТ-кадрах: сила шва СИДІННЯ ЗБОКУ (не фронт) на {what}. "
              "Множиться на «Шви сидіння». Повзунки «крило» без «фронт» діють на решті кадрів. 1 = як решта сидінь", p, 0.0, 4.0)
        fsock(f"Шви сидіння {nm}, фронт: ширина ×", 1.0, f"Лише на ФРОНТ-кадрах: ширина шва СИДІННЯ ЗБОКУ (не фронт) на {what}. "
              "1 = як решта сидінь", p, 0.1, 4.0)
    # v7.60: стик модулів ЛІВОГО КРИЛА (стики, що йдуть углиб, зліва) — лише фронт-кадри; UV-шва там нема
    fsock("Шви стик ліве крило: сила ×", 0.0, "Лише на ФРОНТ-кадрах, лише ЛІВЕ крило кутового дивана (кадри 22, 49, 76…): темна лінія там, де "
          "модулі крила стоять впритул (верх, заокруглення і торець у щілині). Множиться на «Шви: сила». "
          "0 = вимкнено, 1 = як звичайні шви, 3 = утричі темніше", p, 0.0, 10.0)
    fsock("Шви стик ліве крило: ширина ×", 2.0, "Ширина лінії стику лівого крила, см від стику (на модулі ближче до нас — учетверо більше: тінь у наш бік; "
          "разом із заокругленням). Вниз по торцю у щілині — на ширину + 1 см", p, 0.2, 10.0)
    p = it.new_panel("Перевірка і плавність", default_closed=True)
    fsock("Плавність переходів", 1.0, "Ширина плавного переходу між зонами на скругленнях і стиках деталей. "
          "1 = звичайна, 2-3 = м'якше, 0.3 = різкіше", p, 0.2, 4.0)
    fsock("М'якість спаду переходу", 1.6, "Наскільки плавно згасає «перехід» зон: 1 = як було (коротший край), "
          "1.6 = довший м'який хвіст, 2.5-3 = дуже розтягнуто. Діє на всі зони", p, 1.0, 3.0)
    s = it.new_socket("Показати зони", in_out='INPUT', socket_type='NodeSocketBool', parent=p)
    s.default_value = False
    s.description = ("Замість тканини показати зони кольорами: синій спинка, зелений сидіння, рожевий/фіолетовий "
                     "внутр. ліва/права, помаранчевий/коричневий зовн. ліва/права, жовтий верх, "
                     "червоний фронт, бірюзовий задня стінка")


def build_nodes(g):
    if g.animation_data:
        g.animation_data_clear()
    g.nodes.clear()
    N, L = g.nodes, g.links
    gi = N.new('NodeGroupInput'); gi.location = (-2600, 0)
    go = N.new('NodeGroupOutput'); go.location = (1700, 0)
    y = [1600]
    K = None                                   # «Плавність переходів», не менше 0.1 (0 зламав би переходи)

    def nxt():
        y[0] -= 45
        return y[0]

    def math(op, a, b=None, c=None, x=-900, clamp=False, label=None):
        n = N.new('ShaderNodeMath'); n.operation = op; n.location = (x, nxt()); n.use_clamp = clamp
        if label:
            n.label = label
        for i, v in enumerate((a, b, c)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                n.inputs[i].default_value = v
            else:
                L.new(v, n.inputs[i])
        return n.outputs[0]

    def ss(v, a, b, x=-900):                    # фіксований smoothstep
        n = N.new('ShaderNodeMapRange'); n.interpolation_type = 'SMOOTHSTEP'; n.location = (x, nxt())
        n.inputs["From Min"].default_value = a; n.inputs["From Max"].default_value = b
        L.new(v, n.inputs["Value"])
        return n.outputs[0]

    def ssk(v, c, w, x=-900):                   # smoothstep з шириною w * «Плавність переходів»
        hw = math('MULTIPLY', K, w, x=x)
        n = N.new('ShaderNodeMapRange'); n.interpolation_type = 'SMOOTHSTEP'; n.location = (x, nxt())
        L.new(math('SUBTRACT', c, hw, x=x), n.inputs["From Min"])
        L.new(math('ADD', c, hw, x=x), n.inputs["From Max"])
        L.new(v, n.inputs["Value"])
        return n.outputs[0]

    def sep(vec, x=-2000):
        n = N.new('ShaderNodeSeparateXYZ'); n.location = (x, nxt()); L.new(vec, n.inputs[0])
        return n.outputs

    def attr(name):
        a = N.new('ShaderNodeAttribute'); a.attribute_type = 'GEOMETRY'; a.attribute_name = name
        a.location = (-2300, nxt()); a.label = name
        return sep(a.outputs["Vector"])

    K = math('MAXIMUM', gi.outputs["Плавність переходів"], 0.1, x=-2300)

    # ---- кут збірки (драйвер без Python) ----
    ang = N.new('ShaderNodeValue'); ang.name = ang.label = "CFG_ANGLE"; ang.location = (-2400, 1500)
    rot = bpy.data.objects.get(ROT_OBJ)
    if rot:
        fc = g.driver_add('nodes["CFG_ANGLE"].outputs[0].default_value')
        drv = fc.driver; drv.type = 'AVERAGE'
        v = drv.variables.new(); v.name = "rz"; v.type = 'TRANSFORMS'
        v.targets[0].id = rot; v.targets[0].transform_type = 'ROT_Z'; v.targets[0].transform_space = 'WORLD_SPACE'

    def to_cfg(vec_out, frm='OBJECT'):
        if frm == 'OBJECT':
            vt = N.new('ShaderNodeVectorTransform'); vt.vector_type = 'VECTOR'; vt.convert_from = 'OBJECT'
            vt.convert_to = 'WORLD'; vt.location = (-2000, nxt()); L.new(vec_out, vt.inputs[0]); vec_out = vt.outputs[0]
        r = N.new('ShaderNodeVectorRotate'); r.rotation_type = 'Z_AXIS'; r.invert = True; r.location = (-1800, nxt())
        L.new(vec_out, r.inputs["Vector"]); L.new(ang.outputs[0], r.inputs["Angle"])
        return sep(r.outputs[0], x=-1600)

    geo = N.new('ShaderNodeNewGeometry'); geo.location = (-2400, 1300)
    tc = N.new('ShaderNodeTexCoord'); tc.location = (-2400, 1100)
    # нормаль форми з атрибута (Geometry.Normal містить рельєф тканини -> шум у масках)
    an = N.new('ShaderNodeAttribute'); an.attribute_type = 'GEOMETRY'; an.attribute_name = "fz5_n"
    an.location = (-2400, 1250); an.label = "нормаль форми"
    nn = N.new('ShaderNodeVectorMath'); nn.operation = 'NORMALIZE'; nn.location = (-2200, 1300)
    L.new(an.outputs["Vector"], nn.inputs[0])
    nox, noy, noz = sep(nn.outputs[0])                   # гладка нормаль у координатах модуля
    px, py, pz = sep(tc.outputs["Object"])               # точна позиція в координатах модуля
    ncx, ncy, _ = to_cfg(nn.outputs[0])                  # нормаль у координатах збірки
    # v7.12: Ф/Л/П — за РАКУРСОМ КАДРУ (поворот збірки CFG_ANGLE), а не за гранню: одне значення на весь кадр,
    # тож повзунок одного ракурсу не чіпає інші (v7.11 за кутом грані фарбував сидіння/верх на всіх кадрах).
    # Ф = фронт-кадр (0°); Л = 3/4, де видно ЛІВИЙ бік дивана (sin кута > 0: кадри 2, 24, 27, 29…);
    # П = 3/4, де видно ПРАВИЙ бік (sin < 0: кадри 3, 23, 26, 30…). Перевірено по Control_Rotation.
    sn_a = math('SINE', ang.outputs[0], x=-1600)
    A_F = math('SUBTRACT', 1.0, ss(math('ABSOLUTE', sn_a, x=-1600), 0.1, 0.3, x=-1600), x=-1600, label="ракурс: Ф")
    # v7.50: ЗЛ/ЗП = задні ракурси (cos кута < 0: 145-150° і 210-235°), Л/П — лише передні 3/4
    cs_a = math('COSINE', ang.outputs[0], x=-1600)
    back_v = math('LESS_THAN', cs_a, 0.0, x=-1600)
    front_v = math('SUBTRACT', 1.0, back_v, x=-1600)
    side_l = math('MULTIPLY', math('SUBTRACT', 1.0, A_F, x=-1600), math('GREATER_THAN', sn_a, 0.0, x=-1600), x=-1600)
    side_r = math('MULTIPLY', math('SUBTRACT', 1.0, A_F, x=-1600), math('LESS_THAN', sn_a, 0.0, x=-1600), x=-1600)
    A_L = math('MULTIPLY', side_l, front_v, x=-1600, label="ракурс: Л")
    A_R = math('MULTIPLY', side_r, front_v, x=-1600, label="ракурс: П")
    A_ZL = math('MULTIPLY', side_l, back_v, x=-1600, label="ракурс: ЗЛ")
    A_ZR = math('MULTIPLY', side_r, back_v, x=-1600, label="ракурс: ЗП")

    def angle_mult(nm, kind):                  # Ф*wF + Л*wL + П*wR
        k = "яскр." if kind == "яскравість" else "нас."
        t = math('MULTIPLY', gi.outputs[f"{nm}: {k} Ф"], A_F, x=-400)
        t = math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} Л"], A_L, t, x=-400)
        t = math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} ЗЛ"], A_ZL, t, x=-400)
        t = math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} ЗП"], A_ZR, t, x=-400)
        return math('MULTIPLY_ADD', gi.outputs[f"{nm}: {k} П"], A_R, t, x=-400)
    xmin, xmax, ymin = attr("fz5_a")
    ymax, zmin, _ = attr("fz5_b")
    scx, scy, hasB = attr("fz5_c")
    hasL, hasR, _ = attr("fz5_d")
    bx0, bx1, ayl = attr("fz5_e")
    ayr, _, _ = attr("fz5_f")
    nxl, nxr, nfl = attr("fz5_g")
    nfr, is_corner, nby = attr("fz5_h")
    # кутовий модуль: кутик лише якщо його боковина на краю збірки (fz_corner_arm = 1); у середині — сусід перед нею
    ca = N.new('ShaderNodeAttribute'); ca.attribute_type = 'OBJECT'; ca.attribute_name = "fz_corner_arm"
    ca.location = (-2300, nxt()); ca.label = "кутовий на краю"
    corner_ok = math('SUBTRACT', 1.0, math('MULTIPLY', is_corner, math('SUBTRACT', 1.0, ca.outputs["Fac"])))
    nfl = math('MULTIPLY', nfl, corner_ok)
    B = 0.27
    zr = math('SUBTRACT', pz, zmin, x=-1600)

    # ---- ПАНЕЛІ (UV-острови): тип зони цілою панеллю, межа = шов ----
    def fattr(name):
        a_ = N.new('ShaderNodeAttribute'); a_.attribute_type = 'GEOMETRY'; a_.attribute_name = name
        a_.location = (-2300, nxt()); a_.label = name
        return a_
    a_ts = fattr("fz6_ts").outputs["Fac"]
    a_in = fattr("fz6_in").outputs["Fac"]
    ldx, ldy, _ = sep(fattr("fz6_ld").outputs["Vector"])
    top = math('COMPARE', a_ts, 1.0, 0.25, label="ZONE top")
    seat = math('COMPARE', a_ts, 2.0, 0.25, label="ZONE seat")
    V = math('SUBTRACT', math('SUBTRACT', 1.0, top), seat, clamp=True)
    inner_p = math('MULTIPLY', V, a_in)                      # внутрішня панель
    ext = math('SUBTRACT', V, inner_p, clamp=True)           # зовнішня панель

    # блоки деталей (для стиків у щілинах між модулями)
    above = ss(zr, 0.22, 0.26)
    inb = math('MULTIPLY', hasB, ssk(math('SUBTRACT', py, math('SUBTRACT', ymax, B)), 0.0, 0.015))
    inb = math('MULTIPLY', inb, math('MULTIPLY', ssk(math('SUBTRACT', px, bx0), 0.0, 0.015),
                                     ssk(math('SUBTRACT', bx1, px), 0.0, 0.015)))
    inl = math('MULTIPLY', hasL, ssk(math('SUBTRACT', math('ADD', xmin, B), px), 0.0, 0.015))
    inl = math('MULTIPLY', inl, ssk(math('SUBTRACT', py, ayl), 0.0, 0.015))
    inr = math('MULTIPLY', hasR, ssk(math('SUBTRACT', px, math('SUBTRACT', xmax, B)), 0.0, 0.015))
    inr = math('MULTIPLY', inr, ssk(math('SUBTRACT', py, ayr), 0.0, 0.015))
    arm = math('MAXIMUM', inl, inr)
    backpart = math('MULTIPLY', above, math('MULTIPLY', inb, math('SUBTRACT', 1.0, arm)))
    armpart = math('MULTIPLY', above, arm)
    cs = math('MULTIPLY_ADD', ssk(math('SUBTRACT', math('MULTIPLY', math('ADD', xmin, xmax), 0.5), px), 0.0, 0.02), 2.0, -1.0)

    # ---- промені уздовж головної осі збірки (стики й погляд на інший модуль) ----
    use_x = math('GREATER_THAN', math('ABSOLUTE', ncx), math('ABSOLUTE', ncy), x=-1500)
    sgx, sgy = math('SIGN', ncx, x=-1500), math('SIGN', ncy, x=-1500)
    dcx = math('MULTIPLY', use_x, sgx, x=-1500)
    dcy = math('MULTIPLY', math('SUBTRACT', 1.0, use_x, x=-1500), sgy, x=-1500)

    def ray(off):
        """Промінь з точки, зсунутої вбік (поперек напряму) на off метрів."""
        hd = N.new('ShaderNodeCombineXYZ'); hd.location = (-1400, nxt())
        L.new(dcx, hd.inputs[0]); L.new(dcy, hd.inputs[1])
        dw = N.new('ShaderNodeVectorRotate'); dw.rotation_type = 'Z_AXIS'; dw.location = (-1300, nxt())
        L.new(hd.outputs[0], dw.inputs["Vector"]); L.new(ang.outputs[0], dw.inputs["Angle"])
        side = N.new('ShaderNodeVectorRotate'); side.rotation_type = 'Z_AXIS'; side.location = (-1300, nxt())
        L.new(dw.outputs[0], side.inputs["Vector"]); side.inputs["Angle"].default_value = 1.5708
        o1 = N.new('ShaderNodeVectorMath'); o1.operation = 'MULTIPLY_ADD'; o1.location = (-1200, nxt())
        L.new(side.outputs[0], o1.inputs[0]); o1.inputs[1].default_value = (off, off, 0.0)
        L.new(geo.outputs["Position"], o1.inputs[2])
        o2 = N.new('ShaderNodeVectorMath'); o2.operation = 'MULTIPLY_ADD'; o2.location = (-1200, nxt())
        L.new(dw.outputs[0], o2.inputs[0]); o2.inputs[1].default_value = (0.004, 0.004, 0.004)
        L.new(o1.outputs[0], o2.inputs[2])
        rc = N.new('ShaderNodeRaycast'); rc.location = (-1100, nxt())
        L.new(o2.outputs[0], rc.inputs["Position"]); L.new(dw.outputs[0], rc.inputs["Direction"])
        rc.inputs["Length"].default_value = RAY_LEN
        _, hy, hz = sep(rc.outputs["Hit Position"], x=-1000)
        other = math('MULTIPLY', math('SUBTRACT', rc.outputs["Is Hit"], rc.outputs["Self Hit"], clamp=True),
                     math('MULTIPLY', math('LESS_THAN', hy, STAGE_Y), math('GREATER_THAN', hz, 0.03)))
        return other, rc.outputs["Hit Distance"]

    o0, d0 = ray(0.0)
    near = math('SUBTRACT', 1.0, ss(d0, 0.06, 0.12))
    joint = math('MULTIPLY', math('MULTIPLY', o0, near), ext, label="стик")
    # один точний промінь (бічні промені зачіпали сусідній шезлонг і «заливали» фронт біля стику)
    far = math('MULTIPLY', math('MULTIPLY', o0, ss(d0, 0.08, 0.16)),
               math('SUBTRACT', 1.0, ss(d0, RAY_LEN * 0.8, RAY_LEN)))
    ext_far = math('MULTIPLY', math('SUBTRACT', ext, joint, clamp=True), far); ext_far.node.label = 'DBG ext_far'
    # стик = продовження своєї деталі: у блоці спинки/підлокітника -> внутрішня деталь, інакше зовнішня
    bsum = math('MAXIMUM', math('ADD', backpart, armpart), 0.0001)
    jin = math('MINIMUM', math('ADD', backpart, armpart), 1.0)
    jb = math('MULTIPLY', math('MULTIPLY', joint, jin), math('DIVIDE', backpart, bsum))
    ja = math('MULTIPLY', math('MULTIPLY', joint, jin), math('DIVIDE', armpart, bsum))
    outer = math('SUBTRACT', math('SUBTRACT', ext, ext_far), math('ADD', jb, ja), clamp=True)

    # ---- напрями ----
    # деталь спинки дивиться локально (0,-1), підлокітник (cs,0) -> у координатах збірки
    bdv = N.new('ShaderNodeCombineXYZ'); bdv.location = (-1400, nxt()); bdv.inputs[1].default_value = -1.0
    bdx, bdy, _ = to_cfg(bdv.outputs[0])
    adv = N.new('ShaderNodeCombineXYZ'); adv.location = (-1400, nxt()); L.new(cs, adv.inputs[0])
    adx, ady, _ = to_cfg(adv.outputs[0])

    def mix(f, a, b):                         # a + (b-a)*f
        return math('MULTIPLY_ADD', math('SUBTRACT', b, a), f, a)

    def split(xv, yv):                        # (вздовж X, X>0, вздовж Y, Y>0) — гладко
        dX = ssk(math('SUBTRACT', math('ABSOLUTE', xv), math('ABSOLUTE', yv)), 0.0, 0.1)
        return dX, math('GREATER_THAN', xv, 0.0), math('SUBTRACT', 1.0, dX), math('GREATER_THAN', yv, 0.0)

    bX, bXp, bY, _ = split(bdx, bdy)
    aX, aXp, aY, _ = split(adx, ady)
    nX, nXp, nY, nYp = split(ncx, ncy)
    # внутрішня панель: напрям її деталі (з fz6_ld), якщо є; інакше — за нормаллю
    pld = N.new('ShaderNodeCombineXYZ'); pld.location = (-1400, nxt())
    L.new(ldx, pld.inputs[0]); L.new(ldy, pld.inputs[1])
    pdx, pdy, _ = to_cfg(pld.outputs[0])
    has_pd = math('GREATER_THAN', math('ADD', math('ABSOLUTE', ldx), math('ABSOLUTE', ldy)), 0.5)
    pX, pXp, pY, _ = split(mix(has_pd, ncx, pdx), mix(has_pd, ncy, pdy))
    IB = jb                                    # стик у блоці спинки
    IA = ja                                    # стик у блоці підлокітника
    IP = inner_p                               # внутрішня панель
    RN = ext_far                               # зовнішня панель, що дивиться на інший модуль (П-збірка)

    def inner_side(pos):                       # внутрішні грані, що дивляться вздовж +X (pos) / -X
        def part(w, dX, dXp):
            return math('MULTIPLY', math('MULTIPLY', w, dX), dXp if pos else math('SUBTRACT', 1.0, dXp))
        return math('ADD', math('ADD', math('ADD', part(IB, bX, bXp), part(IA, aX, aXp)), part(RN, nX, nXp)),
                    part(IP, pX, pXp))

    zone = {
        "back": math('ADD', math('ADD', math('ADD', math('MULTIPLY', IB, bY), math('MULTIPLY', IA, aY)),
                                 math('MULTIPLY', RN, nY)), math('MULTIPLY', IP, pY)),
        "seat": seat,
        "in_l": inner_side(True),              # ліва боковина дивиться праворуч (+X)
        "in_r": inner_side(False),
        "out_l": math('MULTIPLY', math('MULTIPLY', outer, nX), math('SUBTRACT', 1.0, nXp)),
        "out_r": math('MULTIPLY', math('MULTIPLY', outer, nX), nXp),
        "top": top,
        "front": math('MULTIPLY', math('MULTIPLY', outer, nY), math('SUBTRACT', 1.0, nYp)),
        "rear": math('MULTIPLY', math('MULTIPLY', outer, nY), nYp),
    }
    for k, sock in zone.items():
        sock.node.label = "ZONE " + k

    rN = math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.05)

    def notch(nx, flag, arm_neg):
        # V-щілина між скругленими передніми кромками сидіння й підлокітника (виміряно: від ~0.15 м над низом
        # оббивки до верху сидіння, глибина кількох см). Маска: втоплено за фронт на 3 мм…7 см (далі — ні,
        # інакше смуга по всій глибині модуля й ззаду), поруч із лінією щілини по X, по висоті — сама V.
        dep = math('SUBTRACT', py, ymin)
        in_dep = math('MULTIPLY', ss(dep, 0.0015, 0.008), math('SUBTRACT', 1.0, ss(dep, 0.07, 0.10)))
        dx = math('ABSOLUTE', math('SUBTRACT', px, nx))
        near_x = math('SUBTRACT', 1.0, ssk(dx, math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.055), 0.015))
        # лише бік ПІДЛОКІТНИКА в щілині (сидіння — інший бік V — не чіпаємо)
        side_v = math('SUBTRACT', nx, px) if arm_neg else math('SUBTRACT', px, nx)
        arm_side = ss(side_v, -0.004, 0.004)
        return math('MULTIPLY', flag, math('MULTIPLY', math('MULTIPLY', in_dep, near_x), arm_side))
    # верх затемнення: трохи вище шва сидіння на фронті (шов 0.258 м над низом оббивки) × «Кутик: висота»
    top_h = math('MULTIPLY', gi.outputs["Кутик: висота"], 0.258)
    top_f = N.new('ShaderNodeMapRange'); top_f.interpolation_type = 'SMOOTHSTEP'; top_f.location = (-900, nxt())
    L.new(top_h, top_f.inputs["From Min"]); L.new(math('ADD', top_h, 0.017), top_f.inputs["From Max"])
    L.new(zr, top_f.inputs["Value"])
    hz = math('MULTIPLY', ss(zr, 0.13, 0.17), math('SUBTRACT', 1.0, top_f.outputs[0]))   # не вище сидіння
    # кутовий на краю, де підлокітником працює основна спинка: щілина біля її внутрішньої грані (y = nby),
    # «фронт» модуля тут — площина x = xmax
    ca1 = N.new('ShaderNodeAttribute'); ca1.attribute_type = 'OBJECT'; ca1.attribute_name = "fz_corner_arm1"
    ca1.location = (-2300, nxt()); ca1.label = "основна спинка кутового на краю"
    dep_c = math('SUBTRACT', xmax, px)
    in_dep_c = math('MULTIPLY', ss(dep_c, 0.0015, 0.008), math('SUBTRACT', 1.0, ss(dep_c, 0.07, 0.10)))
    near_c = math('SUBTRACT', 1.0, ssk(math('ABSOLUTE', math('SUBTRACT', py, nby)),
                                     math('MULTIPLY', gi.outputs["Кутик: розмір"], 0.055), 0.015))
    arm_side_c = ss(math('SUBTRACT', py, nby), -0.004, 0.004)
    notch_c = math('MULTIPLY', math('MULTIPLY', is_corner, ca1.outputs["Fac"]),
                   math('MULTIPLY', math('MULTIPLY', in_dep_c, near_c), arm_side_c))
    notch_m = math('MULTIPLY', math('MAXIMUM', math('MAXIMUM', notch(nxl, nfl, True), notch(nxr, nfr, False)), notch_c), hz,
                   label="ZONE notch")
    # пензель (шар кольору fz_kutik у меші): R = дорисувати, G = стерти; шару нема -> чорний -> без змін
    kb = N.new('ShaderNodeVertexColor'); kb.layer_name = "fz_kutik"; kb.location = (-1000, nxt()); kb.label = "Кутик: пензель"
    ksp = N.new('ShaderNodeSeparateColor'); ksp.location = (-850, nxt()); L.new(kb.outputs["Color"], ksp.inputs[0])
    notch_m = math('MAXIMUM', math('MULTIPLY', notch_m, math('SUBTRACT', 1.0, ksp.outputs[1], clamp=True)),
                   ksp.outputs[0], label="ZONE notch + пензель")

    # ---- м'які ваги зон (v7.1): облямівка лише навколо САМОЇ зони — відстань до її граней (fz7_*),
    #      напрям граней у координатах меша переводимо в координати збірки (модулі повернуті на 90°*k)
    def vattr(name):
        a_ = N.new('ShaderNodeAttribute'); a_.attribute_type = 'GEOMETRY'; a_.attribute_name = name
        a_.location = (-2300, nxt()); a_.label = name
        return sep(a_.outputs["Vector"])
    dTop, dSeat, _ = vattr("fz7_a")
    eXp, eXn, eYp = vattr("fz7_b")
    eYn, iXp, iXn = vattr("fz7_c")
    iYp, iYn, _ = vattr("fz7_d")

    def cdir(x, y_):
        v = N.new('ShaderNodeCombineXYZ'); v.location = (-1400, nxt())
        v.inputs[0].default_value = x; v.inputs[1].default_value = y_
        cx, cy, _ = to_cfg(v.outputs[0])
        return cx, cy
    Q = {"+X": cdir(1, 0), "-X": cdir(-1, 0), "+Y": cdir(0, 1), "-Y": cdir(0, -1)}
    # v7.2: сторона модуля, що впирається в сусіда (стик), не дає «переходу» зовнішнім зонам
    ex = N.new('ShaderNodeAttribute'); ex.attribute_type = 'OBJECT'; ex.attribute_name = "fz7_exp"
    ex.location = (-2300, nxt()); ex.label = "вільні сторони модуля (fz7_exp)"
    exs = N.new('ShaderNodeSeparateColor'); exs.location = (-2100, nxt()); L.new(ex.outputs["Color"], exs.inputs[0])
    EXP = {"+X": exs.outputs[0], "-X": exs.outputs[1], "+Y": exs.outputs[2], "-Y": ex.outputs["Alpha"]}

    def free(d, e):                            # стик -> «далеко» (1 м)
        return math('ADD', math('MULTIPLY', d, e), math('SUBTRACT', 1.0, e))
    EXT = {k: free(v, EXP[k]) for k, v in {"+X": eXp, "-X": eXn, "+Y": eYp, "-Y": eYn}.items()}
    INN = {"+X": iXp, "-X": iXn, "+Y": iYp, "-Y": iYn}

    def neg(v):
        return math('MULTIPLY', v, -1.0)

    # v7.7: «Боковина зовн.» лише біля крайнього лівого/правого краю ВСІЄЇ збірки. fz7_asm = габарити збірки
    # у координатах цього модуля -> від повороту/зсуву кадру не залежить. Яка сторона модуля «права» в збірці — з Q.
    asm = N.new('ShaderNodeAttribute'); asm.attribute_type = 'OBJECT'; asm.attribute_name = "fz7_asm"
    asm.location = (-2300, nxt()); asm.label = "габарити збірки в модулі (fz7_asm)"
    asp = N.new('ShaderNodeSeparateColor'); asp.location = (-2100, nxt()); L.new(asm.outputs["Color"], asp.inputs[0])
    a_x0, a_x1, a_y0, a_y1 = asp.outputs[0], asp.outputs[1], asp.outputs[2], asm.outputs["Alpha"]
    no_asm = math('LESS_THAN', math('SUBTRACT', a_x1, a_x0), 0.1)              # нема властивості -> як раніше
    DSIDE = {"+X": math('SUBTRACT', a_x1, px), "-X": math('SUBTRACT', px, a_x0),
             "+Y": math('SUBTRACT', a_y1, py), "-Y": math('SUBTRACT', py, a_y0)}

    def edge_dist(comp):                            # відстань до краю збірки з боку, що в збірці дивиться в comp
        acc = None
        for k, (cx, cy) in Q.items():
            t = math('MULTIPLY', ss(comp(cx, cy), 0.5, 0.9), DSIDE[k])
            acc = t if acc is None else math('ADD', acc, t)
        return acc

    def gate(d, far, near_):
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHSTEP'; n_.location = (-1500, nxt())
        n_.inputs["From Min"].default_value = far; n_.inputs["From Max"].default_value = near_
        L.new(d, n_.inputs["Value"])
        return math('MAXIMUM', n_.outputs[0], no_asm)
    # v7.8: відстань до краю збірки ВЗДОВЖ ВЛАСНОЇ НОРМАЛІ грані (у координатах модуля) — не залежить від того,
    # як модуль повернутий (кадр 4: шезлонг сам під ~45°, через Q сторона ділилась навпіл)
    lX_, lXp_, _, lYp_ = split(nox, noy)
    dX = math('MULTIPLY_ADD', math('SUBTRACT', DSIDE["+X"], DSIDE["-X"]), lXp_, DSIDE["-X"])
    dY = math('MULTIPLY_ADD', math('SUBTRACT', DSIDE["+Y"], DSIDE["-Y"]), lYp_, DSIDE["-Y"])
    d_n = math('MULTIPLY_ADD', math('SUBTRACT', dX, dY), lX_, dY)
    g_n = gate(d_n, 0.18, 0.10)
    zone["out_r"] = math('MULTIPLY', zone["out_r"], g_n)
    zone["out_l"] = math('MULTIPLY', zone["out_l"], g_n)
    edge_rw = edge_lw = gate(d_n, 0.48, 0.40)

    def pick(D, comp):                         # відстань до граней, що в збірці дивляться в потрібний бік
        acc = wsum = None
        for k, (cx, cy) in Q.items():
            w = ss(comp(cx, cy), 0.5, 0.9)
            t = math('MULTIPLY', w, D[k])
            acc = t if acc is None else math('ADD', acc, t)
            wsum = w if wsum is None else math('ADD', wsum, w)
        return math('ADD', acc, math('SUBTRACT', 1.0, wsum, clamp=True))   # нема таких граней -> далеко
    DZ = {"top": dTop, "seat": dSeat,
          "front": pick(EXT, lambda cx, cy: neg(cy)), "rear": pick(EXT, lambda cx, cy: cy),
          "out_l": pick(EXT, lambda cx, cy: neg(cx)), "out_r": pick(EXT, lambda cx, cy: cx),
          "in_l": pick(INN, lambda cx, cy: cx), "in_r": pick(INN, lambda cx, cy: neg(cx)),
          "back": math('MINIMUM', pick(INN, lambda cx, cy: cy), pick(INN, lambda cx, cy: neg(cy)))}
    # v7.22: «Низ внутр.» — вертикальні грані нижче верху подушки (0.31 м над низом оббивки), що дивляться вздовж ±X
    # збірки, крім зовнішніх боків/фронту/заду; забирають ці грані у «Боковина внутр.» (у П) і в «без зони» (у Г)
    # v7.23 (користувач: «впливає на багато інших панелей, навіть на спинку; хай доходить до верху бортика»):
    # не за висотою, а за типом деталі — ЗОВНІШНЯ панель ніжки, що дивиться вбік усередину Г/П:
    #  П: зовнішня панель, що через кут дивиться на інший модуль (RN = ext_far);
    #  Г: зовнішня панель, що дивиться вбік, але НЕ крайній бік усього дивана (те, що g_n прибрав з «зовн.»).
    # Стики між модулями (jb/ja), внутрішні панелі (спинки, подушки) сюди не входять; бортик — на всю висоту.
    side_free = math('MULTIPLY', outer, math('SUBTRACT', 1.0, g_n))
    low_b = math('MULTIPLY', math('MINIMUM', math('ADD', RN, side_free), 1.0), nX)
    # v7.27: не щілини між модулями (прямий диван, кадри 25/58 — тонкі смужки): промінь ТОЧНО вбік по ±X збірки
    # на 15 см; влучив у сусідній модуль -> щілина, не бортик. (v7.26 через fz7_exp губив бік шезлонга, кадр 70)
    sdx = N.new('ShaderNodeCombineXYZ'); sdx.location = (-1400, nxt()); L.new(math('SIGN', ncx), sdx.inputs[0])
    sdw = N.new('ShaderNodeVectorRotate'); sdw.rotation_type = 'Z_AXIS'; sdw.location = (-1300, nxt())
    L.new(sdx.outputs[0], sdw.inputs["Vector"]); L.new(ang.outputs[0], sdw.inputs["Angle"])
    sp0 = N.new('ShaderNodeVectorMath'); sp0.operation = 'MULTIPLY_ADD'; sp0.location = (-1200, nxt())
    L.new(sdw.outputs[0], sp0.inputs[0]); sp0.inputs[1].default_value = (0.004, 0.004, 0.004)
    L.new(geo.outputs["Position"], sp0.inputs[2])
    src = N.new('ShaderNodeRaycast'); src.location = (-1100, nxt())
    L.new(sp0.outputs[0], src.inputs["Position"]); L.new(sdw.outputs[0], src.inputs["Direction"])
    src.inputs["Length"].default_value = 0.15
    gap = math('SUBTRACT', src.outputs["Is Hit"], src.outputs["Self Hit"], clamp=True)
    low_b = math('MULTIPLY', low_b, math('SUBTRACT', 1.0, gap))
    zone["low_l"] = math('MULTIPLY', low_b, nXp, label="ZONE low_l")
    zone["low_r"] = math('MULTIPLY', low_b, math('SUBTRACT', 1.0, nXp), label="ZONE low_r")
    zone["in_l"] = math('MULTIPLY', zone["in_l"], math('SUBTRACT', 1.0, zone["low_l"]))
    zone["in_r"] = math('MULTIPLY', zone["in_r"], math('SUBTRACT', 1.0, zone["low_r"]))
    # v7.51: «торець, см» — відстань від переднього кінця підлокітника (ayl/ayr = його перед у координатах модуля),
    # лівий/правий підлокітник модуля — за боком точки; зона плавно 0 -> 1 на цій відстані
    side_lx = math('LESS_THAN', px, math('MULTIPLY', math('ADD', xmin, xmax), 0.5))
    d_tor = math('SUBTRACT', py, mix(side_lx, ayr, ayl))
    # v7.54: спинка — торець від ВІЛЬНОГО бічного краю модуля (одиночний Armless: край спинки відкритий, світлий);
    # бік, що впирається в сусіда (fz7_exp = 0), не рахується (+10 м)
    d_bend = math('MINIMUM',
                  math('ADD', math('SUBTRACT', px, xmin), math('MULTIPLY', math('SUBTRACT', 1.0, EXP["-X"]), 10.0)),
                  math('ADD', math('SUBTRACT', xmax, px), math('MULTIPLY', math('SUBTRACT', 1.0, EXP["+X"]), 10.0)))
    # v7.56: + кінці СПИНКИ всередині модуля (Island: спинка обривається посередині, далі відкрите сидіння — кадр 44)
    b0_in = math('GREATER_THAN', bx0, math('ADD', xmin, 0.05))
    b1_in = math('LESS_THAN', bx1, math('SUBTRACT', xmax, 0.05))
    d_b0 = math('ADD', math('ABSOLUTE', math('SUBTRACT', px, bx0)), math('MULTIPLY', math('SUBTRACT', 1.0, b0_in), 10.0))
    d_b1 = math('ADD', math('ABSOLUTE', math('SUBTRACT', bx1, px)), math('MULTIPLY', math('SUBTRACT', 1.0, b1_in), 10.0))
    d_bend = math('MINIMUM', d_bend, math('MINIMUM', d_b0, d_b1))
    TBAND = []                                 # v7.56: (смуга біля краю, повзунок яскравості) -> множиться в bri
    for key_, nm_ in (("in_l", "Боковина внутр. ліва"), ("in_r", "Боковина внутр. права"), ("back", "Спинка")):
        z_raw = zone[key_]
        dref = d_bend if key_ == "back" else d_tor
        tw = math('MAXIMUM', math('MULTIPLY', gi.outputs[f"{nm_}: торець, см"], 0.01), 0.0001)
        tr_ = N.new('ShaderNodeMapRange'); tr_.interpolation_type = 'SMOOTHSTEP'; tr_.location = (-1500, nxt())
        tr_.inputs["From Min"].default_value = 0.0
        L.new(tw, tr_.inputs["From Max"]); L.new(dref, tr_.inputs["Value"])
        on_t = math('GREATER_THAN', gi.outputs[f"{nm_}: торець, см"], 0.001)
        if key_ != "back":
            # v7.52: лише на САМОМУ підлокітнику: є підлокітник з цього боку модуля і точка не перед ним
            # (у кутовому модулі в зону входить спинка бічної частини — торець гасив її повністю)
            has_side = mix(side_lx, hasR, hasL)
            on_t = math('MULTIPLY', on_t, math('MULTIPLY', has_side, math('GREATER_THAN', d_tor, -0.02)))
        zone[key_] = math('MULTIPLY', zone[key_], math('MULTIPLY_ADD', math('SUBTRACT', tr_.outputs[0], 1.0), on_t, 1.0))
        if key_ != "back":
            # v7.55: і від ВІЛЬНОГО бічного краю модуля (спинка шезлонга / кутового модуля в зоні внутр. боковини,
            # кадр 44: світла смуга на відкритому торці подушки). Грань підлокітника ~20 см від краю -> при 3-10 см не чіпає
            te = N.new('ShaderNodeMapRange'); te.interpolation_type = 'SMOOTHSTEP'; te.location = (-1500, nxt())
            te.inputs["From Min"].default_value = 0.0
            L.new(tw, te.inputs["From Max"]); L.new(d_bend, te.inputs["Value"])
            on_e = math('GREATER_THAN', gi.outputs[f"{nm_}: торець, см"], 0.001)
            zone[key_] = math('MULTIPLY', zone[key_], math('MULTIPLY_ADD', math('SUBTRACT', te.outputs[0], 1.0), on_e, 1.0))
        # смуга = частина зони, яку торець прибрав (z_raw − зона після торця)
        TBAND.append((math('SUBTRACT', z_raw, zone[key_], clamp=True), gi.outputs[f"{nm_}: торець, яскр"]))
    # v7.48: плюсовий «перехід» і для «Низ внутр.» (користувач: не заходить на верх сидіння). Відстань по тканині
    # до зовнішніх панелей модуля, що дивляться в той самий бік збірки (стики вже виключені fz7_exp), і лише там,
    # де до краю ВСІЄЇ збірки в цей бік далеко (≥ 0.45-0.6 м) — справжні зовнішні боковини переходу не дають
    # fz7_exp тут не годиться: бік шезлонга ззаду торкається сусіда -> увесь бік «стик». Тому відстань до БУДЬ-ЯКОЇ
    # зовнішньої панелі в цей бік, а стик відсікаємо за ВІДРІЗКОМ дотику (fz7_cx/fz7_cy з fabric_exposure7): точка, що
    # навпроти місця дотику до сусіда (+8 см м'якого краю), переходу не отримує. (Промінь Raycast на GPU/OptiX сусідні
    # модулі тут майже не бачить — перевірено, тому без променів.)
    RAW = {"+X": eXp, "-X": eXn, "+Y": eYp, "-Y": eYn}
    DZ["low_l"] = pick(RAW, lambda cx, cy: cx)
    DZ["low_r"] = pick(RAW, lambda cx, cy: neg(cx))

    def oattr4(name):
        a_ = N.new('ShaderNodeAttribute'); a_.attribute_type = 'OBJECT'; a_.attribute_name = name
        a_.location = (-2300, nxt()); a_.label = name
        sp_ = N.new('ShaderNodeSeparateColor'); sp_.location = (-2100, nxt()); L.new(a_.outputs["Color"], sp_.inputs[0])
        return sp_.outputs[0], sp_.outputs[1], sp_.outputs[2], a_.outputs["Alpha"]

    def soft_inside(v, a, b):                  # 1 між a і b, м'яко до 0 за 8 см поза відрізком
        lo = N.new('ShaderNodeMapRange'); lo.interpolation_type = 'SMOOTHSTEP'; lo.location = (-1500, nxt())
        L.new(math('SUBTRACT', a, 0.08), lo.inputs["From Min"]); L.new(a, lo.inputs["From Max"]); L.new(v, lo.inputs["Value"])
        hi = N.new('ShaderNodeMapRange'); hi.interpolation_type = 'SMOOTHSTEP'; hi.location = (-1500, nxt())
        L.new(b, hi.inputs["From Min"]); L.new(math('ADD', b, 0.08), hi.inputs["From Max"]); L.new(v, hi.inputs["Value"])
        return math('MULTIPLY', lo.outputs[0], math('SUBTRACT', 1.0, hi.outputs[0]))
    cxp0, cxp1, cxn0, cxn1 = oattr4("fz7_cx")
    cyp0, cyp1, cyn0, cyn1 = oattr4("fz7_cy")
    FREE = {"+X": math('SUBTRACT', 1.0, soft_inside(py, cxp0, cxp1)), "-X": math('SUBTRACT', 1.0, soft_inside(py, cxn0, cxn1)),
            "+Y": math('SUBTRACT', 1.0, soft_inside(px, cyp0, cyp1)), "-Y": math('SUBTRACT', 1.0, soft_inside(px, cyn0, cyn1))}

    def side_open(comp):                       # вільна частина тієї сторони модуля, що в збірці дивиться в comp
        acc = None
        for k_, (cx, cy) in Q.items():
            t = math('MULTIPLY', ss(comp(cx, cy), 0.5, 0.9), FREE[k_])
            acc = t if acc is None else math('ADD', acc, t)
        return acc
    low_gate = {"low_l": math('MULTIPLY', ss(edge_dist(lambda cx, cy: cx), 0.45, 0.6), side_open(lambda cx, cy: cx)),
                "low_r": math('MULTIPLY', ss(edge_dist(lambda cx, cy: neg(cx)), 0.45, 0.6), side_open(lambda cx, cy: neg(cx)))}
    fz9 = N.new('ShaderNodeAttribute'); fz9.attribute_type = 'GEOMETRY'; fz9.attribute_name = "fz9_in"
    fz9.location = (-900, nxt()); fz9.label = "до краю шматка тканини (fz9_in)"
    W = {}
    for key, nm, _, _, _ in ZONES:
        wcm = gi.outputs[f"{nm}: перехід"]
        wm = math('MAXIMUM', math('MULTIPLY', wcm, 0.01), 0.0001)
        fr = N.new('ShaderNodeMapRange'); fr.interpolation_type = 'SMOOTHERSTEP'; fr.location = (-700, nxt())
        fr.inputs["From Min"].default_value = 0.0
        fo = gi.outputs["М'якість спаду переходу"]          # v7.9: спад довший (W*f) і м'якший ((1-s)^f); f=1 -> як було
        # v7.15: плюсовий перехід — спад удвічі довший і плавний на обох кінцях (smootherstep), без видимої межі
        L.new(math('MULTIPLY', math('MULTIPLY', wm, fo), 2.0), fr.inputs["From Max"]); L.new(DZ[key], fr.inputs["Value"])
        on = math('GREATER_THAN', wcm, 0.001)
        bleed = math('MULTIPLY', math('POWER', math('SUBTRACT', 1.0, fr.outputs[0]), fo), on)
        tst = gi.outputs[f"{nm}: сила"]              # v7.47
        bleed = math('MINIMUM', math('MULTIPLY', bleed, tst), 1.0)
        # v7.3: обмеження за типом панелі прибрано — відстань тепер по тканині (fabric_zones7), фронт до спинки «далеко»
        # v7.57: + перехід зовн. боковини лише біля СПРАВЖНЬОГО краю збірки з цього боку (кадр 50: «зовн. права»
        # через вільний бік крила Г всередині кута світила фронт лівого крила)
        if key == "out_l":
            bleed = math('MULTIPLY', math('MULTIPLY', bleed, edge_lw),
                         math('SUBTRACT', 1.0, ss(edge_dist(lambda cx, cy: math('MULTIPLY', cx, -1.0)), 0.45, 0.6)))
        elif key == "out_r":
            bleed = math('MULTIPLY', math('MULTIPLY', bleed, edge_rw),
                         math('SUBTRACT', 1.0, ss(edge_dist(lambda cx, cy: cx), 0.45, 0.6)))
        elif key in low_gate:
            bleed = math('MULTIPLY', bleed, low_gate[key])
        # v7.13: мінусовий «перехід» — зона звужується до центру: вага всередині зони плавно росте від її країв
        # до 1 на глибині |перехід| × «М'якість спаду». Край зони = шов (зони — цілі шматки тканини між швами),
        # відстань до шва по тканині — fz9_in (fabric_inner9.py, до 0.6 м)
        inner_d = fz9.outputs["Fac"]
        # v7.14: спад удвічі довший і м'якший біля краю (користувач: «більше фолофу»): лінійно на 2×|перехід|×м'якість,
        # потім ^1.6 — біля шва росте повільно, до центру плавно виходить на 1
        # v7.15/16: ще плавніше (користувач: «щоб не було видно межі»): спад на 2×|перехід|×м'якість, smootherstep —
        # нульовий нахил і біля шва, і там, де виходить на повну силу (нема «зламу» = нема видимої межі)
        shr = N.new('ShaderNodeMapRange'); shr.interpolation_type = 'SMOOTHERSTEP'; shr.location = (-700, nxt())
        shr.inputs["From Min"].default_value = 0.0
        L.new(math('MULTIPLY', math('MAXIMUM', math('MULTIPLY', wcm, -0.02), 0.0001), fo), shr.inputs["From Max"])
        L.new(inner_d, shr.inputs["Value"])
        # v7.16: біля шва ефект не 0, а 40 % («з самого початку, лише тьмяніше»), до центру плавно 100 %
        shr_o = math('MULTIPLY_ADD', shr.outputs[0], 0.6, 0.4)
        neg = math('LESS_THAN', wcm, -0.001)
        z_eff = math('MULTIPLY', zone[key], math('MULTIPLY_ADD', math('MULTIPLY', math('SUBTRACT', shr_o, 1.0),
                                                                        math('MULTIPLY', neg, tst)), 1.0, 1.0, clamp=True))
        W[key] = math('MAXIMUM', z_eff, bleed, label="W " + key)

    y[0] = 1200
    S = None
    for key, _, _, _, _ in ZONES:
        S = W[key] if S is None else math('ADD', S, W[key])
    rest = math('SUBTRACT', 1.0, S, clamp=True)                 # частина без зони -> без змін (1)
    den = math('MAXIMUM', S, 1.0)
    acc = {"яскравість": rest, "насиченість": rest}
    dbg = None
    for key, nm, _, _, col in ZONES:
        for kind in ("яскравість", "насиченість"):
            zv = math('MULTIPLY', gi.outputs[f"{nm}: {kind}"], angle_mult(nm, kind), x=-350)
            acc[kind] = math('MULTIPLY_ADD', zv, W[key], acc[kind], x=-300)
        c = N.new('ShaderNodeMix'); c.data_type = 'RGBA'; c.location = (500, nxt())
        c.inputs[6].default_value = (0, 0, 0, 1); c.inputs[7].default_value = (*col, 1)
        L.new(math('DIVIDE', W[key], den, x=300), c.inputs[0])
        if dbg is None:
            dbg = c.outputs[2]
        else:
            ad = N.new('ShaderNodeMix'); ad.data_type = 'RGBA'; ad.blend_type = 'ADD'; ad.location = (700, nxt())
            ad.inputs[0].default_value = 1.0
            L.new(dbg, ad.inputs[6]); L.new(c.outputs[2], ad.inputs[7])
            dbg = ad.outputs[2]
    bri = math('MULTIPLY', math('MULTIPLY', gi.outputs["Вся тканина: яскравість"], angle_mult("Вся тканина", "яскравість")),
               math('DIVIDE', acc["яскравість"], den, x=-200), x=-100)
    for band_, tb_ in TBAND:                   # v7.56: яскравість смуги біля торця
        bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', math('SUBTRACT', tb_, 1.0), band_, 1.0), x=-100)
    sat = math('MULTIPLY', math('MULTIPLY', gi.outputs["Вся тканина: насиченість"], angle_mult("Вся тканина", "насиченість")),
               math('DIVIDE', acc["насиченість"], den, x=-200), x=-100)
    # v7.4: «Свої зони» з аддона Thuma Fabric — атрибут вершин tc_cust (x = яскравість-1, y = насиченість-1)
    cu = N.new('ShaderNodeAttribute'); cu.attribute_type = 'GEOMETRY'; cu.attribute_name = "tc_cust"
    cu.location = (-500, nxt()); cu.label = "Свої зони (tc_cust)"
    cux, cuy, _ = sep(cu.outputs["Vector"], x=-350)
    # v7.12: свої зони за ракурсом — tc_cust = Ф, tc_cust_l = Л, tc_cust_r = П (аддон ≥ 1.7 пише всі три)
    cul = N.new('ShaderNodeAttribute'); cul.attribute_type = 'GEOMETRY'; cul.attribute_name = "tc_cust_l"
    cul.location = (-500, nxt()); cul.label = "Свої зони: Л (tc_cust_l)"
    cur_ = N.new('ShaderNodeAttribute'); cur_.attribute_type = 'GEOMETRY'; cur_.attribute_name = "tc_cust_r"
    cur_.location = (-500, nxt()); cur_.label = "Свої зони: П (tc_cust_r)"
    clx, cly, _ = sep(cul.outputs["Vector"], x=-350)
    crx, cry, _ = sep(cur_.outputs["Vector"], x=-350)
    # v7.50: свої зони — Л/П як і раніше на передніх І задніх кадрах (side_l/side_r), без окремих ЗЛ/ЗП
    cux = math('MULTIPLY_ADD', crx, side_r, math('MULTIPLY_ADD', clx, side_l, math('MULTIPLY', cux, A_F, x=-300), x=-300), x=-300)
    cuy = math('MULTIPLY_ADD', cry, side_r, math('MULTIPLY_ADD', cly, side_l, math('MULTIPLY', cuy, A_F, x=-300), x=-300), x=-300)
    bri = math('MULTIPLY', bri, math('ADD', cux, 1.0, x=-250), x=-100)
    sat = math('MULTIPLY', sat, math('ADD', cuy, 1.0, x=-250), x=-100)

    # кутик біля підлокітника — поверх зон
    bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кутик: яскравість"], 1.0, x=-300),
                                     notch_m, 1.0, x=-300), x=-100)
    sat = math('MULTIPLY', sat, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кутик: насиченість"], 1.0, x=-300),
                                     notch_m, 1.0, x=-300), x=-100)
    # v7.10: кут біля підлокітника лише на фронт-кадрах — прапорець сцени fabric_front (ключі 1/0 по кадрах)
    ff = N.new('ShaderNodeAttribute'); ff.attribute_type = 'VIEW_LAYER'; ff.attribute_name = "fabric_front"
    ff.location = (-500, nxt()); ff.label = "фронт-кадр (fabric_front)"
    def ssv(v, a, b):                          # smoothstep зі змінними межами
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHSTEP'; n_.location = (-500, nxt())
        for sk, val in (("From Min", a), ("From Max", b), ("Value", v)):
            if isinstance(val, (int, float)):
                n_.inputs[sk].default_value = val
            else:
                L.new(val, n_.inputs[sk])
        return n_.outputs[0]

    # лінія стику спинка/підлокітник — виміряна по мешу кожного модуля (measure_joints -> fj_x / fj_y)
    fjx = N.new('ShaderNodeAttribute'); fjx.attribute_type = 'OBJECT'; fjx.attribute_name = "fj_x"
    fjx.location = (-2300, nxt()); fjx.label = "стик: підлокітники (fj_x)"
    fjy = N.new('ShaderNodeAttribute'); fjy.attribute_type = 'OBJECT'; fjy.attribute_name = "fj_y"
    fjy.location = (-2300, nxt()); fjy.label = "стик: спинка (fj_y)"
    fxs = N.new('ShaderNodeSeparateColor'); fxs.location = (-2100, nxt()); L.new(fjx.outputs["Color"], fxs.inputs[0])
    fys = N.new('ShaderNodeSeparateColor'); fys.location = (-2100, nxt()); L.new(fjy.outputs["Color"], fys.inputs[0])
    t_arm = ss(zr, 0.44, 0.60)                 # середина -> верх (скруглення)
    armL = mix(t_arm, fxs.outputs[0], fxs.outputs[1])
    armR = mix(t_arm, fxs.outputs[2], fjx.outputs["Alpha"])
    back_t = mix(ss(zr, 0.32, 0.58), fys.outputs[0], fys.outputs[1])
    # лише підлокітник, що В ЗБІРЦІ лівий (його внутрішня грань дивиться праворуч, +X збірки)
    # + у меші справді знайдено внутрішню грань підлокітника (fj > 5 см), інакше (Island, Armless) — нема кута
    wL = math('MULTIPLY', math('MULTIPLY', hasL, ss(Q["+X"][0], 0.5, 0.9)), math('GREATER_THAN', fxs.outputs[0], 0.05))
    wR = math('MULTIPLY', math('MULTIPLY', hasR, ss(Q["-X"][0], 0.5, 0.9)), math('GREATER_THAN', fxs.outputs[2], 0.05))
    # -1 см -> трикутник починається саме в куті; нема лівого підлокітника -> «далеко»
    d_l = math('ADD', math('SUBTRACT', px, math('ADD', xmin, math('SUBTRACT', armL, 0.01))),
               math('MULTIPLY', math('SUBTRACT', 1.0, wL), 9.0))
    d_r = math('ADD', math('SUBTRACT', math('SUBTRACT', xmax, math('SUBTRACT', armR, 0.01)), px),
               math('MULTIPLY', math('SUBTRACT', 1.0, wR), 9.0))
    # трикутник: угорі вершина в куті стику, донизу ширшає. Висота оббивки 0.59 м, спинка над сидінням ≈ 0.28…0.59
    hn = math('DIVIDE', math('SUBTRACT', zr, 0.28), 0.31, clamp=True)
    tri = math('MAXIMUM', math('SUBTRACT', 1.0, hn), 0.04)
    ramp = math('MULTIPLY_ADD', math('SUBTRACT', 1.0, hn), 0.65, 0.35)   # угорі 35 %, біля сидіння 100 %
    # --- спинка біля лівого підлокітника ---
    # «вершина в кут»: угорі трикутник заходить у кут на 4 см (до сидіння зсув плавно -> 0), без повзунка
    tip = math('MULTIPLY', hn, 0.04)
    d_tip = math('ADD', math('MINIMUM', d_l, d_r), tip)   # межа «спинка/підлокітник» угорі на 3 см глибше в кут
    # v7.21: «згасання до країв» — НЕ розширює (користувач): у тих самих межах форма спаду від «плато + спад»
    # (smoothstep, v=0) до «одразу від кута рівномірно до 0» ((1-x)^1.6, v=10)
    kg = gi.outputs["Кут: згасання до країв"]
    k_t = math('MULTIPLY', kg, 0.1, clamp=True)
    na_ = N.new('ShaderNodeMapRange'); na_.interpolation_type = 'LINEAR'; na_.location = (-500, nxt())
    na_.inputs["From Min"].default_value = 0.0
    L.new(math('DIVIDE', math('MAXIMUM', d_tip, 0.0), tri), na_.inputs["Value"])   # форма v101 (користувач: «відмінно»)
    # спад має дійти до 0 ДО кінця свого модуля (інакше обрізається на стику з сусіднім): d/tri ≤ (ширина модуля − підлокітник − 4 см)/tri
    d_room = math('MAXIMUM', math('SUBTRACT', math('SUBTRACT', xmax, xmin), math('ADD', armL, 0.04)), 0.05)
    L.new(math('MINIMUM', math('MULTIPLY', gi.outputs["Кут: ширина, см"], 0.01),
               math('DIVIDE', d_room, tri)), na_.inputs["From Max"])
    x_b = na_.outputs[0]                                   # 0 біля кута -> 1 на краю

    def profile(x):                                        # 1-f: 0 біля кута, 1 на краю (як «near»)
        sm = ss(x, 0.0, 1.0)
        lin = math('SUBTRACT', 1.0, math('POWER', math('SUBTRACT', 1.0, x), 1.6))
        return math('MULTIPLY_ADD', math('SUBTRACT', lin, sm), k_t, sm)
    near_arm = profile(x_b)
    # скруглення стику (грані дивляться частково вбік -> потрапляють у «in_l») теж рахуємо спинкою,
    # інакше між підлокітником і трикутником лишається темна смужка: це грані ЗА площиною підлокітника
    # (v98 пробував додати кант «Верх» + ширшу вершину — користувач відхилив, гірше)
    fillet = math('MULTIPLY', zone["in_l"], ss(math('MINIMUM', d_l, d_r), 0.012, 0.03))   # межа зон — на стику
    # v7.19: «Фронт: згасання до країв» замінив «кут, перехід» (v7.17-18, користувачу незрозумілий);
    # мінус = біля шва 40 % і плавно до 100 % всередину (відстань до шва fz9_in); smootherstep — без видимої межі

    def smst(v, hi):
        n_ = N.new('ShaderNodeMapRange'); n_.interpolation_type = 'SMOOTHERSTEP'; n_.location = (-500, nxt())
        n_.inputs["From Min"].default_value = 0.0
        L.new(hi, n_.inputs["From Max"]); L.new(v, n_.inputs["Value"])
        return n_.outputs[0]
    m_back = math('MULTIPLY', math('MINIMUM', math('ADD', zone["back"], fillet), 1.0),
                  math('SUBTRACT', 1.0, near_arm), label="ZONE front back")
    m_back = math('MULTIPLY', m_back, ramp)
    # лише справжня спинка, не передня кромка модуля (з оттоманкою впритул вона стає «стиком» -> зона спинки)
    m_back = math('MULTIPLY', m_back, ss(math('SUBTRACT', py, ymin), 0.08, 0.15))
    # не чіпати скруглену верхню кромку біля стику (там з'являлась світла плямка); оббивка ~0.59 м
    m_back = math('MULTIPLY', m_back, math('SUBTRACT', 1.0, ss(zr, 0.57, 0.59)))
    # верхня частина біля кута трохи слабша (до -35 %), щоб не виділялась
    m_back = math('MULTIPLY', m_back, math('SUBTRACT', 1.0, math('MULTIPLY', ss(zr, 0.50, 0.57), 0.35)))
    # --- внутрішня грань САМОГО лівого підлокітника (не стики між модулями, які теж в «in_l») ---
    onL = math('MULTIPLY', wL, math('SUBTRACT', 1.0, ss(math('SUBTRACT', math('SUBTRACT', px, xmin), armL), 0.015, 0.04)))
    onR = math('MULTIPLY', wR, math('SUBTRACT', 1.0, ss(math('SUBTRACT', math('SUBTRACT', xmax, px), armR), 0.015, 0.04)))
    on_arm = math('MULTIPLY', math('MULTIPLY', zone["in_l"], math('MAXIMUM', onL, onR)),
                  math('SUBTRACT', 1.0, ss(math('MINIMUM', d_l, d_r), 0.012, 0.03)))   # без скруглення (воно — спинка)
    # дзеркальний трикутник по глибині: від стику зі спинкою вперед; унизу майже до краю сидіння (-2 см)
    joint_y = math('SUBTRACT', ymax, back_t)
    dy = math('MAXIMUM', math('SUBTRACT', joint_y, math('ADD', py, 0.01)), 0.0)
    # до переднього кінця ПІДЛОКІТНИКА (у шезлонга він коротший за сидіння) мінус 2 см
    reach = math('MULTIPLY', math('MAXIMUM', math('SUBTRACT', math('SUBTRACT', fys.outputs[2], back_t), 0.02), 0.05),
                 gi.outputs["Кут: довжина боковини"])
    # біля кута рівна «полиця», далі плавний спад до 0 на кінці
    # м'якший і довший спад (користувач: «плавніше від краю»): з 10 % довжини до 130 %
    fx_ = N.new('ShaderNodeMapRange'); fx_.interpolation_type = 'LINEAR'; fx_.location = (-500, nxt())
    L.new(math('DIVIDE', dy, tri), fx_.inputs["Value"])
    L.new(math('MULTIPLY', reach, 0.1), fx_.inputs["From Min"]); L.new(math('MULTIPLY', reach, 1.3), fx_.inputs["From Max"])
    fade = profile(fx_.outputs[0])
    # не у V-щілині спереду між сидінням і підлокітником (зона «Кутик») і без верхньої кромки підлокітника
    on_arm = math('MULTIPLY', on_arm, math('MULTIPLY', math('SUBTRACT', 1.0, notch_m, clamp=True),
                                           math('SUBTRACT', 1.0, ss(zr, 0.565, 0.585))))
    # передні 1-5 см підлокітника (самий торець) — без підсвітки; V-щілину вже вирізає notch_m
    # (v7.18: було 3-12 см — користувач: «до краю трохи не доходить»)
    dy_end = math('SUBTRACT', fys.outputs[2], back_t)
    front_cut = math('SUBTRACT', 1.0, ssv(dy, math('SUBTRACT', dy_end, 0.05), math('SUBTRACT', dy_end, 0.01)))
    on_arm = math('MULTIPLY', on_arm, front_cut)
    # v7.19: «згасання до країв» — та сама степінь, що й на спинці
    m_arm = math('MULTIPLY', math('MULTIPLY', on_arm, math('SUBTRACT', 1.0, fade)), ramp,
                 label="ZONE front arm")
    fl = math('ADD', math('MULTIPLY', math('SUBTRACT', gi.outputs["Кут: ліва боковина"], 1.0, x=-300), m_arm),
              math('MULTIPLY', math('SUBTRACT', gi.outputs["Кут: спинка"], 1.0, x=-300), m_back))
    bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', fl, ff.outputs["Fac"], 1.0, x=-200), x=-100)
    # v7.32: фасад сидіння біля виступу ЛІВОРУЧ (як «Фронт-кут» у WOOD LOOK v2): промінь по -X (світ; на фронт-кадрах
    # поворот 0) з точки 15 см перед нею; влучив у ІНШИЙ модуль ближче за ширину -> кут. Лише грані в камеру,
    # нижче верху сидіння, не бокові скруглення. Direction — лише через вузол (незалінкований Cycles ігнорує)
    fw = math('MAXIMUM', math('MULTIPLY', gi.outputs["Кут: фасад, ширина, см"], 0.01), 0.02)
    fdir = N.new('ShaderNodeCombineXYZ'); fdir.location = (-1400, nxt()); fdir.inputs[0].default_value = -1.0
    forg = N.new('ShaderNodeVectorMath'); forg.operation = 'MULTIPLY_ADD'; forg.location = (-1200, nxt())
    # старт рівно на 15 см ПЕРЕД точкою (-Y світу), не вздовж нормалі: на скругленому торці нормаль дивиться вбік
    # і старт залазив у сусідній шезлонг (смужка, кадр 28); сусід на стику на 15 см уперед не дістає, виступ — так
    forg.inputs[0].default_value = (0.0, -1.0, 0.0); forg.inputs[1].default_value = (0.15, 0.15, 0.15)
    L.new(geo.outputs["Position"], forg.inputs[2])
    frc = N.new('ShaderNodeRaycast'); frc.location = (-1100, nxt()); frc.label = "кут: фасад (промінь -X)"
    L.new(forg.outputs[0], frc.inputs["Position"]); L.new(fdir.outputs[0], frc.inputs["Direction"])
    L.new(fw, frc.inputs["Length"])
    f_hit = math('SUBTRACT', frc.outputs["Is Hit"], frc.outputs["Self Hit"], clamp=True)
    # v7.32: ТРИКУТНИК як у спинки (користувач): вершина вгорі в куті біля стіни, донизу ширшає до повної ширини;
    # висота фасаду ~0.29 м від низу оббивки. Угорі 4 % ширини -> скруглений кут сидіння не світиться
    f_tri = math('MAXIMUM', math('SUBTRACT', 1.0, math('DIVIDE', zr, 0.29), clamp=True), 0.04)
    f_x = math('DIVIDE', frc.outputs["Hit Distance"], math('MULTIPLY', fw, f_tri), clamp=True)
    # спад одразу від кута м'яким хвостом (1-x)^2 (без «плато» — користувач: «слабкий плавний перехід»);
    # «Кут: згасання до країв» 10 -> (1-x)^1 (рівніше)
    k_f = math('MULTIPLY', gi.outputs["Кут: фасад, згасання до країв"], 0.1, clamp=True)     # v7.49: власне
    f_m = math('MULTIPLY', f_hit, math('POWER', math('SUBTRACT', 1.0, f_x), math('SUBTRACT', 2.0, k_f)))
    # гладка нормаль форми в координатах збірки (на фронт-кадрах = світ), без рельєфу тканини
    # грань хоч трохи в камеру (скруглена ліва кромка біля стіни теж — маска від самого краю); бічні грані у щілині
    # (дивляться вбік, -ncy≈0) — ні. Крапки на стиках прибрав старт променя рівно вперед, суворий фільтр не потрібен
    f_m = math('MULTIPLY', f_m, ss(math('MULTIPLY', ncy, -1.0), 0.45, 0.7))   # 0.2 ловив бік правого крила (кадр 46)
    f_m = math('MULTIPLY', f_m, math('SUBTRACT', 1.0, ss(zr, 0.20, 0.29)))   # нижче верху сидіння (0.30+ = стик сидіння/спинки біля підлокітника шезлонга, кадри 55/67)
    f_m = math('MULTIPLY', f_m, math('SUBTRACT', 1.0, zone["back"], clamp=True))     # не спинка (крапки на стиках)
    # лише зона «Фронт» (передні зовнішні панелі); стик сидіння/спинки біля підлокітника давав смужку (кадри 55/67)
    f_m = math('MULTIPLY', f_m, math('MINIMUM', zone["front"], 1.0))
    f_m = math('MULTIPLY', f_m, ff.outputs["Fac"], label="ZONE front facade")
    bri = math('MULTIPLY', bri, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кут: фасад сидіння"], 1.0), f_m, 1.0), x=-100)
    sat = math('MULTIPLY', sat, math('MULTIPLY_ADD', math('SUBTRACT', gi.outputs["Кут: фасад, насиченість"], 1.0), f_m, 1.0), x=-100)
    # v7.5: шви — fz8_seam (відстань по тканині до UV-шва), bri *= 1 - сила * (1 - smoothstep(d, 0, ширина/2))
    sa = N.new('ShaderNodeAttribute'); sa.attribute_type = 'GEOMETRY'; sa.attribute_name = "fz8_seam"
    sa.location = (-500, nxt()); sa.label = "шви (fz8_seam)"
    smr = N.new('ShaderNodeMapRange'); smr.interpolation_type = 'SMOOTHSTEP'; smr.location = (-300, nxt())
    smr.inputs["From Min"].default_value = 0.0
    # v7.33: множники по зонах: Σ зона·множник + (1 − Σ зон)·1 (сирі маски зон, сума ≈ 1)
    # v7.35: крило (атрибут об'єкта fz_wing: -1 ліве, +1 праве, 0 решта; measure_wings()) — лише для швів сидіння
    fwg = N.new('ShaderNodeAttribute'); fwg.attribute_type = 'OBJECT'; fwg.attribute_name = "fz_wing"
    fwg.location = (-600, nxt()); fwg.label = "крило (fz_wing)"
    w_l = math('LESS_THAN', fwg.outputs["Fac"], -0.5, x=-500)
    w_r = math('GREATER_THAN', fwg.outputs["Fac"], 0.5, x=-500)

    def wing_seat(kind):
        # v7.45: «Шви сидіння, ліве/праве крило» діють на всіх кадрах КРІМ фронту; «…ліве/праве, фронт» — лише на фронт-кадрах
        ffv = ff.outputs["Fac"]
        nff = math('SUBTRACT', 1.0, ffv, x=-490)

        # v7.46: лише шов ЗБОКУ (край сидіння біля бічної грані): гладка нормаль шва повернута вздовж X збірки
        # (виміряно на крилі: бічний шов |nx|≈0.65, фронтальний/задній |nx|≈0) — шов фронту крила не чіпати
        side_m = ss(math('ABSOLUTE', ncx, x=-500), 0.3, 0.5, x=-495)

        def pick(side, w_0):
            w_ = math('MULTIPLY', w_0, side_m, x=-470)
            o_ = math('SUBTRACT', gi.outputs[f"Шви сидіння, {side} крило: {kind} ×"], 1.0, x=-480)
            f_ = math('SUBTRACT', gi.outputs[f"Шви сидіння {side}, фронт: {kind} ×"], 1.0, x=-480)
            sel = math('ADD', math('MULTIPLY', o_, nff, x=-470), math('MULTIPLY', f_, ffv, x=-470), x=-465)
            return math('MULTIPLY', sel, w_, x=-460)
        a_ = pick("ліве", w_l)
        b_ = pick("праве", w_r)
        return math('ADD', math('ADD', a_, b_, x=-440), 1.0, x=-420, label=f"шви сидіння: крило {kind}")

    # v7.40: шов ФРОНТУ вздовж підлокотника -> «внутр. ліва/права» за РЕАЛЬНОЮ геометрією (не осі модуля):
    # точка підіймається на висоту підлокотника (z світу 0.5) і на 3 см углиб дивана; промені ±X збірки на 4 см
    # (свій меш теж рахується) шукають внутрішню грань підлокотника. Її нормаль -X = правий підлокітник, +X = лівий.
    def rot_w(vec):
        cb_ = N.new('ShaderNodeCombineXYZ'); cb_.location = (-1400, nxt())
        for i_, v_ in enumerate(vec):
            cb_.inputs[i_].default_value = v_
        r_ = N.new('ShaderNodeVectorRotate'); r_.rotation_type = 'Z_AXIS'; r_.location = (-1300, nxt())
        L.new(cb_.outputs[0], r_.inputs["Vector"]); L.new(ang.outputs[0], r_.inputs["Angle"])
        return r_.outputs[0]
    gpx, gpy, _ = sep(geo.outputs["Position"], x=-1300)
    ap = N.new('ShaderNodeCombineXYZ'); ap.location = (-1250, nxt())
    L.new(gpx, ap.inputs[0]); L.new(gpy, ap.inputs[1]); ap.inputs[2].default_value = 0.5
    aorg = N.new('ShaderNodeVectorMath'); aorg.operation = 'MULTIPLY_ADD'; aorg.location = (-1200, nxt())
    L.new(rot_w((0.0, 1.0, 0.0)), aorg.inputs[0]); aorg.inputs[1].default_value = (0.03, 0.03, 0.03)
    L.new(ap.outputs[0], aorg.inputs[2])

    def arm_ray(dx):
        rc_ = N.new('ShaderNodeRaycast'); rc_.location = (-1100, nxt()); rc_.label = f"шов біля підлокітника {dx:+.0f}X"
        L.new(aorg.outputs[0], rc_.inputs["Position"]); L.new(rot_w((dx, 0.0, 0.0)), rc_.inputs["Direction"])
        rc_.inputs["Length"].default_value = 0.04
        hn = N.new('ShaderNodeVectorRotate'); hn.rotation_type = 'Z_AXIS'; hn.invert = True; hn.location = (-1000, nxt())
        L.new(rc_.outputs["Hit Normal"], hn.inputs["Vector"]); L.new(ang.outputs[0], hn.inputs["Angle"])
        hx, _, _ = sep(hn.outputs[0], x=-950)
        # v7.44: лише ВНУТРІШНЯ грань підлокотника — за нею (з боку від підлокотника, де нормаль) є сидіння:
        # з точки 6 см за гранню по її нормалі промінь униз на 25 см має влучити в подушку. Зовнішній бік дивана /
        # торці крила біля кута — за ними порожньо (користувач: «ліва чіпляє багато швів»)
        bo = N.new('ShaderNodeVectorMath'); bo.operation = 'MULTIPLY_ADD'; bo.location = (-950, nxt())
        L.new(rc_.outputs["Hit Normal"], bo.inputs[0]); bo.inputs[1].default_value = (0.06, 0.06, 0.06)
        L.new(rc_.outputs["Hit Position"], bo.inputs[2])
        dn = N.new('ShaderNodeCombineXYZ'); dn.location = (-950, nxt()); dn.inputs[2].default_value = -1.0
        rs = N.new('ShaderNodeRaycast'); rs.location = (-900, nxt()); rs.label = "за гранню є сидіння?"
        L.new(bo.outputs[0], rs.inputs["Position"]); L.new(dn.outputs[0], rs.inputs["Direction"])
        rs.inputs["Length"].default_value = 0.25
        return math('MULTIPLY', rc_.outputs["Is Hit"], rs.outputs["Is Hit"], x=-880), hx
    h1, n1 = arm_ray(1.0)
    h2, n2 = arm_ray(-1.0)
    # без ребра подушки у V-щілині між сидінням і підлокітником (зона «Кутик», notch_m) — користувач: «цей шматок не чіпляй»
    fz_ = math('MULTIPLY', math('MINIMUM', zone["front"], 1.0, x=-900),
               math('SUBTRACT', 1.0, ss(notch_m, 0.02, 0.15), x=-900), x=-890)
    fz_ = math('MULTIPLY', fz_, ss(math('MULTIPLY', ncy, -1.0, x=-900), 0.85, 0.95), x=-880)   # лише пласкі грані фронту
    # права = внутрішня грань дивиться в −X збірки; ліва = в +X
    a_r = math('MULTIPLY', fz_, math('MINIMUM', math('ADD', math('MULTIPLY', h1, ss(math('MULTIPLY', n1, -1.0, x=-920), 0.5, 0.8), x=-900),
                                                          math('MULTIPLY', h2, ss(math('MULTIPLY', n2, -1.0, x=-920), 0.5, 0.8), x=-900), x=-880),
                                                 1.0, x=-870), x=-860, label="шов фронту біля ПРАВОГО підлокітника")
    a_l = math('MULTIPLY', fz_, math('MINIMUM', math('ADD', math('MULTIPLY', h1, ss(n1, 0.5, 0.8), x=-900),
                                                          math('MULTIPLY', h2, ss(n2, 0.5, 0.8), x=-900), x=-880),
                                                 1.0, x=-870), x=-860, label="шов фронту біля ЛІВОГО підлокітника")

    def seam_mult(kind):
        acc_m, zsum = None, None
        ws_ = wing_seat(kind)
        for nm, _ in SEAM_GROUPS_UI:
            for key in SEAM_GROUP_KEYS[nm]:
                mul = gi.outputs[f"Шви {nm}: {kind} ×"]
                if key == "seat":
                    mul = math('MULTIPLY', mul, ws_, x=-520)
                if key == "front":                      # v7.40: смуга вздовж підлокотника -> внутр. ліва/права
                    rest_f = math('SUBTRACT', 1.0, math('ADD', a_l, a_r, x=-520), clamp=True, x=-510)
                    mul = math('ADD', math('MULTIPLY', mul, rest_f, x=-500),
                               math('ADD', math('MULTIPLY', gi.outputs[f"Шви внутр. ліва: {kind} ×"], a_l, x=-500),
                                    math('MULTIPLY', gi.outputs[f"Шви внутр. права: {kind} ×"], a_r, x=-500), x=-490), x=-480)
                t = math('MULTIPLY', zone[key], mul, x=-500)
                acc_m = t if acc_m is None else math('ADD', acc_m, t, x=-450)
                zsum = zone[key] if zsum is None else math('ADD', zsum, zone[key], x=-450)
        rest_ = math('MULTIPLY', math('SUBTRACT', 1.0, zsum, clamp=True, x=-450), gi.outputs[f"Шви інше: {kind} ×"], x=-450)
        return math('DIVIDE', math('ADD', acc_m, rest_, x=-420), math('MAXIMUM', zsum, 1.0, x=-420),
                    x=-400, label=f"шви: множник {kind}")
    s_w = seam_mult("ширина")
    s_s = seam_mult("сила")
    L.new(math('MAXIMUM', math('MULTIPLY', math('MULTIPLY', gi.outputs["Шви: ширина"], s_w, x=-400), 0.005, x=-400), 0.00005, x=-400),
          smr.inputs["From Max"])
    # v7.31: «зсув від ямки» (v7.29-30) прибрано на прохання користувача — тінь знову по центру шва
    L.new(sa.outputs["Fac"], smr.inputs["Value"])
    # v7.9: де шов прибрано пензлем/виділенням аддона — атрибут tc_seam_off (червоний = без шва)
    so = N.new('ShaderNodeAttribute'); so.attribute_type = 'GEOMETRY'; so.attribute_name = "tc_seam_off"
    so.location = (-500, nxt()); so.label = "шов прибрано (tc_seam_off)"
    sor, _, _ = sep(so.outputs["Color"], x=-350)
    seam_d = math('MULTIPLY', math('SUBTRACT', 1.0, smr.outputs[0], x=-200), math('SUBTRACT', 1.0, sor, clamp=True, x=-250), x=-200)
    seam_k = math('SUBTRACT', 1.0, math('MULTIPLY', math('MULTIPLY', gi.outputs["Шви: сила"], s_s, x=-250), seam_d, x=-200),
                  x=-150, label="шви: множник")
    bri = math('MULTIPLY', bri, seam_k, x=-100)
    # v7.60: стик ЛІВОГО КРИЛА: відстань до сторони модуля, що впирається в сусіда (fz7_exp = 0) І дивиться
    # уздовж ±Y збірки (стики крила йдуть углиб; стики заднього ряду дивляться вздовж ±X — не беремо); інші — далеко
    dj = None
    for k_, d_ in (("+X", eXp), ("-X", eXn), ("+Y", eYp), ("-Y", eYn)):
        w_y = ss(math('ABSOLUTE', Q[k_][1], x=-310), 0.5, 0.9, x=-305)
        use_ = math('MULTIPLY', math('SUBTRACT', 1.0, EXP[k_], x=-300), w_y, x=-300)
        # v7.61: модуль БЛИЖЧЕ до нас (його сторона стику дивиться назад, +Y збірки) — тінь сягає вчетверо далі
        d_n = math('DIVIDE', d_, math('MULTIPLY_ADD', ss(Q[k_][1], 0.5, 0.9, x=-305), 3.0, 1.0, x=-300), x=-298)   # v7.62: ×4
        t_ = math('ADD', math('MULTIPLY', d_n, use_, x=-295), math('SUBTRACT', 1.0, use_, x=-295), x=-290)
        dj = t_ if dj is None else math('MINIMUM', dj, t_, x=-280)
    jmr = N.new('ShaderNodeMapRange'); jmr.interpolation_type = 'SMOOTHSTEP'; jmr.location = (-260, nxt())
    jmr.inputs["From Min"].default_value = 0.0
    L.new(dj, jmr.inputs["Value"])
    jw = math('MAXIMUM', math('MULTIPLY', gi.outputs["Шви стик ліве крило: ширина ×"], 0.01, x=-280), 0.001, x=-270)     # см -> м
    L.new(jw, jmr.inputs["From Max"])
    # біля верху: верх, заокруглення і верх торця у щілині (торець видно з фронту між модулями)
    jt = N.new('ShaderNodeMapRange'); jt.interpolation_type = 'SMOOTHSTEP'; jt.location = (-260, nxt())
    L.new(dTop, jt.inputs["Value"]); L.new(math('ADD', jw, 0.01, x=-270), jt.inputs["From Min"])
    L.new(math('ADD', jw, 0.02, x=-270), jt.inputs["From Max"])
    # ліва частина збірки: центр збірки (fz7_asm, коорд. модуля) -> вектор до точки -> у координати збірки
    acx = math('MULTIPLY', math('ADD', a_x0, a_x1, x=-300), 0.5, x=-295)
    acy = math('MULTIPLY', math('ADD', a_y0, a_y1, x=-300), 0.5, x=-295)
    dv = N.new('ShaderNodeCombineXYZ'); dv.location = (-1400, nxt())
    L.new(math('SUBTRACT', px, acx, x=-290), dv.inputs[0]); L.new(math('SUBTRACT', py, acy, x=-290), dv.inputs[1])
    dcx, _, _ = to_cfg(dv.outputs[0])
    j_left = math('MULTIPLY', math('SUBTRACT', 1.0, ss(dcx, -0.3, -0.1), x=-250), math('SUBTRACT', 1.0, no_asm, x=-250), x=-245)
    j_m = math('MULTIPLY', math('SUBTRACT', 1.0, jmr.outputs[0], x=-240), math('SUBTRACT', 1.0, jt.outputs[0], x=-240), x=-230)
    j_m = math('MULTIPLY', math('MULTIPLY', j_m, j_left, x=-225), ff.outputs["Fac"], x=-220, label="шов: стик лівого крила (фронт)")
    j_s = math('MULTIPLY', gi.outputs["Шви: сила"], gi.outputs["Шви стик ліве крило: сила ×"], x=-210)
    bri = math('MULTIPLY', bri, math('SUBTRACT', 1.0, math('MULTIPLY', j_s, j_m, x=-200), clamp=True, x=-180), x=-100)
    nd = N.new('ShaderNodeMix'); nd.data_type = 'RGBA'; nd.location = (800, nxt())
    L.new(notch_m, nd.inputs[0]); L.new(dbg, nd.inputs[6]); nd.inputs[7].default_value = (0, 0, 0, 1)
    dbg = nd.outputs[2]                        # у «Показати зони» кутик — чорний
    # v7.53: свої зони (аддон) теж видно в «Показати зони» — білим там, де вони НА ЦЬОМУ КАДРІ щось змінюють
    # (|яскравість−1| + |насиченість−1| ≥ ~0.05 -> повністю біле); нульові/вимкнені зони не підсвічуються
    cz = math('MULTIPLY', math('ADD', math('ABSOLUTE', cux), math('ABSOLUTE', cuy)), 20.0, clamp=True)
    czm = N.new('ShaderNodeMix'); czm.data_type = 'RGBA'; czm.location = (850, nxt())
    # білі ДІАГОНАЛЬНІ СМУЖКИ (2.5 см) — не сплутати з пастельними кольорами зон
    stp = math('GREATER_THAN', math('SINE', math('MULTIPLY', math('ADD', math('ADD', px, py), pz), 125.0)), 0.0)
    L.new(math('MULTIPLY', cz, stp), czm.inputs[0]); L.new(dbg, czm.inputs[6]); czm.inputs[7].default_value = (1, 1, 1, 1)
    dbg = czm.outputs[2]

    hsv = N.new('ShaderNodeHueSaturation'); hsv.location = (200, 1300); hsv.label = "Look (HSV)"
    L.new(gi.outputs["Колір"], hsv.inputs["Color"])
    L.new(gi.outputs["Вся тканина: відтінок"], hsv.inputs["Hue"])
    L.new(sat, hsv.inputs["Saturation"]); L.new(bri, hsv.inputs["Value"])
    hsv.inputs["Fac"].default_value = 1.0
    lum_c = N.new('ShaderNodeRGBToBW'); lum_c.location = (450, 1500); L.new(hsv.outputs[0], lum_c.inputs[0])
    lum_t = N.new('ShaderNodeRGBToBW'); lum_t.location = (450, 1600); L.new(gi.outputs["Вся тканина: колір тону"], lum_t.inputs[0])
    ratio = math('DIVIDE', lum_c.outputs[0], math('MAXIMUM', lum_t.outputs[0], 0.0001, x=650), x=650)
    cv = N.new('ShaderNodeCombineColor'); cv.location = (800, 1600)
    for i in range(3):
        L.new(ratio, cv.inputs[i])
    tn = N.new('ShaderNodeMix'); tn.data_type = 'RGBA'; tn.blend_type = 'MULTIPLY'; tn.location = (950, 1600)
    tn.inputs[0].default_value = 1.0
    L.new(gi.outputs["Вся тканина: колір тону"], tn.inputs[6]); L.new(cv.outputs[0], tn.inputs[7])
    fac = gi.outputs["Вся тканина: сила тону"]          # тон на всю тканину
    mx = N.new('ShaderNodeMix'); mx.data_type = 'RGBA'; mx.location = (1150, 1300)
    L.new(fac, mx.inputs[0]); L.new(hsv.outputs[0], mx.inputs[6]); L.new(tn.outputs[2], mx.inputs[7])
    base = N.new('ShaderNodeMix'); base.data_type = 'RGBA'; base.blend_type = 'ADD'; base.location = (1150, 900)
    base.inputs[0].default_value = 1.0; base.inputs[6].default_value = (0.1, 0.1, 0.1, 1)
    L.new(dbg, base.inputs[7])
    sw = N.new('ShaderNodeMix'); sw.data_type = 'RGBA'; sw.location = (1450, 1100); sw.name = "SHOW_ZONES"
    L.new(gi.outputs["Показати зони"], sw.inputs[0])
    fill = N.new('ShaderNodeMix'); fill.data_type = 'RGBA'; fill.location = (1300, 1300); fill.label = "заливка кольором"
    L.new(gi.outputs["Вся тканина: сила заливки"], fill.inputs[0])
    L.new(mx.outputs[2], fill.inputs[6]); L.new(gi.outputs["Вся тканина: колір заливки"], fill.inputs[7])
    L.new(fill.outputs[2], sw.inputs[6]); L.new(base.outputs[2], sw.inputs[7])
    L.new(sw.outputs[2], go.inputs[0])
    return len(g.nodes)


def _cfg_angle_attr():
    """v7.58: драйвер на вузлі CFG_ANGLE перекомпільовував усі матеріали на кожному кадрі (Rendered-вʼюпорт
    +1.3 ГБ памʼяті за перемикання). Тепер ракурс — атрибут сцени cfg_angle (cfg_angle_attr.py)."""
    sys.path.insert(0, HERE)
    import importlib
    import cfg_angle_attr
    importlib.reload(cfg_angle_attr)
    return cfg_angle_attr.run()


def upgrade():
    sys.path.insert(0, HERE)
    import importlib
    import fabric_zones6
    importlib.reload(fabric_zones6)
    # пензель кутика (fz_kutik) — малюнок користувача: зберегти до перерахунку зон і повернути після
    import numpy as np
    keep = {}
    for me in bpy.data.meshes:
        ca = me.color_attributes.get("fz_kutik")
        if ca is not None:
            a = np.empty(len(ca.data) * 4, np.float32); ca.data.foreach_get("color", a); keep[me.name] = a
    info = fabric_zones6.run()
    import fabric_zones7
    importlib.reload(fabric_zones7)
    fabric_zones7.run()
    import fabric_exposure7
    importlib.reload(fabric_exposure7)
    fabric_exposure7.run()
    import fabric_seams8
    importlib.reload(fabric_seams8)
    fabric_seams8.run()
    import fabric_inner9
    importlib.reload(fabric_inner9)
    fabric_inner9.run()
    for nm, a in keep.items():
        me = bpy.data.meshes.get(nm)
        ca = me.color_attributes.get("fz_kutik") if me else None
        if ca is None and me is not None:
            ca = me.color_attributes.new("fz_kutik", 'BYTE_COLOR', 'POINT')
        if ca is not None and len(ca.data) * 4 == len(a):
            ca.data.foreach_set("color", a); me.update()
    joints = measure_joints()
    fronts = ensure_front_flag()
    measure_wings()
    g = bpy.data.node_groups[GROUP]
    snap = _snapshot(g)
    build_interface(g)
    nn = build_nodes(g)
    _restore(snap)
    g["fl_version"] = FL_VERSION
    _tidy()
    ensure_eevee_preview()
    for o in bpy.data.objects:
        if "fj_x" in o:
            o.update_tag()
    bad = [n.id_data.name for n, _, _ in snap
           if not n.outputs[0].links or n.outputs[0].links[0].to_socket.name != "Base Color"
           or not n.inputs[0].links]
    cfga = _cfg_angle_attr()                    # v7.58: ракурс через атрибут сцени (без перекомпіляції на кадрі)
    return {"instances": len(snap), "nodes": nn, "bad_links": bad, "meshes": len(info), "joints": joints, "fronts": fronts,
            "cfg_angle": cfga}


def measure_joints():
    """Лінія стику спинка/підлокітник по мешу кожного модуля -> властивості об'єкта (координати меша, м):
    fj_x = (лівий підлокітник від xmin: середина, верх; правий від xmax: середина, верх)
    fj_y = (спинка від ymax: низ ~0.3, верх ~0.6, 0, 0). Середина = z 0.28-0.44 над низом оббивки, верх = 0.56+."""
    done = 0
    cache = {}
    for o in bpy.data.objects:
        m = o.active_material
        if o.type != 'MESH' or not m or not m.get('thuma_fabric'):
            continue
        me = o.data
        if me.name not in cache:
            xs = [v.co.x for v in me.vertices]; ys = [v.co.y for v in me.vertices]; zs = [v.co.z for v in me.vertices]
            x0, x1, y1, z0 = min(xs), max(xs), max(ys), min(zs)

            def band(vals, lo, hi, fn):
                v = [d for z, d in vals if lo <= z <= hi]
                return fn(v) if v else 0.0
            al, ar, bk, arm_len = [], [], [], []
            for p in me.polygons:
                c, n, z = p.center, p.normal, p.center.z - z0
                if n.x > 0.8 and c.x < (x0 + x1) / 2:
                    al.append((z, c.x - x0)); arm_len.append(y1 - c.y)
                elif n.x < -0.8 and c.x > (x0 + x1) / 2:
                    ar.append((z, x1 - c.x)); arm_len.append(y1 - c.y)
                elif n.y < -0.8 and x0 + 0.3 < c.x < x1 - 0.3 and z > 0.28:
                    bk.append((z, y1 - c.y))
            cache[me.name] = ((band(al, 0.28, 0.44, max), band(al, 0.54, 0.62, max),
                               band(ar, 0.28, 0.44, max), band(ar, 0.54, 0.62, max)),
                              (band(bk, 0.28, 0.36, min), band(bk, 0.54, 0.62, min),
                               max(arm_len) if arm_len else 0.0, 0.0))     # [2] = довжина підлокітника від ymax
        o["fj_x"], o["fj_y"] = cache[me.name]
        done += 1
    return done


def measure_wings():
    """Крила кутових диванів -> властивість об'єкта fz_wing (-1 ліве, +1 праве, 0 решта).
    На кожному фронт-кадрі (fabric_front=1, поворот збірки 0 -> світ = збірка): видимі модулі тканини;
    задній ряд = найбільший «передній край» (min Y) серед модулів; модуль, чий передній край на 0.3 м+ ближче
    до камери, — крило; ліве/праве за центром модуля відносно центру всієї збірки по X."""
    from mathutils import Vector
    sc = bpy.context.scene
    f0 = sc.frame_current
    fab = [o for o in bpy.data.objects if o.type == 'MESH' and o.active_material and o.active_material.get('thuma_fabric')]
    for o in fab:
        o["fz_wing"] = 0.0
    n_w = 0
    for f in range(sc.frame_start, sc.frame_end + 1):
        sc.frame_set(f)
        if sc.get("fabric_front", 0) < 0.5:
            continue
        vis = [o for o in fab if o.visible_get()]
        if len(vis) < 2:
            continue
        bb = {}
        for o in vis:
            pts = [o.matrix_world @ Vector(c) for c in o.bound_box]
            bb[o] = (min(p.x for p in pts), max(p.x for p in pts), min(p.y for p in pts))
        back = max(v[2] for v in bb.values())
        cx = (min(v[0] for v in bb.values()) + max(v[1] for v in bb.values())) / 2
        for o, (x0, x1, y0) in bb.items():
            if y0 < back - 0.3:
                o["fz_wing"] = -1.0 if (x0 + x1) / 2 < cx else 1.0
                n_w += 1
    sc.frame_set(f0)
    for o in fab:
        o.update_tag()
    return n_w


def ensure_eevee_preview():
    """v7.43: Material Preview (EEVEE) не тягне 22 атрибути пульта -> рожеві дивани. Для кожної тканини:
    основний вихід -> лише CYCLES; новий вихід EEVEE <- копія шейдерної групи без FABRIC LOOK + «FL preview (EEVEE)»
    (загальні шви + яскравість/насиченість тканини, значення — драйвери з пульта). Перестворюється щоразу."""
    pg = bpy.data.node_groups.get("FL preview (EEVEE)")
    if pg is None:
        pg = bpy.data.node_groups.new("FL preview (EEVEE)", 'ShaderNodeTree')
        it = pg.interface
        it.new_socket("Колір", in_out='INPUT', socket_type='NodeSocketColor')
        for nm, d in (("Шви: сила", 0.0), ("Шви: ширина", 0.35), ("Яскравість", 1.0), ("Насиченість", 1.0)):
            it.new_socket(nm, in_out='INPUT', socket_type='NodeSocketFloat').default_value = d
        it.new_socket("Колір", in_out='OUTPUT', socket_type='NodeSocketColor')
        N, L = pg.nodes, pg.links
        gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput'); go.location = (600, 0); gi.location = (-900, 0)
        a = N.new('ShaderNodeAttribute'); a.attribute_type = 'GEOMETRY'; a.attribute_name = "fz8_seam"; a.location = (-700, -200)
        so = N.new('ShaderNodeAttribute'); so.attribute_type = 'GEOMETRY'; so.attribute_name = "tc_seam_off"; so.location = (-700, -400)

        def m(op, a_, b_=None, clamp=False):
            n = N.new('ShaderNodeMath'); n.operation = op; n.use_clamp = clamp
            for i, v in enumerate((a_, b_)):
                if v is None:
                    continue
                if isinstance(v, (int, float)):
                    n.inputs[i].default_value = v
                else:
                    L.new(v, n.inputs[i])
            return n.outputs[0]
        w = m('MAXIMUM', m('MULTIPLY', gi.outputs["Шви: ширина"], 0.005), 0.00005)
        mr = N.new('ShaderNodeMapRange'); mr.interpolation_type = 'SMOOTHSTEP'
        mr.inputs["From Min"].default_value = 0.0; L.new(w, mr.inputs["From Max"]); L.new(a.outputs["Fac"], mr.inputs["Value"])
        sp = N.new('ShaderNodeSeparateColor'); L.new(so.outputs["Color"], sp.inputs[0])
        d_ = m('MULTIPLY', m('SUBTRACT', 1.0, mr.outputs[0]), m('SUBTRACT', 1.0, sp.outputs[0], clamp=True))
        k = m('SUBTRACT', 1.0, m('MULTIPLY', gi.outputs["Шви: сила"], d_))
        hsv = N.new('ShaderNodeHueSaturation'); hsv.location = (300, 0)
        L.new(gi.outputs["Колір"], hsv.inputs["Color"]); L.new(gi.outputs["Насиченість"], hsv.inputs["Saturation"])
        L.new(m('MULTIPLY', gi.outputs["Яскравість"], k), hsv.inputs["Value"])
        L.new(hsv.outputs[0], go.inputs[0])
    done = 0
    for mat in bpy.data.materials:
        if not mat.get('thuma_fabric') or not mat.node_tree:
            continue
        nt = mat.node_tree
        for n in [n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputMaterial' and n.target == 'EEVEE']:
            src_n = n.inputs['Surface'].links[0].from_node if n.inputs['Surface'].is_linked else None
            nt.nodes.remove(n)
            if src_n is not None and src_n.type == 'GROUP':
                old = src_n.node_tree; nt.nodes.remove(src_n)
                if old is not None and old.users == 0 and old.name.endswith("(EEVEE preview)"):
                    bpy.data.node_groups.remove(old)
        outs = [n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputMaterial']
        if not outs:
            continue
        out = next((n for n in outs if n.is_active_output), outs[0])
        if not out.inputs['Surface'].is_linked:
            continue
        gn = out.inputs['Surface'].links[0].from_node
        if gn.type != 'GROUP' or gn.node_tree is None:
            continue
        orig = gn.node_tree
        fl = [n for n in orig.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name == GROUP]
        if len(fl) != 1:
            continue
        cp = orig.copy(); cp.name = orig.name + " (EEVEE preview)"
        flc = [n for n in cp.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name == GROUP][0]
        srcc = flc.inputs[0].links[0].from_socket if flc.inputs[0].is_linked else None
        tg = [l.to_socket for l in flc.outputs[0].links]
        pn = cp.nodes.new('ShaderNodeGroup'); pn.node_tree = pg; pn.name = "FL preview"; pn.location = flc.location
        cp.nodes.remove(flc)
        if srcc is not None:
            cp.links.new(srcc, pn.inputs["Колір"])
        for t in tg:
            cp.links.new(pn.outputs["Колір"], t)
        for sock, fln in (("Шви: сила", "Шви: сила"), ("Шви: ширина", "Шви: ширина"),
                          ("Яскравість", "Вся тканина: яскравість"), ("Насиченість", "Вся тканина: насиченість")):
            i_ = [i for i, s_ in enumerate(pn.inputs) if s_.name == sock][0]
            fc = pn.inputs[i_].driver_add('default_value')
            fc.driver.type = 'AVERAGE'
            v = fc.driver.variables.new(); v.name = "v"; v.type = 'SINGLE_PROP'
            v.targets[0].id_type = 'NODETREE'; v.targets[0].id = orig
            v.targets[0].data_path = f'nodes["{fl[0].name}"].inputs["{fln}"].default_value'
        out.target = 'CYCLES'
        g2 = nt.nodes.new('ShaderNodeGroup'); g2.node_tree = cp; g2.location = (gn.location.x, gn.location.y - 500)
        g2.label = "EEVEE / Material Preview (без FABRIC LOOK)"
        for i, inp in enumerate(gn.inputs):
            if inp.is_linked:
                nt.links.new(inp.links[0].from_socket, g2.inputs[i])
        eo = nt.nodes.new('ShaderNodeOutputMaterial'); eo.target = 'EEVEE'; eo.location = (out.location.x, out.location.y - 500)
        nt.links.new(g2.outputs[out.inputs['Surface'].links[0].from_socket.name], eo.inputs['Surface'])
        done += 1
    return done


def rebuild():
    """Лише пересобрати вузли групи (атрибути зон у мешах не чіпати) — значення повзунків зберігаються."""
    joints = measure_joints()
    measure_wings()
    g = bpy.data.node_groups[GROUP]
    snap = _snapshot(g)
    build_interface(g)
    nn = build_nodes(g)
    _restore(snap)
    g["fl_version"] = FL_VERSION
    _tidy()
    eevee = ensure_eevee_preview()
    cfga = _cfg_angle_attr()                    # v7.58
    return {"instances": len(snap), "nodes": nn, "joints": joints, "eevee": eevee, "cfg_angle": cfga}


if __name__ == "__main__" and "--" in sys.argv:
    print("FL6", upgrade())
