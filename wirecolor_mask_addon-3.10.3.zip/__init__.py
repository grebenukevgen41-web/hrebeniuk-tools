bl_info = {
    "name":        "WireColor Masks",
    "author":      "Hrebeniuk",
    "version":     (3, 10, 3),
    "blender":     (4, 2, 0),
    "location":    "3D Viewport › N-Panel › WireColor",
    "description": "Кольорові маски: колір на об'єкт або полігони, перегляд у вьюпорті, маски Cycles з рельєфом",
    "category":    "Render",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])
ADDON_CHANGES = {
    (3, 10, 2): "Маски Cycles — один режим, без налаштувань: згладжування самим Cycles (16 семплів), зони тканини "
                "не виходять за межі деталей. Вибір «Краї» і галочки «Чистити шви» / «Зони в межах деталей» прибрано",
    (3, 10, 1): "Панель масок Cycles показує, звідки легенда: «у файлі» чи «від пульта проєкту» (раніше писала «легенди нема», "
                "хоча маски брали кольори пульта). Маски рендеряться швидше (~на чверть): зайві проходи вимкнено, "
                "EXR стискається швидше, підрахунок кольорів швидший; час етапів — у лозі завдання",
    (3, 10, 0):"Маски Cycles з рельєфом: Face + Object рендеряться у фоновому Blender по справжньому рельєфу тканини "
                "(як у бьюті), інтерфейс вільний. Легенда проєкту живе в сцені — у колег ті самі кольори. "
                "Пам'ятає відбиток кожного кадру: «Перерахувати застарілі» в CFRender рендерить лише змінені кадри. "
                "Опція «Чистити шви» (для М'яких/Жорстких країв): тонкі смужки чужих зон у канавках швів перефарбовуються. "
                "Краї за замовчуванням — Cycles AA (16 семплів, як у бьюті); М'які — швидкі, Жорсткі — для чарівної палички PS. "
                "Зони в межах деталей (за замовчуванням): зона тканини не залазить на сусідню деталь, крихти в швах прибрані",
}


import bpy
import bpy.utils.previews
import bmesh
import colorsys
import math
import random
import os
import sys
import json
import time
import hashlib
import tempfile
import subprocess
import numpy as np
from bpy.props import (FloatVectorProperty, IntProperty, FloatProperty,
                       PointerProperty, BoolProperty, StringProperty,
                       CollectionProperty, EnumProperty)
from bpy.types import Panel, Operator, PropertyGroup

ATTR_NAME    = "wc_mask_color"
PAINTED_ATTR = "wc_painted"

_rendering          = False
_preview_coll       = None
_active_color_bak: dict = {}   # mesh.name → original active color attr name

PRESET_COLORS = [
    (1.000, 0.000, 0.000),  # #FF0000 Bright Red
    (0.000, 1.000, 0.000),  # #00FF00 Lime Green
    (0.000, 0.000, 1.000),  # #0000FF Blue
    (1.000, 1.000, 0.000),  # #FFFF00 Yellow
    (0.000, 1.000, 1.000),  # #00FFFF Cyan
    (1.000, 0.000, 1.000),  # #FF00FF Magenta
    (1.000, 0.498, 0.000),  # #FF7F00 Orange
    (0.498, 0.000, 1.000),  # #7F00FF Electric Violet
    (0.000, 1.000, 0.498),  # #00FF7F Mint Neon
    (1.000, 0.000, 0.498),  # #FF007F Fuchsia
    (0.498, 1.000, 0.000),  # #7FFF00 Chartreuse
    (0.000, 0.498, 1.000),  # #007FFF Azure
    (0.545, 0.000, 0.000),  # #8B0000 Dark Red
    (0.000, 0.392, 0.000),  # #006400 Dark Green
    (0.000, 0.000, 0.545),  # #00008B Dark Blue
    (0.502, 0.502, 0.000),  # #808000 Olive
    (0.502, 0.000, 0.502),  # #800080 Purple
    (0.000, 0.502, 0.502),  # #008080 Teal
    (1.000, 0.843, 0.000),  # #FFD700 Gold
    (0.294, 0.000, 0.510),  # #4B0082 Indigo
]

MODE_TITLES = {
    'OBJECT':   "Object",
    'FACE':     "Face",
    'MATERIAL': "Material",
}


# ─────────────────────────────────────────────────────────────────────────────
#  ІКОНКИ ПАЛІТРИ  (кольоровий квадрат на кожен колір, будуються за потреби)
# ─────────────────────────────────────────────────────────────────────────────

def _clear_preview_icons():
    global _preview_coll
    if _preview_coll is not None:
        try:
            bpy.utils.previews.remove(_preview_coll)
        except Exception:
            pass
        _preview_coll = None


def _color_icon(color):
    """icon_id квадратика заданого кольору (кеш по hex)."""
    global _preview_coll
    if _preview_coll is None:
        _preview_coll = bpy.utils.previews.new()
    r, g, b = color[0], color[1], color[2]
    key = _color_to_hex(r, g, b)
    if key not in _preview_coll:
        size = 32
        thumb = _preview_coll.new(key)
        thumb.image_size = (size, size)
        try:
            thumb.image_pixels_float[:] = (r, g, b, 1.0) * (size * size)
        except Exception:
            pass
    return _preview_coll[key].icon_id


# ─────────────────────────────────────────────────────────────────────────────
#  CORE SYNC
# ─────────────────────────────────────────────────────────────────────────────

# ── Спільні меші ─────────────────────────────────────────────────────────────
# Колір маски полігонів живе в меші. Якщо один меш у кількох об'єктів (копії модуля в різних
# конфігураціях), колір ОБ'ЄКТА в меш писати не можна — останній пофарбований перезаписує решту
# («скидає» кольори). Тому для Face-маски на такі об'єкти тимчасово ставиться GN-модифікатор:
# непофарбовані полігони = колір цього об'єкта, пофарбовані = колір з меша (спільний для всіх копій).
OBJ_MOD   = "WC_ObjColor"
OBJ_GROUP = "WC Object Color"


def _objcolor_group():
    ng = bpy.data.node_groups.get(OBJ_GROUP)
    if ng and ng.bl_idname == 'GeometryNodeTree':
        return ng
    ng = bpy.data.node_groups.new(OBJ_GROUP, 'GeometryNodeTree')
    it = ng.interface
    it.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    it.new_socket("Колір", in_out='INPUT', socket_type='NodeSocketColor')
    it.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); gi.location = (-600, 0)
    go = N.new('NodeGroupOutput'); go.location = (400, 0)
    pa = N.new('GeometryNodeInputNamedAttribute'); pa.data_type = 'INT'; pa.location = (-400, -150)
    pa.inputs["Name"].default_value = PAINTED_ATTR
    ca = N.new('GeometryNodeInputNamedAttribute'); ca.data_type = 'FLOAT_COLOR'; ca.location = (-400, -300)
    ca.inputs["Name"].default_value = ATTR_NAME
    sw = N.new('GeometryNodeSwitch'); sw.input_type = 'RGBA'; sw.location = (-150, -150)
    L.new(pa.outputs["Attribute"], sw.inputs["Switch"])
    L.new(gi.outputs["Колір"], sw.inputs["False"])
    L.new(ca.outputs["Attribute"], sw.inputs["True"])
    st = N.new('GeometryNodeStoreNamedAttribute'); st.data_type = 'FLOAT_COLOR'; st.domain = 'CORNER'; st.location = (100, 0)
    st.inputs["Name"].default_value = ATTR_NAME
    L.new(gi.outputs["Geometry"], st.inputs["Geometry"]); L.new(sw.outputs[0], st.inputs["Value"])
    L.new(st.outputs["Geometry"], go.inputs["Geometry"])
    return ng


def _objcolor_set(obj):
    mod = obj.modifiers.get(OBJ_MOD)
    if mod is None or mod.node_group is None:
        return
    ident = mod.node_group.interface.items_tree["Колір"].identifier
    props = getattr(mod, "properties", None)          # Blender 5.x: mod.properties.inputs.<id>.value
    if props is not None and hasattr(props, "inputs"):
        getattr(props.inputs, ident).value = tuple(obj.wc_color)
    else:                                             # Blender 4.x: id-властивість модифікатора
        mod[ident] = tuple(obj.wc_color)
    obj.update_tag()


def _objcolor_mods_add(scene):
    """Модифікатор на об'єкти зі спільним мешем. Повертає імена, на які додали."""
    ng, added = None, []
    for obj in scene.objects:
        if obj.type != 'MESH' or obj.data.users < 2 or ATTR_NAME not in obj.data.color_attributes:
            continue
        if obj.modifiers.get(OBJ_MOD) is None:
            ng = ng or _objcolor_group()
            mod = obj.modifiers.new(OBJ_MOD, 'NODES')
            mod.node_group = ng
            mod.show_in_editmode = True
            added.append(obj.name)
        _objcolor_set(obj)
    return added


def _face_mods(on):
    """Модифікатори з іменем WC_Face* (напр. маска деталей Thuma) працюють лише під час Face-маски."""
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        for mod in obj.modifiers:
            if mod.name.startswith("WC_Face") and (mod.show_viewport != on or mod.show_render != on):
                mod.show_viewport = mod.show_render = on


def _objcolor_mods_remove(names=None):
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or (names is not None and obj.name not in names):
            continue
        mod = obj.modifiers.get(OBJ_MOD)
        if mod is not None:
            obj.modifiers.remove(mod)


def _sync_obj_to_attr(obj):
    if obj.type != 'MESH':
        return
    mesh = obj.data
    if mesh.users > 1:                     # спільний меш: колір об'єкта дає модифікатор, меш не чіпаємо
        _objcolor_set(obj)
        return
    if ATTR_NAME not in mesh.color_attributes:
        return
    old_attr = mesh.color_attributes[ATTR_NAME]
    if not len(old_attr.data):
        return

    painted_attr = mesh.attributes.get(PAINTED_ATTR)
    r, g, b, _   = obj.wc_color
    n_loops = len(old_attr.data)

    # Читаємо всі поточні кольори (щоб зберегти ручні) — numpy, без циклу по loops
    saved = np.empty(n_loops * 4, np.float32)
    old_attr.data.foreach_get('color', saved)
    saved = saved.reshape(-1, 4)
    out = np.tile(np.array((r, g, b, 1.0), np.float32), (n_loops, 1))
    if painted_attr and len(painted_attr.data) == len(mesh.polygons):
        painted = np.empty(len(mesh.polygons), np.int32)
        painted_attr.data.foreach_get('value', painted)
        loop_painted = painted[_loop_to_poly(mesh)] != 0
        out[loop_painted] = saved[loop_painted]

    # Перестворюємо атрибут — тільки так Blender скидає GPU кеш
    mesh.color_attributes.remove(old_attr)
    new_attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
    new_attr.data.foreach_set('color', out.ravel())

    mesh.color_attributes.active_color = new_attr
    mesh.update()


def _loop_to_poly(mesh):
    """Масив: індекс полігона для кожного loop (numpy)."""
    n_poly = len(mesh.polygons)
    starts = np.empty(n_poly, np.int64)
    totals = np.empty(n_poly, np.int64)
    mesh.polygons.foreach_get('loop_start', starts)
    mesh.polygons.foreach_get('loop_total', totals)
    out = np.empty(len(mesh.loops), np.int64)
    for_poly = np.repeat(np.arange(n_poly), totals)
    loop_idx = np.repeat(starts - np.concatenate(([0], np.cumsum(totals)[:-1])), totals) + np.arange(totals.sum())
    out[loop_idx] = for_poly
    return out


def _tag_redraw_viewports():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _wc_color_update(obj, context):
    """Callback: obj.wc_color змінився → оновити маску і те, що видно у вьюпорті."""
    try:
        props = context.scene.wc_props
    except Exception:
        props = None
    # У перегляді «Object» вьюпорт показує obj.color — оновлюємо його одразу
    if props and props.preview_active and props.preview_mode == 'OBJECT':
        bak = json.loads(props.preview_obj_backup or "{}")
        if obj.name not in bak:
            bak[obj.name] = list(obj.color)
            props.preview_obj_backup = json.dumps(bak)
        obj.color = obj.wc_color
    if obj.type == 'MESH' and ATTR_NAME in obj.data.color_attributes \
            and not (obj.mode == 'EDIT'):
        _sync_obj_to_attr(obj)
    _tag_redraw_viewports()


def _init_palette_presets():
    """Заповнити палітру пресетами якщо вона порожня."""
    # 3.10.3: під час register() bpy.data ще обмежений (_RestrictData) — тихо виходимо, пресети заповнить таймер
    if not hasattr(bpy.data, "scenes"):
        return None
    try:
        for scene in list(bpy.data.scenes):
            try:
                props = scene.wc_props
                if len(props.palette_colors) == 0:
                    for r, g, b in PRESET_COLORS:
                        props.palette_colors.add().color = (r, g, b)
            except Exception as e:
                print(f"WireColor: preset error for '{scene.name}': {e}")
    except Exception as e:
        print(f"WireColor: _init_palette_presets failed: {e}")
    return None  # one-shot timer


@bpy.app.handlers.persistent
def _on_load_post(dummy):
    """Після відкриття файлу — ініціалізація."""
    _active_color_bak.clear()
    bpy.app.timers.register(_init_palette_presets, first_interval=0.2)


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

class _ObjectModeScope:
    """Тимчасово вийти з Edit Mode (зміни mesh-даних в Edit Mode губляться)."""
    def __init__(self, context):
        self.was_edit = (context.mode == 'EDIT_MESH')
        # об'єкти запам'ятовуємо ДО виходу з Edit Mode — після нього список порожній
        self.objects = ([o for o in context.objects_in_mode_unique_data if o.type == 'MESH']
                        if self.was_edit else
                        [o for o in context.selected_objects if o.type == 'MESH'])

    def __enter__(self):
        if self.was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        return self

    def __exit__(self, *exc):
        if self.was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        return False


def _make_color_attr(mesh, obj_color):
    if ATTR_NAME in mesh.color_attributes:
        mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
    attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
    r, g, b = obj_color[:3]
    if len(attr.data):
        attr.data.foreach_set('color', np.tile(np.array((r, g, b, 1.0), np.float32), len(attr.data)))
    if PAINTED_ATTR not in mesh.attributes:
        mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
    else:
        for d in mesh.attributes[PAINTED_ATTR].data:
            d.value = 0
    return attr


def _ensure_color_attributes(scene):
    auto_names = []
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        # Зберігаємо оригінальний active_color щоб не зламати Cycles-матеріал
        if mesh.name not in _active_color_bak:
            ac = mesh.color_attributes.active_color
            _active_color_bak[mesh.name] = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            auto_names.append(obj.name)
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return auto_names


def _cleanup_by_names(names):
    for name in names:
        obj = bpy.data.objects.get(name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        # Відновлюємо оригінальний active_color в будь-якому випадку
        orig = _active_color_bak.pop(mesh.name, None)
        if orig and orig in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig]
        # Не видаляємо атрибут якщо є ручне фарбування
        painted = mesh.attributes.get(PAINTED_ATTR)
        if painted and any(d.value for d in painted.data):
            continue
        if ATTR_NAME in mesh.color_attributes:
            mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
        if PAINTED_ATTR in mesh.attributes:
            mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])


def _fill_temp_obj_color(scene):
    """Тимчасово заповнити всі loops obj.color, зберегти оригінальні кольори.
    Повертає {obj_name: (loop_colors або None, orig_active_color_name або None)}."""
    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            loop_backup[obj.name] = (
                [tuple(attr.data[li].color) for li in range(len(attr.data))],
                orig_active,
            )
            r, g, b = obj.wc_color[:3]
            for li in range(len(attr.data)):
                attr.data[li].color = (r, g, b, 1.0)
            mesh.update()
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _fill_temp_mat_color(scene, seed=42):
    """Тимчасово заповнити loops кольором матеріалу PER-FACE (по слоту poly.material_index).
    Однаковий матеріал = однаковий колір на всіх faces і об'єктах."""
    rng = random.Random(seed)
    mat_colors: dict = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        for mat in obj.data.materials:
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())

    NO_MAT_COLOR = (0.5, 0.5, 0.5)

    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None

        slot_colors = [mat_colors.get(mat.name, NO_MAT_COLOR) if mat else NO_MAT_COLOR
                       for mat in mesh.materials]

        if ATTR_NAME not in mesh.color_attributes:
            if PAINTED_ATTR not in mesh.attributes:
                mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            loop_backup[obj.name] = ([tuple(attr.data[li].color) for li in range(len(attr.data))],
                                     orig_active)
        for poly in mesh.polygons:
            r, g, b = slot_colors[poly.material_index] if poly.material_index < len(slot_colors) else NO_MAT_COLOR
            for li in poly.loop_indices:
                attr.data[li].color = (r, g, b, 1.0)
        mesh.update()
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _mat_colors(scene, seed=42):
    """Колір кожного матеріалу сцени (той самий порядок і seed, що й раніше)."""
    rng = random.Random(seed)
    mat_colors = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        for mat in obj.data.materials:
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())
        for slot in obj.material_slots:          # матеріали, прив'язані до об'єкта
            mat = slot.material
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())
    return mat_colors


def _set_mat_display_colors(scene, seed=42):
    """Тимчасово: Viewport Display Color кожного матеріалу = свій колір маски.
    Миттєво (сотні матеріалів замість мільйонів loops) і не чіпає меші. Повертає backup."""
    backup = {}
    for name, (r, g, b) in _mat_colors(scene, seed).items():
        mat = bpy.data.materials.get(name)
        if mat:
            backup[name] = list(mat.diffuse_color)
            mat.diffuse_color = (r, g, b, 1.0)
    return backup


def _restore_mat_display_colors(backup):
    for name, color in backup.items():
        mat = bpy.data.materials.get(name)
        if mat:
            mat.diffuse_color = color


def _set_obj_colors(scene):
    """Тимчасово: obj.color = колір маски (Workbench color_type OBJECT). Повертає backup."""
    backup = {}
    for obj in scene.objects:
        if obj.type == 'MESH':
            backup[obj.name] = list(obj.color)
            obj.color = obj.wc_color
    return backup


def _restore_obj_colors(backup):
    for name, color in backup.items():
        obj = bpy.data.objects.get(name)
        if obj:
            obj.color = color


def _restore_loop_colors(loop_backup):
    """Відновити кольори loops з backup in-place (без видалення/відтворення attr)."""
    for obj_name, (colors, orig_active) in loop_backup.items():
        obj = bpy.data.objects.get(obj_name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        if colors is None:
            if ATTR_NAME in mesh.color_attributes:
                mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
            if PAINTED_ATTR in mesh.attributes:
                mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        else:
            if ATTR_NAME in mesh.color_attributes:
                attr = mesh.color_attributes[ATTR_NAME]
                for li, color in enumerate(colors):
                    if li < len(attr.data):
                        attr.data[li].color = color
                mesh.update()
        if orig_active and orig_active in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig_active]


def _all_viewport_spaces(context):
    """Всі 3D viewport spaces на поточному екрані."""
    spaces = []
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                spaces.append(area.spaces.active)
    return spaces


def _safe_relpath(path):
    """bpy.path.relpath падає ValueError коли вивід і .blend на різних дисках."""
    try:
        return bpy.path.relpath(path)
    except ValueError:
        return path


def _versioned_path(path, animation=False):
    """Якщо файл існує — додає _V01, _V02, ... до імені."""
    if animation:
        abs_p = bpy.path.abspath(path)
        d     = os.path.dirname(abs_p)
        name  = os.path.basename(abs_p)
        if not os.path.isdir(d):
            return path
        existing = [f for f in os.listdir(d) if f.startswith(name)]
        if not existing:
            return path
        for i in range(1, 100):
            new_name = f"{name}_V{i:02d}"
            if not any(f.startswith(new_name) for f in os.listdir(d)):
                return _safe_relpath(os.path.join(d, new_name))
    else:
        if not os.path.exists(path):
            return path
        base, ext = os.path.splitext(path)
        for i in range(1, 100):
            candidate = f"{base}_V{i:02d}{ext}"
            if not os.path.exists(candidate):
                return candidate
    return path


def _color_to_hex(r, g, b):
    return "#{:02x}{:02x}{:02x}".format(
        min(255, int(r * 255)),
        min(255, int(g * 255)),
        min(255, int(b * 255)),
    )


def _distinct_colors(n, seed):
    """n кольорів, що максимально відрізняються (золотий кут по відтінку)."""
    rng = random.Random(seed)
    h = rng.random()
    out = []
    for i in range(n):
        h = (h + 0.618033988749895) % 1.0
        s = (1.0, 0.65)[(i // 2) % 2]
        v = (1.0, 0.75)[i % 2]
        out.append(colorsys.hsv_to_rgb(h, s, v))
    return out


# ─────────────────────────────────────────────────────────────────────────────
#  РЕНДЕР МАСОК — без кнопок у панелі, викликається з Custom Frame Render
# ─────────────────────────────────────────────────────────────────────────────

def _clean_output(scene):
    """Mask renders must be flat colours: no compositor (grain/sharpen), no dither noise and NO view transform
    (AgX/Filmic змінюють кольори: червоний 1,0,0 виходив 240,56,48 -> в Photoshop не виділити за кольором).
    Standard + без look/експозиції/гами: колір маски в PNG = колір у палітрі (sRGB)."""
    vs = scene.view_settings
    saved = (scene.render.use_compositing, scene.render.dither_intensity,
             vs.view_transform, vs.look, vs.exposure, vs.gamma, vs.use_curve_mapping,
             scene.display_settings.display_device)
    scene.render.use_compositing  = False
    scene.render.dither_intensity = 0.0
    try:
        scene.display_settings.display_device = 'sRGB'
        vs.view_transform = 'Standard'
        vs.look = 'None'
    except TypeError:
        pass
    vs.exposure, vs.gamma, vs.use_curve_mapping = 0.0, 1.0, False
    return saved


def _restore_output(scene, saved):
    vs = scene.view_settings
    (scene.render.use_compositing, scene.render.dither_intensity, vt, look, vs.exposure, vs.gamma,
     vs.use_curve_mapping, dev) = saved
    try:
        scene.display_settings.display_device = dev
        vs.view_transform = vt
        vs.look = look
    except TypeError:
        pass


def props_active_face(scene):
    p = getattr(scene, "wc_props", None)
    return bool(p and p.preview_active and p.preview_mode == 'FACE')


def _render_workbench(scene, suffix, fill_all=False, animation=False):
    global _rendering

    orig_filepath = scene.render.filepath

    if animation:
        out_filepath = _versioned_path(orig_filepath + suffix, animation=True)
        out_display  = out_filepath
    else:
        orig_path = bpy.path.abspath(orig_filepath)
        base, ext = os.path.splitext(orig_path)
        ext       = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
        out_path  = _versioned_path(base + suffix + ext, animation=False)
        out_filepath = _safe_relpath(out_path)
        out_display  = out_path

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    if fill_all:
        obj_backup = _set_obj_colors(scene)          # Object-маска: колір об'єкта, меші не чіпаємо
    else:
        auto_names = _ensure_color_attributes(scene)
        mod_names  = _objcolor_mods_add(scene)
        _face_mods(True)

    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'OBJECT' if fill_all else 'VERTEX'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = out_filepath
    out_saved = _clean_output(scene)

    _rendering = True
    try:
        bpy.ops.render.render(animation=animation, write_still=not animation)
    finally:
        _rendering = False
        _restore_output(scene, out_saved)
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        if fill_all:
            _restore_obj_colors(obj_backup)
        else:
            _objcolor_mods_remove(mod_names)
            if not (props_active_face(scene)):
                _face_mods(False)
            _cleanup_by_names(auto_names)

    return out_display


def _render_workbench_mat(scene, suffix, seed=42):
    global _rendering

    orig_filepath = scene.render.filepath
    base, ext     = os.path.splitext(bpy.path.abspath(orig_filepath))
    ext           = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
    out_path      = _versioned_path(base + suffix + ext, animation=False)

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    mat_backup = _set_mat_display_colors(scene, seed=seed)
    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'MATERIAL'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = _safe_relpath(out_path)
    out_saved = _clean_output(scene)

    _rendering = True
    try:
        bpy.ops.render.render(animation=False, write_still=True)
    finally:
        _rendering = False
        _restore_output(scene, out_saved)
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        _restore_mat_display_colors(mat_backup)

    return out_path


class WIRECOLOR_OT_render_obj_mask(Operator):
    bl_idname      = "wirecolor.render_obj_mask"
    bl_label       = "Object Mask"
    bl_description = "Рендер маски: кожен об'єкт — свій колір (_mask_obj). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_obj", fill_all=True)
        self.report({'INFO'}, f"Object Mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_face_mask(Operator):
    bl_idname      = "wirecolor.render_face_mask"
    bl_label       = "Face Mask"
    bl_description = "Рендер маски: колір об'єкта + розфарбовані полігони (_mask_face). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_face", fill_all=False)
        self.report({'INFO'}, f"Face Mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_mat_mask(Operator):
    bl_idname      = "wirecolor.render_mat_mask"
    bl_label       = "Material Mask"
    bl_description = "Рендер маски: кожен матеріал — свій колір (_mask_mat). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        path = _render_workbench_mat(context.scene, "_mask_mat", self.seed)
        self.report({'INFO'}, f"Material Mask → {os.path.basename(path)}")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  МАСКИ CYCLES З РЕЛЬЄФОМ (3.10.0)
#  Workbench не бачить Displacement -> контур маски = гладка геометрія, а в бьюті тканина горбиста (1–3 px).
#  Тут маска рендериться Cycles у фоновому Blender (UI вільний) на копії сцени в пам'яті:
#  Displacement лишається, Surface -> чорний Diffuse, світло/світ прибрані, 1 семпл, фільтр 0.01 -> чисті кольори.
#  AOV: wc_m_obj (колір об'єкта), wc_m_face (розфарбовані полігони WireColor), + якщо в сцені є — зони тканини
#  fl_zone/fabric_mask (FABRIC LOOK). Face = зона на тканині, інакше полігони/колір об'єкта. Object = колір об'єкта.
#  Відбиток кадру (геометрія, рельєф, камера, кольори, розцвітка) -> _wc_masks_index.json у теці масок:
#  «Перерахувати застарілі» рендерить лише кадри, де відбиток змінився.
#  Шви (Face, якщо є зони): тонкі (≤2·CM_SEAM_R px) смужки й острівці (< CM_SEAM_AREA px) зон тканини між іншими зонами
#  (канавка шва дає «чужу» зону по нормалі) -> колір найближчої сусідньої зони; силует і межа з нетканиною не рухаються.
#  Краї: hard = 1 px як є (сходинки, чисті кольори); soft = звичайний рендер 1× + згладжування в numpy лише біля меж:
#  для пікселя — 2 головні кольори вікна 5×5, вага = гаусове розмиття бінарної маски кожного, суміш у лінійному світлі.
#  cycles = справжнє згладжування самим Cycles: N семплів, фільтр Blackman-Harris 1.5, AOV усереднені; Face складається
#  в лінійному світлі: зона (AOV fl_zone) + колір полігонів нетканини (wc_m_face×(1−fabric_mask) у шейдері) + частка
#  «тканина без зони» (fabric_mask − wc_m_zcov, щілини) кольором найближчої зони — край щілин не темніє.
#  (Скрито: job["ss"]=K>1 — старий суперсемплінг K× смугами, повільно.)
#  Чистка швів (job["clean"], за замовч. вимкнено) — лише для hard/soft: прибирає й справжні тонкі смужки.
# ─────────────────────────────────────────────────────────────────────────────

CM_RECIPE   = 3                       # змінився рецепт рендеру -> усі маски застарілі (3: чистка швів за замовч. вимк.)
ZCOV_AOV    = "wc_m_zcov"             # cycles AA: частка семплів тканини, де зона є (fl_zone ≠ 0)
CM_AA_SPP   = 16                      # cycles AA: семплів на піксель за замовчуванням
CM_ZOBJ_TOL = 0.03                    # зони по деталях: допуск «суміш двох дозволених кольорів» (лінійне світло)
LEGEND_TEXT = "hrb_mask_legend.json"  # легенда проєкту в самому .blend: {"objects": {ім'я: hex}, "zones": {ключ: hex}}
ZONE_AOV, FLAG_AOV = "fl_zone", "fabric_mask"
CM_OBJ_PROP = "wc_mk_col"
CM_INDEX    = "_wc_masks_index.json"
CM_SS       = 3                       # (скрито, job["ss"]) суперсемплінг: у скільки разів більший рендер
CM_AA_SIGMA = 0.7                     # м'які краї: σ гаусового згладжування межі, px
CM_AA_R     = 2                       # м'які краї: радіус вікна (5×5) -> змінюються лише пікселі ≤2 px від межі
CM_AA_MIN   = 0.03                    # м'які краї: домішка сусіднього кольору менша за це -> піксель лишається чистим
CM_SEAM_R   = 2                       # чистка швів: смужки зон тоншi за 2·R+1 px (відкриття квадратом (2R+1)²)
CM_SEAM_AREA = 200                    # чистка швів: острівці зон тканини, менші за стільки px
CM_SS_MAX_PX = 400_000_000            # стеля пікселів великого рендеру (пам'ять) -> K зменшується
_CM = {"proc": None, "status_path": "", "status": {}, "log": ""}


def _cm_hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _cm_s2l(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _cm_l2s(x):
    x = min(max(float(x), 0.0), 1.0)
    return int(round(255 * (x * 12.92 if x <= 0.0031308 else 1.055 * x ** (1 / 2.4) - 0.055)))


def _cm_l2s8(a):
    a = np.clip(a, 0, 1)
    s = np.where(a <= 0.0031308, a * 12.92, 1.055 * np.power(a, 1 / 2.4) - 0.055)
    return np.round(s * 255).astype(np.uint8)


def cm_legend(hooks=False):
    """Легенда проєкту: Text hrb_mask_legend.json у .blend; якщо нема і hooks — від пульта проєкту
    (hrb_mask_legend()); інакше None (кольори об'єктів WireColor)."""
    tx = bpy.data.texts.get(LEGEND_TEXT)
    d = None
    if tx is not None:
        try:
            d = json.loads(tx.as_string())
        except Exception:
            d = None
    if d is None and hooks:
        for f in _cm_hooks("hrb_mask_legend"):
            try:
                d = f()
            except Exception as e:
                print("[WireColor] hrb_mask_legend:", e)
            if d:
                break
    if not isinstance(d, dict):
        return None
    d.setdefault("objects", {})
    d.setdefault("zones", {})
    return d


def _cm_hooks(name):
    """Функції проєктних пультів (напр. thuma_classic.hrb_mask_prepare) — шукаємо серед завантажених модулів."""
    out = []
    for mn, mod in list(sys.modules.items()):
        if mod is None or mn == __name__:
            continue
        try:
            f = mod.__dict__.get(name)
        except Exception:
            continue
        if callable(f) and f not in out:
            out.append(f)
    return out


def _cm_hidden_colls(view_layer):
    hidden = set()

    def walk(lc, ph):
        h = ph or lc.exclude or lc.collection.hide_render
        if h:
            hidden.add(lc.collection.name)
        for ch in lc.children:
            walk(ch, h)
    walk(view_layer.layer_collection, False)
    return hidden


def _cm_visible(scene, view_layer):
    hid = _cm_hidden_colls(view_layer)
    out = []
    for o in scene.objects:
        if o.type != 'MESH' or o.hide_render:
            continue
        p, ok = o.parent, True
        while p is not None:                      # сховали батька (Control) — сховані й діти
            if p.hide_render:
                ok = False
                break
            p = p.parent
        if ok and any(c.name not in hid for c in o.users_collection):
            out.append(o)
    return out


def _cm_tree_has_aov(nt, seen=None):
    seen = seen if seen is not None else set()
    if nt is None or nt.name in seen:
        return False
    seen.add(nt.name)
    for n in nt.nodes:
        if n.bl_idname == "ShaderNodeOutputAOV":
            return True
        if getattr(n, "node_tree", None) is not None and _cm_tree_has_aov(n.node_tree, seen):
            return True
    return False


def _cm_aov_names(nt, acc, seen=None):
    seen = seen if seen is not None else set()
    if nt is None or nt.name in seen:
        return acc
    seen.add(nt.name)
    for n in nt.nodes:
        if n.bl_idname == "ShaderNodeOutputAOV":
            acc.add(n.aov_name)
        if getattr(n, "node_tree", None) is not None:
            _cm_aov_names(n.node_tree, acc, seen)
    return acc


_CM_NODE_ATTRS = ("operation", "data_type", "blend_type", "attribute_name", "attribute_type", "aov_name",
                  "interpolation", "projection", "extension", "space", "layer_name", "uv_map", "clamp")


def _cm_node_sig(n, h, seen):
    h.update(f"{n.bl_idname}|{n.name}|".encode())
    for s in n.inputs:
        if s.is_linked or not hasattr(s, "default_value"):
            continue
        v = s.default_value
        try:
            v = tuple(round(float(x), 6) for x in v)
        except TypeError:
            v = round(v, 6) if isinstance(v, float) else v
        h.update(f"{s.identifier}={v!r};".encode())
    for a in _CM_NODE_ATTRS:
        if hasattr(n, a):
            h.update(f"{a}={getattr(n, a)!r};".encode())
    img = getattr(n, "image", None)
    if img is not None:
        p = bpy.path.abspath(img.filepath, library=img.library)
        h.update(p.encode("utf-8", "replace"))
        try:
            st = os.stat(p)
            h.update(f":{st.st_size}:{int(st.st_mtime)}".encode())
        except OSError:
            h.update(b":missing")
    nt = getattr(n, "node_tree", None)
    if nt is not None and nt.name not in seen:
        seen.add(nt.name)
        for m in sorted(nt.nodes, key=lambda x: x.name):
            _cm_node_sig(m, h, seen)
        for l in nt.links:
            h.update(f"{l.from_node.name}.{l.from_socket.identifier}>{l.to_node.name}.{l.to_socket.identifier}".encode())


def _cm_mat_sig(m):
    """Відбиток того, що впливає на маску: усе вище Displacement і AOV (колір/шорсткість тканини — ні)."""
    nt = m.node_tree if m else None
    if nt is None:
        return "none"
    h = hashlib.md5()
    for a in ("displacement_method",):
        h.update(repr(getattr(m, a, getattr(getattr(m, "cycles", None), a, None))).encode())
    roots = []
    for n in nt.nodes:
        if n.bl_idname == "ShaderNodeOutputAOV":
            roots.append(n)
        elif n.bl_idname == "ShaderNodeOutputMaterial" and n.target in ("ALL", "CYCLES"):
            for l in n.inputs["Displacement"].links:
                roots.append(l.from_node)
        elif getattr(n, "node_tree", None) is not None and _cm_tree_has_aov(n.node_tree):
            roots.append(n)
    keep, stack = set(), list(roots)
    while stack:
        n = stack.pop()
        if n.name in keep:
            continue
        keep.add(n.name)
        for s in n.inputs:
            for l in s.links:
                stack.append(l.from_node)
    seen = set()
    for n in sorted((nt.nodes[k] for k in keep), key=lambda x: x.name):
        _cm_node_sig(n, h, seen)
    for l in nt.links:
        if l.to_node.name in keep:
            h.update(f"{l.from_node.name}.{l.from_socket.identifier}>{l.to_node.name}.{l.to_socket.identifier}".encode())
    return h.hexdigest()[:16]


def _cm_mesh_sig(me):
    h = hashlib.md5(f"{len(me.vertices)}/{len(me.polygons)}/{len(me.loops)}".encode())
    if len(me.vertices):
        co = np.empty(len(me.vertices) * 3, np.float32)
        me.vertices.foreach_get("co", co)
        h.update(np.round(co, 5).tobytes())
    return h.hexdigest()[:16]


def _cm_mod_sig(o):
    parts = []
    for md in o.modifiers:
        if not md.show_render or md.name.startswith("WC_"):     # WC_* вмикає сама маска — не зміна сцени
            continue
        p = [md.type, md.name]
        for pr in md.bl_rna.properties:
            if pr.is_readonly or pr.identifier in ("name", "show_viewport", "show_in_editmode", "show_on_cage",
                                                  "show_expanded", "is_active", "use_pin_to_last"):
                continue
            try:
                v = getattr(md, pr.identifier)
            except Exception:
                continue
            if pr.type == 'POINTER':
                v = getattr(v, "name", None)
            elif pr.type in ('FLOAT', 'INT', 'BOOLEAN') and getattr(pr, "array_length", 0):
                v = tuple(round(x, 5) if isinstance(x, float) else x for x in v)
            elif isinstance(v, float):
                v = round(v, 5)
            elif pr.type == 'COLLECTION':
                continue
            p.append(f"{pr.identifier}={v!r}")
        if md.type == 'NODES':                        # значення входів групи (4.x — id-властивості, 5.x — properties)
            try:
                p.append(repr(sorted((k, repr(md[k])) for k in md.keys())))
            except Exception:
                pass
        parts.append("|".join(p))
    return hashlib.md5("\n".join(parts).encode("utf-8", "replace")).hexdigest()[:12]


def _cm_frame_fp(scene, vis, mat_sigs, mesh_sigs, legend_sig, hook_sig, edges_tag=""):
    """Відбиток одного кадру після підготовки сцени. edges_tag: "" = жорсткі, "|softaa" = м'які (згладжування), "|softK" = суперсемплінг K."""
    h = hashlib.md5(f"r{CM_RECIPE}|{legend_sig}|{hook_sig}|{scene.get('hrb_colorway', '')}{edges_tag}".encode())
    r = scene.render
    h.update(f"{r.resolution_x}x{r.resolution_y}@{r.resolution_percentage}|{r.pixel_aspect_x}/{r.pixel_aspect_y}".encode())
    cam = scene.camera
    if cam:
        c = cam.data
        mw = tuple(round(x, 5) for row in cam.matrix_world for x in row)
        h.update(f"{cam.name}|{mw}|{c.type}|{c.lens:.4f}|{c.sensor_width:.3f}|{c.sensor_fit}|{c.shift_x:.5f}|"
                 f"{c.shift_y:.5f}|{c.ortho_scale:.5f}|{c.clip_start:.4f}|{c.clip_end:.2f}".encode())
    for o in sorted(vis, key=lambda x: x.name):
        me = o.data
        if me.name not in mesh_sigs:
            mesh_sigs[me.name] = _cm_mesh_sig(me)
        mats = []
        for sl in o.material_slots:
            m = sl.material
            if m is not None and m.name not in mat_sigs:
                mat_sigs[m.name] = _cm_mat_sig(m)
            mats.append(f"{m.name}:{mat_sigs[m.name]}" if m else "-")
        mw = tuple(round(x, 5) for row in o.matrix_world for x in row)
        col = tuple(round(x, 4) for x in o.get(CM_OBJ_PROP, (0, 0, 0)))
        h.update(f"{o.name}|{me.name}:{mesh_sigs[me.name]}|{mw}|{_cm_mod_sig(o)}|{mats}|{col}\n".encode("utf-8", "replace"))
    return h.hexdigest()


# ---------- фоновий процес: підготовка сцени «лише маска» ----------

def _cm_gpu(scene, R):
    try:
        cp = bpy.context.preferences.addons["cycles"].preferences
    except Exception:
        return
    for dt in ("OPTIX", "CUDA", "HIP", "METAL", "ONEAPI"):
        try:
            cp.compute_device_type = dt
        except TypeError:
            continue
        cp.get_devices()
        real = {d.id for d in cp.get_devices_for_type(dt) if d.type == dt}
        if real:
            for d in cp.devices:
                d.use = d.id in real
            scene.cycles.device = 'GPU'
            R["gpu"] = f"{dt} {[d.name for d in cp.devices if d.id in real]}"
            return
    scene.cycles.device = 'CPU'
    R["gpu"] = "CPU"


def _cm_flag_source(nt):
    """cycles AA: звідки береться fabric_mask у матеріалі. -> сокет (AOV на рівні матеріалу), 1.0 (AOV лише в групі —
    вважаємо весь матеріал тканиною), значення (AOV без зв'язку) або None (не тканина)."""
    for n in nt.nodes:
        if n.bl_idname == "ShaderNodeOutputAOV" and n.aov_name == FLAG_AOV:
            s = n.inputs["Value"]
            return s.links[0].from_socket if s.is_linked else float(s.default_value)
    return 1.0 if FLAG_AOV in _cm_aov_names(nt, set()) else None


def _cm_add_zcov(nt, seen=None):
    """cycles AA: поруч з кожним AOV fl_zone (і в групах) — AOV wc_m_zcov = 1, якщо зона ≠ 0. Ідемпотентно."""
    seen = seen if seen is not None else set()
    if nt is None or nt.as_pointer() in seen:
        return
    seen.add(nt.as_pointer())
    for n in list(nt.nodes):
        if getattr(n, "node_tree", None) is not None:
            _cm_add_zcov(n.node_tree, seen)
    if nt.get("_wc_zcov"):
        return
    for n in list(nt.nodes):
        if n.bl_idname != "ShaderNodeOutputAOV" or n.aov_name != ZONE_AOV:
            continue
        nt["_wc_zcov"] = 1
        a = nt.nodes.new("ShaderNodeOutputAOV"); a.aov_name = ZCOV_AOV
        s = n.inputs["Color"]
        if not s.is_linked:
            a.inputs["Value"].default_value = 1.0 if max(s.default_value[:3]) > 1e-6 else 0.0
            continue
        ln = nt.nodes.new("ShaderNodeVectorMath"); ln.operation = 'LENGTH'
        nt.links.new(s.links[0].from_socket, ln.inputs[0])
        gt = nt.nodes.new("ShaderNodeMath"); gt.operation = 'GREATER_THAN'
        gt.inputs[1].default_value = 1e-6
        nt.links.new(ln.outputs["Value"], gt.inputs[0])
        nt.links.new(gt.outputs[0], a.inputs["Value"])


def _cm_convert_mat(m, aa=False):
    """Матеріал -> «лише маска» (у пам'яті фонового процесу). Ідемпотентно.
    aa (cycles AA): у тканині wc_m_face × (1 − fabric_mask) + AOV wc_m_zcov біля fl_zone — Face складається з AOV."""
    nt = m.node_tree
    if nt is None or m.get("_wc_cm_done"):
        return False
    m["_wc_cm_done"] = 1
    outs = [n for n in nt.nodes if n.bl_idname == "ShaderNodeOutputMaterial" and n.target in ("ALL", "CYCLES")]
    if not outs:
        return False
    for out in outs:
        for s in ("Surface", "Volume"):
            for l in list(out.inputs[s].links):
                nt.links.remove(l)
        bk = nt.nodes.new("ShaderNodeBsdfDiffuse")
        bk.inputs["Color"].default_value = (0, 0, 0, 1)
        nt.links.new(bk.outputs[0], out.inputs["Surface"])       # порожній Surface = прозоро, кольори складаються
    oc = nt.nodes.new("ShaderNodeAttribute"); oc.attribute_type = 'OBJECT'; oc.attribute_name = CM_OBJ_PROP
    a1 = nt.nodes.new("ShaderNodeOutputAOV"); a1.aov_name = "wc_m_obj"
    nt.links.new(oc.outputs["Color"], a1.inputs["Color"])
    pa = nt.nodes.new("ShaderNodeAttribute"); pa.attribute_type = 'GEOMETRY'; pa.attribute_name = PAINTED_ATTR
    fc = nt.nodes.new("ShaderNodeAttribute"); fc.attribute_type = 'GEOMETRY'; fc.attribute_name = ATTR_NAME
    mx = nt.nodes.new("ShaderNodeMix"); mx.data_type = 'RGBA'; mx.clamp_factor = True
    nt.links.new(pa.outputs["Fac"], mx.inputs[0])
    nt.links.new(oc.outputs["Color"], mx.inputs[6])
    nt.links.new(fc.outputs["Color"], mx.inputs[7])
    a2 = nt.nodes.new("ShaderNodeOutputAOV"); a2.aov_name = "wc_m_face"
    src = mx.outputs[2]
    if aa:
        fl = _cm_flag_source(nt)
        if fl is not None:                            # тканина: у Face її дає зона, не колір полігонів
            m2 = nt.nodes.new("ShaderNodeMix"); m2.data_type = 'RGBA'; m2.clamp_factor = True
            if isinstance(fl, float):
                m2.inputs[0].default_value = fl
            else:
                nt.links.new(fl, m2.inputs[0])
            nt.links.new(src, m2.inputs[6])
            m2.inputs[7].default_value = (0, 0, 0, 1)
            src = m2.outputs[2]
        _cm_add_zcov(nt)
    nt.links.new(src, a2.inputs["Color"])
    return True


def _cm_prepare(scene, R, soft=False, aa_spp=0, fast=True):
    vl = bpy.context.view_layer
    names = set()
    for m in bpy.data.materials:
        _cm_aov_names(m.node_tree, names)
    R["has_zones"] = ZONE_AOV in names and FLAG_AOV in names
    want = [("wc_m_obj", 'COLOR'), ("wc_m_face", 'COLOR')]
    if R["has_zones"]:
        want += [(ZONE_AOV, 'COLOR'), (FLAG_AOV, 'VALUE')]
        if aa_spp:
            want.append((ZCOV_AOV, 'VALUE'))
    for nm, ty in want:
        if nm not in vl.aovs:
            a = vl.aovs.add(); a.name = nm; a.type = ty
    if not R["has_zones"]:
        _face_mods(True)                              # WC_Face* модифікатори (як у Workbench Face-масці)
    for o in bpy.data.objects:
        if o.type == 'LIGHT':
            o.hide_render = True
        for a in ("is_shadow_catcher", "is_holdout"):
            if hasattr(o, a):
                setattr(o, a, False)
    scene.world = bpy.data.worlds.new("WC_MASK_BLACK")
    C = scene.cycles
    scene.render.engine = 'CYCLES'
    C.max_bounces = C.diffuse_bounces = C.glossy_bounces = C.transmission_bounces = 0
    C.volume_bounces = C.transparent_max_bounces = 0
    C.use_denoising = False
    C.use_adaptive_sampling = False
    C.samples = 1
    C.filter_width = 0.01
    if aa_spp:                                        # cycles AA: звичайний фільтр, N семплів -> усереднені AOV
        C.samples = int(aa_spp)
        C.filter_width = 1.5
        if hasattr(C, "pixel_filter_type"):
            C.pixel_filter_type = 'BLACKMAN_HARRIS'
    C.caustics_reflective = C.caustics_refractive = False
    C.seed = 1
    for a, v in (("use_auto_tile", False), ("use_animated_seed", False)):
        if hasattr(C, a):
            setattr(C, a, v)
    r = scene.render
    r.use_compositing = False
    r.use_sequencer = False
    r.use_border = False
    r.film_transparent = False
    r.use_motion_blur = False
    im = r.image_settings
    if hasattr(im, "media_type"):
        im.media_type = 'MULTI_LAYER_IMAGE'
    im.file_format = 'OPEN_EXR_MULTILAYER'
    im.color_depth = '32'
    im.exr_codec = 'ZIP'
    r.use_file_extension = False
    if fast:                                          # 3.10.0 швидкість: лише потрібні пасси (EXR у рази менший),
        _cm_soft_passes(scene, vl, [n for n, _t in want])   # швидкий стиск без втрат, сцена Cycles між кадрами
        try:
            im.exr_codec = 'RLE'
        except Exception:
            pass
        r.use_persistent_data = bool(R.get("persistent", False))   # +3.5 ГБ RAM за ~0.5 с/кадр (бенч PC2 17.11) — вимк.
    if soft:                                          # великий кадр: лише потрібні пасси, плитки, half EXR
        _cm_soft_passes(scene, vl, [n for n, _t in want])
        if hasattr(C, "use_auto_tile"):
            C.use_auto_tile = True
            C.tile_size = 4096
        im.color_depth = '16'                         # half: колір легенди -> 8 біт без втрат (похибка < 0.13 коду)
        r.use_persistent_data = True                  # смуги одного кадру — без повторної збірки сцени
    _cm_gpu(scene, R)


def _cm_soft_passes(scene, vl, keep_aovs):
    """М'які краї: кадр у K² більший -> вимкнути зайві пасси бьюті й інші шари (пам'ять/час). На AOV не впливає."""
    scene.render.use_single_layer = True
    for a in ("use_pass_z", "use_pass_mist", "use_pass_normal", "use_pass_position", "use_pass_vector", "use_pass_uv",
              "use_pass_object_index", "use_pass_material_index", "use_pass_diffuse_direct", "use_pass_diffuse_indirect",
              "use_pass_diffuse_color", "use_pass_glossy_direct", "use_pass_glossy_indirect", "use_pass_glossy_color",
              "use_pass_transmission_direct", "use_pass_transmission_indirect", "use_pass_transmission_color",
              "use_pass_emit", "use_pass_environment", "use_pass_ambient_occlusion", "use_pass_shadow",
              "use_pass_cryptomatte_object", "use_pass_cryptomatte_material", "use_pass_cryptomatte_asset"):
        if getattr(vl, a, False):
            try:
                setattr(vl, a, False)
            except Exception:
                pass
    cv = getattr(vl, "cycles", None)
    for a in ("denoising_store_passes", "use_pass_shadow_catcher", "use_pass_volume_direct", "use_pass_volume_indirect",
              "pass_debug_sample_count"):
        if cv is not None and getattr(cv, a, False):
            try:
                setattr(cv, a, False)
            except Exception:
                pass
    for a in list(vl.aovs):
        if a.name not in keep_aovs:
            vl.aovs.remove(a)
    for lg in list(getattr(vl, "lightgroups", [])):
        vl.lightgroups.remove(lg)


def _cm_set_obj_colors(legend):
    """Колір об'єкта -> id-властивість wc_mk_col (лінійний) — її читає Attribute(Object). obj.color НЕ чіпаємо:
    матеріали Thuma читають Object Info Color (бьюті змінювалось)."""
    lo = (legend or {}).get("objects", {})
    for o in bpy.data.objects:
        if o.type != 'MESH':
            continue
        if legend is not None:
            h = lo.get(o.name)
            o[CM_OBJ_PROP] = tuple(_cm_s2l(x) for x in _cm_hex2rgb(h)) if h else (0.0, 0.0, 0.0)
        else:
            o[CM_OBJ_PROP] = tuple(o.wc_color[:3])


_CM_LUT16 = None


def _cm_half_lut():
    """half (як uint16) -> sRGB 8 біт: те саме, що _cm_l2s8 на float, але табличкою (кадр 13500² — у рази швидше)."""
    global _CM_LUT16
    if _CM_LUT16 is None:
        v = np.nan_to_num(np.arange(65536, dtype=np.uint16).view(np.float16).astype(np.float32), nan=0.0,
                          posinf=1.0, neginf=0.0)
        _CM_LUT16 = _cm_l2s8(v)
    return _CM_LUT16


def _cm_read_exr(path, want, strip=512, half=False):
    """EXR -> {aov: uint8 sRGB (H,W,3)} для COLOR, {aov: bool (H,W)} (>0.5) для VALUE. Читає смугами лише потрібні
    канали — у пам'яті нема повного float-кадру (м'які краї: кадр 13500²). half=True — EXR записаний у half
    (м'які краї): читаємо як half і переводимо табличкою, без втрат."""
    import OpenImageIO as oiio
    fmt = oiio.HALF if half else oiio.FLOAT
    lut = _cm_half_lut() if half else None
    inp = oiio.ImageInput.open(path)
    if inp is None:
        raise RuntimeError(f"EXR не відкрився: {path}")
    got, i = {}, 0
    try:
        while inp.seek_subimage(i, 0):
            spec = inp.spec()
            nm = list(spec.channelnames)
            for aov, kind in want:
                if aov in got:
                    continue
                flt = kind.endswith("_F")                 # cycles AA: лінійний float як є (H,W,3) / (H,W)
                kind = kind[:-2] if flt else kind
                if kind == 'VALUE':
                    idx = [j for j, n in enumerate(nm) if any(n.endswith(f"{aov}.{c}") for c in ("R", "V", "X"))][:1]
                    ok = len(idx) == 1
                else:
                    idx = [next((j for j, n in enumerate(nm) if n.endswith(f"{aov}.{c}")), None) for c in "RGB"]
                    ok = None not in idx
                if not ok:
                    continue
                H, W = spec.height, spec.width
                if flt:
                    out = np.empty((H, W, 3) if kind == 'COLOR' else (H, W), np.float32)
                else:
                    out = np.empty((H, W, 3), np.uint8) if kind == 'COLOR' else np.empty((H, W), bool)
                c0, c1 = min(idx), max(idx) + 1
                for y in range(0, H, strip):
                    y1 = min(y + strip, H)
                    if c1 - c0 <= 4:
                        px = np.asarray(inp.read_scanlines(i, 0, spec.y + y, spec.y + y1, 0, c0, c1, fmt))
                        px = px.reshape(y1 - y, W, c1 - c0)[:, :, [j - c0 for j in idx]]
                    else:
                        px = np.stack([np.asarray(inp.read_scanlines(i, 0, spec.y + y, spec.y + y1, 0, j, j + 1,
                                                                      fmt)).reshape(y1 - y, W)
                                       for j in idx], -1)
                    if flt:
                        out[y:y1] = px if kind == 'COLOR' else px[:, :, 0]
                    elif kind == 'COLOR':
                        out[y:y1] = lut[px.astype(np.float16).view(np.uint16)] if half else _cm_l2s8(px)
                    else:
                        out[y:y1] = px[:, :, 0] > 0.5
                got[aov] = out
            i += 1
    finally:
        inp.close()
    miss = [a for a, _k in want if a not in got]
    if miss:
        raise RuntimeError(f"нема AOV у EXR: {miss}")
    return got


CM_BAND_PX = 30_000_000               # м'які краї: пікселів великого кадру за один рендер (смуга)


def _cm_render_ss(scene, exr, k, W, H, want, info):
    """Кадр W×H у k× розмірі смугами (border + crop): кадрування як у бьюті, у пам'яті Blender лише одна смуга.
    -> {aov: uint8 (H*k, W*k, 3) | bool (H*k, W*k)}"""
    r = scene.render
    Wh, Hh = W * k, H * k
    keep = (r.resolution_x, r.resolution_y, r.resolution_percentage, r.use_border, r.use_crop_to_border,
            r.border_min_x, r.border_max_x, r.border_min_y, r.border_max_y)
    band = max(k, CM_BAND_PX // Wh // k * k)
    out = {a: (np.zeros((Hh, Wh, 3), np.uint8) if kind == 'COLOR' else np.zeros((Hh, Wh), bool)) for a, kind in want}
    t_r = t_io = 0.0
    C = scene.cycles
    dr = getattr(C, "dicing_rate", None)
    try:
        if dr is not None:                            # адаптивний поділ у пікселях: у k× кадрі піксель у k разів менший
            C.dicing_rate = dr * k                    # -> та сама сітка рельєфу, що в бьюті (і не в 9 разів важча)
        r.resolution_x, r.resolution_y, r.resolution_percentage = Wh, Hh, 100
        r.use_border = r.use_crop_to_border = True
        r.border_min_x, r.border_max_x = 0.0, 1.0
        nb = 0
        for top in range(0, Hh, band):                # рядки зверху вниз; border — знизу вгору
            bot = min(top + band, Hh)
            r.border_min_y = (Hh - bot + 0.25) / Hh       # +0.25 px: Blender обрізає до цілого -> рівно наш рядок
            r.border_max_y = min((Hh - top + 0.25) / Hh, 1.0)
            t = time.time()
            bpy.ops.render.render(write_still=True)
            t_r += time.time() - t
            t = time.time()
            got = _cm_read_exr(exr, want, half=True)
            for a, arr in got.items():
                if arr.shape[:2] != (bot - top, Wh):
                    raise RuntimeError(f"смуга {top}-{bot}: розмір {arr.shape[1]}x{arr.shape[0]} ≠ {Wh}x{bot - top}")
                out[a][top:bot] = arr
            del got
            t_io += time.time() - t
            nb += 1
    finally:
        (r.resolution_x, r.resolution_y, r.resolution_percentage, r.use_border, r.use_crop_to_border,
         r.border_min_x, r.border_max_x, r.border_min_y, r.border_max_y) = keep
        if dr is not None:
            C.dicing_rate = dr
    info["render_s"], info["read_s"], info["bands"] = round(t_r, 1), round(t_io, 1), nb
    return out


_CM_LUT = None


def _cm_down(a, K, H, W, strip=256):
    """М'які краї: uint8 sRGB (H*K, W*K, 3) -> (H, W, 3) середнім блоків K×K у лінійному світлі.
    Якщо великий кадр не рівно K× (не мало б бути) — обрізати / дотягнути краєм."""
    global _CM_LUT
    if _CM_LUT is None:
        _CM_LUT = np.array([_cm_s2l(c) for c in range(256)], np.float32)
    hh, ww = H * K, W * K
    if a.shape[0] != hh or a.shape[1] != ww:
        a = a[:hh, :ww]
        if a.shape[0] < hh or a.shape[1] < ww:
            a = np.pad(a, ((0, hh - a.shape[0]), (0, ww - a.shape[1]), (0, 0)), mode="edge")
    out = np.empty((H, W, 3), np.uint8)
    for y in range(0, H, strip):
        n = min(strip, H - y)
        blk = _CM_LUT[a[y * K:(y + n) * K]]                   # (n*K, W*K, 3) float32, лінійне
        out[y:y + n] = _cm_l2s8(blk.reshape(n, K, W, K, 3).mean(axis=(1, 3)))
    return out


CM_PNG_LEVEL = 6                      # zlib PNG масок (6 = як раніше); job["png_level"] міняє (1–3 швидше, файл трохи більший)


def _cm_write_png(path, arr, level=None):
    import OpenImageIO as oiio
    tmp = path + ".tmp.png"
    o = oiio.ImageOutput.create(tmp)
    spec = oiio.ImageSpec(arr.shape[1], arr.shape[0], arr.shape[2], oiio.UINT8)
    spec.attribute("png:compressionLevel", int(CM_PNG_LEVEL if level is None else level))
    o.open(tmp, spec)
    o.write_image(np.ascontiguousarray(arr))
    o.close()
    os.replace(tmp, path)


def _cm_fill(face, need, valid, max_it=400):
    """Пікселі тканини без зони (тонкі щілини на стиках подушок) -> колір найближчої зони. Силует не рухається.
    Той самий результат, що зсуви np.roll по всьому кадру, але працює лише зі списком порожніх пікселів
    (на кадрі 13500² — секунди, а не хвилини). valid змінюється на місці."""
    H, W = need.shape
    ys, xs = np.nonzero(need)
    it = 0
    while ys.size and it < max_it:
        it += 1
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            sy, sx = (ys - dy) % H, (xs - dx) % W         # np.roll(valid, (dy, dx))[y, x] == valid[y-dy, x-dx]
            m = valid[sy, sx]
            if m.any():
                ty, tx = ys[m], xs[m]
                face[ty, tx] = face[sy[m], sx[m]]
                valid[ty, tx] = True
                k = ~m
                ys, xs = ys[k], xs[k]
                if not ys.size:
                    break
    return it


def _cm_pack(a):
    """uint8 (H,W,3) -> uint32 (H,W) 0xRRGGBB."""
    return (a[..., 0].astype(np.uint32) << 16) | (a[..., 1].astype(np.uint32) << 8) | a[..., 2]


def _cm_dil(m, r):
    """Бінарна дилатація квадратом (2r+1)², сепарабельно."""
    o = m.copy()
    for s in range(1, r + 1):
        o[s:] |= m[:-s]
        o[:-s] |= m[s:]
    m, o = o, o.copy()
    for s in range(1, r + 1):
        o[:, s:] |= m[:, :-s]
        o[:, :-s] |= m[:, s:]
    return o


def _cm_core(p, r):
    """Пікселі, у квадраті (2r+1)² яких усі мітки однакові (ерозія всіх кольорів разом)."""
    H, W = p.shape
    pp = np.pad(p, r, mode="edge")
    row = np.ones((H + 2 * r, W), bool)
    for dx in range(-r, r + 1):
        if dx:
            row &= pp[:, r + dx:r + dx + W] == pp[:, r:r + W]
    c = pp[r:r + H, r:r + W]
    ok = np.ones((H, W), bool)
    for dy in range(-r, r + 1):
        ok &= row[r + dy:r + dy + H] & (pp[r + dy:r + dy + H, r:r + W] == c)
    return ok


def _cm_components(p, m):
    """Зв'язні області одного кольору (4-сусідство) серед пікселів m: пробіги рядків + union-find.
    -> (id області на піксель (H,W) int64, площа області за id)."""
    H, W = p.shape
    q = np.where(m, p.astype(np.int64), -1)
    st = np.ones((H, W), bool)
    st[:, 1:] = q[:, 1:] != q[:, :-1]
    rid = np.cumsum(st.ravel()).reshape(H, W) - 1                  # id пробігу (новий рядок -> новий пробіг)
    n = int(rid[-1, -1]) + 1
    v = m[:-1] & (q[:-1] == q[1:])
    e = np.unique(rid[:-1][v] * n + rid[1:][v])
    a, b = e // n, e % n
    lab = np.arange(n)
    for _ in range(200):
        mn = np.minimum(lab[a], lab[b])
        new = lab.copy()
        np.minimum.at(new, lab[a], mn)
        np.minimum.at(new, lab[b], mn)
        while True:                                                # стиснення шляхів
            nn = new[new]
            if np.array_equal(nn, new):
                break
            new = nn
        if np.array_equal(new, lab):
            break
        lab = new
    area = np.bincount(lab, weights=np.bincount(rid.ravel(), minlength=n), minlength=n)
    return lab[rid], area


def _cm_clean_seams(face, fab, k=1, r=CM_SEAM_R, min_area=CM_SEAM_AREA):
    """Face: тонкі смужки (тонші за 2r+1 px) і острівці (< min_area px) зон тканини, затиснуті між іншими зонами
    (канавка шва — «чужа» зона по нормалі) -> колір найближчої сусідньої зони, шов ділиться навпіл.
    Не чіпає: нетканину, силует (смужки ≤r px від нетканини/фону), острівці, що торкаються нетканини.
    k — масштаб кадру (суперсемплінг). face змінюється на місці. -> (перефарбовано px, {hex: px})."""
    if not fab.any():
        return 0, {}
    r, min_area = r * k, min_area * k * k
    rows, cols = np.flatnonzero(fab.any(1)), np.flatnonzero(fab.any(0))
    y0, y1 = max(rows[0] - r - 2, 0), rows[-1] + r + 3
    x0, x1 = max(cols[0] - r - 2, 0), cols[-1] + r + 3
    f, fb = face[y0:y1, x0:x1], fab[y0:y1, x0:x1]
    p = np.where(fb, _cm_pack(f), np.uint32(0x1000000))           # уся нетканина = одна мітка
    near_nf = _cm_dil(~fb, r)
    thin = fb & ~_cm_dil(_cm_core(p, r), r) & ~near_nf             # не пережила відкриття і далеко від нетканини
    cid, area = _cm_components(p, fb)
    touch = np.zeros(area.size, bool)
    touch[cid[fb & _cm_dil(~fb, 1)]] = True                        # область торкається нетканини/фону -> не чіпати
    small = fb & (area[cid] < min_area) & ~touch[cid]
    del cid, near_nf
    bad = thin | small
    if not bad.any():
        return 0, {}
    was = _cm_pack(f[bad])
    sub = f.copy()
    _cm_fill(sub, bad, fb & ~bad)
    now = _cm_pack(sub[bad])
    ch = was != now
    u, c = np.unique(was[ch], return_counts=True)
    face[y0:y1, x0:x1] = sub
    return int(ch.sum()), {"#%06x" % int(x): int(n) for x, n in sorted(zip(u, c), key=lambda t: -t[1])}


def _cm_aa(img, sigma=CM_AA_SIGMA, R=CM_AA_R, chunk=1 << 19):
    """М'які краї після жорсткого рендеру: лише пікселі ≤R px від межі кольорів. Для пікселя — його колір A і головний
    інший колір вікна (2R+1)² B; вага кольору = гаусове (σ) розмиття його бінарної маски; результат = суміш A і B
    у лінійному світлі -> 8 біт. Всередині зон колір не змінюється. -> (нове зображення, змінено px)."""
    global _CM_LUT
    if _CM_LUT is None:
        _CM_LUT = np.array([_cm_s2l(c) for c in range(256)], np.float32)
    H, W = img.shape[:2]
    p = _cm_pack(img)
    e = np.zeros((H, W), bool)
    d = p[:, 1:] != p[:, :-1]
    e[:, 1:] |= d
    e[:, :-1] |= d
    d = p[1:] != p[:-1]
    e[1:] |= d
    e[:-1] |= d
    del d
    if not e.any():
        return img, 0
    rows, cols = np.flatnonzero(e.any(1)), np.flatnonzero(e.any(0))
    y0, y1 = max(rows[0] - R, 0), min(rows[-1] + R + 1, H)
    x0, x1 = max(cols[0] - R, 0), min(cols[-1] + R + 1, W)
    band = _cm_dil(e[y0:y1, x0:x1], R - 1) if R > 1 else e[y0:y1, x0:x1]   # e — уже пікселі біля межі
    del e
    pp = np.pad(p[y0:y1, x0:x1], R, mode="edge")
    offs = sorted(((dy, dx) for dy in range(-R, R + 1) for dx in range(-R, R + 1)), key=lambda o: o[0] ** 2 + o[1] ** 2)
    g = np.array([math.exp(-(dy * dy + dx * dx) / (2 * sigma * sigma)) for dy, dx in offs], np.float32)[:, None]
    ys, xs = np.nonzero(band)
    del band
    out = img.copy()
    NONE = np.uint32(0xFFFFFFFF)
    changed = 0
    for i in range(0, ys.size, chunk):
        y, x = ys[i:i + chunk] + R, xs[i:i + chunk] + R
        L = np.stack([pp[y + dy, x + dx] for dy, dx in offs])           # (K, n), [0] — сам піксель
        A = L[0]
        B = np.full(A.shape, NONE)
        C = np.full(A.shape, NONE)
        for j in range(1, len(offs)):                                   # найближчий інший колір, і ще один
            o = L[j] != A
            C = np.where((C == NONE) & (B != NONE) & o & (L[j] != B), L[j], C)
            B = np.where((B == NONE) & o, L[j], B)
        wa, wb, wc = (g * (L == A)).sum(0), (g * (L == B)).sum(0), (g * (L == C)).sum(0)
        sw = (C != NONE) & (wc > wb)                                    # головний інший — з більшою вагою
        B, wb = np.where(sw, C, B), np.where(sw, wc, wb)
        t = wb / (wa + wb + 1e-9)
        m = (B != NONE) & (t >= CM_AA_MIN)                              # дрібна домішка -> рівно колір легенди
        if not m.any():
            continue
        A, B, t = A[m], B[m], t[m][:, None]
        ca = np.stack([(A >> 16) & 255, (A >> 8) & 255, A & 255], -1)
        cb = np.stack([(B >> 16) & 255, (B >> 8) & 255, B & 255], -1)
        out[y[m] - R + y0, x[m] - R + x0] = _cm_l2s8(_CM_LUT[ca] * (1 - t) + _CM_LUT[cb] * t)
        changed += int(m.sum())
    return out, changed


def _cm_compose_aa(got, has_zones, spp, info):
    """cycles AA: усереднені лінійні AOV -> Face, Object uint8 sRGB.
    Face = зона + полігони нетканини (у шейдері вже ×(1−fabric_mask)) + (fabric_mask − zcov) × колір найближчої зони:
    семпли тканини без зони (щілини) отримують зону сусіда, як заливка в жорсткому режимі, -> край не темніє."""
    obj = _cm_l2s8(got.pop("wc_m_obj"))
    face = got.pop("wc_m_face")
    if has_zones:
        z, f, c = got.pop(ZONE_AOV), got.pop(FLAG_AOV), got.pop(ZCOV_AOV)
        face += z
        miss = np.clip(f - c, 0.0, 1.0)
        info["fabric_px"] = int((f > 0.5).sum())
        need = miss > 1e-3
        info["gap_px"] = int(need.sum())
        if need.any():
            fab = f > 1e-4
            rows, cols = np.flatnonzero(fab.any(1)), np.flatnonzero(fab.any(0))
            y0, y1 = max(rows[0] - 4, 0), rows[-1] + 5
            x0, x1 = max(cols[0] - 4, 0), cols[-1] + 5
            cs, zs, ns = c[y0:y1, x0:x1], z[y0:y1, x0:x1], need[y0:y1, x0:x1]
            eps = 0.5 / max(int(spp), 1)
            valid = cs >= eps
            zf = np.where(valid[..., None], zs / np.maximum(cs, eps)[..., None], 0.0).astype(np.float32)
            holes = ns & ~valid                       # піксель цілком у щілині -> зона найближчого сусіда
            info["gap_hole_px"] = int(holes.sum())
            if holes.any():
                info["fill_iters"] = _cm_fill(zf, holes, valid.copy())
            face[y0:y1, x0:x1] += miss[y0:y1, x0:x1, None] * zf
            del zf, valid, holes
        del z, f, c, miss, need
    return _cm_l2s8(face), obj


def _cm_zones_by_object(face, obj, zone_cols, info=None):
    """Face: зони тканини не виходять за межі деталей (Object). Для кожної деталі тканини: «свої» зони = ті, що мають
    товсту ділянку (квадрат ~9 px) і площу ≥ ~1500 px (на 4500²); їхні ділянки лишаються, крім крихт (< ~40 px,
    тонких). Решта — чужі смужки (зона сусідньої деталі, наприклад сидіння, що залилося в щілину на підлокітник) і
    крихти в швах -> колір найближчої своєї зони цієї ж деталі. Пікселі згладжених країв лишаються, якщо це суміш двох
    своїх кольорів (біля межі деталі — свого і будь-якого кольору кадру), інакше теж перефарбовуються.
    Пороги масштабуються від розміру кадру. face змінюється на місці. -> перефарбовано px."""
    t0 = time.time()
    H, W = obj.shape[:2]
    s = max(max(H, W) / 4500.0, 0.25)
    r_th, a_main, a_crumb = max(2, int(round(4 * s))), 1500 * s * s, 40 * s * s
    zp = np.array(sorted({(r << 16) | (g << 8) | b for r, g, b in zone_cols}), np.uint32)
    if not zp.size:
        return 0
    pf = _cm_pack(face)
    zpure = np.isin(pf, zp)
    if not zpure.any():
        return 0
    rows, cols = np.flatnonzero(zpure.any(1)), np.flatnonzero(zpure.any(0))
    y0, y1 = max(rows[0] - 8, 0), min(rows[-1] + 9, H)
    x0, x1 = max(cols[0] - 8, 0), min(cols[-1] + 9, W)
    f, pf, zpure = face[y0:y1, x0:x1], pf[y0:y1, x0:x1], zpure[y0:y1, x0:x1]
    po = _cm_pack(obj[y0:y1, x0:x1])
    # мітка деталі на піксель: чисті кольори Object (3×3 однакові), змішані краї -> найближча чиста
    core1 = _cm_core(po, 1)
    pal, inv = np.unique(po[core1], return_inverse=True)
    L = np.full(po.shape, -1, np.int32)
    L[core1] = inv
    pure_o = np.isin(po, pal)
    L[pure_o & ~core1] = np.searchsorted(pal, po[pure_o & ~core1])
    need = L < 0
    if need.any():
        _cm_fill(L, need, ~need)
    del core1, inv, need
    n_o = pal.size
    # «свої» зони деталі: області (деталь, колір) серед чистих зон, товщина = переживає ерозію квадратом (2r+1)²
    key = np.where(zpure, (L.astype(np.int64) << 24) | pf, -1)
    cid, area = _cm_components(key, zpure)
    thick_c = np.zeros(area.size, bool)
    thick_c[cid[zpure & _cm_core(key, r_th)]] = True
    zi = np.searchsorted(zp, pf)                                  # індекс зони (для чистих)
    ids = np.flatnonzero(zpure.ravel())
    cmp_ = cid.ravel()[ids]
    ucmp, first = np.unique(cmp_, return_index=True)
    c_obj = L.ravel()[ids[first]]
    c_zone = zi.ravel()[ids[first]]
    c_area = area[ucmp]
    c_thick = thick_c[ucmp]
    main = np.zeros((n_o, zp.size), bool)
    big = c_thick & (c_area >= a_main)
    main[c_obj[big], c_zone[big]] = True
    fab_o = main.any(1)                                           # деталі тканини (є хоч одна своя зона)
    keep_c = np.zeros(area.size, bool)
    keep_c[ucmp] = main[c_obj, c_zone] & (c_thick | (c_area >= a_crumb))
    kept = zpure & keep_c[cid]
    del key, cid, area, thick_c, ids, cmp_, ucmp, first
    in_fab = fab_o[L]
    own = pf == po                                                # нетканина деталі (Face = колір об'єкта)
    bad = in_fab & zpure & ~kept
    # згладжені пікселі: суміш двох дозволених кольорів?
    mixed = in_fab & ~zpure & ~own
    if mixed.any():
        lut = np.array([_cm_s2l(float(v)) for v in range(256)], np.float32)
        band = ~_cm_core(L, 2)                                    # біля межі деталей
        allc = np.unique(np.concatenate([zp, pal]))               # усі кольори кадру (зони, об'єкти, фон)
        r_n = max(2, int(round(2 * s)))
        src = kept | ~zpure                                       # чисті пікселі, що лишаються (свої зони, нетканина, фон)
        near = {}

        def near_of(c):                                           # поруч (≤ r_n px) є чистий піксель кольору c, що лишається
            if c not in near:
                near[c] = _cm_dil(src & (pf == c), r_n)
            return near[c]

        def lin(p):
            return np.stack([lut[(p >> 16) & 255], lut[(p >> 8) & 255], lut[p & 255]], -1)
        my, mx = np.nonzero(mixed)
        P = lin(pf[my, mx])
        ok = np.zeros(my.size, bool)
        Lm, Bm = L[my, mx], band[my, mx]
        for o in np.unique(Lm):
            sel = np.flatnonzero(Lm == o)
            Ac = np.concatenate([zp[main[o]], pal[o:o + 1]])
            for inner, Bcs in ((True, Ac), (False, allc)):
                ss = sel[~Bm[sel]] if inner else sel[Bm[sel]]
                if not ss.size:
                    continue
                Pp, sy, sx = P[ss], my[ss], mx[ss]
                best = np.full(ss.size, np.inf, np.float32)
                for ca in Ac:
                    na = near_of(int(ca))[sy, sx]
                    if not na.any():
                        continue
                    a = lin(np.array([ca], np.uint32))[0]
                    for cb in Bcs:
                        if cb == ca:
                            continue
                        nab = na & near_of(int(cb))[sy, sx]
                        if not nab.any():
                            continue
                        d = lin(np.array([cb], np.uint32))[0] - a
                        dd = float((d * d).sum())
                        q = Pp[nab] - a
                        t = np.clip((q @ d) / dd, 0.0, 1.0)
                        e = q - t[:, None] * d
                        best[nab] = np.minimum(best[nab], np.sqrt((e * e).sum(1)))
                ok[ss] = best <= CM_ZOBJ_TOL
        bad[my[~ok], mx[~ok]] = True
        del P, ok, my, mx, near
    n = int(bad.sum())
    if n:
        # заливка лише з «своїх» пікселів тієї ж деталі: окремо по деталях (рамка деталі)
        lab = np.where(bad | kept | own, L, -1)
        for o in np.flatnonzero(fab_o):
            b_o = bad & (L == o)
            if not b_o.any():
                continue
            rr, cc = np.flatnonzero((lab == o).any(1)), np.flatnonzero((lab == o).any(0))
            a0, a1, b0, b1 = rr[0], rr[-1] + 1, cc[0], cc[-1] + 1
            sub = f[a0:a1, b0:b1].copy()
            v = ((kept | own) & (L == o))[a0:a1, b0:b1]
            nb = b_o[a0:a1, b0:b1]
            _cm_fill(sub, nb, v.copy())
            f[a0:a1, b0:b1][nb] = sub[nb]
    if info is not None:
        info["zobj_px"] = n
        info["zobj_s"] = round(time.time() - t0, 2)
    return n


def _cm_hist(a):
    p = (a[..., 0].astype(np.uint32) << 16) | (a[..., 1].astype(np.uint32) << 8) | a[..., 2]
    c = np.bincount(p.ravel(), minlength=1 << 24)     # 24 біти: лічильник 128 МБ, у рази швидше за np.unique (сортування)
    u = np.flatnonzero(c)
    return {"#%06x" % int(x): int(n) for x, n in zip(u, c[u])}


def _cm_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _cm_load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _cm_write_legend(out_dir, legend, seen, has_zones, edges="hard", ss=1, spp=0):
    """legend.json + legend.txt у теку масок (дописує до наявних: кадри різних запусків разом)."""
    p = os.path.join(out_dir, "legend.json")
    old = _cm_load(p, {})
    objs = old.get("objects_in_frames", {})
    for hx_, (name, frames) in seen.items():
        e = objs.setdefault(hx_, {"object": name, "frames": []})
        e["frames"] = sorted(set(e["frames"]) | set(frames))
    lz = (legend or {}).get("zones", {}) if has_zones else {}
    titles = (legend or {}).get("zone_titles", {})
    data = {"zones": lz, "objects": (legend or {}).get("objects", {}), "objects_in_frames": objs, "edges": edges,
            "note": "Face: тканина = колір зони, решта = колір об'єкта; Object: кожен об'єкт свій колір; фон #000000"}
    _cm_json(p, data)
    if edges in ("soft", "cycles"):
        head = [f"MASK LEGEND (WireColor Cycles masks, SOFT edges: " +
                (f"{ss}x{ss} supersampled)" if ss > 1 else f"Cycles antialiasing, {spp} spp)" if edges == "cycles"
                 else "antialiased, 1-2 px)"),
                "Inside every zone/object the colour is exactly the hex below; only edge pixels are a mix of the",
                "neighbouring colours (smooth, no stair-steps). For a PS magic-wand selection use hard edges.", ""]
    else:
        head = ["MASK LEGEND (WireColor Cycles masks, hard edges, no antialiasing)", ""]
    L = head + [
         "FACE mask: fabric = zone colour; everything else = its OBJECT colour.",
         "OBJECT mask: every mesh object = its own flat colour. Background = #000000.", ""]
    if lz:
        L.append("== FABRIC ZONES (Face mask) ==")
        L += [f"{h}  {titles.get(k, k)}" for k, h in lz.items()]
        L.append("")
    L.append("== OBJECTS (visible in rendered frames) - hex / object / frames ==")
    for hx_ in sorted(objs, key=lambda x: objs[x]["object"]):
        e = objs[hx_]
        L.append(f"{hx_}  {e['object']}   frames {','.join(map(str, e['frames']))}")
    with open(os.path.join(out_dir, "legend.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def cm_run_job(job_path):
    """Фоновий Blender: job.json -> маски. Статус пише в job["status"] після кожного кадру."""
    job = _cm_load(job_path, None)
    if job is None:
        raise RuntimeError(f"нема job: {job_path}")
    st_path = job["status"]
    S = {"ok": False, "finished": False, "total": len(job["items"]), "done": 0, "rendered": 0, "skipped": 0,
         "stale": [], "fresh": [], "missing": [], "errors": [], "current": None, "log": [], "files": [],
         "pid": os.getpid(), "t0": time.time(), "mode": job.get("mode", "render"), "blender": bpy.app.version_string, "recipe": CM_RECIPE}

    def log(*x):
        s = time.strftime("%H:%M:%S ") + " ".join(str(v) for v in x)
        S["log"] = (S["log"] + [s])[-40:]
        print("WCM", s, flush=True)

    def dump():
        S["secs"] = round(time.time() - S["t0"], 1)
        _cm_json(st_path, S)

    scene = bpy.context.scene
    try:
        mode = job.get("mode", "render")              # render | stale | check
        edges = job.get("edges") if job.get("edges") in ("hard", "soft", "cycles") else "cycles"
        K = max(1, int(job.get("ss", 1))) if edges == "soft" else 1   # суперсемплінг лише явно (job["ss"]), повільно
        spp = max(2, int(job.get("aa_spp", CM_AA_SPP))) if edges == "cycles" else 0
        clean = bool(job.get("clean", False)) and edges != "cycles"     # cycles AA: межі вже згладжені, чистки нема
        edges_tag = ((f"|soft{K}" if K > 1 else "|softaa" if edges == "soft" else f"|cyc{spp}" if spp else "")
                     + ("|clean" if clean else ""))
        zobj = bool(job.get("zones_by_object", True))   # зони тканини не виходять за межі деталей (Object)
        edges_tag += "|zobj" if zobj else ""
        S["edges"], S["ss"], S["clean"], S["spp"], S["zobj"] = edges, K, clean, spp, zobj
        legend = cm_legend(hooks=True)
        zcols = [_cm_hex2rgb(h) for h in (legend or {}).get("zones", {}).values()]
        if zobj and not zcols:
            S["zobj_note"] = "нема зон у легенді — зони по деталях не застосовано"
        legend_sig = hashlib.md5(json.dumps(legend, sort_keys=True).encode()).hexdigest()[:12] if legend else "wc_color"
        S["legend"] = (("сцена" if LEGEND_TEXT in bpy.data.texts else "пульт проєкту") if legend
                       else "кольори об'єктів WireColor")
        R = {"persistent": bool(job.get("persistent", False))}
        mat_sigs, mesh_sigs = {}, {}
        for m in bpy.data.materials:                   # відбитки — ДО переробки матеріалів
            mat_sigs[m.name] = _cm_mat_sig(m)
        fast = bool(job.get("fast", True))             # пасси/RLE/сцена між кадрами (False = як до 17.11 вечора)
        png_level = int(job.get("png_level", CM_PNG_LEVEL))
        S["fast"], S["png_level"] = fast, png_level
        if mode != "check":
            _cm_prepare(scene, R, soft=K > 1, aa_spp=spp, fast=fast)
            for m in bpy.data.materials:
                _cm_convert_mat(m, aa=bool(spp))
        else:
            R["has_zones"] = False
        S["gpu"] = R.get("gpu", "")
        S["has_zones"] = R.get("has_zones", False)
        _cm_set_obj_colors(legend)
        prep = _cm_hooks("hrb_mask_prepare")
        S["hooks"] = [getattr(f, "__module__", "?") for f in prep]
        log("сцена", os.path.basename(bpy.data.filepath), "| кадрів", S["total"], "| режим", mode, "| зони", S["has_zones"],
            "| хуки", S["hooks"], "|", S.get("gpu"), "| краї", edges + (f" {K}x" if K > 1 else " aa" if edges == "soft"
                                                                        else f" {spp} spp" if spp else ""),
            "| шви", clean, "| зони по деталях", zobj and bool(zcols))
        dump()
        seen_by_dir = {}
        for it in job["items"]:
            F = int(it["frame"])
            S["current"] = F
            dump()
            try:
                tf = time.time()
                scene.frame_set(F)
                hsig = []
                for f in prep:
                    info = f(scene, F)                 # може кинути помилку = кадр не готовий (розцвітка/шви)
                    if isinstance(info, dict) and info.get("sig"):
                        hsig.append(str(info["sig"]))
                for m in bpy.data.materials:           # пульт міг підставити матеріал, якого ще не бачили
                    if m.name not in mat_sigs:
                        mat_sigs[m.name] = _cm_mat_sig(m)
                    if mode != "check":
                        _cm_convert_mat(m, aa=bool(spp))
                hook_s = round(time.time() - tf, 2)
                vl = bpy.context.view_layer
                vis = _cm_visible(scene, vl)
                fp = _cm_frame_fp(scene, vis, mat_sigs, mesh_sigs, legend_sig, "|".join(hsig), edges_tag)
                fp_s = round(time.time() - tf - hook_s, 2)
                face_p, obj_p = it["face"], it["obj"]
                out_dir = os.path.dirname(face_p)
                os.makedirs(out_dir, exist_ok=True)
                ip = os.path.join(out_dir, CM_INDEX)
                idx = _cm_load(ip, {})
                key = os.path.basename(face_p)
                exists = os.path.exists(face_p) and os.path.exists(obj_p)
                same = exists and idx.get(key, {}).get("fp") == fp
                if mode in ("stale", "check"):
                    (S["fresh"] if same else S["stale"] if exists else S["missing"]).append(F)
                    if mode == "check" or same:
                        S["skipped"] += mode == "stale"
                        S["done"] += 1
                        continue
                exr = os.path.join(out_dir, f"_wc_tmp_f{F}_{os.getpid()}.exr")
                scene.render.filepath = exr
                r = scene.render
                W, H = r.resolution_x * r.resolution_percentage // 100, r.resolution_y * r.resolution_percentage // 100
                k = K                                  # м'які: великий кадр рівно K× (кадрування те саме, що в бьюті)
                while k > 1 and (W * H * k * k > CM_SS_MAX_PX or max(W, H) * k > 65536):
                    k -= 1
                want = [("wc_m_obj", 'COLOR'), ("wc_m_face", 'COLOR')]
                if S["has_zones"]:
                    want += [(ZONE_AOV, 'COLOR'), (FLAG_AOV, 'VALUE')]
                if spp:                                # cycles AA: лінійні float, Face складається з AOV
                    want = [(a, kd + "_F") for a, kd in want] + ([(ZCOV_AOV, 'VALUE_F')] if S["has_zones"] else [])
                t = time.time()
                info = {}
                if spp:
                    bpy.ops.render.render(write_still=True)
                    info["render_s"], info["spp"] = round(time.time() - t, 1), spp
                    t = time.time()
                    try:
                        info["exr_mb"] = round(os.path.getsize(exr) / 2**20, 1)
                    except OSError:
                        pass
                    got = _cm_read_exr(exr, want)
                    info["read_s"] = round(time.time() - t, 2)
                    try:
                        os.remove(exr)
                    except OSError:
                        pass
                    t = time.time()
                    face, obj = _cm_compose_aa(got, S["has_zones"], spp, info)
                    del got
                    if zobj and zcols and S["has_zones"]:
                        _cm_zones_by_object(face, obj, zcols, info)
                    hist_hard = None
                elif k > 1:                            # великий кадр смугами (пам'ять), одразу в uint8
                    got = _cm_render_ss(scene, exr, k, W, H, want, info)
                else:
                    bpy.ops.render.render(write_still=True)
                    info["render_s"] = round(time.time() - t, 1)
                    got = _cm_read_exr(exr, want)      # уже uint8 sRGB / bool
                if not spp:                            # жорсткий рендер -> заливка щілин, шви, м'які краї
                    try:
                        os.remove(exr)
                    except OSError:
                        pass
                    t = time.time()
                    hist_hard = None
                    obj, face = got.pop("wc_m_obj"), got.pop("wc_m_face")
                    if S["has_zones"]:
                        zone, fab = got.pop(ZONE_AOV), got.pop(FLAG_AOV)
                        face[fab] = zone[fab]
                        need = fab & ~zone.any(-1)
                        del zone
                        info["fabric_px"], info["filled_px"] = int(fab.sum()), int(need.sum())
                        if need.any():
                            rows, cols = np.flatnonzero(fab.any(1)), np.flatnonzero(fab.any(0))
                            y0, y1 = max(rows[0] - 4, 0), rows[-1] + 5
                            x0, x1 = max(cols[0] - 4, 0), cols[-1] + 5
                            sub = face[y0:y1, x0:x1].copy()
                            valid = fab[y0:y1, x0:x1] & ~need[y0:y1, x0:x1]
                            info["fill_iters"] = _cm_fill(sub, need[y0:y1, x0:x1], valid)
                            face[y0:y1, x0:x1] = sub
                            del sub, valid
                        del need
                        info["fill_s"] = round(time.time() - t, 2)
                        if clean:                          # шви: тонкі смужки/острівці чужих зон -> сусідні зони
                            t2 = time.time()
                            info["seam_px"], info["seam_cols"] = _cm_clean_seams(face, fab, k)
                            info["seam_s"] = round(time.time() - t2, 2)
                        del fab
                        if zobj and zcols:                 # до згладжування: межі деталей ще чисті
                            _cm_zones_by_object(face, obj, zcols, info)
                    if k > 1:
                        info["ss"] = k
                        t2 = time.time()
                        face, obj = _cm_down(face, k, H, W), _cm_down(obj, k, H, W)
                        info["down_s"] = round(time.time() - t2, 1)
                    elif edges == "soft":                  # м'які: згладжування меж після жорсткого рендеру
                        t2 = time.time()
                        hist_hard = _cm_hist(obj)          # об'єкти кадру — до згладжування (тонкі деталі теж)
                        face, n1 = _cm_aa(face)
                        obj, n2 = _cm_aa(obj)
                        info["aa_px"], info["aa_s"] = n1 + n2, round(time.time() - t2, 2)
                if face.shape[:2] != (H, W) or obj.shape[:2] != (H, W):
                    raise RuntimeError(f"розмір маски {face.shape[1]}x{face.shape[0]} ≠ кадр {W}x{H}")
                t2 = time.time()
                _cm_write_png(face_p, face, png_level)
                _cm_write_png(obj_p, obj, png_level)
                info["write_s"] = round(time.time() - t2, 2)
                t2 = time.time()
                hist = _cm_hist(obj)
                info["hist_s"] = round(time.time() - t2, 2)
                info["hook_s"], info["fp_s"] = hook_s, fp_s
                inv = {}
                for o in vis:
                    c = o.get(CM_OBJ_PROP, (0, 0, 0))
                    inv["#%02x%02x%02x" % tuple(_cm_l2s(x) for x in c)] = o.name
                if edges in ("soft", "cycles"):        # м'які: проміжні кольори країв — не «кольори об'єктів»
                    info["object_colours"] = sum(1 for h_ in (hist_hard or hist) if h_ in inv or h_ == "#000000")
                    info["edge_px_obj"] = sum(n for h_, n in hist.items() if h_ not in inv and h_ != "#000000")
                else:
                    info["object_colours"] = len(hist)
                info["post_s"] = round(time.time() - t, 2)
                sd = seen_by_dir.setdefault(out_dir, {})
                for hx_ in (hist_hard if hist_hard is not None else hist):
                    if hx_ != "#000000" and hx_ in inv:
                        sd.setdefault(hx_, [inv[hx_], []])[1].append(F)
                if legend is not None:
                    unk = [o.name for o in vis if o.name not in legend["objects"]]
                    if unk:
                        info["not_in_legend"] = unk[:20]
                idx = _cm_load(ip, {})                 # могли дописати паралельно — перечитуємо
                idx[key] = {"fp": fp, "frame": F, "obj": os.path.basename(obj_p), "t": time.strftime("%Y-%m-%d %H:%M"),
                            "colorway": scene.get("hrb_colorway", ""), "recipe": CM_RECIPE, "edges": edges,
                            "ss": k, "spp": spp, "clean": clean, "zobj": zobj, "file": os.path.basename(bpy.data.filepath)}
                _cm_json(ip, idx)
                S["files"] += [face_p, obj_p]
                S["rendered"] += 1
                S["done"] += 1
                info["frame_s"] = round(time.time() - tf, 1)
                log(f"кадр {F}: {info['render_s']} с", json.dumps(info, ensure_ascii=False))
            except Exception as e:
                import traceback
                S["errors"].append({"frame": F, "error": str(e), "tb": traceback.format_exc()[-1500:]})
                S["done"] += 1
                log(f"кадр {F}: ПОМИЛКА {e}")
            dump()
        for d, seen in seen_by_dir.items():
            _cm_write_legend(d, legend, seen, S["has_zones"], edges, K, spp)
        S["ok"] = not S["errors"]
    except Exception as e:
        import traceback
        S["errors"].append({"frame": None, "error": str(e), "tb": traceback.format_exc()[-2000:]})
        log("ПОМИЛКА", e)
    S["finished"] = True
    S["current"] = None
    dump()
    return S


# ---------- UI: запуск фонового процесу ----------

def cm_start(job, blend=None):
    """Зберегти стан сцени (копія, якщо є незбережені зміни) і запустити фоновий Blender. job — dict з items/status."""
    if _CM["proc"] is not None and _CM["proc"].poll() is None:
        raise RuntimeError("маски вже рендеряться")
    src = bpy.data.filepath
    if not src:
        raise RuntimeError("спершу збережи .blend")
    work = os.path.join(tempfile.gettempdir(), "wc_masks")
    os.makedirs(work, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    if blend is None:
        if bpy.data.is_dirty:
            blend = os.path.join(work, f"{os.path.splitext(os.path.basename(src))[0]}_wcmask_{stamp}.blend")
            bpy.ops.wm.save_as_mainfile(filepath=blend, copy=True, relative_remap=True, compress=False)
            job["tmp_blend"] = blend
        else:
            blend = src
    job.setdefault("status", os.path.join(work, f"status_{stamp}.json"))
    jp = os.path.join(work, f"job_{stamp}.json")
    _cm_json(jp, job)
    _cm_json(job["status"], {"finished": False, "done": 0, "total": len(job["items"]), "log": ["старт…"], "errors": []})
    logp = os.path.join(work, f"log_{stamp}.txt")
    cmd = [bpy.app.binary_path, "-b", blend, "-noaudio"]
    if bpy.context.preferences.filepaths.use_scripts_auto_execute:
        cmd.append("-y")
    cmd += ["--python-expr", "import bpy,sys; bpy.ops.wirecolor.cycles_masks_job(job=sys.argv[sys.argv.index('--')+1])",
            "--", jp]
    flags = 0x08000000 if os.name == "nt" else 0      # CREATE_NO_WINDOW
    lf = open(logp, "w", encoding="utf-8", errors="replace")
    _CM["proc"] = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT, creationflags=flags)
    _CM.update(status_path=job["status"], log=logp, job=jp, status={}, tmp_blend=job.get("tmp_blend", ""))
    return job["status"]


def cm_poll():
    """-> (running, status dict). Прибирає тимчасову копію сцени після завершення."""
    p = _CM["proc"]
    st = _cm_load(_CM["status_path"], {}) if _CM["status_path"] else {}
    running = p is not None and p.poll() is None
    if p is not None and not running:
        if not st.get("finished"):
            st.setdefault("errors", []).append({"frame": None, "error": f"Blender завершився з кодом {p.returncode}, "
                                                                        f"лог: {_CM['log']}"})
            st["finished"] = True
            try:
                _cm_json(_CM["status_path"], st)        # CFRender читає лише файл статусу
            except Exception:
                pass
        tb = _CM.get("tmp_blend")
        if tb and os.path.exists(tb):
            try:
                os.remove(tb)
            except OSError:
                pass
        _CM["tmp_blend"] = ""
        _CM["proc"] = None
    _CM["status"] = st
    return running, st


def cm_stop():
    p = _CM["proc"]
    if p is not None and p.poll() is None:
        p.terminate()


def cm_status_text(st):
    if not st:
        return ""
    if st.get("mode") == "check" and st.get("finished"):
        return (f"застаріли {len(st.get('stale', []))}, нема {len(st.get('missing', []))}, "
                f"актуальні {len(st.get('fresh', []))}")
    t = f"{st.get('done', 0)}/{st.get('total', 0)}"
    if st.get("current") is not None and not st.get("finished"):
        t += f" · кадр {st['current']}"
    if st.get("skipped"):
        t += f" · актуальні {st['skipped']}"
    if st.get("errors"):
        t += f" · помилок {len(st['errors'])}"
    return t


def _cm_ui_poll():
    running, st = cm_poll()
    p = getattr(bpy.context.scene, "wc_props", None) if bpy.context else None
    if p is not None:
        if st.get("finished") and not running:
            e = st.get("errors") or []
            p.cm_status = (f"Готово {cm_status_text(st)}" if not e else f"Є помилки: {e[0].get('error', '')[:80]}")
        else:
            p.cm_status = "Рендер масок: " + cm_status_text(st)
    _tag_redraw_viewports()
    return 1.0 if running else None


def _cm_items_for_frames(scene, frames):
    """Як Workbench-маски: <шлях виводу без розширення>_mask_face.png; шлях — тека -> <тека>/0001_mask_face.png."""
    p = bpy.path.abspath(scene.render.filepath)
    base = os.path.splitext(p)[0]
    items = []
    for f in frames:
        b = base + f"{f:04d}" if (not os.path.basename(base) or len(frames) > 1) else base
        items.append({"frame": f, "face": b + "_mask_face.png", "obj": b + "_mask_obj.png"})
    return items


class WIRECOLOR_OT_cycles_masks(Operator):
    bl_idname      = "wirecolor.cycles_masks"
    bl_label       = "Маски Cycles (з рельєфом)"
    bl_description = ("Face + Object маски Cycles у фоновому Blender: контур іде по справжньому рельєфу тканини, "
                      "як у бьюті. Інтерфейс вільний. Файли поруч із шляхом виводу (_mask_face / _mask_obj)")
    bl_options     = {'REGISTER'}

    mode: EnumProperty(items=[('render', "Рендер", "Рендерити всі кадри"),
                              ('stale', "Застарілі", "Лише кадри, де маска застаріла або її нема"),
                              ('check', "Перевірити", "Лише перевірити, без рендеру")], default='render')
    job_items: StringProperty(default="", options={'SKIP_SAVE'},
                              description="JSON [{frame, face, obj}] — якщо порожньо, поточний кадр")
    status_path: StringProperty(default="", options={'SKIP_SAVE'})
    edges: StringProperty(default="", options={'SKIP_SAVE', 'HIDDEN'},
                          description="cycles | soft | hard — якщо порожньо, як у панелі WireColor (Краї)")

    def execute(self, context):
        sc = context.scene
        items = json.loads(self.job_items) if self.job_items else _cm_items_for_frames(sc, [sc.frame_current])
        # 3.10.2: завжди Cycles AA (старі сцени могли зберегти soft/hard у панелі — ігноруємо); hard/soft лише явно зі скрипта
        edges = self.edges if self.edges in ("soft", "hard", "cycles") else "cycles"
        job = {"items": items, "mode": self.mode, "edges": edges, "clean": False, "zones_by_object": True}
        if self.status_path:
            job["status"] = self.status_path
        try:
            cm_start(job)
        except Exception as e:
            self.report({'ERROR'}, f"Маски: {e}")
            return {'CANCELLED'}
        sc.wc_props.cm_status = f"Рендер масок: 0/{len(items)}"
        if not bpy.app.timers.is_registered(_cm_ui_poll):
            bpy.app.timers.register(_cm_ui_poll, first_interval=1.0)
        self.report({'INFO'}, f"Маски Cycles: {len(items)} кадр(ів) у фоні")
        return {'FINISHED'}


class WIRECOLOR_OT_cycles_masks_stop(Operator):
    bl_idname      = "wirecolor.cycles_masks_stop"
    bl_label       = "Зупинити маски"
    bl_description = "Зупинити фоновий рендер масок (готові кадри лишаються)"
    bl_options     = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        cm_stop()
        return {'FINISHED'}


class WIRECOLOR_OT_cycles_masks_job(Operator):
    bl_idname  = "wirecolor.cycles_masks_job"
    bl_label   = "Маски Cycles: фонова задача"
    bl_options = {'INTERNAL'}

    job: StringProperty()

    def execute(self, context):
        cm_run_job(self.job)
        return {'FINISHED'}


class WIRECOLOR_OT_legend_import(Operator):
    bl_idname      = "wirecolor.legend_import"
    bl_label       = "Легенда з файлу"
    bl_description = ("Записати легенду проєкту (JSON: objects ім'я→hex, zones ключ→hex) у сцену. Вона їде разом "
                      "із .blend — у колег маски тих самих кольорів")
    bl_options     = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            d = _cm_load(self.filepath, None)
            if not isinstance(d, dict) or "objects" not in d:
                raise ValueError("у файлі нема ключа objects")
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        cm_legend_write(d)
        self.report({'INFO'}, f"Легенда: {len(d['objects'])} об'єктів, {len(d.get('zones', {}))} зон")
        return {'FINISHED'}


def cm_legend_write(d):
    tx = bpy.data.texts.get(LEGEND_TEXT) or bpy.data.texts.new(LEGEND_TEXT)
    tx.clear()
    tx.write(json.dumps(d, ensure_ascii=False, indent=1))
    tx.use_fake_user = True
    return tx


_CM_LEG_UI = {"t": 0.0, "v": None}


def _cm_legend_ui():
    """(легенда, джерело) для панелі — як cm_legend(hooks=True) у завданні. Пульт опитуємо не частіше 1 разу на 2 с."""
    if bpy.data.texts.get(LEGEND_TEXT) is not None:
        return cm_legend(), "у файлі"
    now = time.time()
    if now - _CM_LEG_UI["t"] > 2.0:
        _CM_LEG_UI["t"] = now
        _CM_LEG_UI["v"] = cm_legend(hooks=True)
    return _CM_LEG_UI["v"], "від пульта"


def _draw_cycles_masks(layout, context):
    props = context.scene.wc_props
    box = layout.box()
    box.label(text="Маски Cycles (з рельєфом)", icon='RENDER_STILL')
    leg, src = _cm_legend_ui()                     # 3.10.1: та сама легенда, що піде в завдання (з пультом)
    if leg is None:
        box.label(text="Кольори: об'єктів WireColor (легенди проєкту нема)", icon='INFO')
    else:
        box.label(text=f"Легенда ({src}): {len(leg['objects'])} об'єктів, {len(leg['zones'])} зон", icon='CHECKMARK')
    running = _CM["proc"] is not None and _CM["proc"].poll() is None
    # 3.10.2: один режим — Cycles AA, зони в межах деталей, без чистки швів (вибір країв і галочки прибрано)
    row = box.row(align=True)
    row.scale_y = 1.2
    row.enabled = not running
    row.operator("wirecolor.cycles_masks", text="Поточний кадр", icon='IMAGE_RGB').mode = 'render'
    row.operator("wirecolor.legend_import", text="", icon='IMPORT')
    if running:
        r = box.row(align=True)
        r.alert = True
        r.operator("wirecolor.cycles_masks_stop", icon='X')
    if props.cm_status:
        box.label(text=props.cm_status)


# ─────────────────────────────────────────────────────────────────────────────
#  ПЕРЕГЛЯД МАСКИ У ВЬЮПОРТІ
# ─────────────────────────────────────────────────────────────────────────────

def _preview_cleanup(props, scene):
    """Відновити стан після будь-якого режиму перегляду."""
    if props.preview_mode == 'OBJECT' and props.preview_obj_backup:
        try:
            for obj_name, color in json.loads(props.preview_obj_backup).items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.color = color
        except Exception as e:
            print(f"WireColor: Object preview restore error: {e}")
        props.preview_obj_backup = ""

    elif props.preview_mode == 'MATERIAL' and props.preview_mat_backup:
        try:
            backup_serial = json.loads(props.preview_mat_backup)
            if backup_serial.get("__kind") == "diffuse":
                _restore_mat_display_colors(backup_serial["colors"])
            else:   # перегляд, збережений старою версією (≤3.5.4) — відновлюємо loops
                loop_backup = {k: ([tuple(c) for c in v[0]] if v[0] is not None else None, v[1])
                               for k, v in backup_serial.items()}
                _restore_loop_colors(loop_backup)
        except Exception as e:
            print(f"WireColor: Material preview restore error: {e}")
        props.preview_mat_backup = ""

    elif props.preview_mode == 'FACE':
        _objcolor_mods_remove()
        _face_mods(False)
        _cleanup_by_names(json.loads(props.preview_auto_names))

    props.preview_auto_names = "[]"


def _preview_start(context, mode, seed=42):
    scene = context.scene
    props = scene.wc_props
    all_spaces = _all_viewport_spaces(context)

    if not props.preview_active:
        props.preview_saved_all = json.dumps([{'type': s.shading.type,
                                               'color': s.shading.color_type,
                                               'light': s.shading.light} for s in all_spaces])

    with _ObjectModeScope(context):
        _preview_cleanup(props, scene)
        props.preview_mode = mode
        props.preview_obj_backup = ""
        props.preview_mat_backup = ""

        if mode == 'OBJECT':
            # Суцільний колір per-object через color_type='OBJECT'
            obj_bak = {}
            for obj in scene.objects:
                if obj.type == 'MESH':
                    obj_bak[obj.name] = list(obj.color)
                    obj.color = obj.wc_color
            props.preview_obj_backup = json.dumps(obj_bak)
            color_type = 'OBJECT'
        elif mode == 'FACE':
            props.preview_auto_names = json.dumps(_ensure_color_attributes(scene))
            _objcolor_mods_add(scene)
            _face_mods(True)
            color_type = 'VERTEX'
        else:  # MATERIAL
            props.preview_mat_backup = json.dumps(
                {"__kind": "diffuse", "colors": _set_mat_display_colors(scene, seed=seed)})
            color_type = 'MATERIAL'

    for s in all_spaces:
        s.shading.type       = 'SOLID'
        s.shading.color_type = color_type
        s.shading.light      = 'FLAT'
    props.preview_active = True


def _preview_stop(context):
    props = context.scene.wc_props
    all_spaces = _all_viewport_spaces(context)
    saved = json.loads(props.preview_saved_all or "[]")
    for i, s in enumerate(all_spaces):
        st = saved[i] if i < len(saved) else {'type': 'SOLID', 'color': 'MATERIAL', 'light': 'STUDIO'}
        s.shading.type       = st['type']
        s.shading.color_type = st['color']
        s.shading.light      = st['light']
    with _ObjectModeScope(context):
        _preview_cleanup(props, context.scene)
    props.preview_mat_backup = ""
    props.preview_obj_backup = ""
    props.preview_saved_all  = "[]"
    props.preview_active     = False
    props.preview_mode       = ''


def _show_result(context, faces):
    """Після фарбування показати результат: вмикаємо відповідний перегляд."""
    props = context.scene.wc_props
    if not props.auto_preview:
        return
    if faces:
        if not props.preview_active or props.preview_mode != 'FACE':
            _preview_start(context, 'FACE')
    elif not props.preview_active or props.preview_mode == 'MATERIAL':
        _preview_start(context, 'OBJECT')


class WIRECOLOR_OT_preview_set(Operator):
    bl_idname  = "wirecolor.preview_set"
    bl_label   = "Перегляд маски"
    bl_options = {'REGISTER'}

    @classmethod
    def description(cls, context, properties):
        return {
            'OBJECT':   "Показати у вьюпорті кольори об'єктів (як маска _mask_obj). "
                        "Повторний клік — вимкнути перегляд",
            'FACE':     "Показати кольори об'єктів разом із розфарбованими полігонами (як маска _mask_face). "
                        "Повторний клік — вимкнути перегляд",
            'MATERIAL': "Показати кожен матеріал своїм кольором (як маска _mask_mat). "
                        "Повторний клік — вимкнути перегляд",
        }.get(properties.mode, "Показати маску у вьюпорті без рендеру")

    mode: EnumProperty(
        items=[
            ('OBJECT',   "Object",    "Кожен об'єкт — свій колір"),
            ('FACE',     "Face",      "Колір об'єкта + розфарбовані полігони"),
            ('MATERIAL', "Material",  "Кожен матеріал — свій колір"),
        ],
        default='OBJECT',
    )
    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        if not _all_viewport_spaces(context):
            self.report({'ERROR'}, "Не знайдено 3D-вьюпорт")
            return {'CANCELLED'}
        props = context.scene.wc_props
        if props.preview_active and props.preview_mode == self.mode:
            _preview_stop(context)
        else:
            _preview_start(context, self.mode, self.seed)
        return {'FINISHED'}


class WIRECOLOR_OT_preview_exit(Operator):
    bl_idname      = "wirecolor.preview_exit"
    bl_label       = "Вимкнути перегляд"
    bl_description = "Повернути звичайний вигляд вьюпорту"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        _preview_stop(context)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ФАРБУВАННЯ
# ─────────────────────────────────────────────────────────────────────────────

def _paint_objects(context, color):
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    for obj in objs:
        obj.wc_color = (color[0], color[1], color[2], 1.0)   # callback оновить маску
    return len(objs)


def _paint_faces(context, color):
    props = context.scene.wc_props
    r, g, b = color[0], color[1], color[2]
    total = 0
    with _ObjectModeScope(context) as scope:
        objs = scope.objects

        for obj in objs:
            mesh = obj.data
            if ATTR_NAME not in mesh.color_attributes:
                _make_color_attr(mesh, obj.wc_color)
            # фарбування має пережити вимкнення перегляду
            auto = json.loads(props.preview_auto_names or "[]")
            if obj.name in auto:
                auto.remove(obj.name)
                props.preview_auto_names = json.dumps(auto)
            color_attr   = mesh.color_attributes[ATTR_NAME]
            painted_attr = mesh.attributes.get(PAINTED_ATTR) or \
                mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            mesh.color_attributes.active_color = color_attr
            for poly in mesh.polygons:
                if poly.select:
                    for li in poly.loop_indices:
                        color_attr.data[li].color = (r, g, b, 1.0)
                    painted_attr.data[poly.index].value = 1
                    total += 1
            mesh.update()
    if props.preview_active and props.preview_mode == 'FACE':
        _objcolor_mods_add(context.scene)
    return total


def _apply_color(op, context, color):
    """Колір → виділеним полігонам (Edit Mode) або виділеним об'єктам (Object Mode)."""
    if context.mode == 'EDIT_MESH':
        n = _paint_faces(context, color)
        if not n:
            op.report({'WARNING'}, "Виділи полігони")
            return {'CANCELLED'}
        _show_result(context, faces=True)
        op.report({'INFO'}, f"{n} полігонів → {_color_to_hex(*color[:3])}")
    else:
        n = _paint_objects(context, color)
        if not n:
            op.report({'WARNING'}, "Виділи об'єкти")
            return {'CANCELLED'}
        _show_result(context, faces=False)
        op.report({'INFO'}, f"{n} об'єкт(ів) → {_color_to_hex(*color[:3])}")
    _tag_redraw_viewports()
    return {'FINISHED'}


class WIRECOLOR_OT_palette_click(Operator):
    bl_idname  = "wirecolor.palette_click"
    bl_label   = ""
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    index: IntProperty(default=0)

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Пофарбувати виділені полігони цим кольором"
        return "Пофарбувати виділені об'єкти цим кольором"

    def execute(self, context):
        props = context.scene.wc_props
        if self.index >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_index = self.index
        c = props.palette_colors[self.index].color
        props.face_color = (c[0], c[1], c[2])
        return _apply_color(self, context, props.face_color)


class WIRECOLOR_OT_apply_color(Operator):
    bl_idname  = "wirecolor.apply_color"
    bl_label   = "Пофарбувати"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Пофарбувати виділені полігони поточним кольором"
        return "Пофарбувати виділені об'єкти поточним кольором"

    def execute(self, context):
        return _apply_color(self, context, context.scene.wc_props.face_color)


class WIRECOLOR_OT_paint_faces(Operator):
    """Сумісність зі старими версіями / гарячими клавішами."""
    bl_idname      = "wirecolor.paint_faces"
    bl_label       = "Пофарбувати полігони"
    bl_description = "Пофарбувати виділені полігони поточним кольором"
    bl_options     = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        n = _paint_faces(context, context.scene.wc_props.face_color)
        if not n:
            self.report({'WARNING'}, "Виділи полігони")
            return {'CANCELLED'}
        return {'FINISHED'}


class WIRECOLOR_OT_pick_color(Operator):
    bl_idname  = "wirecolor.pick_color"
    bl_label   = "Взяти колір"
    bl_options = {'REGISTER'}

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Піпетка: взяти колір першого виділеного полігона"
        return "Піпетка: взяти колір маски активного об'єкта"

    def execute(self, context):
        obj = context.active_object
        props = context.scene.wc_props
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Виділи об'єкт")
            return {'CANCELLED'}
        if context.mode != 'EDIT_MESH':
            props.face_color = obj.wc_color[:3]
            return {'FINISHED'}
        with _ObjectModeScope(context):
            attr = obj.data.color_attributes.get(ATTR_NAME)
            poly = next((p for p in obj.data.polygons if p.select), None)
            if poly is None:
                self.report({'WARNING'}, "Виділи полігон")
                return {'CANCELLED'}
            c = attr.data[poly.loop_indices[0]].color if attr else obj.wc_color
            props.face_color = (c[0], c[1], c[2])
        return {'FINISHED'}


def _assign_targets(context):
    """Що пофарбує «Призначити кольори»: виділені меші, а якщо нічого не виділено — УСІ меші сцени
    (і ті, що видно лише в інших кадрах: конфігурації, перемикання по кадрах)."""
    sel = [o for o in context.selected_objects if o.type == 'MESH']
    if sel:
        return sel, 'selected'
    return [o for o in context.scene.objects if o.type == 'MESH'], 'all'


def _covisible_colors(scene, objs, seed):
    """Кольори так, щоб об'єкти, які видно РАЗОМ хоч в одному кадрі, були різні. Об'єкти з різних кадрів
    можуть повторювати колір — палітра лишається контрастною (розмір = макс. кількість видимих разом)."""
    cur = scene.frame_current
    frames = list(range(scene.frame_start, scene.frame_end + 1))
    step = max(1, len(frames) // 300)                       # довгі анімації — вибірка кадрів
    groups = []
    seen = set()
    for f in frames[::step]:
        scene.frame_set(f)
        g = frozenset(o.name for o in objs if o.visible_get())
        if g and g not in seen:
            seen.add(g); groups.append(g)
    scene.frame_set(cur)
    nb = {o.name: set() for o in objs}
    for g in groups:
        for n in g:
            nb[n] |= g
    k = max([len(g) for g in groups] + [1])
    pal = list(_distinct_colors(k, seed))
    idx = {}
    order = [n for g in sorted(groups, key=len, reverse=True) for n in sorted(g)] + sorted(o.name for o in objs)
    for n in order:
        if n in idx:
            continue
        used = {idx[m] for m in nb[n] if m in idx}
        c = 0
        while c in used:
            c += 1
        if c >= len(pal):
            pal = list(_distinct_colors(c + 1, seed))
        idx[n] = c
    return {n: pal[i] for n, i in idx.items()}


def _assign_targets_label(context):
    objs, how = _assign_targets(context)
    if how == 'all':
        return f"Буде: усі об'єкти сцени ({len(objs)}), разом видимі — різні"
    if len(objs) == 1:
        o = objs[0]
        return f"Буде: тільки {o.name}" + (" (фон!)" if o.is_shadow_catcher else "")
    return f"Буде: {len(objs)} виділених"


class WIRECOLOR_OT_assign_object_colors(Operator):
    bl_idname      = "wirecolor.assign_object_colors"
    bl_label       = "Призначити кольори"
    bl_options     = {'REGISTER', 'UNDO'}

    reroll: BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        if properties.reroll:
            return ("Інші кольори: кожне натискання дає новий набір. "
                    "Виділені об'єкти, або всі об'єкти сцени, якщо нічого не виділено")
        return ("Дати кожному об'єкту свій колір, що добре відрізняється від сусідніх. "
                "Виділені об'єкти, або ВСІ об'єкти сцени (і з інших кадрів), якщо нічого не виділено. "
                "Клік по колекції в Outliner об'єкти НЕ виділяє — виділяй самі об'єкти (ПКМ по колекції → Select Objects)")

    def execute(self, context):
        props = context.scene.wc_props
        if self.reroll:
            props.color_seed = (props.color_seed + 1) % 100000
        objs, how = _assign_targets(context)
        with _ObjectModeScope(context):
            if how == 'all':
                cols = _covisible_colors(context.scene, objs, props.color_seed)
                pairs = [(o, cols[o.name]) for o in objs]
            else:
                pairs = list(zip(objs, _distinct_colors(len(objs), props.color_seed)))
            for obj, c in pairs:
                obj.wc_color = (c[0], c[1], c[2], 1.0)
        _show_result(context, faces=False)
        self.report({'INFO'}, f"{len(objs)} об'єктів отримали різні кольори")
        return {'FINISHED'}


class WIRECOLOR_OT_select_by_angle(Operator):
    bl_idname      = "wirecolor.select_by_angle"
    bl_label       = "Розширити виділення"
    bl_description = ("Від виділених полігонів розширити виділення на сусідні, "
                      "поки кут між ними не більший за заданий (зручно виділяти цілу площину чи деталь)")
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.mode == 'EDIT_MESH' or bool(obj and obj.type == 'MESH')

    def execute(self, context):
        if context.mode == 'EDIT_MESH':
            objects_to_process = [o for o in context.objects_in_mode_unique_data if o.type == 'MESH']
        else:   # з Object Mode: виділені меші (полігони, виділені раніше в Edit Mode, зберігаються в mesh)
            objects_to_process = [o for o in context.selected_objects if o.type == 'MESH']
        bpy.ops.object.mode_set(mode='OBJECT')

        threshold   = math.radians(context.scene.wc_props.select_angle)
        total_faces = 0
        objs_hit    = 0
        for obj in objects_to_process:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            seeds = [f for f in bm.faces if f.select]
            if not seeds:
                bm.free()
                continue
            objs_hit += 1
            visited = set(seeds)
            queue   = list(seeds)
            while queue:
                face = queue.pop()
                face.select = True
                for edge in face.edges:
                    for nb in edge.link_faces:
                        if nb in visited:
                            continue
                        visited.add(nb)
                        try:
                            angle = face.normal.angle(nb.normal)
                        except ValueError:
                            angle = 0.0
                        if angle <= threshold:
                            queue.append(nb)
            total_faces += sum(1 for f in visited if f.select)
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        if objs_hit == 0:
            self.report({'WARNING'}, "Спочатку виділи хоча б один полігон")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Виділено {total_faces} полігонів (≤ {context.scene.wc_props.select_angle:.0f}°)")
        return {'FINISHED'}


class WIRECOLOR_OT_reset_faces(Operator):
    bl_idname      = "wirecolor.reset_faces"
    bl_label       = "Скинути полігони"
    bl_description = ("Прибрати ручне фарбування полігонів: весь об'єкт знову одного кольору. "
                      "Діє на виділені об'єкти")
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with _ObjectModeScope(context) as scope:
            objs = scope.objects

            n = 0
            for obj in objs:
                if ATTR_NAME in obj.data.color_attributes:
                    _make_color_attr(obj.data, obj.wc_color)
                    obj.data.update()
                    n += 1
        self.report({'INFO'}, f"Скинуто: {n} об'єкт(ів)")
        _tag_redraw_viewports()
        return {'FINISHED'}


class WIRECOLOR_OT_clear_attr(Operator):
    bl_idname      = "wirecolor.clear_attr"
    bl_label       = "Видалити маску з об'єктів"
    bl_description = ("Повністю прибрати дані маски (атрибут кольору) з виділених об'єктів. "
                      "Колір об'єкта лишається")
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with _ObjectModeScope(context) as scope:
            objs = scope.objects

            n = 0
            for obj in objs:
                mesh = obj.data
                if ATTR_NAME in mesh.color_attributes:
                    mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
                    n += 1
                if PAINTED_ATTR in mesh.attributes:
                    mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        self.report({'INFO'}, f"Маску видалено: {n} об'єкт(ів)")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ПАЛІТРА
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_palette_add(Operator):
    bl_idname      = "wirecolor.palette_add"
    bl_label       = "Додати в палітру"
    bl_description = "Додати поточний колір у палітру"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        props.palette_colors.add().color = props.face_color
        props.palette_index = len(props.palette_colors) - 1
        return {'FINISHED'}


class WIRECOLOR_OT_palette_remove(Operator):
    bl_idname      = "wirecolor.palette_remove"
    bl_label       = "Прибрати з палітри"
    bl_description = "Прибрати з палітри вибраний колір (обведений)"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        idx   = props.palette_index
        if not props.palette_colors or idx >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_colors.remove(idx)
        props.palette_index = max(0, idx - 1)
        return {'FINISHED'}


class WIRECOLOR_OT_palette_load_presets(Operator):
    bl_idname      = "wirecolor.palette_load_presets"
    bl_label       = "Стандартна палітра"
    bl_description = "Повернути стандартні 20 яскравих кольорів (власні кольори палітри зникнуть)"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        props.palette_colors.clear()
        for r, g, b in PRESET_COLORS:
            props.palette_colors.add().color = (r, g, b)
        props.palette_index = 0
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

class WireColorPaletteEntry(PropertyGroup):
    color: FloatVectorProperty(
        name="Колір", description="Колір палітри", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
    )


class WireColorProps(PropertyGroup):
    face_color: FloatVectorProperty(
        name="", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
        description="Поточний колір. Кнопка «Пофарбувати» наносить його на виділене",
    )
    select_angle: FloatProperty(
        name="Кут",
        description="Наскільки сильно можуть бути повернуті сусідні полігони, щоб потрапити у виділення (градуси)",
        default=15.0, min=0.0, max=180.0, precision=0,
    )
    auto_preview: BoolProperty(
        name="Одразу показувати",
        description="Після фарбування автоматично вмикати перегляд маски у вьюпорті",
        default=True,
    )
    color_seed: IntProperty(default=42, min=0)   # набір для «Призначити кольори», ↻ змінює
    palette_colors: CollectionProperty(type=WireColorPaletteEntry)
    palette_index:  IntProperty(default=0, min=0)
    preview_active:        BoolProperty(default=False)
    preview_mode:          StringProperty(default='')
    preview_auto_names:    StringProperty(default='[]')
    preview_saved_all:     StringProperty(default='[]')   # JSON [{type,color,light}, ...]
    preview_mat_backup:    StringProperty(default='')     # JSON backup для перегляду матеріалів
    preview_obj_backup:    StringProperty(default='')     # JSON backup obj.color для перегляду об'єктів
    cm_status:             StringProperty(default='')     # 3.10.0: стан фонового рендеру масок Cycles
    cm_edges:              EnumProperty(
        name="Краї", default='cycles',
        description="Які краї зон у масках Cycles",
        items=[('cycles', "Cycles AA (рекомендовано)",
                "Справжнє згладжування самим Cycles: 16 семплів, звичайний фільтр, як у бьюті. Край точно по "
                "рельєфу, без сходинок і вигаданих кольорів; кілька секунд на кадр. Чистка швів не застосовується"),
               ('soft', "М'які (швидкі)",
                "Гладкий край без сходинок: звичайний рендер, край згладжується після нього (+1–2 с на кадр). "
                "Всередині зон колір рівно як у легенді, лише крайові пікселі — суміш сусідніх кольорів"),
               ('hard', "Жорсткі (чарівна паличка PS)",
                "Кожен піксель — рівно колір легенди, край сходинками. Для виділення чарівною паличкою "
                "Photoshop без допуску")])
    cm_zobj:               BoolProperty(
        name="Зони в межах деталей", default=True,
        description="Зони тканини (Face) не виходять за межі деталей (Object): чужа зона, що залилася смужкою з "
                    "сусідньої деталі (напр. сидіння на підлокітник), і пістряві крихти в швах -> найближча своя "
                    "зона цієї деталі. Справжні зони деталі (товсті ділянки) не чіпає")
    cm_clean:              BoolProperty(
        name="Чистити шви", default=False,
        description="Тонкі (до 4 px) смужки й острівці зон тканини в канавках швів перефарбувати в сусідні зони. "
                    "Увага: стирає й справжні тонкі смужки (напр. сидіння в щілині біля підлокітника). "
                    "Лише для м'яких/жорстких країв")


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_PT_panel(Panel):
    bl_label       = "WireColor Masks"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "WireColor"

    def draw_header_preset(self, context):
        self.layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

    def draw(self, context):
        layout  = self.layout
        props   = context.scene.wc_props
        obj     = context.active_object
        is_mesh = bool(obj and obj.type == 'MESH')
        edit    = (context.mode == 'EDIT_MESH')

        # ── ПЕРЕГЛЯД ─────────────────────────────────────────
        col = layout.column(align=True)
        col.label(text="Перегляд маски", icon='HIDE_OFF')
        row = col.row(align=True)
        row.scale_y = 1.2
        for mode, text, icon in (('OBJECT', "Object", 'OBJECT_DATA'),
                                 ('FACE', "Face", 'FACESEL'),
                                 ('MATERIAL', "Material",  'MATERIAL')):
            on = props.preview_active and props.preview_mode == mode
            row.operator("wirecolor.preview_set", text=text, icon=icon, depress=on).mode = mode
        if props.preview_active:
            r = col.row(align=True)
            r.alert = True
            r.operator("wirecolor.preview_exit", icon='X')

        layout.separator(factor=0.5)

        # ── КОЛІР / ПАЛІТРА ──────────────────────────────────
        box = layout.box()
        target = "виділені полігони" if edit else "виділені об'єкти"
        box.label(text=f"Клік по кольору → {target}", icon='BRUSH_DATA')
        grid = box.grid_flow(row_major=True, columns=5, even_columns=True, even_rows=True, align=True)
        for i, entry in enumerate(props.palette_colors):
            cell = grid.column(align=True)
            cell.scale_y = 1.4
            cell.operator("wirecolor.palette_click", text="", icon_value=_color_icon(entry.color),
                          depress=(i == props.palette_index)).index = i

        row = box.row(align=True)
        row.prop(props, "face_color")
        row.operator("wirecolor.pick_color", text="", icon='EYEDROPPER')
        row.operator("wirecolor.palette_add", text="", icon='ADD')
        row.operator("wirecolor.palette_remove", text="", icon='REMOVE')
        row.operator("wirecolor.palette_load_presets", text="", icon='FILE_REFRESH')
        row = box.row()
        row.scale_y = 1.3
        row.operator("wirecolor.apply_color", icon='BRUSH_DATA')
        box.prop(props, "auto_preview")

        # ── ОБ'ЄКТИ ──────────────────────────────────────────
        if not edit:
            box = layout.box()
            box.label(text="Об'єкти", icon='OBJECT_DATA')
            if is_mesh:
                box.prop(obj, "wc_color", text="Колір активного")
            row = box.row(align=True)
            row.scale_y = 1.2
            row.operator("wirecolor.assign_object_colors", icon='COLOR')
            row.operator("wirecolor.assign_object_colors", text="", icon='FILE_REFRESH').reroll = True
            box.label(text=_assign_targets_label(context), icon='RIGHTARROW_THIN')
            if is_mesh:
                box.label(text="Tab → Edit Mode, щоб фарбувати полігони", icon='INFO')

        # ── МАСКИ CYCLES (3.10.0) ────────────────────────────
        if not edit:
            _draw_cycles_masks(layout, context)

        # ── ВИДІЛЕННЯ ПО КУТУ (завжди видно) ─────────────────
        box = layout.box()
        box.label(text="Виділення по куту", icon='FACESEL')
        row = box.row(align=True)
        row.prop(props, "select_angle")
        row.operator("wirecolor.select_by_angle", icon='SELECT_EXTEND')

        # ── ОЧИСТКА ──────────────────────────────────────────
        header, body = layout.panel("wirecolor_cleanup", default_closed=True)
        header.label(text="Очистка", icon='TRASH')
        if body:
            col = body.column(align=True)
            col.operator("wirecolor.reset_faces", icon='LOOP_BACK')
            col.operator("wirecolor.clear_attr", icon='TRASH')


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    WireColorPaletteEntry,
    WireColorProps,
    WIRECOLOR_OT_render_obj_mask,
    WIRECOLOR_OT_render_face_mask,
    WIRECOLOR_OT_render_mat_mask,
    WIRECOLOR_OT_cycles_masks,
    WIRECOLOR_OT_cycles_masks_stop,
    WIRECOLOR_OT_cycles_masks_job,
    WIRECOLOR_OT_legend_import,
    WIRECOLOR_OT_preview_set,
    WIRECOLOR_OT_preview_exit,
    WIRECOLOR_OT_palette_click,
    WIRECOLOR_OT_apply_color,
    WIRECOLOR_OT_paint_faces,
    WIRECOLOR_OT_pick_color,
    WIRECOLOR_OT_assign_object_colors,
    WIRECOLOR_OT_select_by_angle,
    WIRECOLOR_OT_reset_faces,
    WIRECOLOR_OT_clear_attr,
    WIRECOLOR_OT_palette_add,
    WIRECOLOR_OT_palette_remove,
    WIRECOLOR_OT_palette_load_presets,
    WIRECOLOR_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.wc_props = PointerProperty(type=WireColorProps)
    bpy.types.Object.wc_color = FloatVectorProperty(
        name="Колір маски",
        description="Колір цього об'єкта в масці (на матеріали не впливає)",
        subtype='COLOR', size=4,
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        update=_wc_color_update,
    )
    # Пресети: і напряму, і через таймер (запасний — на випадок якщо сцена ще не готова)
    _init_palette_presets()
    bpy.app.timers.register(_init_palette_presets, first_interval=1.0)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)


def unregister():
    _clear_preview_icons()
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Object.wc_color
    del bpy.types.Scene.wc_props


if __name__ == "__main__":
    register()
