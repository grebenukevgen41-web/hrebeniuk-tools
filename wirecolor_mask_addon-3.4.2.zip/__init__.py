bl_info = {
    "name":        "WireColor Masks",
    "author":      "Auto",
    "version":     (3, 4, 2),
    "blender":     (4, 0, 0),
    "location":    "3D Viewport › N-Panel › WireColor",
    "description": "Кольорові маски: per-object і per-face, прев'ю, select by angle",
    "category":    "Render",
}

import bpy
import bpy.utils.previews
import bmesh
import math
import random
import os
import json
from bpy.props import (FloatVectorProperty, IntProperty, FloatProperty,
                       PointerProperty, BoolProperty, StringProperty,
                       CollectionProperty, EnumProperty)
from bpy.types import Panel, Operator, PropertyGroup

ATTR_NAME    = "wc_mask_color"
PAINTED_ATTR = "wc_painted"

_rendering          = False
_preview_coll       = None
_active_color_bak: dict = {}   # mesh.name → original active color attr name

PRESET_COLORS = [
    # (r, g, b) — sRGB 0-1, назва
    (1.000, 0.000, 0.000),  # #FF0000 Bright Red
    (0.000, 1.000, 0.000),  # #00FF00 Lime Green
    (0.000, 0.000, 1.000),  # #0000FF Blue
    (1.000, 1.000, 0.000),  # #FFFF00 Yellow
    (0.000, 1.000, 1.000),  # #00FFFF Cyan
    (1.000, 0.000, 1.000),  # #FF00FF Magenta
    (1.000, 0.498, 0.000),  # #FF7F00 Orange
    (0.498, 0.000, 1.000),  # #7F00FF Electric Violet
    (0.000, 1.000, 0.498),  # #00FF7F Mint Neon
    (1.000, 0.000, 0.498),  # #FF007F Fuchsia
    (0.498, 1.000, 0.000),  # #7FFF00 Chartreuse
    (0.000, 0.498, 1.000),  # #007FFF Azure
    (0.545, 0.000, 0.000),  # #8B0000 Dark Red
    (0.000, 0.392, 0.000),  # #006400 Dark Green
    (0.000, 0.000, 0.545),  # #00008B Dark Blue
    (0.502, 0.502, 0.000),  # #808000 Olive
    (0.502, 0.000, 0.502),  # #800080 Purple
    (0.000, 0.502, 0.502),  # #008080 Teal
    (1.000, 0.843, 0.000),  # #FFD700 Gold
    (0.294, 0.000, 0.510),  # #4B0082 Indigo
]


# ─────────────────────────────────────────────────────────────────────────────
#  PREVIEW ICONS  (кольорові кубики для палітри)
# ─────────────────────────────────────────────────────────────────────────────

def _build_preview_icons():
    global _preview_coll
    _clear_preview_icons()
    _preview_coll = bpy.utils.previews.new()
    size = 32
    n    = size * size
    for i, (r, g, b) in enumerate(PRESET_COLORS):
        thumb = _preview_coll.new(f"wc_{i}")
        thumb.image_size = (size, size)
        try:
            thumb.image_pixels_float[:] = [c for _ in range(n) for c in (r, g, b, 1.0)]
        except Exception:
            pass


def _clear_preview_icons():
    global _preview_coll
    if _preview_coll is not None:
        try:
            bpy.utils.previews.remove(_preview_coll)
        except Exception:
            pass
        _preview_coll = None


def _preset_icon(index):
    if _preview_coll and f"wc_{index}" in _preview_coll:
        return _preview_coll[f"wc_{index}"].icon_id
    return 0


# ─────────────────────────────────────────────────────────────────────────────
#  CORE SYNC
# ─────────────────────────────────────────────────────────────────────────────

def _sync_obj_to_attr(obj):
    if obj.type != 'MESH':
        return
    mesh = obj.data
    if ATTR_NAME not in mesh.color_attributes:
        return
    old_attr = mesh.color_attributes[ATTR_NAME]
    if not len(old_attr.data):
        return

    painted_attr = mesh.attributes.get(PAINTED_ATTR)
    r, g, b, _   = obj.wc_color
    pd = painted_attr.data if painted_attr and len(painted_attr.data) else None

    # Читаємо всі поточні кольори (щоб зберегти ручні)
    saved = [tuple(old_attr.data[li].color) for li in range(len(old_attr.data))]

    # Перестворюємо атрибут — тільки так Blender скидає GPU кеш
    mesh.color_attributes.remove(old_attr)
    new_attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')

    for poly in mesh.polygons:
        is_painted = pd and poly.index < len(pd) and bool(pd[poly.index].value)
        for li in poly.loop_indices:
            if is_painted:
                new_attr.data[li].color = saved[li]
            else:
                new_attr.data[li].color = (r, g, b, 1.0)

    mesh.update()


def _tag_redraw_viewports():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _wc_color_update(obj, context):
    """Callback: obj.wc_color змінився → оновити color attribute."""
    if obj.type != 'MESH':
        return
    mesh = obj.data
    if ATTR_NAME in mesh.color_attributes:
        _sync_obj_to_attr(obj)
        _tag_redraw_viewports()


def _init_palette_presets():
    """Заповнити палітру пресетами якщо вона порожня."""
    try:
        scenes = list(bpy.data.scenes)
        if not scenes:
            return None
        for scene in scenes:
            try:
                props = scene.wc_props
                if len(props.palette_colors) == 0:
                    for r, g, b in PRESET_COLORS:
                        entry = props.palette_colors.add()
                        entry.color = (r, g, b)
                    print(f"WireColor: loaded {len(PRESET_COLORS)} presets into '{scene.name}'")
            except Exception as e:
                print(f"WireColor: preset error for '{scene.name}': {e}")
    except Exception as e:
        print(f"WireColor: _init_palette_presets failed: {e}")
    return None  # one-shot timer


@bpy.app.handlers.persistent
def _on_load_post(dummy):
    """Після відкриття файлу — ініціалізація."""
    _active_color_bak.clear()
    bpy.app.timers.register(_init_palette_presets, first_interval=0.2)


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _make_color_attr(mesh, obj_color):
    if ATTR_NAME in mesh.color_attributes:
        mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
    attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
    r, g, b = obj_color[:3]
    for i in range(len(attr.data)):
        attr.data[i].color = (r, g, b, 1.0)
    if PAINTED_ATTR not in mesh.attributes:
        mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
    else:
        for d in mesh.attributes[PAINTED_ATTR].data:
            d.value = 0
    return attr


def _ensure_color_attributes(scene):
    auto_names = []
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        # Зберігаємо оригінальний active_color щоб не зламати Cycles-матеріал
        if mesh.name not in _active_color_bak:
            ac = mesh.color_attributes.active_color
            _active_color_bak[mesh.name] = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            auto_names.append(obj.name)
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return auto_names


def _cleanup_by_names(names):
    for name in names:
        obj = bpy.data.objects.get(name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        # Відновлюємо оригінальний active_color в будь-якому випадку
        orig = _active_color_bak.pop(mesh.name, None)
        if orig and orig in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig]
        # Не видаляємо атрибут якщо є ручне фарбування
        painted = mesh.attributes.get(PAINTED_ATTR)
        if painted and any(d.value for d in painted.data):
            continue
        if ATTR_NAME in mesh.color_attributes:
            mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
        if PAINTED_ATTR in mesh.attributes:
            mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])


def _backup_manual_attrs(scene):
    backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        if ATTR_NAME not in mesh.color_attributes:
            continue
        painted = mesh.attributes.get(PAINTED_ATTR)
        if not painted:
            continue
        faces = {}
        for poly in mesh.polygons:
            if painted.data[poly.index].value:
                faces[poly.index] = [tuple(mesh.color_attributes[ATTR_NAME].data[li].color)
                                     for li in poly.loop_indices]
        if faces:
            backup[obj.name] = faces
    return backup


def _restore_manual_attrs(backup):
    for obj_name, faces in backup.items():
        obj = bpy.data.objects.get(obj_name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        # Якщо атрибут прибрали (cleanup) — відтворюємо з obj.wc_color як основу
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
        attr    = mesh.color_attributes[ATTR_NAME]
        painted = mesh.attributes.get(PAINTED_ATTR)
        if not painted:
            painted = mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
        for poly in mesh.polygons:
            if poly.index not in faces:
                continue
            for i, li in enumerate(poly.loop_indices):
                attr.data[li].color = faces[poly.index][i]
            painted.data[poly.index].value = 1
        mesh.update()


def _fill_all_from_obj_color(scene):
    backup    = _backup_manual_attrs(scene)
    all_names = []
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        _make_color_attr(obj.data, obj.wc_color)
        all_names.append(obj.name)
    return all_names, backup


def _fill_temp_obj_color(scene):
    """Тимчасово заповнити всі loops obj.color, зберегти оригінальні кольори.
    Повертає {obj_name: (loop_colors або None, orig_active_color_name або None)}.
    Безпечна версія — без destroy/recreate атрибутів."""
    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            loop_backup[obj.name] = (
                [tuple(attr.data[li].color) for li in range(len(attr.data))],
                orig_active,
            )
            r, g, b = obj.wc_color[:3]
            for li in range(len(attr.data)):
                attr.data[li].color = (r, g, b, 1.0)
            mesh.update()
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _fill_temp_mat_color(scene, seed=42):
    """Тимчасово заповнити loops кольором матеріалу PER-FACE (по слоту poly.material_index).
    Однаковий матеріал = однаковий колір на всіх faces і об'єктах.
    Не змінює wc_color перманентно. Повертає backup як _fill_temp_obj_color."""
    rng = random.Random(seed)
    mat_colors: dict = {}
    # Збираємо всі унікальні матеріали сцени → призначаємо колір
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        for mat in obj.data.materials:
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())

    NO_MAT_COLOR = (0.5, 0.5, 0.5)

    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None

        # Будуємо масив кольорів per-loop на основі material_index поліґона
        slot_colors = []
        for mat in mesh.materials:
            slot_colors.append(mat_colors.get(mat.name, NO_MAT_COLOR) if mat else NO_MAT_COLOR)

        if ATTR_NAME not in mesh.color_attributes:
            # Атрибута ще немає — створюємо і заповнюємо по матеріалах
            if PAINTED_ATTR not in mesh.attributes:
                mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
            for poly in mesh.polygons:
                r, g, b = slot_colors[poly.material_index] if poly.material_index < len(slot_colors) else NO_MAT_COLOR
                for li in poly.loop_indices:
                    attr.data[li].color = (r, g, b, 1.0)
            mesh.update()
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            # Зберігаємо оригінал
            orig_colors = [tuple(attr.data[li].color) for li in range(len(attr.data))]
            loop_backup[obj.name] = (orig_colors, orig_active)
            # Заповнюємо по матеріальних слотах
            for poly in mesh.polygons:
                r, g, b = slot_colors[poly.material_index] if poly.material_index < len(slot_colors) else NO_MAT_COLOR
                for li in poly.loop_indices:
                    attr.data[li].color = (r, g, b, 1.0)
            mesh.update()

        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _restore_loop_colors(loop_backup):
    """Відновити кольори loops з backup in-place (без видалення/відтворення attr)."""
    for obj_name, (colors, orig_active) in loop_backup.items():
        obj = bpy.data.objects.get(obj_name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        if colors is None:
            # Attr було створено тимчасово — видаляємо
            if ATTR_NAME in mesh.color_attributes:
                mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
            if PAINTED_ATTR in mesh.attributes:
                mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        else:
            if ATTR_NAME in mesh.color_attributes:
                attr = mesh.color_attributes[ATTR_NAME]
                for li, color in enumerate(colors):
                    if li < len(attr.data):
                        attr.data[li].color = color
                mesh.update()
        # Відновлюємо оригінальний active_color
        if orig_active and orig_active in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig_active]


def _render_alpha_mask(scene, animation=False):
    """True alpha маска: included об'єкти = білий силует, фон = прозорий.
    Використовує Workbench SINGLE color + film_transparent → чисті краї без шуму.
    Зберігає PNG RGBA."""

    # Зберігаємо стан
    orig_hide   = {obj.name: obj.hide_render for obj in scene.objects if obj.type == 'MESH'}
    orig_engine        = scene.render.engine
    orig_color_type    = scene.display.shading.color_type
    orig_light         = scene.display.shading.light
    orig_single        = tuple(scene.display.shading.single_color)
    orig_transparent   = scene.render.film_transparent
    orig_file_format   = scene.render.image_settings.file_format
    orig_color_mode    = scene.render.image_settings.color_mode
    orig_filepath      = scene.render.filepath

    # Ховаємо excluded об'єкти
    for obj in scene.objects:
        if obj.type == 'MESH':
            obj.hide_render = not obj.wc_alpha_include

    # Будуємо вихідний шлях
    if animation:
        raw_fp   = orig_filepath + "_mask_alpha"
        out_fp   = _versioned_path(raw_fp, animation=True)
    else:
        abs_path = bpy.path.abspath(orig_filepath)
        base, _  = os.path.splitext(abs_path)
        raw_path = base + "_mask_alpha.png"
        out_path = _versioned_path(raw_path, animation=False)
        out_fp   = _safe_relpath(out_path)

    # Налаштовуємо Workbench + прозорий фон + PNG RGBA
    scene.render.engine                      = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type         = 'SINGLE'
    scene.display.shading.single_color       = (1.0, 1.0, 1.0)
    scene.display.shading.light              = 'FLAT'
    scene.render.film_transparent            = True
    scene.render.image_settings.file_format  = 'PNG'
    scene.render.image_settings.color_mode   = 'RGBA'
    scene.render.filepath                    = out_fp

    global _rendering
    _rendering = True
    try:
        bpy.ops.render.render(animation=animation, write_still=not animation)
    finally:
        _rendering = False
        # Відновлюємо все
        scene.render.engine                      = orig_engine
        scene.display.shading.color_type         = orig_color_type
        scene.display.shading.light              = orig_light
        scene.display.shading.single_color       = orig_single
        scene.render.film_transparent            = orig_transparent
        scene.render.image_settings.file_format  = orig_file_format
        scene.render.image_settings.color_mode   = orig_color_mode
        scene.render.filepath                    = orig_filepath
        for obj in scene.objects:
            if obj.type == 'MESH' and obj.name in orig_hide:
                obj.hide_render = orig_hide[obj.name]

    return bpy.path.abspath(out_fp)


def _get_viewport_space(context):
    """Повертає space_data поточного контексту якщо це VIEW_3D, інакше перший знайдений."""
    if context.space_data and context.space_data.type == 'VIEW_3D':
        return context.space_data
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            return area.spaces.active
    return None


def _all_viewport_spaces(context):
    """Всі 3D viewport spaces на поточному екрані."""
    spaces = []
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                spaces.append(area.spaces.active)
    return spaces


def _safe_relpath(path):
    """bpy.path.relpath падає ValueError коли шлях виводу і .blend файл на різних
    дисках (напр. сцена відкрита з F:, вивід на D:) -- в такому разі лишаємо
    абсолютний шлях, Blender його теж приймає в scene.render.filepath."""
    try:
        return bpy.path.relpath(path)
    except ValueError:
        return path


def _versioned_path(path, animation=False):
    """Якщо файл існує — додає _V01, _V02, ... до імені."""
    if animation:
        abs_p = bpy.path.abspath(path)
        d     = os.path.dirname(abs_p)
        name  = os.path.basename(abs_p)
        if not os.path.isdir(d):
            return path
        existing = [f for f in os.listdir(d) if f.startswith(name)]
        if not existing:
            return path
        for i in range(1, 100):
            new_name = f"{name}_V{i:02d}"
            if not any(f.startswith(new_name) for f in os.listdir(d)):
                return _safe_relpath(os.path.join(d, new_name))
    else:
        if not os.path.exists(path):
            return path
        base, ext = os.path.splitext(path)
        for i in range(1, 100):
            candidate = f"{base}_V{i:02d}{ext}"
            if not os.path.exists(candidate):
                return candidate
    return path


def _color_to_hex(r, g, b):
    return "#{:02x}{:02x}{:02x}".format(
        min(255, int(r * 255)),
        min(255, int(g * 255)),
        min(255, int(b * 255)),
    )


def _render_workbench(scene, suffix, fill_all=False, animation=False):
    global _rendering

    orig_filepath = scene.render.filepath

    if animation:
        raw_filepath = orig_filepath + suffix
        out_filepath = _versioned_path(raw_filepath, animation=True)
        out_display  = out_filepath
    else:
        orig_path = bpy.path.abspath(orig_filepath)
        base, ext = os.path.splitext(orig_path)
        ext       = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
        raw_path  = base + suffix + ext
        out_path  = _versioned_path(raw_path, animation=False)
        out_filepath = _safe_relpath(out_path)
        out_display  = out_path

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    if fill_all:
        loop_backup = _fill_temp_obj_color(scene)
    else:
        auto_names = _ensure_color_attributes(scene)

    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'VERTEX'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = out_filepath

    _rendering = True
    try:
        bpy.ops.render.render(animation=animation, write_still=not animation)
    finally:
        _rendering = False
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        if fill_all:
            _restore_loop_colors(loop_backup)
        else:
            _cleanup_by_names(auto_names)

    return out_display


def _render_workbench_mat(scene, suffix, seed=42):
    """Рендер маски по матеріалах — тимчасово заповнює color attrs кольором матеріалу,
    рендерить у Workbench VERTEX mode, відновлює. Не змінює wc_color об'єктів."""
    global _rendering

    orig_filepath = scene.render.filepath
    orig_path     = bpy.path.abspath(orig_filepath)
    base, ext     = os.path.splitext(orig_path)
    ext           = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
    out_path      = _versioned_path(base + suffix + ext, animation=False)
    out_filepath  = _safe_relpath(out_path)

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    loop_backup = _fill_temp_mat_color(scene, seed=seed)
    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'VERTEX'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = out_filepath

    _rendering = True
    try:
        bpy.ops.render.render(animation=False, write_still=True)
    finally:
        _rendering = False
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        _restore_loop_colors(loop_backup)

    return out_path


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Objects
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_sync_colors(Operator):
    bl_idname      = "wirecolor.sync_colors"
    bl_label       = "Sync Colors Now"
    bl_description = "Примусово синхронізувати obj.color → Color Attributes зараз"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        synced = 0
        for obj in context.scene.objects:
            if obj.type != 'MESH':
                continue
            if ATTR_NAME in obj.data.color_attributes:
                _sync_obj_to_attr(obj)
                synced += 1
        _tag_redraw_viewports()
        self.report({'INFO'}, f"Synced {synced} objects")
        return {'FINISHED'}


class WIRECOLOR_OT_assign_object_colors(Operator):
    bl_idname      = "wirecolor.assign_object_colors"
    bl_label       = "Assign Random Colors"
    bl_description = "Призначити рандомний wc_color кожному mesh-об'єкту сцени"
    bl_options     = {'REGISTER', 'UNDO'}

    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        random.seed(self.seed)
        colored = 0
        for obj in bpy.data.objects:
            if obj.type in ('CAMERA', 'LIGHT', 'SPEAKER', 'ARMATURE', 'EMPTY'):
                continue
            obj.wc_color = (random.random(), random.random(), random.random(), 1.0)
            colored += 1
        self.report({'INFO'}, f"{colored} об'єктів розфарбовано (seed={self.seed})")
        return {'FINISHED'}


def _preview_cleanup(props, scene):
    """Відновити стан після будь-якого preview режиму."""
    if props.preview_mode == 'OBJECT' and props.preview_obj_backup:
        try:
            obj_bak = json.loads(props.preview_obj_backup)
            for obj_name, color in obj_bak.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.color = color
        except Exception as e:
            print(f"WireColor: Object preview restore error: {e}")
        props.preview_obj_backup = ""

    elif props.preview_mode == 'MATERIAL' and props.preview_mat_backup:
        try:
            backup_serial = json.loads(props.preview_mat_backup)
            loop_backup = {k: ([tuple(c) for c in v[0]] if v[0] is not None else None, v[1])
                           for k, v in backup_serial.items()}
            _restore_loop_colors(loop_backup)
        except Exception as e:
            print(f"WireColor: Material preview restore error: {e}")
        props.preview_mat_backup = ""

    elif props.preview_mode == 'FACE':
        _cleanup_by_names(json.loads(props.preview_auto_names))

    props.preview_auto_names = "[]"


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Viewport Preview
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_preview_set(Operator):
    bl_idname  = "wirecolor.preview_set"
    bl_label   = "Preview Mask"
    bl_options = {'REGISTER'}

    @classmethod
    def description(cls, context, properties):
        return {
            'OBJECT':   "Показати маску по об'єктах прямо у вьюпорті: кожен об'єкт — свій колір",
            'FACE':     "Показати маску по полігонах (ручне фарбування faces поверх кольору об'єкта)",
            'MATERIAL': "Показати маску по матеріалах: кожен матеріал — унікальний колір",
        }.get(properties.mode, "Показати маску у вьюпорті без рендеру")

    mode: EnumProperty(
        items=[
            ('OBJECT',   "Object",   "Кожен об'єкт — свій wc_color"),
            ('FACE',     "Face",     "Ручне фарбування faces поверх wc_color"),
            ('MATERIAL', "Material", "Кожен матеріал — унікальний колір"),
        ],
        default='OBJECT',
    )

    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        scene = context.scene
        props = scene.wc_props
        space = _get_viewport_space(context)
        if not space:
            self.report({'ERROR'}, "Не знайдено 3D Viewport")
            return {'CANCELLED'}

        all_spaces = _all_viewport_spaces(context)

        if not props.preview_active:
            saved = [{'type': s.shading.type,
                      'color': s.shading.color_type,
                      'light': s.shading.light} for s in all_spaces]
            props.preview_saved_all = json.dumps(saved)
            if space:
                props.preview_saved_shading = space.shading.type
                props.preview_saved_color   = space.shading.color_type
                props.preview_saved_light   = space.shading.light

        # ── Cleanup попереднього режиму ──
        _preview_cleanup(props, scene)

        props.preview_mode = self.mode

        if self.mode == 'OBJECT':
            # Суцільний колір per-object через color_type='OBJECT'.
            # Тимчасово ставимо obj.color = obj.wc_color (у SOLID mode матеріал не рендериться).
            obj_bak = {}
            for obj in scene.objects:
                if obj.type == 'MESH':
                    obj_bak[obj.name] = list(obj.color)
                    obj.color = obj.wc_color
            props.preview_obj_backup = json.dumps(obj_bak)
            props.preview_mat_backup = ""
            props.preview_auto_names = "[]"
            for s in all_spaces:
                s.shading.type       = 'SOLID'
                s.shading.color_type = 'OBJECT'
                s.shading.light      = 'FLAT'

        elif self.mode == 'FACE':
            # VERTEX mode — показує wc_mask_color з painted faces поверх wc_color
            auto = _ensure_color_attributes(scene)
            props.preview_auto_names = json.dumps(auto)
            props.preview_mat_backup = ""
            props.preview_obj_backup = ""
            for s in all_spaces:
                s.shading.type       = 'SOLID'
                s.shading.color_type = 'VERTEX'
                s.shading.light      = 'FLAT'

        else:  # MATERIAL
            # VERTEX mode per-face по матеріалах
            loop_backup = _fill_temp_mat_color(scene, seed=self.seed)
            auto = list(loop_backup.keys())
            props.preview_auto_names = json.dumps(auto)
            backup_serial = {k: ([list(c) for c in v[0]] if v[0] is not None else None, v[1])
                             for k, v in loop_backup.items()}
            props.preview_mat_backup = json.dumps(backup_serial)
            props.preview_obj_backup = ""
            for s in all_spaces:
                s.shading.type       = 'SOLID'
                s.shading.color_type = 'VERTEX'
                s.shading.light      = 'FLAT'

        props.preview_active = True
        return {'FINISHED'}


class WIRECOLOR_OT_preview_exit(Operator):
    bl_idname  = "wirecolor.preview_exit"
    bl_description = "Вийти з перегляду маски — повернути звичайний вигляд вьюпорту"
    bl_label   = "Exit Preview"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.wc_props
        all_spaces = _all_viewport_spaces(context)
        saved = json.loads(props.preview_saved_all) if props.preview_saved_all != '[]' else []
        if saved:
            for i, s in enumerate(all_spaces):
                if i < len(saved):
                    s.shading.type       = saved[i]['type']
                    s.shading.color_type = saved[i]['color']
                    s.shading.light      = saved[i]['light']
                else:
                    # viewport з'явився під час preview — повертаємо дефолт
                    s.shading.type       = props.preview_saved_shading
                    s.shading.color_type = props.preview_saved_color
                    s.shading.light      = props.preview_saved_light
        elif all_spaces:
            # Fallback: single-viewport restore
            all_spaces[0].shading.type       = props.preview_saved_shading
            all_spaces[0].shading.color_type = props.preview_saved_color
            all_spaces[0].shading.light      = props.preview_saved_light
        _preview_cleanup(props, context.scene)
        props.preview_mat_backup  = ""
        props.preview_obj_backup  = ""
        props.preview_saved_all   = "[]"
        props.preview_active      = False
        props.preview_mode        = ''
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Select by Angle
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_select_by_angle(Operator):
    bl_idname      = "wirecolor.select_by_angle"
    bl_label       = "Expand Selection by Angle"
    bl_description = ("Виділи faces на одному або кількох об'єктах (Shift+клік у Object mode → Edit), "
                      "натисни — розшириться на всі сусідні faces в межах кута")
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        was_edit = (context.mode == 'EDIT_MESH')

        if was_edit:
            # Зберігаємо список ДО виходу з edit mode — після виходу objects_in_mode недоступний
            objects_to_process = [o for o in context.objects_in_mode if o.type == 'MESH']
            bpy.ops.object.mode_set(mode='OBJECT')
        else:
            obj = context.active_object
            if not obj or obj.type != 'MESH':
                self.report({'ERROR'}, "Немає активного mesh-об'єкта")
                return {'CANCELLED'}
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='FACE')
            objects_to_process = [obj]
            bpy.ops.object.mode_set(mode='OBJECT')

        threshold    = math.radians(context.scene.wc_props.select_angle)
        total_faces  = 0
        objs_hit     = 0

        for obj in objects_to_process:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bm.faces.ensure_lookup_table()

            seeds = [f for f in bm.faces if f.select]
            if not seeds:
                bm.free()
                continue

            objs_hit += 1
            visited = set(seeds)
            queue   = list(seeds)
            while queue:
                face = queue.pop()
                face.select = True
                for edge in face.edges:
                    for nb in edge.link_faces:
                        if nb in visited:
                            continue
                        visited.add(nb)
                        try:
                            angle = face.normal.angle(nb.normal)
                        except ValueError:
                            angle = 0.0
                        if angle <= threshold:
                            queue.append(nb)

            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()
            total_faces += len(visited)

        bpy.ops.object.mode_set(mode='EDIT')

        if objs_hit == 0:
            self.report({'WARNING'}, "Виділи хоча б один face спочатку")
            return {'CANCELLED'}

        msg = f"{total_faces} faces (≤ {context.scene.wc_props.select_angle:.1f}°)"
        if objs_hit > 1:
            msg += f"  ·  {objs_hit} об'єктів"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Face Paint
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_paint_faces(Operator):
    bl_idname      = "wirecolor.paint_faces"
    bl_label       = "Paint Selected Faces"
    bl_description = "Назначити обраний колір виділеним faces (накопичувально)"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        was_edit = (context.mode == 'EDIT_MESH')

        if was_edit:
            objects = [o for o in context.objects_in_mode if o.type == 'MESH']
            bpy.ops.object.mode_set(mode='OBJECT')
        else:
            obj = context.active_object
            if not obj or obj.type != 'MESH':
                self.report({'ERROR'}, "Немає активного mesh-об'єкта")
                return {'CANCELLED'}
            objects = [obj]

        props = context.scene.wc_props
        r, g, b = props.face_color
        total = 0

        for obj in objects:
            mesh = obj.data
            if ATTR_NAME not in mesh.color_attributes:
                _make_color_attr(mesh, obj.wc_color)
                if props.preview_active:
                    auto = json.loads(props.preview_auto_names)
                    if obj.name in auto:
                        auto.remove(obj.name)
                        props.preview_auto_names = json.dumps(auto)

            color_attr   = mesh.color_attributes[ATTR_NAME]
            painted_attr = mesh.attributes.get(PAINTED_ATTR)
            if not painted_attr:
                painted_attr = mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            mesh.color_attributes.active_color = color_attr

            count = 0
            for poly in mesh.polygons:
                if poly.select:
                    for li in poly.loop_indices:
                        color_attr.data[li].color = (r, g, b, 1.0)
                    painted_attr.data[poly.index].value = 1
                    count += 1
            mesh.update()
            total += count

        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')

        if total == 0:
            self.report({'WARNING'}, "Жодного виділеного face")
            return {'CANCELLED'}

        self.report({'INFO'}, f"{total} faces → {_color_to_hex(r, g, b)}")
        return {'FINISHED'}


class WIRECOLOR_OT_pick_from_object(Operator):
    bl_idname      = "wirecolor.pick_from_object"
    bl_label       = "← від об'єкта"
    bl_description = "Взяти obj.color активного об'єкта у color picker"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "Немає активного об'єкта")
            return {'CANCELLED'}
        r, g, b, _ = obj.wc_color
        context.scene.wc_props.face_color = (r, g, b)
        return {'FINISHED'}


class WIRECOLOR_OT_pick_from_face(Operator):
    bl_idname      = "wirecolor.pick_from_face"
    bl_label       = "← від face"
    bl_description = "Взяти колір першого виділеного face у color picker"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Немає активного mesh-об'єкта")
            return {'CANCELLED'}

        was_edit = (context.mode == 'EDIT_MESH')
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh   = obj.data
        attr   = mesh.color_attributes.get(ATTR_NAME)
        picked = False

        if attr:
            for poly in mesh.polygons:
                if poly.select:
                    c = attr.data[poly.loop_indices[0]].color
                    context.scene.wc_props.face_color = (c[0], c[1], c[2])
                    self.report({'INFO'}, f"Picked {_color_to_hex(c[0], c[1], c[2])}")
                    picked = True
                    break

        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')

        if not picked:
            self.report({'WARNING'}, "Виділи face з Color Attribute")
            return {'CANCELLED'}
        return {'FINISHED'}


class WIRECOLOR_OT_reset_faces(Operator):
    bl_idname      = "wirecolor.reset_faces"
    bl_label       = "Reset to Object Color"
    bl_description = "Скинути всі faces активного об'єкта до його obj.color"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Немає активного mesh-об'єкта")
            return {'CANCELLED'}
        _make_color_attr(obj.data, obj.wc_color)
        obj.data.update()
        self.report({'INFO'}, f"Скинуто → {_color_to_hex(*obj.wc_color[:3])}")
        return {'FINISHED'}


class WIRECOLOR_OT_clear_attr(Operator):
    bl_idname      = "wirecolor.clear_attr"
    bl_label       = "Clear Color Attribute"
    bl_description = "Видалити Color Attribute з активного об'єкта"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Немає активного mesh-об'єкта")
            return {'CANCELLED'}
        mesh    = obj.data
        removed = False
        if ATTR_NAME in mesh.color_attributes:
            mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
            removed = True
        if PAINTED_ATTR in mesh.attributes:
            mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        self.report({'INFO'} if removed else {'WARNING'},
                    "Видалено" if removed else "Атрибут не знайдено")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Diagnose
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_diagnose(Operator):
    bl_idname      = "wirecolor.diagnose"
    bl_label       = "WC Diagnose (log)"
    bl_description = "Вивести в консоль стан color attributes та матеріалів активного об'єкта"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Немає активного mesh-об'єкта")
            return {'CANCELLED'}
        mesh = obj.data
        props = context.scene.wc_props

        print("\n=== WireColor Diagnose ===")
        print(f"Object: {obj.name}  Mesh: {mesh.name}")
        print(f"obj.color: {tuple(round(c,3) for c in obj.color)}")

        # Viewport shading стан
        print(f"\n--- Viewport Shading ---")
        print(f"preview_active: {props.preview_active}  preview_mode: '{props.preview_mode}'")
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                s = area.spaces.active
                print(f"  Viewport: type={s.shading.type}  color_type={s.shading.color_type}  light={s.shading.light}")

        # Color attributes
        print(f"\n--- Color Attributes ---")
        ac = mesh.color_attributes.active_color
        print(f"active_color: {ac.name if ac else 'None'}")
        for ca in mesh.color_attributes:
            mark = " ← ACTIVE" if ac and ca.name == ac.name else ""
            print(f"  '{ca.name}'  type={ca.data_type}  domain={ca.domain}{mark}")
        if not mesh.color_attributes:
            print("  (жодного)")
        print(f"_active_color_bak: {_active_color_bak.get(mesh.name, 'not in dict')}")

        # Materials — рекурсивно в групи
        def scan_nodes(node_tree, indent="    "):
            found = []
            for n in node_tree.nodes:
                if n.type == 'VERTEX_COLOR':
                    found.append(f"{indent}[VERTEX_COLOR]  layer_name='{n.layer_name}'{'  <-- empty=reads active!' if not n.layer_name else ''}")
                elif n.type == 'ATTRIBUTE':
                    found.append(f"{indent}[ATTRIBUTE]     name='{n.attribute_name}'")
                elif n.type == 'OBJECT_INFO':
                    color_out = n.outputs.get("Color")
                    linked = bool(color_out and color_out.is_linked)
                    found.append(f"{indent}[OBJECT_INFO]   Color linked={linked}{'  <-- obj.color!' if linked else ''}")
                elif n.type == 'GROUP' and n.node_tree:
                    sub = scan_nodes(n.node_tree, indent + "  ")
                    if sub:
                        found.append(f"{indent}[GROUP '{n.node_tree.name}']")
                        found.extend(sub)
            return found

        print(f"\n--- Materials ---")
        for mat in mesh.materials:
            if not mat or not mat.use_nodes:
                print(f"  '{mat.name if mat else 'None'}' — no nodes")
                continue
            print(f"  '{mat.name}'  (top-level nodes: {len(mat.node_tree.nodes)})")
            lines = scan_nodes(mat.node_tree)
            if lines:
                for l in lines:
                    print(l)
            else:
                print("    (Color Attribute / Attribute / Object Info — не знайдено)")

        print("=========================\n")
        self.report({'INFO'}, "Дивись консоль Blender (Window → Toggle System Console)")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Alpha Mask
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_alpha_include_selected(Operator):
    bl_idname      = "wirecolor.alpha_include_selected"
    bl_label       = "Include in Alpha"
    bl_description = "Позначити виділені mesh-об'єкти як ВКЛЮЧЕНІ в Alpha маску (білі)"

    def execute(self, context):
        count = sum(1 for obj in context.selected_objects
                    if obj.type == 'MESH' and setattr(obj, 'wc_alpha_include', True) is None)
        self.report({'INFO'}, f"Alpha include: {count} об'єктів")
        return {'FINISHED'}


class WIRECOLOR_OT_alpha_exclude_selected(Operator):
    bl_idname      = "wirecolor.alpha_exclude_selected"
    bl_label       = "Exclude from Alpha"
    bl_description = "Позначити виділені mesh-об'єкти як ВИКЛЮЧЕНІ з Alpha маски (чорні)"

    def execute(self, context):
        count = sum(1 for obj in context.selected_objects
                    if obj.type == 'MESH' and setattr(obj, 'wc_alpha_include', False) is None)
        self.report({'INFO'}, f"Alpha exclude: {count} об'єктів")
        return {'FINISHED'}


class WIRECOLOR_OT_render_alpha_mask(Operator):
    bl_idname      = "wirecolor.render_alpha_mask"
    bl_label       = "Render Alpha Mask"
    bl_description = "Alpha маска: included=білий, excluded=чорний (_mask_alpha)"

    def execute(self, context):
        path = _render_alpha_mask(context.scene)
        self.report({'INFO'}, f"Alpha → {os.path.basename(path)}")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Render
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_render_obj_mask(Operator):
    bl_idname      = "wirecolor.render_obj_mask"
    bl_label       = "Render Object Mask"
    bl_description = "Маска: кожен об'єкт = свій obj.color, без ручного фарбування"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_obj", fill_all=True)
        self.report({'INFO'}, f"Object mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_face_mask(Operator):
    bl_idname      = "wirecolor.render_face_mask"
    bl_label       = "Render Face Mask"
    bl_description = "Маска: obj.color + ручне фарбування faces поверх"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_face", fill_all=False)
        self.report({'INFO'}, f"Face mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_mat_mask(Operator):
    bl_idname      = "wirecolor.render_mat_mask"
    bl_label       = "Render Material Mask"
    bl_description = "Маска: кожен матеріал = унікальний колір (_mask_mat). Не змінює кольори об'єктів"
    bl_options     = {'REGISTER'}

    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        scene = context.scene
        path  = _render_workbench_mat(scene, "_mask_mat", self.seed)
        self.report({'INFO'}, f"Material mask → {os.path.basename(path)}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_both_masks(Operator):
    bl_idname      = "wirecolor.render_both_masks"
    bl_label       = "Render Both Masks"
    bl_description = "Рендерити _mask_obj і _mask_face послідовно"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        p1 = _render_workbench(scene, "_mask_obj",  fill_all=True)
        p2 = _render_workbench(scene, "_mask_face", fill_all=False)
        self.report({'INFO'}, f"Object → {os.path.basename(p1)}")
        self.report({'INFO'}, f"Face   → {os.path.basename(p2)}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_all(Operator):
    bl_idname      = "wirecolor.render_all"
    bl_label       = "Render Beauty + Both Masks"
    bl_description = "Beauty + object mask + face mask (3 файли)"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        scene     = context.scene
        orig_path = bpy.path.abspath(scene.render.filepath)
        bpy.ops.render.render(animation=False, write_still=True)
        p1 = _render_workbench(scene, "_mask_obj",  fill_all=True)
        p2 = _render_workbench(scene, "_mask_face", fill_all=False)
        self.report({'INFO'}, f"Beauty → {os.path.basename(orig_path)}")
        self.report({'INFO'}, f"Object → {os.path.basename(p1)}")
        self.report({'INFO'}, f"Face   → {os.path.basename(p2)}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_anim_masks(Operator):
    bl_idname      = "wirecolor.render_anim_masks"
    bl_label       = "Render Animation Masks"
    bl_description = "Рендерити анімацію обох масок (_mask_obj і _mask_face)"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        p1 = _render_workbench(scene, "_mask_obj",  fill_all=True,  animation=True)
        p2 = _render_workbench(scene, "_mask_face", fill_all=False, animation=True)
        self.report({'INFO'}, f"Anim Object → {p1}")
        self.report({'INFO'}, f"Anim Face   → {p2}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_anim_all(Operator):
    bl_idname      = "wirecolor.render_anim_all"
    bl_label       = "Render Animation Beauty + Masks"
    bl_description = "Рендерити анімацію: beauty + object mask + face mask"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        scene         = context.scene
        orig_filepath = scene.render.filepath

        # Beauty — стандартний рендер анімації
        bpy.ops.render.render(animation=True)
        self.report({'INFO'}, f"Anim Beauty → {orig_filepath}")

        p1 = _render_workbench(scene, "_mask_obj",  fill_all=True,  animation=True)
        p2 = _render_workbench(scene, "_mask_face", fill_all=False, animation=True)
        self.report({'INFO'}, f"Anim Object → {p1}")
        self.report({'INFO'}, f"Anim Face   → {p2}")
        return {'FINISHED'}


class WIRECOLOR_OT_export_mapping(Operator):
    bl_idname      = "wirecolor.export_mapping"
    bl_label       = "Export Color Mapping"
    bl_description = "Зберегти JSON: об'єкт → колір (в папку рендеру)"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        scene    = context.scene
        out_dir  = os.path.dirname(bpy.path.abspath(scene.render.filepath)) or bpy.path.abspath("//")
        json_path = os.path.join(out_dir, "wirecolor_mapping.json")
        mapping  = {}
        for obj in scene.objects:
            if obj.type not in ('MESH', 'CURVE', 'SURFACE'):
                continue
            r, g, b, _ = obj.wc_color
            has_fp = (obj.type == 'MESH' and ATTR_NAME in obj.data.color_attributes
                      and PAINTED_ATTR in obj.data.attributes)
            mapping[obj.name] = {
                "color":        [round(r, 4), round(g, 4), round(b, 4)],
                "hex":          _color_to_hex(r, g, b),
                "face_painted": has_fp,
            }
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({"objects": mapping}, f, indent=2, ensure_ascii=False)
        self.report({'INFO'}, f"Saved: {json_path}")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS — Palette
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_palette_click(Operator):
    bl_idname      = "wirecolor.palette_click"
    bl_label       = ""
    bl_description = "Застосувати цей колір до виділених faces"
    bl_options     = {'REGISTER', 'INTERNAL'}

    index: IntProperty(default=0)

    def execute(self, context):
        props = context.scene.wc_props
        if self.index >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_index = self.index
        c = props.palette_colors[self.index].color
        r, g, b = c[0], c[1], c[2]
        props.face_color = (r, g, b)

        if context.mode == 'EDIT_MESH':
            try:
                bpy.ops.wirecolor.paint_faces()
            except Exception:
                pass
        else:
            # Object Mode — встановити wc_color виділеним mesh-об'єктам
            for obj in context.selected_objects:
                if obj.type == 'MESH':
                    obj.wc_color = (r, g, b, 1.0)
                    # update callback викличе _sync_obj_to_attr автоматично
            _tag_redraw_viewports()
        return {'FINISHED'}


class WIRECOLOR_OT_palette_add(Operator):
    bl_idname      = "wirecolor.palette_add"
    bl_label       = "Add to Palette"
    bl_description = "Зберегти поточний face_color у палітру"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        entry = props.palette_colors.add()
        entry.color = props.face_color
        props.palette_index = len(props.palette_colors) - 1
        self.report({'INFO'}, f"+ {_color_to_hex(*props.face_color)}")
        return {'FINISHED'}


class WIRECOLOR_OT_palette_remove(Operator):
    bl_idname      = "wirecolor.palette_remove"
    bl_label       = "Remove from Palette"
    bl_description = "Видалити активний колір з палітри"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        idx   = props.palette_index
        if not props.palette_colors or idx >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_colors.remove(idx)
        props.palette_index = max(0, idx - 1)
        return {'FINISHED'}


class WIRECOLOR_OT_palette_apply(Operator):
    bl_idname      = "wirecolor.palette_apply"
    bl_label       = "Apply Palette Color"
    bl_description = "Взяти активний колір з палітри у face_color"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        props = context.scene.wc_props
        idx   = props.palette_index
        if not props.palette_colors or idx >= len(props.palette_colors):
            self.report({'WARNING'}, "Виділи колір у палітрі")
            return {'CANCELLED'}
        c = props.palette_colors[idx].color
        props.face_color = (c[0], c[1], c[2])
        return {'FINISHED'}


class WIRECOLOR_OT_palette_load_presets(Operator):
    bl_idname      = "wirecolor.palette_load_presets"
    bl_label       = "Load Preset Colors"
    bl_description = "Очистити палітру і завантажити 15 яскравих пресетів"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        props.palette_colors.clear()
        for r, g, b in PRESET_COLORS:
            entry = props.palette_colors.add()
            entry.color = (r, g, b)
        props.palette_index = 0
        self.report({'INFO'}, f"Loaded {len(PRESET_COLORS)} preset colors")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

def _palette_index_update(self, context):
    idx = self.palette_index
    if self.palette_colors and idx < len(self.palette_colors):
        c = self.palette_colors[idx].color
        self.face_color = (c[0], c[1], c[2])
        # Авто-фарбування виділених faces якщо зараз Edit Mode
        try:
            if context and context.mode == 'EDIT_MESH':
                bpy.ops.wirecolor.paint_faces()
        except Exception:
            pass


class WireColorPaletteEntry(PropertyGroup):
    color: FloatVectorProperty(description="Колір палітри", 
        name="Color", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
    )


class WIRECOLOR_UL_palette(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.prop(item, "color", text="")


class WireColorProps(PropertyGroup):
    face_color: FloatVectorProperty(
        name="", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
        description="Колір для фарбування виділених faces",
    )
    select_angle: FloatProperty(
        name="Angle",
        description="Максимальний кут між нормалями сусідніх faces (градуси)",
        default=15.0, min=0.0, max=180.0, precision=1,
        subtype='NONE',
    )
    palette_colors: CollectionProperty(type=WireColorPaletteEntry)
    palette_index:  IntProperty(default=0, min=0, update=_palette_index_update)
    preview_active:        BoolProperty(default=False)
    preview_mode:          StringProperty(default='')
    preview_auto_names:    StringProperty(default='[]')
    preview_saved_shading: StringProperty(default='SOLID')
    preview_saved_color:   StringProperty(default='MATERIAL')
    preview_saved_light:   StringProperty(default='STUDIO')
    preview_saved_all:     StringProperty(default='[]')   # JSON [{type,color,light}, ...]
    preview_mat_backup:    StringProperty(default='')     # JSON backup для Material preview mode
    preview_obj_backup:    StringProperty(default='')     # JSON backup obj.color для Object preview mode


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_PT_panel(Panel):
    bl_label       = "WireColor Masks"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "WireColor"

    def draw(self, context):
        layout   = self.layout
        props    = context.scene.wc_props
        obj      = context.active_object
        is_mesh  = bool(obj and obj.type == 'MESH')
        has_attr = is_mesh and (ATTR_NAME in obj.data.color_attributes)

        layout.label(text="v" + ".".join(str(v) for v in bl_info["version"]))

        # ── OBJECTS ──────────────────────────────────────────
        box = layout.box()
        box.label(text="Objects", icon='OBJECT_DATA')
        if is_mesh:
            box.prop(obj, "wc_color", text="Mask Color")
        row = box.row(align=True)
        row.operator("wirecolor.assign_object_colors", icon='COLOR')
        row.operator("wirecolor.sync_colors", text="", icon='FILE_REFRESH')

        # Alpha Mask
        box.separator(factor=0.4)
        box.label(text="Alpha Mask", icon='IMAGE_ALPHA')
        row = box.row(align=True)
        row.operator("wirecolor.alpha_include_selected", text="Include", icon='CHECKBOX_HLT')
        row.operator("wirecolor.alpha_exclude_selected", text="Exclude", icon='CHECKBOX_DEHLT')
        if is_mesh:
            icon_a = 'RADIOBUT_ON' if obj.wc_alpha_include else 'RADIOBUT_OFF'
            label  = "Active: INCLUDED" if obj.wc_alpha_include else "Active: excluded"
            box.label(text=label, icon=icon_a)

        # ── VIEWPORT PREVIEW ─────────────────────────────────
        box = layout.box()
        box.label(text="Viewport Preview", icon='HIDE_OFF')
        if props.preview_active:
            row = box.row()
            row.alert = True
            row.operator("wirecolor.preview_exit", icon='HIDE_ON')
            row2 = box.row(align=True)
            sub = row2.row(align=True)
            sub.enabled = (props.preview_mode != 'OBJECT')
            sub.operator("wirecolor.preview_set", text="Object",   icon='OBJECT_DATA').mode = 'OBJECT'
            sub2 = row2.row(align=True)
            sub2.enabled = (props.preview_mode != 'FACE')
            sub2.operator("wirecolor.preview_set", text="Face",    icon='UV_FACESEL').mode  = 'FACE'
            sub3 = row2.row(align=True)
            sub3.enabled = (props.preview_mode != 'MATERIAL')
            sub3.operator("wirecolor.preview_set", text="Mat",     icon='MATERIAL').mode    = 'MATERIAL'
        else:
            row = box.row(align=True)
            row.operator("wirecolor.preview_set", text="Object", icon='OBJECT_DATA').mode  = 'OBJECT'
            row.operator("wirecolor.preview_set", text="Face",   icon='UV_FACESEL').mode   = 'FACE'
            row.operator("wirecolor.preview_set", text="Mat",    icon='MATERIAL').mode     = 'MATERIAL'

        # ── SELECT BY ANGLE ──────────────────────────────────
        box = layout.box()
        box.label(text="Select by Angle", icon='RESTRICT_SELECT_OFF')
        row = box.row(align=True)
        row.prop(props, "select_angle", text="Angle °")
        box.operator("wirecolor.select_by_angle", icon='RESTRICT_SELECT_OFF')

        # ── FACE PAINT ───────────────────────────────────────
        box = layout.box()
        box.label(text="Face Paint", icon='UV_FACESEL')
        box.prop(props, "face_color")
        row = box.row(align=True)
        row.enabled = bool(obj)
        row.operator("wirecolor.pick_from_object", icon='OBJECT_DATA')
        row.operator("wirecolor.pick_from_face",   icon='EYEDROPPER')

        # Palette — кубики 5 в ряд, клік = фарбує
        box.separator(factor=0.4)
        row = box.row(align=True)
        row.label(text="Palette", icon='COLORSET_01_VEC')
        row.operator("wirecolor.palette_load_presets", text="↻ Presets", icon='FILE_REFRESH')
        row.operator("wirecolor.palette_add",          text="", icon='ADD')

        grid = box.grid_flow(row_major=True, columns=5,
                             even_columns=True, even_rows=True, align=True)
        for i, entry in enumerate(props.palette_colors):
            icon_id = _preset_icon(i)
            is_sel  = (i == props.palette_index)
            col = grid.column(align=True)
            col.scale_y = 1.6
            col.emboss  = 'NONE'
            op = col.operator("wirecolor.palette_click", text="",
                              icon_value=icon_id, depress=is_sel)
            op.index = i
        box.separator(factor=0.3)

        col = box.column(align=True)
        col.enabled = is_mesh
        col.operator("wirecolor.paint_faces", icon='BRUSH_DATA')
        col.operator("wirecolor.reset_faces", icon='LOOP_BACK')
        row = col.row()
        row.enabled = has_attr
        row.operator("wirecolor.clear_attr", icon='TRASH')
        if not is_mesh:
            box.label(text="Виділи mesh-об'єкт", icon='INFO')
        elif has_attr:
            box.label(text="wc_mask_color: є  ✓", icon='CHECKMARK')
        col.operator("wirecolor.diagnose", icon='INFO')

        # ── RENDER ───────────────────────────────────────────
        box = layout.box()
        box.label(text="Render", icon='RENDER_STILL')
        col = box.column(align=True)
        col.operator("wirecolor.render_obj_mask",   icon='OBJECT_DATA')
        col.operator("wirecolor.render_face_mask",  icon='UV_FACESEL')
        col.operator("wirecolor.render_mat_mask",   icon='MATERIAL')
        col.operator("wirecolor.render_alpha_mask",  icon='IMAGE_ALPHA')
        col.separator(factor=0.3)
        col.operator("wirecolor.render_both_masks",  icon='IMAGE_DATA')
        col.operator("wirecolor.render_all",         icon='RENDERLAYERS')
        col.separator(factor=0.3)
        col.operator("wirecolor.render_anim_masks",  icon='RENDER_ANIMATION')
        col.operator("wirecolor.render_anim_all",    icon='RENDER_ANIMATION')
        col.separator(factor=0.3)
        col.operator("wirecolor.export_mapping",     icon='FILE_TEXT')


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    WireColorPaletteEntry,
    WireColorProps,
    WIRECOLOR_UL_palette,
    WIRECOLOR_OT_sync_colors,
    WIRECOLOR_OT_assign_object_colors,
    WIRECOLOR_OT_preview_set,
    WIRECOLOR_OT_preview_exit,
    WIRECOLOR_OT_select_by_angle,
    WIRECOLOR_OT_paint_faces,
    WIRECOLOR_OT_pick_from_object,
    WIRECOLOR_OT_pick_from_face,
    WIRECOLOR_OT_palette_click,
    WIRECOLOR_OT_palette_add,
    WIRECOLOR_OT_palette_remove,
    WIRECOLOR_OT_palette_apply,
    WIRECOLOR_OT_palette_load_presets,
    WIRECOLOR_OT_reset_faces,
    WIRECOLOR_OT_clear_attr,
    WIRECOLOR_OT_diagnose,
    WIRECOLOR_OT_alpha_include_selected,
    WIRECOLOR_OT_alpha_exclude_selected,
    WIRECOLOR_OT_render_alpha_mask,
    WIRECOLOR_OT_render_obj_mask,
    WIRECOLOR_OT_render_face_mask,
    WIRECOLOR_OT_render_mat_mask,
    WIRECOLOR_OT_render_both_masks,
    WIRECOLOR_OT_render_all,
    WIRECOLOR_OT_render_anim_masks,
    WIRECOLOR_OT_render_anim_all,
    WIRECOLOR_OT_export_mapping,
    WIRECOLOR_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.wc_props = PointerProperty(type=WireColorProps)
    bpy.types.Object.wc_alpha_include = BoolProperty(
        name="Include in Alpha",
        description="Включити об'єкт в Alpha маску (білий = included, чорний = excluded)",
        default=False,
    )
    bpy.types.Object.wc_color = FloatVectorProperty(
        name="Mask Color",
        description="WireColor маскований колір (не впливає на матеріали)",
        subtype='COLOR', size=4,
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        update=_wc_color_update,
    )
    _build_preview_icons()
    # Пресети: і напряму, і через таймер (запасний — на випадок якщо сцена ще не готова)
    _init_palette_presets()
    bpy.app.timers.register(_init_palette_presets, first_interval=1.0)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)


def unregister():
    _clear_preview_icons()
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Object.wc_alpha_include
    del bpy.types.Object.wc_color
    del bpy.types.Scene.wc_props


if __name__ == "__main__":
    register()
