bl_info = {
    "name":        "WireColor Masks",
    "author":      "Hrebeniuk",
    "version":     (3, 9, 0),
    "blender":     (4, 2, 0),
    "location":    "3D Viewport › N-Panel › WireColor",
    "description": "Кольорові маски: колір на об'єкт або полігони, перегляд у вьюпорті",
    "category":    "Render",
}
# Blender (extensions) прибирає bl_info після завантаження — версію запам'ятовуємо тут
ADDON_VERSION = tuple(bl_info["version"])


import bpy
import bpy.utils.previews
import bmesh
import colorsys
import math
import random
import os
import json
import numpy as np
from bpy.props import (FloatVectorProperty, IntProperty, FloatProperty,
                       PointerProperty, BoolProperty, StringProperty,
                       CollectionProperty, EnumProperty)
from bpy.types import Panel, Operator, PropertyGroup

ATTR_NAME    = "wc_mask_color"
PAINTED_ATTR = "wc_painted"

_rendering          = False
_preview_coll       = None
_active_color_bak: dict = {}   # mesh.name → original active color attr name

PRESET_COLORS = [
    (1.000, 0.000, 0.000),  # #FF0000 Bright Red
    (0.000, 1.000, 0.000),  # #00FF00 Lime Green
    (0.000, 0.000, 1.000),  # #0000FF Blue
    (1.000, 1.000, 0.000),  # #FFFF00 Yellow
    (0.000, 1.000, 1.000),  # #00FFFF Cyan
    (1.000, 0.000, 1.000),  # #FF00FF Magenta
    (1.000, 0.498, 0.000),  # #FF7F00 Orange
    (0.498, 0.000, 1.000),  # #7F00FF Electric Violet
    (0.000, 1.000, 0.498),  # #00FF7F Mint Neon
    (1.000, 0.000, 0.498),  # #FF007F Fuchsia
    (0.498, 1.000, 0.000),  # #7FFF00 Chartreuse
    (0.000, 0.498, 1.000),  # #007FFF Azure
    (0.545, 0.000, 0.000),  # #8B0000 Dark Red
    (0.000, 0.392, 0.000),  # #006400 Dark Green
    (0.000, 0.000, 0.545),  # #00008B Dark Blue
    (0.502, 0.502, 0.000),  # #808000 Olive
    (0.502, 0.000, 0.502),  # #800080 Purple
    (0.000, 0.502, 0.502),  # #008080 Teal
    (1.000, 0.843, 0.000),  # #FFD700 Gold
    (0.294, 0.000, 0.510),  # #4B0082 Indigo
]

MODE_TITLES = {
    'OBJECT':   "Object",
    'FACE':     "Face",
    'MATERIAL': "Material",
}


# ─────────────────────────────────────────────────────────────────────────────
#  ІКОНКИ ПАЛІТРИ  (кольоровий квадрат на кожен колір, будуються за потреби)
# ─────────────────────────────────────────────────────────────────────────────

def _clear_preview_icons():
    global _preview_coll
    if _preview_coll is not None:
        try:
            bpy.utils.previews.remove(_preview_coll)
        except Exception:
            pass
        _preview_coll = None


def _color_icon(color):
    """icon_id квадратика заданого кольору (кеш по hex)."""
    global _preview_coll
    if _preview_coll is None:
        _preview_coll = bpy.utils.previews.new()
    r, g, b = color[0], color[1], color[2]
    key = _color_to_hex(r, g, b)
    if key not in _preview_coll:
        size = 32
        thumb = _preview_coll.new(key)
        thumb.image_size = (size, size)
        try:
            thumb.image_pixels_float[:] = (r, g, b, 1.0) * (size * size)
        except Exception:
            pass
    return _preview_coll[key].icon_id


# ─────────────────────────────────────────────────────────────────────────────
#  CORE SYNC
# ─────────────────────────────────────────────────────────────────────────────

# ── Спільні меші ─────────────────────────────────────────────────────────────
# Колір маски полігонів живе в меші. Якщо один меш у кількох об'єктів (копії модуля в різних
# конфігураціях), колір ОБ'ЄКТА в меш писати не можна — останній пофарбований перезаписує решту
# («скидає» кольори). Тому для Face-маски на такі об'єкти тимчасово ставиться GN-модифікатор:
# непофарбовані полігони = колір цього об'єкта, пофарбовані = колір з меша (спільний для всіх копій).
OBJ_MOD   = "WC_ObjColor"
OBJ_GROUP = "WC Object Color"


def _objcolor_group():
    ng = bpy.data.node_groups.get(OBJ_GROUP)
    if ng and ng.bl_idname == 'GeometryNodeTree':
        return ng
    ng = bpy.data.node_groups.new(OBJ_GROUP, 'GeometryNodeTree')
    it = ng.interface
    it.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    it.new_socket("Колір", in_out='INPUT', socket_type='NodeSocketColor')
    it.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); gi.location = (-600, 0)
    go = N.new('NodeGroupOutput'); go.location = (400, 0)
    pa = N.new('GeometryNodeInputNamedAttribute'); pa.data_type = 'INT'; pa.location = (-400, -150)
    pa.inputs["Name"].default_value = PAINTED_ATTR
    ca = N.new('GeometryNodeInputNamedAttribute'); ca.data_type = 'FLOAT_COLOR'; ca.location = (-400, -300)
    ca.inputs["Name"].default_value = ATTR_NAME
    sw = N.new('GeometryNodeSwitch'); sw.input_type = 'RGBA'; sw.location = (-150, -150)
    L.new(pa.outputs["Attribute"], sw.inputs["Switch"])
    L.new(gi.outputs["Колір"], sw.inputs["False"])
    L.new(ca.outputs["Attribute"], sw.inputs["True"])
    st = N.new('GeometryNodeStoreNamedAttribute'); st.data_type = 'FLOAT_COLOR'; st.domain = 'CORNER'; st.location = (100, 0)
    st.inputs["Name"].default_value = ATTR_NAME
    L.new(gi.outputs["Geometry"], st.inputs["Geometry"]); L.new(sw.outputs[0], st.inputs["Value"])
    L.new(st.outputs["Geometry"], go.inputs["Geometry"])
    return ng


def _objcolor_set(obj):
    mod = obj.modifiers.get(OBJ_MOD)
    if mod is None or mod.node_group is None:
        return
    ident = mod.node_group.interface.items_tree["Колір"].identifier
    props = getattr(mod, "properties", None)          # Blender 5.x: mod.properties.inputs.<id>.value
    if props is not None and hasattr(props, "inputs"):
        getattr(props.inputs, ident).value = tuple(obj.wc_color)
    else:                                             # Blender 4.x: id-властивість модифікатора
        mod[ident] = tuple(obj.wc_color)
    obj.update_tag()


def _objcolor_mods_add(scene):
    """Модифікатор на об'єкти зі спільним мешем. Повертає імена, на які додали."""
    ng, added = None, []
    for obj in scene.objects:
        if obj.type != 'MESH' or obj.data.users < 2 or ATTR_NAME not in obj.data.color_attributes:
            continue
        if obj.modifiers.get(OBJ_MOD) is None:
            ng = ng or _objcolor_group()
            mod = obj.modifiers.new(OBJ_MOD, 'NODES')
            mod.node_group = ng
            mod.show_in_editmode = True
            added.append(obj.name)
        _objcolor_set(obj)
    return added


def _face_mods(on):
    """Модифікатори з іменем WC_Face* (напр. маска деталей Thuma) працюють лише під час Face-маски."""
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        for mod in obj.modifiers:
            if mod.name.startswith("WC_Face") and (mod.show_viewport != on or mod.show_render != on):
                mod.show_viewport = mod.show_render = on


def _objcolor_mods_remove(names=None):
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or (names is not None and obj.name not in names):
            continue
        mod = obj.modifiers.get(OBJ_MOD)
        if mod is not None:
            obj.modifiers.remove(mod)


def _sync_obj_to_attr(obj):
    if obj.type != 'MESH':
        return
    mesh = obj.data
    if mesh.users > 1:                     # спільний меш: колір об'єкта дає модифікатор, меш не чіпаємо
        _objcolor_set(obj)
        return
    if ATTR_NAME not in mesh.color_attributes:
        return
    old_attr = mesh.color_attributes[ATTR_NAME]
    if not len(old_attr.data):
        return

    painted_attr = mesh.attributes.get(PAINTED_ATTR)
    r, g, b, _   = obj.wc_color
    n_loops = len(old_attr.data)

    # Читаємо всі поточні кольори (щоб зберегти ручні) — numpy, без циклу по loops
    saved = np.empty(n_loops * 4, np.float32)
    old_attr.data.foreach_get('color', saved)
    saved = saved.reshape(-1, 4)
    out = np.tile(np.array((r, g, b, 1.0), np.float32), (n_loops, 1))
    if painted_attr and len(painted_attr.data) == len(mesh.polygons):
        painted = np.empty(len(mesh.polygons), np.int32)
        painted_attr.data.foreach_get('value', painted)
        loop_painted = painted[_loop_to_poly(mesh)] != 0
        out[loop_painted] = saved[loop_painted]

    # Перестворюємо атрибут — тільки так Blender скидає GPU кеш
    mesh.color_attributes.remove(old_attr)
    new_attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
    new_attr.data.foreach_set('color', out.ravel())

    mesh.color_attributes.active_color = new_attr
    mesh.update()


def _loop_to_poly(mesh):
    """Масив: індекс полігона для кожного loop (numpy)."""
    n_poly = len(mesh.polygons)
    starts = np.empty(n_poly, np.int64)
    totals = np.empty(n_poly, np.int64)
    mesh.polygons.foreach_get('loop_start', starts)
    mesh.polygons.foreach_get('loop_total', totals)
    out = np.empty(len(mesh.loops), np.int64)
    for_poly = np.repeat(np.arange(n_poly), totals)
    loop_idx = np.repeat(starts - np.concatenate(([0], np.cumsum(totals)[:-1])), totals) + np.arange(totals.sum())
    out[loop_idx] = for_poly
    return out


def _tag_redraw_viewports():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _wc_color_update(obj, context):
    """Callback: obj.wc_color змінився → оновити маску і те, що видно у вьюпорті."""
    try:
        props = context.scene.wc_props
    except Exception:
        props = None
    # У перегляді «Object» вьюпорт показує obj.color — оновлюємо його одразу
    if props and props.preview_active and props.preview_mode == 'OBJECT':
        bak = json.loads(props.preview_obj_backup or "{}")
        if obj.name not in bak:
            bak[obj.name] = list(obj.color)
            props.preview_obj_backup = json.dumps(bak)
        obj.color = obj.wc_color
    if obj.type == 'MESH' and ATTR_NAME in obj.data.color_attributes \
            and not (obj.mode == 'EDIT'):
        _sync_obj_to_attr(obj)
    _tag_redraw_viewports()


def _init_palette_presets():
    """Заповнити палітру пресетами якщо вона порожня."""
    try:
        for scene in list(bpy.data.scenes):
            try:
                props = scene.wc_props
                if len(props.palette_colors) == 0:
                    for r, g, b in PRESET_COLORS:
                        props.palette_colors.add().color = (r, g, b)
            except Exception as e:
                print(f"WireColor: preset error for '{scene.name}': {e}")
    except Exception as e:
        print(f"WireColor: _init_palette_presets failed: {e}")
    return None  # one-shot timer


@bpy.app.handlers.persistent
def _on_load_post(dummy):
    """Після відкриття файлу — ініціалізація."""
    _active_color_bak.clear()
    bpy.app.timers.register(_init_palette_presets, first_interval=0.2)


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

class _ObjectModeScope:
    """Тимчасово вийти з Edit Mode (зміни mesh-даних в Edit Mode губляться)."""
    def __init__(self, context):
        self.was_edit = (context.mode == 'EDIT_MESH')
        # об'єкти запам'ятовуємо ДО виходу з Edit Mode — після нього список порожній
        self.objects = ([o for o in context.objects_in_mode_unique_data if o.type == 'MESH']
                        if self.was_edit else
                        [o for o in context.selected_objects if o.type == 'MESH'])

    def __enter__(self):
        if self.was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        return self

    def __exit__(self, *exc):
        if self.was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        return False


def _make_color_attr(mesh, obj_color):
    if ATTR_NAME in mesh.color_attributes:
        mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
    attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
    r, g, b = obj_color[:3]
    if len(attr.data):
        attr.data.foreach_set('color', np.tile(np.array((r, g, b, 1.0), np.float32), len(attr.data)))
    if PAINTED_ATTR not in mesh.attributes:
        mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
    else:
        for d in mesh.attributes[PAINTED_ATTR].data:
            d.value = 0
    return attr


def _ensure_color_attributes(scene):
    auto_names = []
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        # Зберігаємо оригінальний active_color щоб не зламати Cycles-матеріал
        if mesh.name not in _active_color_bak:
            ac = mesh.color_attributes.active_color
            _active_color_bak[mesh.name] = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            auto_names.append(obj.name)
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return auto_names


def _cleanup_by_names(names):
    for name in names:
        obj = bpy.data.objects.get(name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        # Відновлюємо оригінальний active_color в будь-якому випадку
        orig = _active_color_bak.pop(mesh.name, None)
        if orig and orig in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig]
        # Не видаляємо атрибут якщо є ручне фарбування
        painted = mesh.attributes.get(PAINTED_ATTR)
        if painted and any(d.value for d in painted.data):
            continue
        if ATTR_NAME in mesh.color_attributes:
            mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
        if PAINTED_ATTR in mesh.attributes:
            mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])


def _fill_temp_obj_color(scene):
    """Тимчасово заповнити всі loops obj.color, зберегти оригінальні кольори.
    Повертає {obj_name: (loop_colors або None, orig_active_color_name або None)}."""
    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None
        if ATTR_NAME not in mesh.color_attributes:
            _make_color_attr(mesh, obj.wc_color)
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            loop_backup[obj.name] = (
                [tuple(attr.data[li].color) for li in range(len(attr.data))],
                orig_active,
            )
            r, g, b = obj.wc_color[:3]
            for li in range(len(attr.data)):
                attr.data[li].color = (r, g, b, 1.0)
            mesh.update()
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _fill_temp_mat_color(scene, seed=42):
    """Тимчасово заповнити loops кольором матеріалу PER-FACE (по слоту poly.material_index).
    Однаковий матеріал = однаковий колір на всіх faces і об'єктах."""
    rng = random.Random(seed)
    mat_colors: dict = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        for mat in obj.data.materials:
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())

    NO_MAT_COLOR = (0.5, 0.5, 0.5)

    loop_backup = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        mesh = obj.data
        ac = mesh.color_attributes.active_color
        orig_active = ac.name if ac else None

        slot_colors = [mat_colors.get(mat.name, NO_MAT_COLOR) if mat else NO_MAT_COLOR
                       for mat in mesh.materials]

        if ATTR_NAME not in mesh.color_attributes:
            if PAINTED_ATTR not in mesh.attributes:
                mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            attr = mesh.color_attributes.new(name=ATTR_NAME, type='FLOAT_COLOR', domain='CORNER')
            loop_backup[obj.name] = (None, orig_active)
        else:
            attr = mesh.color_attributes[ATTR_NAME]
            loop_backup[obj.name] = ([tuple(attr.data[li].color) for li in range(len(attr.data))],
                                     orig_active)
        for poly in mesh.polygons:
            r, g, b = slot_colors[poly.material_index] if poly.material_index < len(slot_colors) else NO_MAT_COLOR
            for li in poly.loop_indices:
                attr.data[li].color = (r, g, b, 1.0)
        mesh.update()
        mesh.color_attributes.active_color = mesh.color_attributes[ATTR_NAME]
    return loop_backup


def _mat_colors(scene, seed=42):
    """Колір кожного матеріалу сцени (той самий порядок і seed, що й раніше)."""
    rng = random.Random(seed)
    mat_colors = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        for mat in obj.data.materials:
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())
        for slot in obj.material_slots:          # матеріали, прив'язані до об'єкта
            mat = slot.material
            if mat and mat.name not in mat_colors:
                mat_colors[mat.name] = (rng.random(), rng.random(), rng.random())
    return mat_colors


def _set_mat_display_colors(scene, seed=42):
    """Тимчасово: Viewport Display Color кожного матеріалу = свій колір маски.
    Миттєво (сотні матеріалів замість мільйонів loops) і не чіпає меші. Повертає backup."""
    backup = {}
    for name, (r, g, b) in _mat_colors(scene, seed).items():
        mat = bpy.data.materials.get(name)
        if mat:
            backup[name] = list(mat.diffuse_color)
            mat.diffuse_color = (r, g, b, 1.0)
    return backup


def _restore_mat_display_colors(backup):
    for name, color in backup.items():
        mat = bpy.data.materials.get(name)
        if mat:
            mat.diffuse_color = color


def _set_obj_colors(scene):
    """Тимчасово: obj.color = колір маски (Workbench color_type OBJECT). Повертає backup."""
    backup = {}
    for obj in scene.objects:
        if obj.type == 'MESH':
            backup[obj.name] = list(obj.color)
            obj.color = obj.wc_color
    return backup


def _restore_obj_colors(backup):
    for name, color in backup.items():
        obj = bpy.data.objects.get(name)
        if obj:
            obj.color = color


def _restore_loop_colors(loop_backup):
    """Відновити кольори loops з backup in-place (без видалення/відтворення attr)."""
    for obj_name, (colors, orig_active) in loop_backup.items():
        obj = bpy.data.objects.get(obj_name)
        if not obj or obj.type != 'MESH':
            continue
        mesh = obj.data
        if colors is None:
            if ATTR_NAME in mesh.color_attributes:
                mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
            if PAINTED_ATTR in mesh.attributes:
                mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        else:
            if ATTR_NAME in mesh.color_attributes:
                attr = mesh.color_attributes[ATTR_NAME]
                for li, color in enumerate(colors):
                    if li < len(attr.data):
                        attr.data[li].color = color
                mesh.update()
        if orig_active and orig_active in mesh.color_attributes:
            mesh.color_attributes.active_color = mesh.color_attributes[orig_active]


def _all_viewport_spaces(context):
    """Всі 3D viewport spaces на поточному екрані."""
    spaces = []
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                spaces.append(area.spaces.active)
    return spaces


def _safe_relpath(path):
    """bpy.path.relpath падає ValueError коли вивід і .blend на різних дисках."""
    try:
        return bpy.path.relpath(path)
    except ValueError:
        return path


def _versioned_path(path, animation=False):
    """Якщо файл існує — додає _V01, _V02, ... до імені."""
    if animation:
        abs_p = bpy.path.abspath(path)
        d     = os.path.dirname(abs_p)
        name  = os.path.basename(abs_p)
        if not os.path.isdir(d):
            return path
        existing = [f for f in os.listdir(d) if f.startswith(name)]
        if not existing:
            return path
        for i in range(1, 100):
            new_name = f"{name}_V{i:02d}"
            if not any(f.startswith(new_name) for f in os.listdir(d)):
                return _safe_relpath(os.path.join(d, new_name))
    else:
        if not os.path.exists(path):
            return path
        base, ext = os.path.splitext(path)
        for i in range(1, 100):
            candidate = f"{base}_V{i:02d}{ext}"
            if not os.path.exists(candidate):
                return candidate
    return path


def _color_to_hex(r, g, b):
    return "#{:02x}{:02x}{:02x}".format(
        min(255, int(r * 255)),
        min(255, int(g * 255)),
        min(255, int(b * 255)),
    )


def _distinct_colors(n, seed):
    """n кольорів, що максимально відрізняються (золотий кут по відтінку)."""
    rng = random.Random(seed)
    h = rng.random()
    out = []
    for i in range(n):
        h = (h + 0.618033988749895) % 1.0
        s = (1.0, 0.65)[(i // 2) % 2]
        v = (1.0, 0.75)[i % 2]
        out.append(colorsys.hsv_to_rgb(h, s, v))
    return out


# ─────────────────────────────────────────────────────────────────────────────
#  РЕНДЕР МАСОК — без кнопок у панелі, викликається з Custom Frame Render
# ─────────────────────────────────────────────────────────────────────────────

def _clean_output(scene):
    """Mask renders must be flat colours: no compositor (grain/sharpen), no dither noise and NO view transform
    (AgX/Filmic змінюють кольори: червоний 1,0,0 виходив 240,56,48 -> в Photoshop не виділити за кольором).
    Standard + без look/експозиції/гами: колір маски в PNG = колір у палітрі (sRGB)."""
    vs = scene.view_settings
    saved = (scene.render.use_compositing, scene.render.dither_intensity,
             vs.view_transform, vs.look, vs.exposure, vs.gamma, vs.use_curve_mapping,
             scene.display_settings.display_device)
    scene.render.use_compositing  = False
    scene.render.dither_intensity = 0.0
    try:
        scene.display_settings.display_device = 'sRGB'
        vs.view_transform = 'Standard'
        vs.look = 'None'
    except TypeError:
        pass
    vs.exposure, vs.gamma, vs.use_curve_mapping = 0.0, 1.0, False
    return saved


def _restore_output(scene, saved):
    vs = scene.view_settings
    (scene.render.use_compositing, scene.render.dither_intensity, vt, look, vs.exposure, vs.gamma,
     vs.use_curve_mapping, dev) = saved
    try:
        scene.display_settings.display_device = dev
        vs.view_transform = vt
        vs.look = look
    except TypeError:
        pass


def props_active_face(scene):
    p = getattr(scene, "wc_props", None)
    return bool(p and p.preview_active and p.preview_mode == 'FACE')


def _render_workbench(scene, suffix, fill_all=False, animation=False):
    global _rendering

    orig_filepath = scene.render.filepath

    if animation:
        out_filepath = _versioned_path(orig_filepath + suffix, animation=True)
        out_display  = out_filepath
    else:
        orig_path = bpy.path.abspath(orig_filepath)
        base, ext = os.path.splitext(orig_path)
        ext       = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
        out_path  = _versioned_path(base + suffix + ext, animation=False)
        out_filepath = _safe_relpath(out_path)
        out_display  = out_path

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    if fill_all:
        obj_backup = _set_obj_colors(scene)          # Object-маска: колір об'єкта, меші не чіпаємо
    else:
        auto_names = _ensure_color_attributes(scene)
        mod_names  = _objcolor_mods_add(scene)
        _face_mods(True)

    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'OBJECT' if fill_all else 'VERTEX'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = out_filepath
    out_saved = _clean_output(scene)

    _rendering = True
    try:
        bpy.ops.render.render(animation=animation, write_still=not animation)
    finally:
        _rendering = False
        _restore_output(scene, out_saved)
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        if fill_all:
            _restore_obj_colors(obj_backup)
        else:
            _objcolor_mods_remove(mod_names)
            if not (props_active_face(scene)):
                _face_mods(False)
            _cleanup_by_names(auto_names)

    return out_display


def _render_workbench_mat(scene, suffix, seed=42):
    global _rendering

    orig_filepath = scene.render.filepath
    base, ext     = os.path.splitext(bpy.path.abspath(orig_filepath))
    ext           = ext if ext.lower() in ('.png', '.jpg', '.exr', '.tif') else '.png'
    out_path      = _versioned_path(base + suffix + ext, animation=False)

    orig_engine     = scene.render.engine
    orig_color_type = scene.display.shading.color_type
    orig_light      = scene.display.shading.light

    mat_backup = _set_mat_display_colors(scene, seed=seed)
    scene.render.engine              = 'BLENDER_WORKBENCH'
    scene.display.shading.color_type = 'MATERIAL'
    scene.display.shading.light      = 'FLAT'
    scene.render.filepath            = _safe_relpath(out_path)
    out_saved = _clean_output(scene)

    _rendering = True
    try:
        bpy.ops.render.render(animation=False, write_still=True)
    finally:
        _rendering = False
        _restore_output(scene, out_saved)
        scene.render.engine              = orig_engine
        scene.display.shading.color_type = orig_color_type
        scene.display.shading.light      = orig_light
        scene.render.filepath            = orig_filepath
        _restore_mat_display_colors(mat_backup)

    return out_path


class WIRECOLOR_OT_render_obj_mask(Operator):
    bl_idname      = "wirecolor.render_obj_mask"
    bl_label       = "Object Mask"
    bl_description = "Рендер маски: кожен об'єкт — свій колір (_mask_obj). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_obj", fill_all=True)
        self.report({'INFO'}, f"Object Mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_face_mask(Operator):
    bl_idname      = "wirecolor.render_face_mask"
    bl_label       = "Face Mask"
    bl_description = "Рендер маски: колір об'єкта + розфарбовані полігони (_mask_face). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        path = _render_workbench(context.scene, "_mask_face", fill_all=False)
        self.report({'INFO'}, f"Face Mask → {path}")
        return {'FINISHED'}


class WIRECOLOR_OT_render_mat_mask(Operator):
    bl_idname      = "wirecolor.render_mat_mask"
    bl_label       = "Material Mask"
    bl_description = "Рендер маски: кожен матеріал — свій колір (_mask_mat). Використовує Custom Frame Render"
    bl_options     = {'REGISTER', 'INTERNAL'}

    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        path = _render_workbench_mat(context.scene, "_mask_mat", self.seed)
        self.report({'INFO'}, f"Material Mask → {os.path.basename(path)}")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ПЕРЕГЛЯД МАСКИ У ВЬЮПОРТІ
# ─────────────────────────────────────────────────────────────────────────────

def _preview_cleanup(props, scene):
    """Відновити стан після будь-якого режиму перегляду."""
    if props.preview_mode == 'OBJECT' and props.preview_obj_backup:
        try:
            for obj_name, color in json.loads(props.preview_obj_backup).items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.color = color
        except Exception as e:
            print(f"WireColor: Object preview restore error: {e}")
        props.preview_obj_backup = ""

    elif props.preview_mode == 'MATERIAL' and props.preview_mat_backup:
        try:
            backup_serial = json.loads(props.preview_mat_backup)
            if backup_serial.get("__kind") == "diffuse":
                _restore_mat_display_colors(backup_serial["colors"])
            else:   # перегляд, збережений старою версією (≤3.5.4) — відновлюємо loops
                loop_backup = {k: ([tuple(c) for c in v[0]] if v[0] is not None else None, v[1])
                               for k, v in backup_serial.items()}
                _restore_loop_colors(loop_backup)
        except Exception as e:
            print(f"WireColor: Material preview restore error: {e}")
        props.preview_mat_backup = ""

    elif props.preview_mode == 'FACE':
        _objcolor_mods_remove()
        _face_mods(False)
        _cleanup_by_names(json.loads(props.preview_auto_names))

    props.preview_auto_names = "[]"


def _preview_start(context, mode, seed=42):
    scene = context.scene
    props = scene.wc_props
    all_spaces = _all_viewport_spaces(context)

    if not props.preview_active:
        props.preview_saved_all = json.dumps([{'type': s.shading.type,
                                               'color': s.shading.color_type,
                                               'light': s.shading.light} for s in all_spaces])

    with _ObjectModeScope(context):
        _preview_cleanup(props, scene)
        props.preview_mode = mode
        props.preview_obj_backup = ""
        props.preview_mat_backup = ""

        if mode == 'OBJECT':
            # Суцільний колір per-object через color_type='OBJECT'
            obj_bak = {}
            for obj in scene.objects:
                if obj.type == 'MESH':
                    obj_bak[obj.name] = list(obj.color)
                    obj.color = obj.wc_color
            props.preview_obj_backup = json.dumps(obj_bak)
            color_type = 'OBJECT'
        elif mode == 'FACE':
            props.preview_auto_names = json.dumps(_ensure_color_attributes(scene))
            _objcolor_mods_add(scene)
            _face_mods(True)
            color_type = 'VERTEX'
        else:  # MATERIAL
            props.preview_mat_backup = json.dumps(
                {"__kind": "diffuse", "colors": _set_mat_display_colors(scene, seed=seed)})
            color_type = 'MATERIAL'

    for s in all_spaces:
        s.shading.type       = 'SOLID'
        s.shading.color_type = color_type
        s.shading.light      = 'FLAT'
    props.preview_active = True


def _preview_stop(context):
    props = context.scene.wc_props
    all_spaces = _all_viewport_spaces(context)
    saved = json.loads(props.preview_saved_all or "[]")
    for i, s in enumerate(all_spaces):
        st = saved[i] if i < len(saved) else {'type': 'SOLID', 'color': 'MATERIAL', 'light': 'STUDIO'}
        s.shading.type       = st['type']
        s.shading.color_type = st['color']
        s.shading.light      = st['light']
    with _ObjectModeScope(context):
        _preview_cleanup(props, context.scene)
    props.preview_mat_backup = ""
    props.preview_obj_backup = ""
    props.preview_saved_all  = "[]"
    props.preview_active     = False
    props.preview_mode       = ''


def _show_result(context, faces):
    """Після фарбування показати результат: вмикаємо відповідний перегляд."""
    props = context.scene.wc_props
    if not props.auto_preview:
        return
    if faces:
        if not props.preview_active or props.preview_mode != 'FACE':
            _preview_start(context, 'FACE')
    elif not props.preview_active or props.preview_mode == 'MATERIAL':
        _preview_start(context, 'OBJECT')


class WIRECOLOR_OT_preview_set(Operator):
    bl_idname  = "wirecolor.preview_set"
    bl_label   = "Перегляд маски"
    bl_options = {'REGISTER'}

    @classmethod
    def description(cls, context, properties):
        return {
            'OBJECT':   "Показати у вьюпорті кольори об'єктів (як маска _mask_obj). "
                        "Повторний клік — вимкнути перегляд",
            'FACE':     "Показати кольори об'єктів разом із розфарбованими полігонами (як маска _mask_face). "
                        "Повторний клік — вимкнути перегляд",
            'MATERIAL': "Показати кожен матеріал своїм кольором (як маска _mask_mat). "
                        "Повторний клік — вимкнути перегляд",
        }.get(properties.mode, "Показати маску у вьюпорті без рендеру")

    mode: EnumProperty(
        items=[
            ('OBJECT',   "Object",    "Кожен об'єкт — свій колір"),
            ('FACE',     "Face",      "Колір об'єкта + розфарбовані полігони"),
            ('MATERIAL', "Material",  "Кожен матеріал — свій колір"),
        ],
        default='OBJECT',
    )
    seed: IntProperty(name="Seed", default=42, min=0)

    def execute(self, context):
        if not _all_viewport_spaces(context):
            self.report({'ERROR'}, "Не знайдено 3D-вьюпорт")
            return {'CANCELLED'}
        props = context.scene.wc_props
        if props.preview_active and props.preview_mode == self.mode:
            _preview_stop(context)
        else:
            _preview_start(context, self.mode, self.seed)
        return {'FINISHED'}


class WIRECOLOR_OT_preview_exit(Operator):
    bl_idname      = "wirecolor.preview_exit"
    bl_label       = "Вимкнути перегляд"
    bl_description = "Повернути звичайний вигляд вьюпорту"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        _preview_stop(context)
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ФАРБУВАННЯ
# ─────────────────────────────────────────────────────────────────────────────

def _paint_objects(context, color):
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    for obj in objs:
        obj.wc_color = (color[0], color[1], color[2], 1.0)   # callback оновить маску
    return len(objs)


def _paint_faces(context, color):
    props = context.scene.wc_props
    r, g, b = color[0], color[1], color[2]
    total = 0
    with _ObjectModeScope(context) as scope:
        objs = scope.objects

        for obj in objs:
            mesh = obj.data
            if ATTR_NAME not in mesh.color_attributes:
                _make_color_attr(mesh, obj.wc_color)
            # фарбування має пережити вимкнення перегляду
            auto = json.loads(props.preview_auto_names or "[]")
            if obj.name in auto:
                auto.remove(obj.name)
                props.preview_auto_names = json.dumps(auto)
            color_attr   = mesh.color_attributes[ATTR_NAME]
            painted_attr = mesh.attributes.get(PAINTED_ATTR) or \
                mesh.attributes.new(name=PAINTED_ATTR, type='INT', domain='FACE')
            mesh.color_attributes.active_color = color_attr
            for poly in mesh.polygons:
                if poly.select:
                    for li in poly.loop_indices:
                        color_attr.data[li].color = (r, g, b, 1.0)
                    painted_attr.data[poly.index].value = 1
                    total += 1
            mesh.update()
    if props.preview_active and props.preview_mode == 'FACE':
        _objcolor_mods_add(context.scene)
    return total


def _apply_color(op, context, color):
    """Колір → виділеним полігонам (Edit Mode) або виділеним об'єктам (Object Mode)."""
    if context.mode == 'EDIT_MESH':
        n = _paint_faces(context, color)
        if not n:
            op.report({'WARNING'}, "Виділи полігони")
            return {'CANCELLED'}
        _show_result(context, faces=True)
        op.report({'INFO'}, f"{n} полігонів → {_color_to_hex(*color[:3])}")
    else:
        n = _paint_objects(context, color)
        if not n:
            op.report({'WARNING'}, "Виділи об'єкти")
            return {'CANCELLED'}
        _show_result(context, faces=False)
        op.report({'INFO'}, f"{n} об'єкт(ів) → {_color_to_hex(*color[:3])}")
    _tag_redraw_viewports()
    return {'FINISHED'}


class WIRECOLOR_OT_palette_click(Operator):
    bl_idname  = "wirecolor.palette_click"
    bl_label   = ""
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    index: IntProperty(default=0)

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Пофарбувати виділені полігони цим кольором"
        return "Пофарбувати виділені об'єкти цим кольором"

    def execute(self, context):
        props = context.scene.wc_props
        if self.index >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_index = self.index
        c = props.palette_colors[self.index].color
        props.face_color = (c[0], c[1], c[2])
        return _apply_color(self, context, props.face_color)


class WIRECOLOR_OT_apply_color(Operator):
    bl_idname  = "wirecolor.apply_color"
    bl_label   = "Пофарбувати"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Пофарбувати виділені полігони поточним кольором"
        return "Пофарбувати виділені об'єкти поточним кольором"

    def execute(self, context):
        return _apply_color(self, context, context.scene.wc_props.face_color)


class WIRECOLOR_OT_paint_faces(Operator):
    """Сумісність зі старими версіями / гарячими клавішами."""
    bl_idname      = "wirecolor.paint_faces"
    bl_label       = "Пофарбувати полігони"
    bl_description = "Пофарбувати виділені полігони поточним кольором"
    bl_options     = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        n = _paint_faces(context, context.scene.wc_props.face_color)
        if not n:
            self.report({'WARNING'}, "Виділи полігони")
            return {'CANCELLED'}
        return {'FINISHED'}


class WIRECOLOR_OT_pick_color(Operator):
    bl_idname  = "wirecolor.pick_color"
    bl_label   = "Взяти колір"
    bl_options = {'REGISTER'}

    @classmethod
    def description(cls, context, properties):
        if context.mode == 'EDIT_MESH':
            return "Піпетка: взяти колір першого виділеного полігона"
        return "Піпетка: взяти колір маски активного об'єкта"

    def execute(self, context):
        obj = context.active_object
        props = context.scene.wc_props
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Виділи об'єкт")
            return {'CANCELLED'}
        if context.mode != 'EDIT_MESH':
            props.face_color = obj.wc_color[:3]
            return {'FINISHED'}
        with _ObjectModeScope(context):
            attr = obj.data.color_attributes.get(ATTR_NAME)
            poly = next((p for p in obj.data.polygons if p.select), None)
            if poly is None:
                self.report({'WARNING'}, "Виділи полігон")
                return {'CANCELLED'}
            c = attr.data[poly.loop_indices[0]].color if attr else obj.wc_color
            props.face_color = (c[0], c[1], c[2])
        return {'FINISHED'}


def _assign_targets(context):
    """Що пофарбує «Призначити кольори»: виділені меші, а якщо нічого не виділено — УСІ меші сцени
    (і ті, що видно лише в інших кадрах: конфігурації, перемикання по кадрах)."""
    sel = [o for o in context.selected_objects if o.type == 'MESH']
    if sel:
        return sel, 'selected'
    return [o for o in context.scene.objects if o.type == 'MESH'], 'all'


def _covisible_colors(scene, objs, seed):
    """Кольори так, щоб об'єкти, які видно РАЗОМ хоч в одному кадрі, були різні. Об'єкти з різних кадрів
    можуть повторювати колір — палітра лишається контрастною (розмір = макс. кількість видимих разом)."""
    cur = scene.frame_current
    frames = list(range(scene.frame_start, scene.frame_end + 1))
    step = max(1, len(frames) // 300)                       # довгі анімації — вибірка кадрів
    groups = []
    seen = set()
    for f in frames[::step]:
        scene.frame_set(f)
        g = frozenset(o.name for o in objs if o.visible_get())
        if g and g not in seen:
            seen.add(g); groups.append(g)
    scene.frame_set(cur)
    nb = {o.name: set() for o in objs}
    for g in groups:
        for n in g:
            nb[n] |= g
    k = max([len(g) for g in groups] + [1])
    pal = list(_distinct_colors(k, seed))
    idx = {}
    order = [n for g in sorted(groups, key=len, reverse=True) for n in sorted(g)] + sorted(o.name for o in objs)
    for n in order:
        if n in idx:
            continue
        used = {idx[m] for m in nb[n] if m in idx}
        c = 0
        while c in used:
            c += 1
        if c >= len(pal):
            pal = list(_distinct_colors(c + 1, seed))
        idx[n] = c
    return {n: pal[i] for n, i in idx.items()}


def _assign_targets_label(context):
    objs, how = _assign_targets(context)
    if how == 'all':
        return f"Буде: усі об'єкти сцени ({len(objs)}), разом видимі — різні"
    if len(objs) == 1:
        o = objs[0]
        return f"Буде: тільки {o.name}" + (" (фон!)" if o.is_shadow_catcher else "")
    return f"Буде: {len(objs)} виділених"


class WIRECOLOR_OT_assign_object_colors(Operator):
    bl_idname      = "wirecolor.assign_object_colors"
    bl_label       = "Призначити кольори"
    bl_options     = {'REGISTER', 'UNDO'}

    reroll: BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        if properties.reroll:
            return ("Інші кольори: кожне натискання дає новий набір. "
                    "Виділені об'єкти, або всі об'єкти сцени, якщо нічого не виділено")
        return ("Дати кожному об'єкту свій колір, що добре відрізняється від сусідніх. "
                "Виділені об'єкти, або ВСІ об'єкти сцени (і з інших кадрів), якщо нічого не виділено. "
                "Клік по колекції в Outliner об'єкти НЕ виділяє — виділяй самі об'єкти (ПКМ по колекції → Select Objects)")

    def execute(self, context):
        props = context.scene.wc_props
        if self.reroll:
            props.color_seed = (props.color_seed + 1) % 100000
        objs, how = _assign_targets(context)
        with _ObjectModeScope(context):
            if how == 'all':
                cols = _covisible_colors(context.scene, objs, props.color_seed)
                pairs = [(o, cols[o.name]) for o in objs]
            else:
                pairs = list(zip(objs, _distinct_colors(len(objs), props.color_seed)))
            for obj, c in pairs:
                obj.wc_color = (c[0], c[1], c[2], 1.0)
        _show_result(context, faces=False)
        self.report({'INFO'}, f"{len(objs)} об'єктів отримали різні кольори")
        return {'FINISHED'}


class WIRECOLOR_OT_select_by_angle(Operator):
    bl_idname      = "wirecolor.select_by_angle"
    bl_label       = "Розширити виділення"
    bl_description = ("Від виділених полігонів розширити виділення на сусідні, "
                      "поки кут між ними не більший за заданий (зручно виділяти цілу площину чи деталь)")
    bl_options     = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.mode == 'EDIT_MESH' or bool(obj and obj.type == 'MESH')

    def execute(self, context):
        if context.mode == 'EDIT_MESH':
            objects_to_process = [o for o in context.objects_in_mode_unique_data if o.type == 'MESH']
        else:   # з Object Mode: виділені меші (полігони, виділені раніше в Edit Mode, зберігаються в mesh)
            objects_to_process = [o for o in context.selected_objects if o.type == 'MESH']
        bpy.ops.object.mode_set(mode='OBJECT')

        threshold   = math.radians(context.scene.wc_props.select_angle)
        total_faces = 0
        objs_hit    = 0
        for obj in objects_to_process:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            seeds = [f for f in bm.faces if f.select]
            if not seeds:
                bm.free()
                continue
            objs_hit += 1
            visited = set(seeds)
            queue   = list(seeds)
            while queue:
                face = queue.pop()
                face.select = True
                for edge in face.edges:
                    for nb in edge.link_faces:
                        if nb in visited:
                            continue
                        visited.add(nb)
                        try:
                            angle = face.normal.angle(nb.normal)
                        except ValueError:
                            angle = 0.0
                        if angle <= threshold:
                            queue.append(nb)
            total_faces += sum(1 for f in visited if f.select)
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        if objs_hit == 0:
            self.report({'WARNING'}, "Спочатку виділи хоча б один полігон")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Виділено {total_faces} полігонів (≤ {context.scene.wc_props.select_angle:.0f}°)")
        return {'FINISHED'}


class WIRECOLOR_OT_reset_faces(Operator):
    bl_idname      = "wirecolor.reset_faces"
    bl_label       = "Скинути полігони"
    bl_description = ("Прибрати ручне фарбування полігонів: весь об'єкт знову одного кольору. "
                      "Діє на виділені об'єкти")
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with _ObjectModeScope(context) as scope:
            objs = scope.objects

            n = 0
            for obj in objs:
                if ATTR_NAME in obj.data.color_attributes:
                    _make_color_attr(obj.data, obj.wc_color)
                    obj.data.update()
                    n += 1
        self.report({'INFO'}, f"Скинуто: {n} об'єкт(ів)")
        _tag_redraw_viewports()
        return {'FINISHED'}


class WIRECOLOR_OT_clear_attr(Operator):
    bl_idname      = "wirecolor.clear_attr"
    bl_label       = "Видалити маску з об'єктів"
    bl_description = ("Повністю прибрати дані маски (атрибут кольору) з виділених об'єктів. "
                      "Колір об'єкта лишається")
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with _ObjectModeScope(context) as scope:
            objs = scope.objects

            n = 0
            for obj in objs:
                mesh = obj.data
                if ATTR_NAME in mesh.color_attributes:
                    mesh.color_attributes.remove(mesh.color_attributes[ATTR_NAME])
                    n += 1
                if PAINTED_ATTR in mesh.attributes:
                    mesh.attributes.remove(mesh.attributes[PAINTED_ATTR])
        self.report({'INFO'}, f"Маску видалено: {n} об'єкт(ів)")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  ПАЛІТРА
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_OT_palette_add(Operator):
    bl_idname      = "wirecolor.palette_add"
    bl_label       = "Додати в палітру"
    bl_description = "Додати поточний колір у палітру"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        props.palette_colors.add().color = props.face_color
        props.palette_index = len(props.palette_colors) - 1
        return {'FINISHED'}


class WIRECOLOR_OT_palette_remove(Operator):
    bl_idname      = "wirecolor.palette_remove"
    bl_label       = "Прибрати з палітри"
    bl_description = "Прибрати з палітри вибраний колір (обведений)"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        idx   = props.palette_index
        if not props.palette_colors or idx >= len(props.palette_colors):
            return {'CANCELLED'}
        props.palette_colors.remove(idx)
        props.palette_index = max(0, idx - 1)
        return {'FINISHED'}


class WIRECOLOR_OT_palette_load_presets(Operator):
    bl_idname      = "wirecolor.palette_load_presets"
    bl_label       = "Стандартна палітра"
    bl_description = "Повернути стандартні 20 яскравих кольорів (власні кольори палітри зникнуть)"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.wc_props
        props.palette_colors.clear()
        for r, g, b in PRESET_COLORS:
            props.palette_colors.add().color = (r, g, b)
        props.palette_index = 0
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTIES
# ─────────────────────────────────────────────────────────────────────────────

class WireColorPaletteEntry(PropertyGroup):
    color: FloatVectorProperty(
        name="Колір", description="Колір палітри", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
    )


class WireColorProps(PropertyGroup):
    face_color: FloatVectorProperty(
        name="", subtype='COLOR',
        default=(1.0, 0.0, 0.0), min=0.0, max=1.0,
        description="Поточний колір. Кнопка «Пофарбувати» наносить його на виділене",
    )
    select_angle: FloatProperty(
        name="Кут",
        description="Наскільки сильно можуть бути повернуті сусідні полігони, щоб потрапити у виділення (градуси)",
        default=15.0, min=0.0, max=180.0, precision=0,
    )
    auto_preview: BoolProperty(
        name="Одразу показувати",
        description="Після фарбування автоматично вмикати перегляд маски у вьюпорті",
        default=True,
    )
    color_seed: IntProperty(default=42, min=0)   # набір для «Призначити кольори», ↻ змінює
    palette_colors: CollectionProperty(type=WireColorPaletteEntry)
    palette_index:  IntProperty(default=0, min=0)
    preview_active:        BoolProperty(default=False)
    preview_mode:          StringProperty(default='')
    preview_auto_names:    StringProperty(default='[]')
    preview_saved_all:     StringProperty(default='[]')   # JSON [{type,color,light}, ...]
    preview_mat_backup:    StringProperty(default='')     # JSON backup для перегляду матеріалів
    preview_obj_backup:    StringProperty(default='')     # JSON backup obj.color для перегляду об'єктів


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

class WIRECOLOR_PT_panel(Panel):
    bl_label       = "WireColor Masks"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "WireColor"

    def draw_header_preset(self, context):
        self.layout.label(text="v" + ".".join(str(v) for v in ADDON_VERSION))

    def draw(self, context):
        layout  = self.layout
        props   = context.scene.wc_props
        obj     = context.active_object
        is_mesh = bool(obj and obj.type == 'MESH')
        edit    = (context.mode == 'EDIT_MESH')

        # ── ПЕРЕГЛЯД ─────────────────────────────────────────
        col = layout.column(align=True)
        col.label(text="Перегляд маски", icon='HIDE_OFF')
        row = col.row(align=True)
        row.scale_y = 1.2
        for mode, text, icon in (('OBJECT', "Object", 'OBJECT_DATA'),
                                 ('FACE', "Face", 'FACESEL'),
                                 ('MATERIAL', "Material",  'MATERIAL')):
            on = props.preview_active and props.preview_mode == mode
            row.operator("wirecolor.preview_set", text=text, icon=icon, depress=on).mode = mode
        if props.preview_active:
            r = col.row(align=True)
            r.alert = True
            r.operator("wirecolor.preview_exit", icon='X')

        layout.separator(factor=0.5)

        # ── КОЛІР / ПАЛІТРА ──────────────────────────────────
        box = layout.box()
        target = "виділені полігони" if edit else "виділені об'єкти"
        box.label(text=f"Клік по кольору → {target}", icon='BRUSH_DATA')
        grid = box.grid_flow(row_major=True, columns=5, even_columns=True, even_rows=True, align=True)
        for i, entry in enumerate(props.palette_colors):
            cell = grid.column(align=True)
            cell.scale_y = 1.4
            cell.operator("wirecolor.palette_click", text="", icon_value=_color_icon(entry.color),
                          depress=(i == props.palette_index)).index = i

        row = box.row(align=True)
        row.prop(props, "face_color")
        row.operator("wirecolor.pick_color", text="", icon='EYEDROPPER')
        row.operator("wirecolor.palette_add", text="", icon='ADD')
        row.operator("wirecolor.palette_remove", text="", icon='REMOVE')
        row.operator("wirecolor.palette_load_presets", text="", icon='FILE_REFRESH')
        row = box.row()
        row.scale_y = 1.3
        row.operator("wirecolor.apply_color", icon='BRUSH_DATA')
        box.prop(props, "auto_preview")

        # ── ОБ'ЄКТИ ──────────────────────────────────────────
        if not edit:
            box = layout.box()
            box.label(text="Об'єкти", icon='OBJECT_DATA')
            if is_mesh:
                box.prop(obj, "wc_color", text="Колір активного")
            row = box.row(align=True)
            row.scale_y = 1.2
            row.operator("wirecolor.assign_object_colors", icon='COLOR')
            row.operator("wirecolor.assign_object_colors", text="", icon='FILE_REFRESH').reroll = True
            box.label(text=_assign_targets_label(context), icon='RIGHTARROW_THIN')
            if is_mesh:
                box.label(text="Tab → Edit Mode, щоб фарбувати полігони", icon='INFO')

        # ── ВИДІЛЕННЯ ПО КУТУ (завжди видно) ─────────────────
        box = layout.box()
        box.label(text="Виділення по куту", icon='FACESEL')
        row = box.row(align=True)
        row.prop(props, "select_angle")
        row.operator("wirecolor.select_by_angle", icon='SELECT_EXTEND')

        # ── ОЧИСТКА ──────────────────────────────────────────
        header, body = layout.panel("wirecolor_cleanup", default_closed=True)
        header.label(text="Очистка", icon='TRASH')
        if body:
            col = body.column(align=True)
            col.operator("wirecolor.reset_faces", icon='LOOP_BACK')
            col.operator("wirecolor.clear_attr", icon='TRASH')


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    WireColorPaletteEntry,
    WireColorProps,
    WIRECOLOR_OT_render_obj_mask,
    WIRECOLOR_OT_render_face_mask,
    WIRECOLOR_OT_render_mat_mask,
    WIRECOLOR_OT_preview_set,
    WIRECOLOR_OT_preview_exit,
    WIRECOLOR_OT_palette_click,
    WIRECOLOR_OT_apply_color,
    WIRECOLOR_OT_paint_faces,
    WIRECOLOR_OT_pick_color,
    WIRECOLOR_OT_assign_object_colors,
    WIRECOLOR_OT_select_by_angle,
    WIRECOLOR_OT_reset_faces,
    WIRECOLOR_OT_clear_attr,
    WIRECOLOR_OT_palette_add,
    WIRECOLOR_OT_palette_remove,
    WIRECOLOR_OT_palette_load_presets,
    WIRECOLOR_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.wc_props = PointerProperty(type=WireColorProps)
    bpy.types.Object.wc_color = FloatVectorProperty(
        name="Колір маски",
        description="Колір цього об'єкта в масці (на матеріали не впливає)",
        subtype='COLOR', size=4,
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        update=_wc_color_update,
    )
    # Пресети: і напряму, і через таймер (запасний — на випадок якщо сцена ще не готова)
    _init_palette_presets()
    bpy.app.timers.register(_init_palette_presets, first_interval=1.0)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)


def unregister():
    _clear_preview_icons()
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Object.wc_color
    del bpy.types.Scene.wc_props


if __name__ == "__main__":
    register()
